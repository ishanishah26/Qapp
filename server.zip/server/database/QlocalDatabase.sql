-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jul 12, 2016 at 04:32 PM
-- Server version: 5.6.28-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `finalQapp`
--
CREATE DATABASE IF NOT EXISTS `finalQapp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `finalQapp`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `cancel_Request`$$
CREATE DEFINER=`test`@`%` PROCEDURE `cancel_Request`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE t1 INT;
	DECLARE t2 INT;
	IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 2) THEN
		SELECT TIMESTAMPDIFF(MINUTE, (SELECT acceptDate from qRequestAccept where qRequestId = r_requestId), NOW() ) into t1;
		IF(t1 < 3) THEN
			select 'time < 180' as msg;
		ELSE
			select 'cant cancel' as msg;
		END IF;
	ELSE 
    IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 3) THEN
    select 'Cannot cancel the request. It is already completed.' as msg;
    ELSE
			select 'canceled' as msg;
			update qRequest set requestStatus = "4", cancelDate = NOW() where qRequestId = r_requestId;
		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);
        END IF;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `changeProfile_Email`$$
CREATE DEFINER=`test`@`%` PROCEDURE `changeProfile_Email`(IN `id` BIGINT, IN `new_email` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	IF EXISTS (select userId from user where email = new_email) THEN
		select 'exists' as msg;
	ELSE 
		select 'not exists' as msg;
    	UPDATE user SET passcode = random, isEmailVerified = "0", changedEmail = new_email WHERE userId = id;
		select firstName from user where userId = id;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `change_Email`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `change_Email`(IN `id` BIGINT(20), IN `new_email` VARCHAR(100), IN `random` INT)
    NO SQL
BEGIN
	IF EXISTS (select userId from user where email = new_email) THEN
		select 'exists' as msg;
	ELSE 
    	UPDATE user SET email = new_email, passcode = random WHERE userId = id;
		select 'update' as msg;
		select firstName from user where userId = id;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `confirmCalcel_Request`$$
CREATE DEFINER=`test`@`%` PROCEDURE `confirmCalcel_Request`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 2) THEN
		
		select 'canceled' as msg;
        update qRequest set requestStatus = "4", cancelDate = NOW(), fine = "5" where qRequestId = r_requestId;
		update qRequestAccept set isConfirmedByQ = "2" where qRequestId = r_requestId;
		SELECT qRequestAccept.qId, qProvider.userId, qRequest.requestVerb, qRequest.requestNoun, user.deviceToken, user.deviceType
		FROM qRequestAccept
		INNER JOIN qProvider ON qRequestAccept.qId = qProvider.qId
		INNER JOIN qRequest ON qRequestAccept.qRequestId = qRequest.qRequestId
		INNER JOIN user ON qProvider.userId = user.userId
		WHERE qRequestAccept.qRequestId = r_requestId;
		select stripeCustomerAccount from qRequest qr join  userCard uc on qr.userId = uc.userId where  qRequestId = r_requestId;
		
		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);

	ELSE
		select 'canceled' as msg;
        select stripeCustomerAccount from qRequest qr join  userCard uc on qr.userId = uc.userId where  qRequestId = r_requestId;
        		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);


	END IF;
END$$

DROP PROCEDURE IF EXISTS `confirm_Request`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `confirm_Request`(IN `r_qRequestId` BIGINT)
    NO SQL
BEGIN
	DECLARE amt float(9,2);
    
    	IF EXISTS (select * from qRequest where qRequestId = r_qRequestId and requestStatus = "4") THEN
					select 'Request Already Cancelled. You cannot complete it.' as msg;

        
       	Else
    
	UPDATE qProvider,qRequestAccept SET qRequestAccept.isConfirmedByQ = 1, qRequestAccept.requestCompletionDateTime = NOW(), qProvider.TotalRequestCompleted = qProvider.TotalRequestCompleted + 1  WHERE qProvider.qId = qRequestAccept.qId AND qRequestId = r_qRequestId; 
	UPDATE qRequest SET requestStatus = "3" WHERE qRequestId = r_qRequestId;
    
    Select sum(billAmount) into amt from qRequestBillImages where qRequestId = r_qRequestId group by qRequestId; 
    
	SELECT qRequest.currentLat, qRequest.currentLong,qRequestAccept.receiptTotalBill, qRequestAccept.milesTransported, qRequestAccept.acceptDate, qRequestBillImages.billImage, qProvider.qId, qProvider.firstName, qProvider.lastName,
	qProvider.qStripeId, qRequest.requestVerb, qRequest.requestNoun, user.firstName as u_name, user.email, user.deviceToken, user.deviceType,amt,
	qRequest.isTransport, quser.userProfile
	FROM qRequestAccept 
	LEFT JOIN qRequestBillImages ON qRequestAccept.qRequestId = qRequestBillImages.qRequestId
	INNER JOIN qProvider ON qRequestAccept.qId = qProvider.qId
	INNER JOIN qRequest ON qRequestAccept.qRequestId = qRequest.qRequestId
	INNER JOIN user ON qRequest.userId = user.userId
	LEFT JOIN user quser ON qProvider.userId = quser.userId
	WHERE qRequestAccept.qRequestId = r_qRequestId;
	
    Update qProvider set isPerformingRequest=0 where qId = (select qId from qRequest where qRequestId =r_qRequestId);
    
	SELECT userCard.userId , userCard.cardNumber, userCard.stripeCustomerAccount FROM userCard WHERE userId IN(SELECT userId FROM qRequest WHERE qRequestId = r_qRequestId);
    
    SELECT deviceToken AS qDeviceToken, deviceType AS qDeviceType FROM `user` WHERE userId IN ( SELECT userId FROM qProvider WHERE qId IN(SELECT qId FROM qRequestAccept WHERE qRequestId = r_qRequestId));
    
    SELECT stopLat, stopLong FROM stopDetail WHERE qRequestId = r_qRequestId;

	End if;
END$$

DROP PROCEDURE IF EXISTS `create_userCard`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_userCard`(IN `r_userId` BIGINT, IN `r_cardNumber` INT, IN `r_cardToken` VARCHAR(255))
    NO SQL
BEGIN
	IF EXISTS (SELECT userId FROM userCard WHERE userId = r_userId) THEN
		UPDATE userCard SET cardNumber = r_cardNumber, cardToken = r_cardToken WHERE userId = r_userId;
        SELECT cardToken, stripeCustomerAccount, userId FROM userCard where userId = r_userId;
	ELSE 
    	INSERT INTO userCard(`userId`,`cardNumber`,`cardToken`) values(r_userId, r_cardNumber, r_cardToken);
        SELECT cardToken, stripeCustomerAccount, userId FROM userCard where userId = r_userId;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `delete_Account`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_Account`(IN `id` BIGINT(20))
    NO SQL
BEGIN
	UPDATE user SET isDeleted=-1 WHERE userId = id;
	IF EXISTS(SELECT userId FROM qProvider WHERE userId=id) THEN
		UPDATE `qProvider` SET `isDeleted`=-1 WHERE userId = id;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `insert_qProvider`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_qProvider`(IN `id` BIGINT(20), IN `curLat` FLOAT, IN `curLong` FLOAT, IN `q_fname` VARCHAR(50), IN `q_lname` VARCHAR(50), IN `q_email` VARCHAR(100), IN `q_zip` VARCHAR(50), IN `q_mobile` VARCHAR(50), IN `q_address` VARCHAR(255), IN `q_city` VARCHAR(50), IN `q_state` VARCHAR(50))
    NO SQL
BEGIN
	DECLARE qProviderId bigint;
	IF EXISTS (select qId from qProvider join user on qProvider.userId = user.userId  where user.IsDeleted=0 AND qProvider.email = q_email) THEN
		select 'exists' as msg;
	ELSE IF EXISTS(select qId from qProvider where userId = id) THEN
		select 'exists' as msg;
	ELSE
    	insert into qProvider(userId,currentLat,currentLong,firstName,lastName,email,address,city,state,zipCode,mobile,registrationStepCompleted) values(id,curLat,curLong,q_fname,q_lname,q_email,q_address,q_city,q_state,q_zip,q_mobile,1);
		select  LAST_INSERT_ID() into qProviderId;
		select 'insert' as msg, qProviderId;
	END IF;
END IF;
END$$

DROP PROCEDURE IF EXISTS `qAverageRating`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qAverageRating`(IN `p_qId` BIGINT)
    NO SQL
BEGIN
	
	IF EXISTS (select qId from qRequestAccept where qId = p_qId) THEN
		SELECT (AVG(speedRating+qualityRating)+4)/3 AS averageRating 
		FROM qRequestAccept 
		WHERE qId=p_qId AND isReviewed=1;
		SELECT u.firstName,u.lastName,qreqa.feedback,qreqa.ratingDate 
		FROM qRequestAccept AS qreqa INNER JOIN qRequest AS qreq 
		ON qreq.qRequestId=qreqa.qRequestId AND qreqa.qId=p_qId AND isReviewed=1
		INNER JOIN user AS u ON qreq.userId=u.userId
		ORDER BY qreqa.ratingDate DESC;
	ELSE
		SELECT 4 AS averageRating;
		SELECT u.firstName,u.lastName,qreqa.feedback,qreqa.ratingDate 
		FROM qRequestAccept AS qreqa INNER JOIN qRequest AS qreq 
		ON qreq.qRequestId=qreqa.qRequestId AND qreqa.qId=p_qId AND isReviewed=1
		INNER JOIN user AS u ON qreq.userId=u.userId
		ORDER BY qreqa.ratingDate DESC;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `qRequest_anyThingElse`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_anyThingElse`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT, IN `verb` VARCHAR(255), IN `noun` VARCHAR(255), IN `time` VARCHAR(255), IN `price` VARCHAR(255), IN `requiredNow` INT, IN `requiredDate` DATE, OUT `qRequsetId` BIGINT)
    NO SQL
BEGIN
	insert into qRequest(userId,currentLat,currentLong,requestVerb,requestNoun,qRequiredTime_Hr,qRequiredPayment,isRequiredNow,qRequiredDate,requestStatus) values(id,curLat,curLong,verb,noun,time,price,requiredNow,requiredDate,1);
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 3000;
    	select LAST_INSERT_ID() into qRequsetId;

END$$

DROP PROCEDURE IF EXISTS `qRequest_anyThingElse_resend`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_anyThingElse_resend`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT)
    NO SQL
BEGIN
	
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 
	having temp < 3000;
    
   update qProvider set LastRequestSent =  now() where qId in (SELECT qId FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 3000);
    
END$$

DROP PROCEDURE IF EXISTS `qRequest_HistoryById`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_HistoryById`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE reimbursementAmount float(9,2);


 Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = r_requestId group by qRequestId; 
	SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.createdDate, qRequest.numberOfStops, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, qRequest.requestStatus,
qRequestAccept.qId,  qRequestAccept.paymentDoneByRequestor AS totalPayment, "16 + 0.20/min" AS baseRate , qRequestAccept.milesTransported , (qRequestAccept.milesTransported*0.20) AS distanceFee, qRequestAccept.paymentDoneByRequestor AS subTotal, qRequestAccept.paymentReceivedByQ AS TotalPaymentToQ , (qRequestAccept.paymentDoneByRequestor-qRequestAccept.paymentReceivedByQ) AS QAdminFee, reimbursementAmount, TIMESTAMPDIFF(MINUTE, qRequestAccept.acceptDate , qRequestAccept.requestCompletionDateTime) AS timeElapsed ,
qProvider.firstName, qProvider.lastName, qProvider.email, qProvider.mobile, user.userProfile, 
stopDetail.stopDetailId,stopDetail.stopLat, stopDetail.stopLong, stopDetail.address 
FROM qRequest LEFT JOIN qRequestAccept ON qRequest.qRequestId = qRequestAccept.qRequestId 
LEFT JOIN qProvider ON qRequestAccept.qId = qProvider.qId 
LEFT JOIN user ON qProvider.userId = user.userId
LEFT JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId 
WHERE qRequest.qRequestId = r_requestId ORDER BY stopDetail.stopDetailId ASC;
SELECT userId, cardNumber FROM userCard where userId IN(SELECT userId FROM qRequest WHERE qRequest.qRequestId = r_requestId);
END$$

DROP PROCEDURE IF EXISTS `qRequest_HistoryById_ruben_test`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_HistoryById_ruben_test`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE reimbursementAmount float(9,2);


 Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = r_requestId group by qRequestId; 
	SELECT qRequest.isTransport, qRequest.currentLat, qRequest.currentLong, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.createdDate, qRequest.numberOfStops, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, qRequest.requestStatus,
qRequestAccept.qId, qRequestAccept.mapURL, qRequestAccept.paymentDoneByRequestor AS totalPayment, "16 + 0.20/min" AS baseRate , qRequestAccept.milesTransported , (qRequestAccept.milesTransported*0.20) AS distanceFee, qRequestAccept.paymentDoneByRequestor AS subTotal, qRequestAccept.paymentReceivedByQ AS TotalPaymentToQ , (qRequestAccept.paymentDoneByRequestor-qRequestAccept.paymentReceivedByQ) AS QAdminFee, reimbursementAmount, TIMESTAMPDIFF(MINUTE, qRequestAccept.acceptDate , qRequestAccept.requestCompletionDateTime) AS timeElapsed ,
qProvider.firstName, qProvider.lastName, qProvider.email, qProvider.mobile, user.userProfile, cu.firstName as cFirstName, cu.lastName as cLastName, cu.userProfile as cUserPrifile,
stopDetail.stopDetailId,stopDetail.stopLat, stopDetail.stopLong, stopDetail.address ,
qRequestAccept.receiptTotalBill,  qRequestAccept.paymentDoneByRequestor, qRequestAccept.paymentReceivedByQ, qRequestAccept.requestAmt, qRequestAccept.serviceFeeToQ, qRequestAccept.serviceFeeToUser,
qRequestAccept.MapURL
FROM qRequest LEFT JOIN qRequestAccept ON qRequest.qRequestId = qRequestAccept.qRequestId 
LEFT JOIN qProvider ON qRequestAccept.qId = qProvider.qId 
LEFT JOIN user ON qProvider.userId = user.userId
LEFT JOIN user cu ON cu.userId = qRequest.userId
LEFT JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId 
WHERE qRequest.qRequestId = r_requestId ORDER BY stopDetail.stopDetailId ASC;
SELECT userId, cardNumber FROM userCard where userId IN(SELECT userId FROM qRequest WHERE qRequest.qRequestId = r_requestId);
SELECT * FROM stopDetail WHERE stopDetail.qRequestId = r_requestId;
END$$

DROP PROCEDURE IF EXISTS `qRequest_Resend_anyThingElse`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Resend_anyThingElse`(IN `p_qRequestId` BIGINT)
    NO SQL
BEGIN
	SELECT qRequest.qRequestId, qRequest.requestVerb, qRequest.isTransport, qRequest.requestNoun, qRequest.qRequiredPayment, qRequest.qRequiredTime_Hr, qRequest.currentLat, qRequest.currentLong, qProvider.qId, 
    ( 3959 * acos( cos( radians( qRequest.currentLat ) ) * cos( radians( qProvider.currentLat ) ) * cos( radians( qProvider.currentLong ) - radians( qProvider.currentLong ) ) + sin( radians( qRequest.currentLat ) ) * sin( radians( qProvider.currentLat ) ) ) ) AS temp 
    FROM qProvider,qRequest 
    WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = 1 and qProvider.userId != qRequest.userId AND qId NOT IN (SELECT qId FROM requestSentToQ WHERE qRequestId=p_qRequestId ) and isPerformingRequest =0 AND 
    qRequest.requeststatus =1 AND isTransport=0 AND qRequest.qRequestId= p_qRequestId and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 having temp < 3000;
END$$

DROP PROCEDURE IF EXISTS `qRequest_Resend_Transport`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Resend_Transport`(IN `p_qRequestId` BIGINT)
    NO SQL
BEGIN
	SELECT qRequest.qRequestId, qRequest.requestVerb, qRequest.isTransport, qRequest.requestNoun, qRequest.qRequiredPayment, qRequest.qRequiredTime_Hr, qRequest.currentLat, qRequest.currentLong, qProvider.qId, 
    ( 3959 * acos( cos( radians( qRequest.currentLat ) ) * cos( radians( qProvider.currentLat ) ) * cos( radians( qProvider.currentLong ) - radians( qProvider.currentLong ) ) + sin( radians( qRequest.currentLat ) ) * sin( radians( qProvider.currentLat ) ) ) ) AS temp 
    FROM qProvider,qRequest 
    WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = 1 and qProvider.userId != qRequest.userId AND qId NOT IN (SELECT qId FROM requestSentToQ WHERE qRequestId = p_qRequestId ) and isPerformingRequest =0 AND 
    qRequest.requeststatus =1  AND isTransport=1 AND  qRequest.qRequestId=p_qRequestId and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 having temp < 10;
END$$

DROP PROCEDURE IF EXISTS `qRequest_Tranport`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Tranport`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT, IN `verb` VARCHAR(255), IN `noun` VARCHAR(255), IN `time` VARCHAR(255), IN `price` VARCHAR(255), IN `nStops` INT, OUT `qRequsetId` INT)
    NO SQL
BEGIN
	insert into qRequest(userId,currentLat,currentLong,isTransport,requestVerb,requestNoun,qRequiredTime_Hr,qRequiredPayment,numberOfStops,requestStatus) values(id,curLat,curLong,1,verb,noun,time,price,nStops,1);
	select  LAST_INSERT_ID() into qRequsetId;
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 10;
	select LAST_INSERT_ID() into qRequsetId;
END$$

DROP PROCEDURE IF EXISTS `qRequest_Tranport_resend`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Tranport_resend`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT)
    NO SQL
BEGIN
	

	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 
	having temp < 10;
    
    update qProvider set LastRequestSent =  now() where qId in (SELECT qId FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 10);

	END$$

DROP PROCEDURE IF EXISTS `reached_AtStop`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `reached_AtStop`(IN `q_RequestId` BIGINT, IN `Lat` FLOAT, IN `c_Long` FLOAT)
    NO SQL
BEGIN
	UPDATE stopDetail SET isQReachedAtStop = "1" WHERE qRequestId = q_RequestId and stopLat = Lat  and stopLong = c_Long ;
	SELECT address FROM stopDetail WHERE qRequestId =  q_RequestId and stopLat = Lat and stopLong = c_Long and isQReachedAtStop = "1";
	SELECT user.userId, user.mobile FROM user INNER JOIN  qRequest 
	ON qRequest.userId = user.userId WHERE qRequestId =  q_RequestId;
END$$

DROP PROCEDURE IF EXISTS `request_Accept`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `request_Accept`(IN `requestId` BIGINT, IN `qId` BIGINT)
    NO SQL
BEGIN
	IF EXISTS (select * from qRequest where qRequestId = requestId and requestStatus = "2") THEN
		select 'already accepted' as msg;	
	ELSE IF EXISTS (select * from qRequest where qRequestId = requestId and requestStatus = "4") THEN
		select 'request canceled' as msg;	
	ELSE
		Update qRequest set requestStatus = "2" where qRequestId = requestId;
		Update qProvider set isPerformingRequest =1 where qProvider.qId = qId;
		insert into qRequestAccept (qId,qRequestId)	values(qId,requestId);	
		select 'accept now' as msg;
		select qRequest.requestVerb, qRequest.requestNoun, qRequest.isTransport, user.userId, user.deviceToken, user.deviceType from qRequest 
		INNER JOIN user
		ON qRequest.userId = user.userId
		where qRequestId = requestId;
		#select firstName from qProvider where qId = qId;
	END IF;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `resendOtp_email`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `resendOtp_email`(IN `id` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	DECLARE mail varchar(255);
		UPDATE user SET passcode = random WHERE userId = id;
		select email as mail,firstName from user where userId = id;
END$$

DROP PROCEDURE IF EXISTS `resendOtp_mobile`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `resendOtp_mobile`(IN `id` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	DECLARE num varchar(255);
		UPDATE qProvider SET mobileVerificationCode = random WHERE userId = id;
		select mobile as num from qProvider where userId = id;
END$$

DROP PROCEDURE IF EXISTS `reverse_Confirm_Request`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `reverse_Confirm_Request`(IN `r_qRequestId` BIGINT)
    NO SQL
BEGIN

	UPDATE qProvider,qRequestAccept 
	SET qRequestAccept.isConfirmedByQ = 0, 
	qRequestAccept.requestCompletionDateTime = 0000-00-00, 
	qProvider.TotalRequestCompleted = (qProvider.TotalRequestCompleted - 1)  
	WHERE qProvider.qId = qRequestAccept.qId AND qRequestId = r_qRequestId; 
	
	UPDATE qRequest 
	SET requestStatus = "2" 
	WHERE qRequestId = r_qRequestId;
    
	-- UPDATE qProvider 
	-- SET isPerformingRequest=1 
	-- WHERE qId = (SELECT qId FROM qRequest WHERE qRequestId =r_qRequestId);

END$$

DROP PROCEDURE IF EXISTS `show_Request`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `show_Request`(IN `requestId` BIGINT)
    NO SQL
BEGIN
DECLARE reimbursementAmount float(9,2);
	IF EXISTS (select * from qRequest where qRequestId = requestId and isTransport = "1") THEN
		SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.currentLat, qRequest.currentLong, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.numberOfStops, qRequest.createdDate, user.userId, user.firstName, user.lastName, user.email, user.mobile, user.userProfile, stopDetail.stopDetailId, stopDetail.stopLat, stopDetail.stopLong, stopDetail.address
		FROM qRequest
		INNER JOIN user ON qRequest.userId = user.userId
		INNER JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId
		WHERE qRequest.qRequestId = requestId 
		ORDER BY stopDetail.stopDetailId ASC;	
	ELSE 
		SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.currentLat, qRequest.currentLong, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, user.userId, user.firstName, user.lastName, user.email, user.mobile, user.userProfile
		FROM qRequest
		INNER JOIN user ON qRequest.userId = user.userId
		WHERE qRequest.qRequestId = requestId;
	END IF;
    
        Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = requestId group by qRequestId; 

    
    SELECT paymentDoneByRequestor AS userPayment , paymentDoneByRequestor AS subTotal, paymentReceivedByQ AS TotalPaymentToQ , (paymentDoneByRequestor-paymentReceivedByQ) AS QAdminFee, reimbursementAmount ,
	requestAmt, serviceFeeToQ, serviceFeeToUser, paymentReceivedByQ, paymentDoneByRequestor
	 FROM `qRequestAccept` WHERE qRequestId = requestId;
	SELECT qBankAccountNumber FROM qProvider WHERE qId IN (SELECT qId FROM qRequestAccept WHERE qRequestId = requestId);
END$$

DROP PROCEDURE IF EXISTS `update_Email`$$
CREATE DEFINER=`test`@`%` PROCEDURE `update_Email`(IN `id` BIGINT, IN `random` INT)
    NO SQL
BEGIN
	DECLARE new_email VARCHAR(100);
	SELECT changedEmail into new_email FROM user where userId = id;
	IF EXISTS (select * from qProvider where userId = id) THEN
		UPDATE user, qProvider SET user.isEmailVerified = "1", user.email = new_email, user.changedEmail = "" ,
		qProvider.email = new_email
		WHERE user.userId = qProvider.userId AND
		user.userId = id AND user.passcode = random;
	ELSE 
		UPDATE user SET isEmailVerified = "1", email = new_email, changedEmail = "" WHERE userId = id AND passcode = random;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `update_Mobile`$$
CREATE DEFINER=`test`@`%` PROCEDURE `update_Mobile`(IN `id` BIGINT, IN `random` INT)
    NO SQL
BEGIN
	DECLARE new_mobile VARCHAR(100);
	SELECT mobile into new_mobile FROM user where userId = id;
	IF EXISTS (select * from qProvider where userId = id) THEN
		UPDATE user, qProvider SET user.isMobileverified = "1", user.mobile = new_mobile, user.changedMobile = "" ,
		qProvider.mobile = new_mobile
		WHERE user.userId = qProvider.userId AND
		user.userId = id AND user.mobilePasscode = random;
	ELSE 
		UPDATE user SET isMobileverified = "1", mobile = new_mobile, changedMobile = "" WHERE userId = id AND mobilePasscode = random;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `user_register`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_register`(IN `p_email` VARCHAR(255), IN `mobile` VARCHAR(50), IN `password` VARCHAR(50), IN `random` INT, IN `fname` VARCHAR(100), IN `lname` VARCHAR(100), IN `p_image` VARCHAR(255), IN `p_deviceToken` VARCHAR(255), IN `p_deviceType` INT, IN `mobileRandom` INT)
    NO SQL
BEGIN
	DECLARE userId BIGINT;
	IF EXISTS (select userId from user where email = p_email AND isDeleted <>-1) THEN
		select 'exists' as msg;
	ELSE 
    	insert into user(firstName,lastName,email,mobile,password,passcode,userProfile,deviceToken,deviceType,mobilePasscode) values(fname,lname,p_email,mobile,password,random,p_image,p_deviceToken,p_deviceType,mobileRandom);
		select  LAST_INSERT_ID() into userId;
		select 'insert' as msg, userId;
	END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `qProvider`
--

DROP TABLE IF EXISTS `qProvider`;
CREATE TABLE IF NOT EXISTS `qProvider` (
`qId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `currentLat` float(9,6) NOT NULL,
  `currentLong` float(9,6) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(5000) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zipCode` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `isMobileVerified` tinyint(4) NOT NULL COMMENT '0 = not varified 1 = verified',
  `mobileVerificationCode` varchar(100) NOT NULL,
  `nameOnDL` varchar(255) NOT NULL,
  `socialSecurityNo` varchar(1000) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `dlNo` varchar(1000) NOT NULL,
  `dlState` varchar(255) NOT NULL,
  `dateOfDlExpiration` date NOT NULL,
  `highSchoolName` varchar(255) NOT NULL,
  `highSchoolCity` varchar(255) NOT NULL,
  `highSchoolState` varchar(255) NOT NULL,
  `highSchoolYOGrad` varchar(255) NOT NULL,
  `hsInfo` varchar(50) NOT NULL,
  `collegeInfo` varchar(255) NOT NULL,
  `totalYearOfProfExp` int(11) NOT NULL,
  `personalAssistantExp` int(11) NOT NULL,
  `roleOfQ` varchar(255) NOT NULL,
  `isStateDisclouserAcknowledged` tinyint(4) NOT NULL,
  `isBackgroundCheckAuthorized` tinyint(4) NOT NULL,
  `isQVerified` tinyint(4) NOT NULL DEFAULT '0',
  `registrationDate` datetime NOT NULL,
  `isQOnline` tinyint(4) NOT NULL,
  `registrationStepCompleted` int(11) NOT NULL COMMENT '1 = first step completd, 2= verification done, 7 =  completed all step',
  `TotalRequestCompleted` bigint(20) NOT NULL,
  `TotalPaymentReceived` float NOT NULL,
  `qBankAccountNumber` varchar(1000) NOT NULL,
  `qStripeId` varchar(100) NOT NULL,
  `qStripeBankTokenId` varchar(100) NOT NULL,
  `qStripeBankId` varchar(100) NOT NULL,
  `isPerformingRequest` int(1) NOT NULL DEFAULT '0',
  `LastRequestSent` datetime NOT NULL,
  `isDeleted` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=221 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qProvider`
--

INSERT INTO `qProvider` (`qId`, `userId`, `currentLat`, `currentLong`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipCode`, `mobile`, `isMobileVerified`, `mobileVerificationCode`, `nameOnDL`, `socialSecurityNo`, `dateOfBirth`, `dlNo`, `dlState`, `dateOfDlExpiration`, `highSchoolName`, `highSchoolCity`, `highSchoolState`, `highSchoolYOGrad`, `hsInfo`, `collegeInfo`, `totalYearOfProfExp`, `personalAssistantExp`, `roleOfQ`, `isStateDisclouserAcknowledged`, `isBackgroundCheckAuthorized`, `isQVerified`, `registrationDate`, `isQOnline`, `registrationStepCompleted`, `TotalRequestCompleted`, `TotalPaymentReceived`, `qBankAccountNumber`, `qStripeId`, `qStripeBankTokenId`, `qStripeBankId`, `isPerformingRequest`, `LastRequestSent`, `isDeleted`) VALUES
(1, 1, 21.148766, 72.762474, 'Tilak', 'Jethva', 'lanetteam.tilak@gmail.com', 'surat', 'surat', 'Connecticut', '79119', '8758504790', 0, '', 'Tilak Ckj Jethva', '4242', '1988-05-13', '758555', 'Arizona', '2014-05-13', '', '', '', '', 'Attended', 'Attended', 5, 5, 'Transport , Anything else', 1, 1, 1, '2016-05-13 06:47:45', 0, 7, 4, 4560, '6789', '', '', '', 0, '2016-06-01 00:44:02', 0),
(2, 2, 37.332333, -122.031219, 'Riken', 'Doshi', 'lanetteam.riken@gmail.com', 'surat', 'surat', 'Armed Forces Americas', '99501', '9913060874', 0, '', 'Riken Vipul Doshi', '4242', '1983-05-13', '556566', 'Armed Forces Americas', '2021-05-13', '', '', '', '', 'Attended', 'Attended', 5, 5, 'Transport , Anything else', 1, 1, 1, '2016-05-13 06:59:28', 0, 7, 3, 9560, '6789', 'acct_18Aex6CEQO8c82kx', 'btok_8RY4nPdMY9y4iB', 'ba_18AeyYCEQO8c82kx9VGIRIhW', 0, '2016-06-01 00:44:02', 0),
(3, 4, 21.148085, 72.760704, 'Tapan', 'Gohil', 'lanetteam.tapan@gmail.com', 'surat', 'surat', 'Federated Micronesia', '72201', '9998078073', 0, '', 'Tapan Rajeshbhai Gohil', '5555', '2010-05-13', '55799753$7$35197', 'Federated Micronesia', '2021-05-13', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 1, '2016-05-13 08:01:49', 0, 7, 24, 185266, '6789', 'acct_18AfziJwcSQT5h5t', 'btok_8RZR0xBqOlvZe6', 'ba_18AgIcJwcSQT5h5tAMjYLq7W', 0, '2016-07-08 02:42:30', 0),
(4, 7, 34.106323, -118.463943, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '123 red st', 'los angeles ', 'California', '90077', '2038879349', 0, '', 'Kimberly Ann Idoko', '2534', '1979-05-13', '123457648', 'California', '2018-05-14', '', '', '', '', 'Graduated', 'Graduated', 12, 2, 'Transport,Anything else', 1, 1, 1, '2016-05-14 19:27:51', 0, 7, 5, 0, '1273', 'acct_18GsunLAzuI16PIU', 'btok_8Y1nxDG6fU90kY', 'ba_18GvjZLAzuI16PIUtom5sHKi', 0, '2016-07-07 05:34:30', -1),
(5, 8, 21.148390, 72.760948, 'Test', 'User', 'lanetteam.sajid@gmail.com', 'surat', 'surat', 'New Mexico', '72201', '9998078073', 0, '', 'Test Android User', '5555', '1992-05-17', '11212212333', 'Nevada', '2038-05-17', '', '', '', '', 'Graduated', 'Graduated', 2, 3, 'Transport , Anything else', 1, 1, 1, '2016-05-17 06:04:49', 0, 7, 0, 0, '6789', 'acct_18C61qHqdzl1ODcq', 'btok_8T27o4ZEdqsc22', 'ba_18C62xHqdzl1ODcqesrZkUko', 0, '0000-00-00 00:00:00', 0),
(6, 10, 34.151836, -118.453987, 'Demo', 'User', 'demo@qapp.com', 'surat', 'surat', 'Nevada', '72201', '9998887770', 0, '', 'Test Iphone User', '1111', '1991-05-18', '1335464647474', 'Northern Mariana Islands', '1993-05-18', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 1, '2016-05-18 06:32:00', 0, 7, 0, 0, '', 'acct_18CSuxGbOmsFu2tW', '', '', 0, '0000-00-00 00:00:00', 0),
(7, 12, 19.387493, -99.209747, 'Cristian ', 'Try', 'lokinenuco@gmail.com', 'mmm', 'El paso', 'Texas', '79912', '9153556813', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(8, 14, 34.106091, -118.463913, 'Felix', 'Odigie', 'felix@myqapp.com', '200 rosco rd', 'los angeles', 'California', '90077', '6173881912', 0, '', 'Felix Armstrong Odigie', '3964', '1976-09-30', '3418924', 'California', '2020-10-01', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport,Anything else', 1, 1, 0, '2016-05-29 21:09:02', 0, 7, 0, 0, '1912', 'acct_18GsufB2LZy7CiFA', 'btok_8XzoopMPMQB73D', 'ba_18GtoYB2LZy7CiFAcljMaM5w', 0, '2016-07-07 05:34:30', 1),
(9, 17, 34.106194, -118.463921, 'Kevin', 'Robinson', 'thomas77607@aol.com', '2001 roscomare rd', 'Los  Angeles ', 'California', '90077', '8185197366', 0, '', 'Kevin Varden Robinson', '7525', '1956-05-23', 'D6704100', 'California', '2019-05-23', '', '', '', '', 'Graduated', 'Attended', 25, 5, 'Transport', 1, 1, 1, '2016-05-30 12:51:34', 0, 7, 5, 0, '9934', 'acct_18Gub1JTf5hIBqmy', 'btok_8ZwwTzv97Hb8Fa', 'ba_18In2pJTf5hIBqmyjyQKFP5T', 0, '2016-06-29 10:21:17', 0),
(10, 16, 34.106140, -118.464005, 'Felix', 'Odigie', 'felix.odigie@gmail.com', '2000 roscomare rd', 'Los Angeles ', 'California', '90077', '6173881912', 0, '', 'Felix Odigie Odigie', '3964', '1976-10-01', '754689y', 'California', '2020-10-02', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport , Anything else', 1, 1, 1, '2016-05-30 15:39:09', 0, 7, 2, 0, '1912', 'acct_18GxEOIY5VeKvAum', 'btok_8Y3xmoWa1Us56T', 'ba_18GxprIY5VeKvAumVqSTF0bP', 0, '2016-06-22 01:50:50', 0),
(11, 24, 33.858624, -117.998375, 'Derrick', 'Smith', 'iderricksmithjr@gmail.com', '1861 Ashland Dr', 'Tracy', 'California', '95376', '2096403224', 0, '', 'Derrick Lynn Smith', '6436', '2016-06-05', '1928018', 'California', '2019-11-16', '', '', '', '', 'Graduated', 'Attended', 4, 1, 'Transport', 1, 1, 0, '2016-06-06 13:54:16', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(12, 25, 34.045151, -118.279182, 'Ivan', 'Cerezo', 'ivan.cerezo28@gmail.com', '1320 s. Burlington Ave apt 309', 'Los Angeles', 'California', '90006', '3234701069', 0, '', 'Ivan   Cerezo', '4717', '1990-06-28', 'D6105499', 'California', '2020-06-28', '', '', '', '', 'Graduated', 'Attended', 8, 1, 'Transport', 1, 1, 0, '2016-06-06 17:53:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(13, 26, 31.912424, -106.585587, 'Erin', 'Wilber', 'forever4learning@yahoo.com', '9237 La Salle Ave', 'Los Angeles', 'California', '90047', '3235433435', 0, '', 'Erin Mariebell Wilber', '6754', '1995-09-16', '3465084', 'California', '2012-12-24', '', '', '', '', 'Graduated', 'Attended', 3, 4, 'Transport', 1, 1, 0, '2016-06-07 18:10:29', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(14, 22, 31.912230, -106.573906, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '200 desert pass apt 129', 'El paso', 'Texas', '79911', '9154746047', 0, '', 'Ruben Ruben Hernandez', '2314', '2016-06-06', '1234567', 'Texas', '2032-06-07', '', '', '', '', 'Graduated', 'Graduated', 12, 25, 'Transport,Anything else', 1, 1, 0, '2016-06-07 19:04:13', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(15, 29, 34.592793, -83.741531, 'Jessica', 'Walton', 'jesssicaalexine@gmail.com', 'Atterberry ct ', 'decatur', 'Georgia', '30033', '4705648397', 0, '', 'Jessica Alexine Walton', '0221', '1992-08-20', '053344888', 'Georgia', '2017-08-21', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-08 11:50:44', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(16, 30, 40.838219, -73.900307, 'Kristeen', 'Washington', 'kristeen.washington@gmail.com', '11741 gilmore st ', 'north hollywood', 'California', '91606', '7078535100', 0, '', 'Kristeen Antoinette Washington', '5743', '1990-01-01', '9107295', 'California', '2018-01-02', '', '', '', '', 'Graduated', 'Graduated', 10, 5, 'Transport', 1, 1, 0, '2016-06-08 14:53:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(17, 31, 40.715889, -73.984024, 'Fanny', 'Lin', 'fannylinnn@gmail.com', '460 grand st Apt17B', 'New York', 'New York', '10002', '19178856565', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(18, 35, 31.912189, -106.573875, 'Rub', 'Her', 'jrhernandez2@miners.utep.edu', '200 desert pass', 'el paso', 'Texas', '79911', '9154746047', 0, '', 'Ruben Jos Hern', '1234', '1970-04-04', '123456789', 'Texas', '1970-04-05', '', '', '', '', 'Graduated', 'Graduated', 25, 23, 'Transport,Anything else', 1, 1, 0, '2016-06-08 23:40:53', 0, 7, 0, 0, '3786', 'acct_18KKzQEyXWFq4B99', 'btok_8bY7jZUvN3BWWk', 'ba_18KL1YEyXWFq4B99RYz6Buzy', 0, '0000-00-00 00:00:00', 1),
(19, 37, 42.464367, -70.956039, 'Rachel', 'Fulgencio', 'rfulgencio@outlook.com', 'P.O. Box 924', 'Lynn', 'Massachusetts', '01903', '6175050713', 0, '', 'Rachel None Fulgencio', '9453', '1993-01-17', '34651270', 'Massachusetts', '2019-01-18', '', '', '', '', 'Graduated', 'Attended', 5, 4, 'Transport', 1, 1, 0, '2016-06-09 12:52:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(20, 38, 33.938370, -84.499992, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '2001 roscomare rd', 'los angeles', 'California', '90077', '8184658228', 0, '', 'Kimberly Liz Odigie', '8854', '1982-06-08', '877546794', 'New York', '2020-06-09', '', '', '', '', 'Graduated', 'Graduated', 8, 8, 'Transport', 1, 1, 1, '2016-06-09 12:30:05', 0, 7, 0, 0, '', 'acct_18KX04F1yquyNukN', '', '', 0, '0000-00-00 00:00:00', 1),
(21, 42, 42.263481, -71.109978, 'Tyneshia', 'Stephenson', 'tyneshiastephenson@gmail.com', '104 lewiston st', 'hyde park', 'Massachusetts', '02136', '6176026526', 0, '', 'Tyneshia Shawne Stephenson', '4556', '1990-01-08', '58357991', 'Massachusetts', '2019-01-09', '', '', '', '', 'Graduated', 'Attended', 8, 8, 'Transport', 1, 1, 0, '2016-06-09 13:25:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(22, 43, 34.077709, -84.637848, 'Foluke', 'Arogundade', 'folukearogundade@yahoo.com', '1081 Athena Ct', 'Acworth', 'Georgia', '30101', '6785239128', 0, '', 'Foluke Adetokunbo Arogundade', '0130', '1982-04-23', '049363877', 'Georgia', '2017-04-24', '', '', '', '', 'Graduated', 'Graduated', 10, 1, 'Transport', 1, 1, 0, '2016-06-09 13:47:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(23, 44, 42.264076, -71.103775, 'Vanessa', 'Jean Louis', 'vanessa19jl91@gmail.com', '45 highland ave apt 12', 'randolph', 'Massachusetts', '02368', '6174129581', 0, '', 'Vanessa N/A Jean Louis', '2212', '1991-07-17', 'S30877722', 'Massachusetts', '2018-07-17', '', '', '', '', 'Graduated', 'Attended', 2, 2, 'Transport', 1, 1, 0, '2016-06-09 15:13:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(24, 27, 40.689346, -73.870537, 'Rubot', 'H', 'vauxxer@gmail.com', '3rd street', 'el paso', 'Louisiana', '79911', '9154746047', 0, '', 'Ruben J Hernandez', '4141', '1971-06-08', '256341879', 'Florida', '2021-06-09', '', '', '', '', 'Graduated', 'Graduated', 54, 54, 'Transport,Anything else', 1, 1, 0, '2016-06-09 17:28:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(25, 45, 40.693497, -73.946793, 'Kiron', 'Harper', 'KOHARPER92@gmail.com', '120 Hart Street', 'Brooklyn ', 'New York', '11206', '9543973616', 0, '', 'Kiron Okero Harper', '1317', '1992-12-03', '616514924430', 'Florida', '2018-12-03', '', '', '', '', 'Graduated', 'Attended', 4, 1, 'Transport', 1, 1, 0, '2016-06-09 16:58:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(26, 33, 37.332333, -122.031219, 'Ruben', 'Dev', 'ruben.h.dev@gmail.com', 'test', 'el paso', 'Guam', '22256', '9154746047', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, 'Transport', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(27, 48, 0.000000, 0.000000, 'Katie', 'Toups', 'katietoups@gmail.com', '47 Lincoln Ave ', 'Brooklyn', 'New York', '11208', '9177537604', 0, '', 'Katie Lynn Toups', '8695', '1988-02-26', '7977543', 'California', '2019-02-27', '', '', '', '', 'Graduated', 'Attended', 8, 3, 'Transport', 1, 1, 0, '2016-06-09 18:49:48', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(28, 52, 34.106045, -118.464035, 'Kimberly', 'Odigie', 'kimberly@theqnowapp.com', '56 bay st', 'los angeles', 'California', '90077', '8184658228', 0, '', 'Kimberly Ray Odigie', '5266', '1985-06-09', '845675496', 'California', '2021-06-10', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-10 11:30:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(29, 53, 33.839886, -83.886940, 'Jesse', 'Ferguson', 'j.ferguson1@lafilm.edu', '297 meadows drive', 'Loganville', 'Georgia', '30052', '4236939242', 0, '', 'Jesse Austin Feeguson', '3094', '1995-10-09', '057175925', 'Georgia', '2018-10-27', '', '', '', '', 'Graduated', 'Attended', 2, 1, 'Transport', 1, 1, 0, '2016-06-10 12:20:51', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(30, 55, 40.838230, -73.899910, 'Fati', 'Haruna', 'haruna.fati@gmail.com', '1555 Fulton Ave', 'bronx', 'New York', '10457', '6463398454', 0, '', 'Fati None Haruna', '5734', '1996-05-26', '200743105', 'New York', '2019-05-27', '', '', '', '', 'Graduated', 'Attended', 0, 1, 'Transport', 1, 1, 0, '2016-06-10 18:42:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(31, 56, 33.710094, -117.853897, 'Richard', 'Sherlock', 'richard77sherlock@gmail.com', '12601 Arena Drive', 'Rancho Cucamonga', 'California', '91739', '9092243168', 0, '', 'Richard Christian Sherlock', '3223', '1990-04-18', '9728724', 'California', '2021-04-18', '', '', '', '', 'Graduated', 'Attended', 8, 4, 'Transport', 1, 1, 0, '2016-06-10 14:25:58', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(32, 54, 33.900692, -84.238327, 'Vanice', 'Simpson', 's.vanice@ymail.com', '416 Brooke Ridge Ave', 'Atlanta', 'Georgia', '30340', '9548026914', 0, '', 'Vanice Nichole Simpson', '5097', '1991-04-02', '060011720', 'Georgia', '2021-04-03', '', '', '', '', 'Graduated', 'Attended', 9, 4, 'Transport', 1, 1, 0, '2016-06-10 17:07:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(33, 57, 33.678871, -84.441261, 'Kiah', 'Cronin', 'kiah.cronin@yahoo.com', '3989 foxhunt lane', 'East Point', 'Georgia', '30344', '8145746755', 0, '', 'Kiah Nicole Cronin', '0671', '1995-10-19', '103951958', 'South Carolina', '2025-10-19', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-10 17:56:59', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(34, 59, 40.663719, -73.940697, 'Raven', 'David', 'rdavid_18@yahoo.com', '206 Parkside Ave', 'Brooklyn', 'New York', '11226', '9293925629', 0, '', 'Raven None David', '0288', '1992-04-24', '360277641', 'New York', '2018-04-24', '', '', '', '', 'Graduated', 'Attended', 4, 4, 'Transport', 1, 1, 0, '2016-06-10 19:30:27', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(35, 61, 40.867050, -73.841263, 'Salim', 'Diakite', 'sdiakite16@yahoo.com', '2758 Woodhull ave', 'Bronx ', 'New York', '10469 ', '3478216504', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(36, 64, 42.485149, -70.899422, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', '31 Franklin st Apt 6 ', 'lynn ', 'Massachusetts', '01902', '7817312269', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(37, 65, 42.462654, -70.950279, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', '31 Franklin St Apt 6 ', 'Lynn ', 'Massachusetts', '01902', '7817312269', 0, '', 'Natasha Marie Diaz', '4045', '1994-05-24', '57659841', 'Massachusetts', '2020-05-24', '', '', '', '', 'Graduated', 'Attended', 0, 0, 'Transport', 1, 1, 0, '2016-06-13 11:33:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(38, 66, 34.204670, -118.446411, 'Rebekah', 'Pelzel', 'rebekahpelzel@gmail.com', '735 market st', 'woodstock', 'Georgia', '30188', '5756404303', 0, '', 'Rebekah Faith Pelzel', '3255', '1992-06-27', '059464471', 'Georgia', '2016-07-29', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport', 1, 1, 0, '2016-06-15 08:03:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(39, 67, 31.912004, -106.573738, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '-£-£++', 'el paso', 'American Samoa', '91423', '9154746047', 0, '', 'Jose Hernandez', '4242', '1970-06-21', 'AV27389817', 'Texas', '2035-06-22', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Transport , Anything else', 1, 1, 1, '2016-06-22 23:51:02', 0, 7, 15, 3040, '6702', 'acct_18PPpwJoR1VUISMG', 'btok_8gpdaSxGAKvxtH', 'ba_18PRydJoR1VUISMG16WtQb0J', 0, '2016-07-07 05:34:30', 0),
(40, 68, 45.620949, -94.213211, 'Seth', 'Sharbono', 'sethsharb@gmail.com', '466 Washington St 1W', 'New York', 'New York', '10013', '3202491523', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(41, 69, 40.630604, -73.903221, 'Nerishka', 'Jeanty', 'Nerishkaj@icloud.com', '1220 east 84th street', 'Brooklyn', 'New York', '11236', '3474099134', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(42, 70, 33.929123, -118.331505, 'Bianca', 'Latham', 'balatham@ymail.com', '3360 w 116th st', 'Inglewood', 'Armed Forces Americas', '90303', '3107437584', 0, '', 'Bianca A Latham', '6500', '1988-12-19', 'd6179193', 'Armed Forces Americas', '2016-12-19', '', '', '', '', 'Graduated', 'Attended', 10, 6, 'Transport', 1, 1, 0, '2016-06-13 19:57:03', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(43, 71, 40.821831, -73.878044, 'Richard', 'Ramirez', 'richardramirez5@hotmail.com', '907 elder ave ', 'bronx ', 'New York', '10473', '3476912171', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(44, 74, 33.644077, -117.746819, 'Michelle', 'Barrionuevomazzini', 'mbmazzini@me.com', '7203 Telmo', 'Irvine', 'California', '92618', '4157061677', 0, '', 'Michelle Mavel Barrionuevomazzini', '7613', '2016-06-13', '7727794', 'California', '2017-06-02', '', '', '', '', 'Attended', 'Attended', 16, 13, 'Transport', 1, 1, 0, '2016-06-14 02:51:05', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(45, 76, 34.009239, -118.300179, 'Tori', 'Uvaas', 'toriuvaas@gmail.com', '15613 fernview st', 'whittier ', 'California', '90604', '5624479004', 0, '', 'Tori Anne Uvaas', '8183', '1995-10-24', '3078245', 'California', '2020-10-25', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-14 11:14:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(46, 78, 0.000000, 0.000000, 'Courtney', 'Siwek', 'csiwek13@gmail.com', '11011 Huston St', 'North Hollywood', 'California', '91601', '4196109863', 0, '', 'Courtney Ann Siwek', '8295', '1993-05-15', '442942', 'Ohio', '2018-05-16', '', '', '', '', 'Graduated', 'Graduated', 4, 3, 'Transport,Anything else', 1, 1, 0, '2016-06-14 12:18:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(47, 80, 34.106144, -118.463882, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '56 hamilton rd', 'los angeles', 'California', '90049', '8184658228', 0, '', 'Kimberly Liz Odigie', '5425', '2016-06-13', '852467545', 'California', '2019-06-14', '', '', '', '', 'Attended', 'Attended', 2, 2, 'Transport', 1, 1, 0, '2016-06-14 13:19:04', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(48, 82, 40.682350, -74.331223, 'Deandra', 'Egusquiza', 'deandraelise@yahoo.com', '12 cedar st', 'hillside', 'New Jersey', '07205', '9085149546', 0, '', 'Deandra Elise Egusquiza', '9959', '1988-02-19', '31201576552882', 'New Jersey', '2018-11-30', '', '', '', '', 'Attended', 'Attended', 5, 0, 'Transport,Anything else', 1, 1, 0, '2016-06-14 13:26:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(49, 73, 31.912167, -106.573845, 'Ruben', 'Hernandez', 'ruben.h.dev@gmail.com', 'jdjdjkd', 'hdjdkdk', 'Delaware', '61616', '9154746047', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(50, 83, 42.264492, -71.354477, 'Aliza', 'Greenstein', 'lizadancesandswims@gmail.com', '45 Centre st', 'natick', 'Massachusetts', '01760', '5085051534', 0, '', 'Aliza Rose Greenstein', '9760', '1998-05-15', '60419788', 'Massachusetts', '2019-05-15', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport,Anything else', 1, 1, 0, '2016-06-14 18:13:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(51, 84, 33.965286, -118.364838, 'Helena', 'Cohen', 'helenacohee@gmail.com', '527 west regent street ', 'Inglewood', 'California', '90301', '3235612620', 0, '', 'Helena Beth Cohen', '8298', '1986-12-06', '7192853', 'California', '2017-12-07', '', '', '', '', 'Graduated', 'Graduated', 14, 10, 'Transport,Anything else', 1, 1, 0, '2016-06-14 18:13:10', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(52, 85, 40.785500, -73.946495, 'Imani Shadae', 'James', 'imanis.ajames@gmail.com', '326 E. 100th street Apt. 5D', 'New York ', 'New York', '10029', '7189159713', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(53, 87, 34.156578, -118.347374, 'Michele', 'Brown', 'm_brown18@yahoo.com', '4141 W Kling St #19', 'Burbank', 'California', '91505', '7604152638', 0, '', 'Michele Elise Brown', '7145', '1990-09-17', '1484192', 'California', '2016-09-18', '', '', '', '', 'Graduated', 'Graduated', 7, 2, 'Transport', 1, 1, 0, '2016-06-14 19:07:20', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(54, 89, 40.649578, -74.011368, 'Drayton ', 'Hiers', 'drayton.a.hiers@gmail.com', '329 46 Street, #2', 'Brooklyn', 'New York', '11220', '9172028396', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(55, 88, 33.696392, -117.958588, 'Andrew', 'Neal', 'andrewxxneal@gmail.com', '18345 Jacaranda street', 'Fountain Valley', 'California', '92708', '7146252326', 0, '', 'Andrew Michael Neal', '2238', '1993-03-30', '3830902', 'California', '2019-03-30', '', '', '', '', 'Graduated', 'Attended', 4, 0, 'Transport,Anything else', 1, 1, 0, '2016-06-14 22:27:22', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(56, 90, 33.922409, -83.993401, 'Chantell', 'Lawson', 'chantellandreina@yahoo.com', '738 channel lane', 'lawrenceville', 'Georgia', '30046', '6786126696', 0, '', 'Chantell Andreina Lawson', '0435', '1997-07-11', '26588917', 'Georgia', '2017-07-12', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport', 1, 1, 0, '2016-06-15 01:21:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(57, 91, 33.963821, -84.377045, 'Shermayne', 'Butts', 'sheabee09@gmail.com', '721 cimmarion pkwy', 'atlanta', 'Georgia', '30350', '9312167534', 0, '', 'Shermayne Mikel Butts', '0845', '1991-10-02', '113028408', 'Tennessee', '2021-10-03', '', '', '', '', 'Graduated', 'Graduated', 7, 2, 'Transport', 1, 1, 0, '2016-06-15 02:59:18', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(58, 92, 40.671150, -73.915756, 'Kyandra', 'Richardson', 'kyandra919@gmail.com', '1580 Eastern Parkway ', 'Brooklyn', 'New York', '11233', '3475819741', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(59, 93, 42.212193, -71.036499, 'Zelmia', 'Harvey', 'kimera.draven@gmail.com', '43 fowler st', 'randolph', 'Massachusetts', '02368', '7815100227', 0, '', 'Zelmia Ameera Harvey', '9118', '1987-11-15', '30326957', 'Massachusetts', '2017-11-16', '', '', '', '', 'Graduated', 'Graduated', 5, 2, 'Transport', 1, 1, 0, '2016-06-15 08:54:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(60, 94, 40.756351, -73.909332, 'Jasmin', 'Rodriguez', 'jasminvrodriguez@outlook.com', '5020 31st Ave 4D', 'Woodside', 'New York', '11377', '3472170160', 0, '', 'Jasmin V Rodriguez', '5096', '1991-10-02', '304516621', 'New York', '2022-10-02', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Transport', 1, 1, 0, '2016-06-16 15:51:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(61, 96, 34.088638, -118.291252, 'Jonathan', 'Shelton', 'jshelton85@gmail.com', '4456 Lockwood Ave, #402', 'Los Angeles', 'California', '90029', '2132801920', 0, '', 'Jonathan Lee Shelton', '3363', '1985-04-24', 'D3909512', 'California', '2020-04-24', '', '', '', '', 'Graduated', 'Attended', 14, 5, 'Transport', 1, 1, 0, '2016-06-15 12:05:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(62, 97, 0.000000, 0.000000, 'Kary', 'Hudson', 'Karyh92@gmail.com', '859 Lenox Road', 'Brooklyn', 'New York', '11203', '9177547685', 0, '', 'Kary Andre Hudson', '2392', '1992-03-07', '561327812', 'New York', '2023-03-08', '', '', '', '', 'Attended', 'Attended', 9, 6, 'Transport', 1, 1, 0, '2016-06-15 16:21:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(63, 100, 34.172703, -118.367485, 'Jeff', 'Lazelle', 'jefflazelle@gmail.com', '5615 Satsuma Avenue, Apt. 104', 'North Hollywood', 'California', '91601', '3235921641', 0, '', 'Jeffrey Adam Lazelle', '3443', '1989-01-03', 'Y3639745', 'California', '2020-01-03', '', '', '', '', 'Graduated', 'Graduated', 1, 1, 'Transport', 1, 1, 0, '2016-06-15 19:58:27', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(64, 99, 33.929359, -118.200256, 'Lisa', 'Willis', 'michell_willis64@yahoo.com', '11167 Carson Drive apt c', 'Lynwood', 'California', '90262', '4242326790', 0, '', 'Lisa Michell Willis', '5126', '1964-03-30', 'c1561468', 'California', '2016-06-15', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Transport', 1, 1, 0, '2016-06-15 20:17:53', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(65, 102, 33.863052, -118.352798, 'Paulina', 'Tamayo', 'paulinaadrian917@yahoo.com', '1720 e 115th st ', 'los angeles', 'California', '90059', '5624517983', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(66, 103, 34.204685, -118.446358, 'Nicholas', 'Kasule', 'kasule23n@gmail.com', '14360 Valerio street 316', 'Van nuys', 'California', '91405', '4242139725', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(67, 104, 40.839348, -73.864784, 'Maria', 'Caraballo', 'aradia097@gmail.com', '1552 Leland ave apt 2B', 'Bronx', 'New York', '10460', '3475206899', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(68, 107, 34.087547, -118.385895, 'Nathan', 'Fisher', 'nateafisher@gmail.com', '909 N San Vicente Blvd ', 'West Hollywood', 'California', '90069', '3236202111', 0, '', 'Nathan Allen Fisher', '8411', '1984-06-24', '1527010', 'California', '2019-06-24', '', '', '', '', 'Attended', 'Attended', 6, 6, 'Transport', 1, 1, 0, '2016-06-16 05:13:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(69, 108, 33.850815, -84.368019, 'Victoria', 'Graham', 'jvgraham2014@gmail.com', '174 Wavetree Dr', 'Roswell ', 'Armed Forces Americas', '30075', '6787554500', 0, '', 'Victoria LisaRuth  craft perez', '3090', '1994-09-07', '057451668', 'Armed Forces Americas', '2023-09-09', '', '', '', '', 'Graduated', 'Attended', 1, 1, 'Transport', 1, 1, 0, '2016-06-16 07:25:45', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(70, 109, 0.000000, 0.000000, 'Ciera', 'Crossling', 'cieracrossling@gmail.com', 'not sure ', 'los angeles', 'California', '90002', '4437864318', 0, '', 'Ciera Gene Crossling', '8799', '1988-01-28', '624116275077', 'Maryland', '2018-01-29', '', '', '', '', 'Graduated', 'Attended', 7, 7, 'Transport', 1, 1, 0, '2016-06-16 09:52:59', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(71, 110, 42.365501, -71.103722, 'Whitney', 'Pensinger', 'whitneypensinger@gmail.com', '22 Roseland Street', 'cambridge ', 'Massachusetts', '02140', '6179453117', 0, '', 'Whitney C Pensinger', '4226', '1986-05-22', 'S38459192', 'Massachusetts', '2017-05-22', '', '', '', '', 'Graduated', 'Graduated', 12, 1, 'Transport', 1, 1, 0, '2016-06-16 10:16:22', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(72, 106, 33.930279, -84.348526, 'Tyechia', 'Spann', 'tyspann82@yahoo.com', '4364 Kousa Rd', 'Austell', 'Georgia', '30106', '4042002525', 0, '', 'Tyechia N Spann', '5594', '1982-10-03', '052861830', 'Georgia', '2022-10-03', '', '', '', '', 'Graduated', 'Graduated', 9, 3, 'Transport , Anything else', 1, 1, 0, '2016-06-16 16:52:29', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(73, 117, 34.106236, -118.463425, 'Felix', 'Odigie ', 'felix@myqapp.com', '2001 roscomare rd', 'Los Angeles ', 'Armed Forces Americas', '90077', '2104644634', 0, '', 'Felix Odigie', '3964', '1976-10-01', 's2301356', 'Armed Forces Americas', '2022-10-03', '', '', '', '', 'Graduated', 'Graduated', 5, 6, 'Transport , Anything else', 1, 1, 0, '2016-06-16 14:50:45', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(74, 115, 34.215473, -118.598007, 'Zeinab', 'Golbaz', 'asal.golbaz@gmail.com', '6450 Franrivers Ave', 'west Hills', 'California', '91307', '8187939840', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(75, 119, 34.212814, -118.387390, 'Daniela', 'Lopez', 'danielaylopez02@gmail.com', '7716 Laurel Cyn Blvd 12', 'North Hollywood ', 'California', '91605', '8185682927', 0, '', 'Daniela Yocelyn Lopez', '4305', '1992-08-06', 'D8014720', 'California', '2016-08-06', '', '', '', '', 'Graduated', 'Attended', 5, 5, 'Transport', 1, 1, 0, '2016-06-16 20:04:16', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(76, 120, 33.972263, -118.261749, 'Shaharazaad', 'Carter', 'shaharazaadc92@gmail.com', '735 e 75th ', 'Los Angeles', 'California', '90001', '3238843496', 0, '', 'Shaharazaad Evalena Carter', '3417', '1992-05-15', '2858873', 'California', '2020-05-16', '', '', '', '', 'Graduated', 'Attended', 11, 1, 'Transport', 1, 1, 0, '2016-06-16 21:52:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(77, 123, 33.785896, -84.400406, 'Tiana', 'Pope', 'tianapope7@yahoo.com', '178 Moury Ave SW ', 'Atlanta ', 'Georgia', '30315', '4043122186', 0, '', 'Tiana A Pope', '5127', '1989-01-06', '056354212', 'Georgia', '2019-01-07', '', '', '', '', 'Graduated', 'Attended', 11, 8, 'Transport', 1, 1, 0, '2016-06-16 21:54:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(78, 111, 40.741043, -73.639236, 'Christine', 'Thomas', 'kristine318@me.com', '68 Guinn St SW', 'marietta', 'Georgia', '30030', '6788365439', 0, '', 'Christine Mckenzie Thomas', '3887', '1993-03-17', '055736472', 'Georgia', '1993-03-18', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-17 07:41:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(79, 124, 33.513344, -84.220177, 'Machella', 'Anthony', 'manthony2007@yahoo.com', '1206 Pleasant Ave', 'Griffin ', 'Georgia', '30223', '6785884574', 0, '', 'Machella  Anthony ', '6548', '1989-07-28', '051996467', 'Georgia', '2018-07-28', '', '', '', '', 'Graduated', 'Graduated', 16, 3, 'Transport', 1, 1, 0, '2016-06-17 10:26:22', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(80, 126, 34.580261, -118.057587, 'Tarian', 'Bullock', 't.bullock@lafilm.edu', '43223 Gadsden Avenue ', 'lancaster ', 'California', '93534', '6616747084', 0, '', 'Tarian B Bullock', '1675', '1994-08-18', 'f7469661', 'California', '2019-08-18', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport', 1, 1, 0, '2016-06-17 14:13:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(81, 127, 34.106346, -118.463867, 'Aliyah', 'Burroughs', 'burroughsaliyah@yahoo.com', '1510 Primrose park rd', 'sugar hill', 'Georgia', '30518', '2145859419', 0, '', 'Aliyah Nicole Burroughs', '8347', '1994-09-11', '058645700', 'Georgia', '2018-09-11', '', '', '', '', 'Graduated', 'Attended', 4, 0, 'Transport', 1, 1, 0, '2016-06-17 17:10:33', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(82, 132, 33.966782, -118.248917, 'Jannai', 'Calderon', 'jannaicalderon@ymail.com', '7920 Antwerp street', 'Los Angeles', 'California', '90001', '3234121141', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(83, 134, 42.515892, -71.033157, 'Stephanie', 'Breen', 'SAB934@gmail.com', '10 Hutch Rd', 'Salem', 'New Hampshire', '03079', '6034016617', 0, '', 'Stephanie A Breen', '9895', '1992-04-10', '0426792111', 'New Hampshire', '2018-04-11', '', '', '', '', 'Attended', 'Attended', 8, 1, 'Transport', 1, 1, 0, '2016-06-17 18:42:15', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(84, 135, 42.345516, -71.088173, 'Perry ', 'Wade ', 'pwade16@gmail.com', '41 edgerly road ', 'Boston ', 'Massachusetts', '02115', '8573338308', 0, '', 'Perry  Wade', '2691', '1989-07-05', 'S81798740', 'Massachusetts', '2019-07-05', '', '', '', '', 'Graduated', 'Attended', 8, 0, 'Transport', 1, 1, 0, '2016-06-17 19:40:14', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(85, 116, 34.145626, -118.370674, 'Nicholas', 'Ruck', 'ruck.nick@gmail.com', '4215 vineland ave', 'los angeles', 'California', '91602', '9197706024', 0, '', 'Nicholas Robin Ruck', '8126', '1992-04-25', 'y3872237', 'California', '2020-04-25', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport', 1, 1, 0, '2016-06-18 00:57:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(86, 136, 34.058834, -118.293434, 'Amber', 'Guidry', 'AmbercadeG@gmail.com', '731 south new hampshire ave', 'los angeles', 'California', '90005', '9162302551', 0, '', 'Amber Cade Guidry', '8668', '1993-04-18', '3585448', 'California', '2021-04-19', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-19 10:53:56', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(87, 137, 42.292675, -71.051941, 'Yulimar', 'Andrades Cordova ', 'yuls2000@hotmail.com', '20 n Munroe ter', 'dorchester', 'Massachusetts', '02122', '8579910489', 0, '', 'Yulimar Andrades cordova', '2052', '1986-10-03', 's09489222', 'Massachusetts', '2018-10-03', '', '', '', '', 'Graduated', 'Attended', 8, 3, 'Transport , Anything else', 1, 1, 0, '2016-06-18 06:04:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(88, 133, 40.589638, -73.806633, 'Felicia', 'Reed', 'feliciareeed12@gmail.com', '260 beach 81 street ', 'queens ', 'New York', '11693', '3478588329', 0, '', 'Felicia Charlotte  Reed', '1053', '1998-04-09', '345591895', 'New York', '2019-04-09', '', '', '', '', 'Attended', 'Attended', 0, 0, 'Transport', 1, 1, 0, '2016-06-18 07:44:28', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(89, 139, 40.833416, -73.888474, 'Brittney', 'Jackson', 'b.jackson1390@icloud.com', '1500 Hoe Ave Apt 10D', 'Bronx', 'New York', '10460', '6466205308', 0, '', 'Brittney Denise Jackson', '6923', '1990-01-12', '346483105', 'New York', '1990-01-13', '', '', '', '', 'Attended', 'Attended', 10, 1, 'Transport', 1, 1, 0, '2016-06-18 11:26:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(90, 142, 34.065895, -118.408554, 'Shaina', 'Lavine', 'shainarlavine3@gmail.com', '132 S Spalding ', 'Beverly Hills', 'California', '92679', '9492915650', 0, '', 'Shaina Rachel Lavine', '5508', '1995-12-23', '4287180', 'California', '2017-12-23', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Transport', 1, 1, 0, '2016-06-19 22:03:20', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(91, 144, 34.063663, -118.398445, 'Laura', 'Martellino', 'lmartellino@gmail.com', '2747 auburn st ', 'los angeles ', 'California', '90212', '4018553322', 0, '', 'Laura Jane Martellino', '3832', '1988-02-26', '148960923', 'Connecticut', '2018-02-26', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Transport,Anything else', 1, 1, 0, '2016-06-19 15:19:21', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(92, 145, 40.826881, -73.130310, 'Esther', 'Lenderman', 'Estherlenderman@yahoo.com', '27 Parr Drive', 'Ronkonkoma', 'New York', '11779', '6314137352', 0, '', 'Esther Malka Lenderman', '1534', '1992-09-11', '655321427', 'New York', '2021-09-12', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport,Anything else', 1, 1, 0, '2016-06-19 16:14:24', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(93, 146, 0.000000, 0.000000, 'Pamela', 'Towner', 'cr8nheat1@yahoo.com', '16250 homecoming dr 1053', 'chino', 'California', '91708', '6613130073', 0, '', 'Pamela Lynette Towner', '4546', '1968-02-19', '5061958', 'California', '2021-02-20', '', '', '', '', 'Graduated', 'Attended', 25, 2, 'Transport', 1, 1, 0, '2016-06-19 21:07:18', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(94, 147, 40.671803, -73.906433, 'Tranise', 'West', 'slimprissi@gmail.com', '108 Christopher ave 14A', 'Brooklyn', 'New York', '11212', '5162326116', 0, '', 'Tranise Ratana West', '9109', '1980-03-17', '871092292', 'New York', '2020-03-17', '', '', '', '', 'Graduated', 'Attended', 10, 10, 'Transport,Anything else', 1, 1, 0, '2016-06-20 09:09:21', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(95, 148, 34.141758, -118.371849, 'Tiffany', 'Glass', 'lalee2@aol.com', '4101 Arch Dr 124', 'Studio City', 'California', '91604', '3107760597', 0, '', 'Tiffany Anne Glass', '5304', '1973-03-19', 'A5524590', 'California', '2020-03-20', '', '', '', '', 'Graduated', 'Graduated', 15, 15, 'Transport', 1, 1, 0, '2016-06-20 09:41:36', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(96, 149, 0.000000, 0.000000, 'Nicholas', 'Oliver', 'nsoliver@outlook.com', '1349 e 84th st ', 'brooklyn', 'New York', '11236', '3472487239', 0, '', 'Nicholas Oliver', '7996', '1994-04-12', '169005306', 'Connecticut', '2020-04-12', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Transport', 1, 1, 0, '2016-06-20 11:04:45', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(97, 151, 34.105816, -118.264900, 'Carla', 'Onofri', 'carlaonofri@gmail.com', '2725 lakewood ave ', 'los angeles ', 'California', '90039', '2134223232', 0, '', 'Carla J Onofri', '1234', '1983-03-01', '3138542', 'California', '2019-03-02', '', '', '', '', 'Attended', 'Attended', 10, 8, 'Transport', 1, 1, 0, '2016-06-20 11:17:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(98, 152, 34.149090, -118.406395, 'Talia', 'Davis', 'talia.ashanti@gmail.com', '4317 babcock ave', 'studio city', 'California', '91604', '9725051301', 0, '', 'Talia Ashanti Davis', '5372', '1991-02-11', '3191301', 'California', '2020-02-11', '', '', '', '', 'Graduated', 'Graduated', 7, 6, 'Transport', 1, 1, 0, '2016-06-20 12:09:15', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(99, 153, 33.837620, -84.257263, 'ShaQuisha', 'DILLARD', 'sydillard@gmail.com', '1872 suite A', 'Tucker', 'Armed Forces Europe', '30084', '6784128727', 0, '', 'ShaQuisha Yvette Dillard', '3249', '1979-06-28', '053141965', 'Georgia', '2020-06-28', '', '', '', '', 'Graduated', 'Attended', 10, 7, 'Anything else', 1, 1, 0, '2016-06-20 13:38:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(100, 154, 40.878647, -73.881348, 'Yasmin ', 'Salah ', 'salamconsulting7@gmail.com', '30 Cowles Ave ', 'Yonkers ', 'New York', '10704', '2405511111', 0, '', 'Yasmin  Mohammed  Salah ', '4379', '2016-06-26', 'so2327897451802', 'New Jersey', '2019-10-31', '', '', '', '', 'Graduated', 'Attended', 12, 10, 'Transport', 1, 1, 0, '2016-06-26 10:27:37', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(101, 155, 40.870647, -73.858810, 'Gina', 'Ramos', 'gramos98@yahoo.com', '3031 Paulding Avenue ', 'Bronx', 'New York', '10469', '3472556470', 0, '', 'Gina J Ramos', '1514', '1984-09-07', '233929156', 'New York', '2023-09-08', '', '', '', '', 'Graduated', 'Attended', 10, 5, 'Transport,Anything else', 1, 1, 0, '2016-06-20 21:00:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(102, 157, 40.724022, -74.042091, 'Bryan', 'Brea', 'bryan.brea11@gmail.com', '184 4th Street', 'Jersey City', 'New Jersey', '07302', '3475641493', 0, '', 'Bryan Geronimo Brea', '3752', '1995-09-09', '0000000', 'New York', '0000-00-00', '', '', '', '', 'Graduated', 'Attended', 7, 2, 'Anything else', 1, 1, 0, '2016-06-21 16:03:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(103, 158, 0.000000, 0.000000, 'Ellis', 'Clayton', 'ellislclaytonlll@gmail.com', '1291 Shakespeare Avenue Apt1', 'Bronx', 'New York', '10452', '3477985460', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(104, 159, 0.000000, 0.000000, 'Qing Lei', 'Lin', 'lin.qing.624@gmail.com', '5115 9th Ave', 'Brooklyn', 'New York', '11220', '6463713510', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(105, 161, 0.000000, 0.000000, 'Kennedy', 'Barnett', 'kennedybarnett1@yahoo.com', '3503 S Norton ave', 'los angeles ', 'California', '90018', '3238778250', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(106, 162, 0.000000, 0.000000, 'Linda', 'Caceres', 'lchcfan@yahoo.com', '325 Fremont Ave', 'South Pasadena', 'California', '91030', '8184689779', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(107, 163, 40.942726, -73.885460, 'Waulinda', 'Harris', 'waulinda@Gmail.com', '11549 140th Street ', 'Jamaica', 'New York', '11436', '3476849032', 0, '', 'Waulinda Jolene Harris', '5026', '1987-04-12', '511795856', 'New York', '2017-04-12', '', '', '', '', 'Graduated', 'Attended', 1, 1, 'Transport', 1, 1, 0, '2016-06-21 06:38:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(108, 150, 34.063538, -118.319374, 'John ', 'Nunez', 'john.e.nunez@gmail.com', '92 Van Cortlandt park south', 'bronx', 'New York', '10463', '3479333141', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(109, 164, 34.106194, -118.463722, 'Lenicia', 'Appleton', 'leniciaappleton@yahoo.com', '448 union ave', 'mount vernon ', 'New York', '10550', '3473102305', 0, '', 'Lenicia Antoinette Appleton', '7133', '1988-02-21', '494334476', 'New York', '1988-02-22', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport', 1, 1, 0, '2016-06-21 10:37:53', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(110, 165, 33.809254, -84.831383, 'Melissa', 'Lehman', 'meemee920@gmail.com', '43 kent lane ', 'Douglasville', 'Armed Forces Europe', '30134', '6786701717', 0, '', 'Melissa Ann Lehman', '1078', '1987-12-06', '05332706', 'Armed Forces Europe', '2016-12-06', '', '', '', '', 'Graduated', 'Graduated', 8, 4, 'Transport , Anything else', 1, 1, 0, '2016-06-21 10:57:59', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(111, 166, 40.777176, -73.954018, 'Francesca', 'Pagano', 'fcp16@me.com', '219 East 84th Street 4C', 'New York', 'New York', '10028', '9178172822', 0, '', 'Francesca C Pagano', '1711', '1980-01-16', '184715261', 'New York', '1980-01-16', '', '', '', '', 'Graduated', 'Graduated', 15, 10, 'Transport', 1, 1, 0, '2016-06-21 10:59:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(112, 169, 0.000000, 0.000000, 'Elizabeth', 'Brown', 'fairfaxb@hotmail.com', '333 West 22nd street', 'New York', 'New York', '10011', '3479223551', 0, '', 'Elizabeth Fairfax Brown', '8387', '1972-12-05', '962714673', 'New York', '2018-12-05', '', '', '', '', 'Graduated', 'Graduated', 20, 20, 'Transport,Anything else', 1, 1, 0, '2016-06-21 12:04:14', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(113, 170, 34.185616, -84.502052, 'Rhiannon', 'Briggs', 'rhiannonmbriggs@hotmail.com', '4400 hickory point dr', 'canton ', 'Georgia', '30115', '7708625816', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(114, 171, 34.106106, -118.463745, 'Brianna', 'Williams', 'b.williams850@yahoo.com', '4305 Rutherford Glen Circle', 'Atlanta', 'Georgia', '30310', '7137033002', 0, '', 'Brianna Marie Williams', '4141', '1992-04-16', '055706274', 'Georgia', '2020-04-17', '', '', '', '', 'Graduated', 'Graduated', 6, 2, 'Transport', 1, 1, 0, '2016-06-21 12:45:23', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(115, 172, 33.895607, -84.596939, 'Victoria ', 'Lash', 'serendipity736@gmail.com', '1411 Glynn Oaks Drive ', 'Marietta ', 'Armed Forces Europe', '30008', '6786877924', 0, '', 'Victoria  Kirsten  Lash', '5331', '1981-10-08', '054243676', 'Armed Forces Europe', '2016-10-08', '', '', '', '', 'Graduated', 'Graduated', 15, 2, 'Transport', 1, 1, 0, '2016-06-21 13:06:03', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(116, 173, 33.540436, -84.071671, 'Ricardo', 'Willis', 'rickyw796@gmail.com', '7706084841', 'mcdonough', 'Georgia', '30252', '7706084841', 0, '', 'Ricardo Sean Willis', '8858', '1982-12-09', '056881217', 'Georgia', '2018-06-08', '', '', '', '', 'Attended', 'Attended', 12, 2, 'Transport , Anything else', 1, 1, 0, '2016-06-21 13:27:14', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(117, 175, 40.630390, -74.151688, 'Kesia', 'Poole', 'kesiashani@icloud.com', '157 harrison avenue', 'staten island ', 'New York', '10302', '9293400542', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(118, 177, 39.100941, -121.630104, 'Jodi', 'John', 'jodilynn0511@gmail.com', '214 Sunridge St ', 'Playa del Rey', 'California', '90293', '5303000763', 0, '', 'Jodi Lynn John', '3598', '1987-12-29', '6581253', 'California', '2017-12-29', '', '', '', '', 'Graduated', 'Graduated', 10, 4, 'Transport,Anything else', 1, 1, 0, '2016-06-21 14:24:36', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(119, 178, 40.813236, -73.940292, 'Yseult', 'Polfliet', 'ypolfliet@gmail.com', '40 west ', 'manhattan ', 'New York', '10037', '6095766606', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(120, 176, 33.597252, -84.318459, 'Loleka', 'Hudson ', 'Lolekah@gmail.com', '1380 interlaken pass ', 'Jonesboro ', 'Georgia', '30238', '3364570430', 0, '', 'Loleka Arlean  Hudson', '4159', '1988-12-19', '060104198', 'Georgia', '2023-12-19', '', '', '', '', 'Graduated', 'Attended', 6, 3, 'Transport', 1, 1, 0, '2016-06-22 21:54:48', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(121, 174, 34.194710, -118.500305, 'Jessica', 'Caceres', 'jessmcaceres@yahoo.com', '6825 mclennan ave ', 'lake balboa', 'California', '91406', '8188499593', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(122, 167, 34.106194, -118.463364, 'Christian', 'Allemand', 'christianallemand91@gmail.com', '1482 derby downs', 'lawrenceville ', 'Georgia', '30043', '4044347941', 0, '', 'Christian Rand Allemand', '0100', '1991-10-21', '053953284', 'Georgia', '2021-10-21', '', '', '', '', 'Graduated', 'Attended', 0, 0, 'Transport', 1, 1, 0, '2016-06-21 16:19:18', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(123, 180, 40.749535, -73.936615, 'Melanie', 'Binet', 'melalexa88@gmail.com', '11150 76th Rd', 'Forest Hills', 'New York', '11375', '5163757956', 0, '', 'Melanie A Binet', '5872', '1988-12-28', '856861116', 'New York', '2017-12-29', '', '', '', '', 'Graduated', 'Graduated', 6, 4, 'Transport', 1, 1, 0, '2016-06-21 16:51:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(124, 181, 34.024956, -83.967476, 'Hailey', 'Brock', 'hb_080995@icloud.com', '1870 fox ridge drive', 'Hoschton ', 'Georgia', '30548', '6784464892', 0, '', 'Hailey Diana christine Brock', '5479', '1995-08-09', '057053590', 'Georgia', '2017-08-09', '', '', '', '', 'Attended', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-21 17:13:41', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(125, 182, 33.443031, -84.170013, 'Alexis', 'Hart', 'lexihart1216@gmail.com', '2505 flowers creek drive', 'mcdonough ', 'Georgia', '30253', '4043246252', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(126, 185, 33.982494, -118.383827, 'Darius', 'Byrd', 'dbyrd10@hotmail.com', '6100 Canterbury Dr Apt 111', 'Culver City', 'California', '90230', '2533895939', 0, '', 'Darius Davon Byrd', '6122', '1994-08-18', '3467989', 'Washington', '1994-08-19', '', '', '', '', 'Graduated', 'Attended', 3, 0, 'Transport', 1, 1, 0, '2016-06-21 19:33:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(127, 188, 34.105980, -118.463867, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2001 Rocomare Rd', 'Los Angeles ', 'California', '90077', '2038879349', 0, '', 'Kimberly Elizabeth Idoko', '8825', '1983-07-28', '755676670', 'New York', '2021-07-28', '', '', '', '', 'Graduated', 'Graduated', 8, 0, 'Transport , Anything else', 1, 1, 0, '2016-06-21 21:32:20', 0, 7, 3, 1300, '9326', 'acct_18P1EIHM8u5dOm2Q', 'btok_8gO1cs5coTVPoR', 'ba_18P1FAHM8u5dOm2QqHHaZsmC', 0, '2016-06-28 07:53:10', 1);
INSERT INTO `qProvider` (`qId`, `userId`, `currentLat`, `currentLong`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipCode`, `mobile`, `isMobileVerified`, `mobileVerificationCode`, `nameOnDL`, `socialSecurityNo`, `dateOfBirth`, `dlNo`, `dlState`, `dateOfDlExpiration`, `highSchoolName`, `highSchoolCity`, `highSchoolState`, `highSchoolYOGrad`, `hsInfo`, `collegeInfo`, `totalYearOfProfExp`, `personalAssistantExp`, `roleOfQ`, `isStateDisclouserAcknowledged`, `isBackgroundCheckAuthorized`, `isQVerified`, `registrationDate`, `isQOnline`, `registrationStepCompleted`, `TotalRequestCompleted`, `TotalPaymentReceived`, `qBankAccountNumber`, `qStripeId`, `qStripeBankTokenId`, `qStripeBankId`, `isPerformingRequest`, `LastRequestSent`, `isDeleted`) VALUES
(128, 189, 0.000000, 0.000000, 'Diane', 'Lester', 'dmlester21@gmail.com', '468 6th avenue ', 'brooklyn', 'New York', '11215', '7033177869', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(129, 156, 40.708553, -73.958115, 'Equanda', 'Willis', 'quandak282@gmail.com', '190 Marcy avenue 20D', 'Brooklyn', 'New York', '11211', '3473044544', 0, '', 'Equanda Kyra Willis', '5563', '1978-02-28', '524965888', 'New York', '2019-05-23', '', '', '', '', 'Attended', 'Graduated', 14, 9, 'Transport', 1, 1, 0, '2016-06-22 02:30:10', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(130, 5, 21.148027, 72.760735, 'Vimal', 'Gajera', 'lanetteam.vimalgajera@gmail.com', 'Florida', 'Florida', 'Florida', '12369', '9998078073', 0, '', 'Vimal G Gajera', '8957', '2007-06-22', '57900022', 'Florida', '2016-06-22', '', '', '', '', 'Attended', 'Attended', 2, 2, 'Anything else', 1, 1, 0, '2016-06-22 03:15:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(131, 192, 0.000000, 0.000000, 'Caitlin', 'Siney', 'caitlinsiney@gmail.com', '1160 Hammond Drive', 'Sandy Springs ', 'Georgia', '30328', '6102031445', 0, '', 'Caitlin Siney', '9752', '1992-12-16', '103381838', 'South Carolina', '2014-08-22', '', '', '', '', 'Graduated', 'Graduated', 6, 3, 'Transport', 1, 1, 0, '2016-06-22 08:46:34', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(132, 190, 40.752159, -73.925560, 'Elisha', 'Sostre', 'lisha1018@gmail.com', '9221 foster Avenue ', 'Brooklyn ', 'New York', '11236', '9293652284', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(133, 199, 33.409576, -84.404259, 'Stephanie ', 'Skinner', 'stephanie32391@gmail.com', '125 Sterling Way', 'Fayetteville', 'Georgia', '30215', '6786508848', 0, '', 'Stephanie Lynne Skinner', '7602', '1991-03-23', '055761690', 'Georgia', '2017-03-23', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport', 1, 1, 0, '2016-06-22 21:10:00', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(134, 201, 34.097843, -118.003860, 'Lola', 'Lopez', 'lola9lopez@gmail.com', '5368 La Madera Avenue ', 'El Monte ', 'California', '91732', '6266930169', 0, '', 'Lola Lopez', '3013', '1995-02-28', '31084014', 'California', '2017-03-01', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-22 22:04:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(135, 202, 32.877438, -84.320618, 'Montana', 'Pickens', 'mpickens2014@yahoo.com', '606 peachtree dr', 'thomaston', 'Georgia', '30286', '7067410591', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(136, 203, 0.000000, 0.000000, 'Joi', 'Allen', 'joi.allen210@yahoo.com', '97 Caboose Court', 'Lawrenceville', 'Georgia', '30044', '5743443401', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(137, 206, 0.000000, 0.000000, 'Charity', 'Wise', 'charityiswise@gmail.com', '4898 Matteo Trail ', 'orlNdo ', 'Florida', '32839', '2026158832', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(138, 207, 40.808308, -73.943962, 'Leanne', 'Stella', 'lstella147@aol.com', '64 w 127th Street 1', 'New York', 'New York', '10027', '9172734405', 0, '', 'Leanne Stella', '7473', '1966-03-24', '161600139', 'New York', '2016-08-21', '', '', '', '', 'Attended', 'Attended', 20, 2, 'Transport', 1, 1, 0, '2016-06-23 08:05:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(139, 210, 40.676178, -74.287575, 'Dailyn', 'Santana', 'santanadaii@gmail.com', '622 Kingston Avenue', 'kenilworth ', 'New Jersey', '07033', '9082175067', 0, '', 'Dailyn Santana', '2864', '1991-03-20', '04811500053912', 'New Jersey', '2018-08-31', '', '', '', '', 'Graduated', 'Graduated', 9, 5, 'Transport,Anything else', 1, 1, 0, '2016-06-23 12:47:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(140, 211, 33.672062, -84.388428, 'Monique', 'Williams', 'moniqueshavon@gmail.com', '183 mount zion road', 'atlanta', 'Georgia', '30354', '6785232604', 0, '', 'Monique Shavon Williams', '7339', '1983-01-23', '050717622', 'Georgia', '2019-01-24', '', '', '', '', 'Graduated', 'Graduated', 12, 10, 'Transport', 1, 1, 0, '2016-06-23 13:01:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(141, 212, 33.701199, -84.259621, 'Darius', 'Taylor', 'dariustaylor16@gmail.com', '3957 Covington Hwy Apt K', 'decatur', 'Georgia', '30032', '6782879404', 0, '', 'Darius Rashad Taylor', '7367', '1996-01-21', '058557449', 'Georgia', '2020-01-21', '', '', '', '', 'Graduated', 'Attended', 3, 0, 'Transport', 1, 1, 0, '2016-06-23 13:11:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(142, 209, 0.000000, 0.000000, 'Elina', 'Stella', 'elinastella9@gmail.com', '64 west 127th st', 'new york', 'New York', '10027', '9175754425', 0, '', 'Elina Stella', '0404', '1996-09-10', '0000', 'New York', '1996-09-11', '', '', '', '', 'Attended', 'Attended', 4, 0, 'Transport', 1, 1, 0, '2016-06-24 16:44:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(143, 214, 33.815136, -118.195518, 'Romaldo', 'Arteaga', 'romyazteka7@gmail.com', '3190 chestnut ave', 'long beach', 'California', '90806', '5622907557', 0, '', 'Romaldo M Arteaga', '5883', '1989-09-04', '7323203', 'California', '1989-09-05', '', '', '', '', 'Attended', 'Attended', 1, 0, 'Transport', 1, 1, 0, '2016-06-23 13:58:42', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(144, 215, 34.156727, -118.455536, 'Josh', 'Mann', 'jsmact@gmail.com', '4717 Willis Ave Apt 18', 'sherman oaks ', 'California', '91403', '3108509839', 0, '', 'Joshua Samuel Mann', '8437', '1979-01-30', '4943704', 'California', '2018-01-31', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport', 1, 1, 0, '2016-06-23 15:03:04', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(145, 216, 0.000000, 0.000000, 'Jai', 'Patel', 'jaipatel850@gmail.com', '2600 Milscott Drive', 'Decatur', 'Georgia', '30033', '8503778952', 0, '', 'Jai Patel', '5557', '1991-11-14', '060067347', 'Georgia', '2023-11-14', '', '', '', '', 'Graduated', 'Graduated', 3, 0, 'Transport', 1, 1, 0, '2016-06-23 15:52:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(146, 217, 33.931328, -84.268852, 'Alisha', 'Watkins', 'alishakenshe@icloud.com', '112 Stoneview Dr', 'Lilburn', 'Georgia', '30047', '6789797024', 0, '', 'Alisha Watkins', '1596', '1993-08-15', '056410984', 'Georgia', '2016-08-16', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Transport,Anything else', 1, 1, 0, '2016-06-23 16:34:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(147, 219, 42.401676, -83.229889, 'Alicia', 'Hosey', 'alicia.hosey7@gmail.com', '1932 Rochester cir', 'los angeles', 'California', '90018', '3232517866', 0, '', 'Alicia Diane Hosey', '7807', '1980-01-19', '1208050', 'California', '2021-01-20', '', '', '', '', 'Graduated', 'Graduated', 20, 15, 'Transport', 1, 1, 0, '2016-06-23 18:20:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(148, 221, 40.754398, -73.880157, 'Deshawn ', 'Millien ', 'deshawnmillien97@gmail.com', '87 09 34th ave apt 2d', 'jackson heights ', 'New York', '11372', '7186631598', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(149, 222, 40.690674, -74.092804, 'Yasmine', 'Christian', 'y.christian312@hotmail.com', '108 brown pl', 'jersey city', 'New Jersey', '07305', '2015899013', 0, '', 'Yasmine Monique Christian', '1789', '1991-03-11', '36587897453912', 'New Jersey', '2017-10-31', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Anything else', 1, 1, 0, '2016-06-23 22:09:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(150, 223, 34.016083, -118.813049, 'Merlin', 'Vinegradova', 'merlinvinegradova@gmail.com', '29500 heathercliff rd', 'malibu', 'California', '90265', '3233339554', 0, '', 'Merlin Moss Vinegradova', '0083', '1994-11-06', '2256887', 'California', '2019-11-07', '', '', '', '', 'Graduated', 'Graduated', 3, 1, 'Transport', 1, 1, 0, '2016-06-23 22:08:10', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(151, 224, 33.447369, -84.163383, 'Cassandra', 'Ball', 'cassandrakball@yahoo.com', '1002 Mark Trail', 'McDonough', 'Georgia', '30253', '4049532117', 0, '', 'Cassandra Katrina Ball', '0396', '1985-02-05', '059087008', 'Georgia', '2019-02-06', '', '', '', '', 'Graduated', 'Attended', 12, 6, 'Transport', 1, 1, 0, '2016-06-24 04:00:23', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(152, 226, 41.967712, -88.203247, 'Jessica', 'Alexander', 'jeshalex23@gmail.com', '5305 indian hills drive', 'simi valley', 'California', '93063', '6304006824', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(153, 227, 40.708912, -74.000984, 'Yamel', 'Favela', 'ya.fav@me.com', '3325 111th st ', 'corona ', 'New York', '11368', '3475754836', 0, '', 'Yamel Manuela Faveladelgadillo', '4544', '1994-06-05', '112573137', 'New York', '2020-06-06', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport,Anything else', 1, 1, 0, '2016-06-24 13:10:20', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(154, 228, 40.701675, -73.987732, 'Sarah', 'Aviles', 'sarahaviles10@yahoo.com', '2940 west 31st street Apt 12C', 'Brookyn', 'New York', '11224', '9174369769', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(155, 229, 42.365627, -71.103729, 'Sarah', 'Crain', 'ms.sarahdc@gmail.com', '61 Marshall Street 1R', 'Somerville ', 'Massachusetts', '02145', '5183214881', 0, '', 'Sarah Rose Diblasicrain', '7637', '1988-12-17', '76976572', 'Massachusetts', '2019-12-18', '', '', '', '', 'Graduated', 'Graduated', 3, 0, 'Transport', 1, 1, 0, '2016-06-24 14:07:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(156, 225, 34.023811, -84.043373, 'Olajauwon ', 'Andrews', 'olajauwon27@gmail.com', '2210 Park Estates Dr', 'Snellville', 'Georgia', '30078', '2162174450', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(157, 230, 34.010071, -118.438721, 'Paulo R', 'Abesamis', 'pau.is.fit5@gmail.com', '830 n Acacia st apt 5', 'inglewood', 'California', '90302', '8186755243', 0, '', 'Pauloroman Roa Abesamis', '3545', '1985-05-11', 'D9203235', 'California', '2021-05-11', '', '', '', '', 'Attended', 'Attended', 3, 3, 'Transport', 1, 1, 0, '2016-06-24 21:02:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(158, 232, 33.514214, -84.362617, 'Ericka', 'Andrews', 'ericka_martin91@outlook.com', '2210 Park Eatates Drive ', 'Snellville', 'Georgia', '30078', '6789000701', 0, '', 'Ericka Shanell Andrews', '5738', '1991-12-25', '054065529', 'Georgia', '2019-12-26', '', '', '', '', 'Graduated', 'Attended', 3, 3, 'Transport', 1, 1, 0, '2016-06-26 10:50:05', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(159, 235, 34.103451, -118.302261, 'Candace', 'Carter', 'candycolette@gmail.com', '1759 winona blvd 2', 'los angeles', 'California', '90027', '8187383337', 0, '', 'Candace Carter', '2436', '1980-07-08', '7392052', 'California', '2019-07-09', '', '', '', '', 'Attended', 'Attended', 14, 14, 'Transport', 1, 1, 0, '2016-06-26 19:58:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(160, 236, 34.106140, -118.463898, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '2001 roscomare rd ', 'los angeles', 'California', '90077', '8184658228', 0, '', 'Kimberly Odigie', '8870', '1987-07-27', '48461648', 'Delaware', '2020-07-28', '', '', '', '', 'Graduated', 'Graduated', 2, 0, 'Transport,Anything else', 1, 1, 0, '2016-06-26 22:56:21', 0, 7, 1, 0, '1273', 'acct_18R4brJdEvzd2B0W', 'btok_8iw78X07ZxxCsz', 'ba_18RUFAJdEvzd2B0WhrdPHvp6', 0, '2016-06-28 17:02:13', 1),
(161, 237, 33.760777, -84.333336, 'Michael', 'Galloway', 'buckcitynow@gmail.com', '421 summer hill circle', 'stockbridge', 'Georgia', '30281', '8044055055', 0, '', 'Michael James Galloway', '1286', '1986-05-09', '050613506', 'Georgia', '2017-05-10', '', '', '', '', 'Graduated', 'Attended', 12, 5, 'Transport', 1, 1, 0, '2016-06-27 08:56:46', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(162, 238, 40.649364, -73.958435, 'Antonett', 'Young', 'ayoung81@aol.com', '420 East 21st Street apt103', 'Brooklyn', 'New York', '11226', '3478161779', 0, '', 'Antonett A Young', '6961', '1981-03-12', '906948547', 'New York', '2018-03-12', '', '', '', '', 'Graduated', 'Attended', 10, 1, 'Transport', 1, 1, 0, '2016-06-27 11:01:17', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(163, 234, 33.576809, -84.501366, 'Tanika', 'Kennedy', 'tanikakennedy@yahoo.com', '215 basswood court ', 'college park', 'Georgia', '30349', '6787990823', 0, '', 'Tanika Lasha Kennedy', '5598', '1993-02-20', '055449899', 'Georgia', '2017-02-21', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport', 1, 1, 0, '2016-06-27 11:09:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(164, 239, 29.522718, -98.501717, 'Felix', 'Odigie', 'felix@myqapp.com', '2001 Roscomare rd', 'los angeles', 'California', '90077', '6173881912', 0, '', 'Felix Im Odigie', '3964', '1976-09-30', 'y3418929', 'California', '2022-10-02', '', '', '', '', 'Graduated', 'Graduated', 8, 9, 'Transport,Anything else', 1, 1, 1, '2016-06-27 22:23:28', 0, 7, 2, 0, '9326', 'acct_18RDZwJk4TAQKJ7C', 'btok_8iysZWzZUYmShK', 'ba_18RWuLJk4TAQKJ7CFaGrUxJj', 0, '2016-07-07 01:55:01', 0),
(165, 241, 28.308712, -81.360764, 'Jessenia', 'Carrasquillo', 'jcarrasquillo90@icloud.com', '1160 hammond drive unit 301', 'sandy springs ', 'Georgia', '30328', '4049914198', 0, '', 'Jessenia Amada Carrasquillo', '9843', '1990-09-22', '059337304', 'Georgia', '2019-09-23', '', '', '', '', 'Graduated', 'Attended', 5, 3, 'Transport', 1, 1, 0, '2016-06-28 01:41:02', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(166, 242, 40.907738, -111.872368, 'Barbara', 'Horsley', 'barbiebabe115@gmail.com', '410 east 900 south', 'centerville', 'Utah', '84014', '8018886538', 0, '', 'Barbara Lee Horsley', '7814', '1997-01-07', '196050967', 'Utah', '2018-01-07', '', '', '', '', 'Attended', 'Attended', 6, 4, 'Transport , Anything else', 1, 1, 0, '2016-07-01 03:01:15', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(167, 245, 34.106251, -118.463783, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2001 Roscomare Rd', 'los angeles', 'California', '90077', '2038879349', 0, '', 'Kimberly Elizabeth Idoko', '8825', '1983-07-27', '755676670', 'New York', '2022-07-28', '', '', '', '', 'Graduated', 'Graduated', 12, 0, 'Transport,Anything else', 1, 1, 1, '2016-06-28 20:02:38', 0, 7, 15, 6432, '9326', 'acct_18RX6ZH40Jarjfbo', 'btok_8iz6gB98jWqLru', 'ba_18RX8OH40JarjfbodX2t0zQ3', 0, '2016-07-07 05:34:30', -1),
(168, 248, 33.650951, -84.451218, 'Kamilah', 'Carter', 'kcarter25@yahoo.com', '4350 Scott Circle', 'East Point', 'Georgia', '30344', '6783589025', 0, '', 'Kamilah Janelle Carter', '1737', '1980-01-09', '054117401', 'Georgia', '2019-01-09', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport , Anything else', 1, 1, 0, '2016-06-30 09:45:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(169, 251, 33.227955, -84.266403, 'Ashley', 'Anthony', 'ashleynnanthony@gmail.com', 'Summit Drive', 'Griffin', 'Georgia', '30224', '7703046301', 0, '', 'Ashley Nicole Anthony', '8886', '1983-11-10', '050288123', 'Georgia', '2016-11-10', '', '', '', '', 'Graduated', 'Graduated', 14, 9, 'Transport,Anything else', 1, 1, 0, '2016-06-30 11:16:41', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(170, 252, 40.740707, -74.184555, 'Ashley', ' Bennia', 'ashley.bennia@gmail.com', '8800 Dunwoody Rd', 'Sandy Springs ', 'Georgia', '30350', '9737276699', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(171, 253, 34.105965, -118.463722, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2001 Roscomare Rd', 'Los Angeles', 'California', '90077', '2038879349', 0, '', 'Kimberly Elizabeth Idoko', '8825', '1983-07-27', '755676670', 'California', '2022-07-28', '', '', '', '', 'Graduated', 'Graduated', 15, 0, 'Transport,Anything else', 1, 1, 1, '2016-07-02 02:47:02', 0, 7, 8, 12170, '1273', 'acct_18Sj6cEJ5ByhSLhE', 'btok_8kDaE5JuV7vwtn', 'ba_18Sj9ZEJ5ByhSLhE63Uqz0H9', 0, '2016-07-06 19:03:20', 0),
(172, 256, 33.920895, -84.561516, 'Taja', 'Jackson', 'hill_taja@yahoo.com', '358 pin oak court ', 'marietta ', 'Georgia', '30008', '4192604385', 0, '', 'Taja M  Hill Jackson ', '0774', '1994-06-11', '060087460', 'Georgia', '2024-06-11', '', '', '', '', 'Attended', 'Attended', 4, 4, 'Transport , Anything else', 1, 1, 0, '2016-07-03 20:12:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(173, 257, 33.776676, -84.301117, 'Jamal', 'Jones', 'jamal.and.jones@gmail.com', '220 Ponce de Leon Pl Unit 443', 'Decatur', 'Georgia', '30030', '6099297013', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(174, 258, 40.612209, -73.945305, 'Jake', 'Montagnino', 'jmonte98@gmail.com', '2823 Avenue P', 'Brooklyn', 'New York', '11229', '3478160721', 0, '', 'Jake Lawrence Montagnino', '1554', '1998-01-22', '253567722', 'New York', '1998-01-22', '', '', '', '', 'Graduated', 'Attended', 3, 5, 'Transport,Anything else', 1, 1, 0, '2016-07-03 22:27:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(175, 259, 40.870617, -73.858742, 'Gina', 'Ramos', 'gramos98@yahoo.com', '3031 Paulding Avenue ', 'Bronx ', 'New York', '10469', '3472556470', 0, '', 'Gina J Ramos', '1514', '1984-09-07', '233929156', 'New York', '2023-09-08', '', '', '', '', 'Graduated', 'Attended', 10, 7, 'Transport,Anything else', 1, 1, 0, '2016-07-03 23:21:33', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(176, 260, 35.453621, -80.848442, 'Michele', 'Sawka', 'michelesawka@gmail.com', '1560 Briarvista Way NE', 'Atlanta', 'Georgia', '30329', '4128979809', 0, '', 'Michele Lynn Sawka', '2718', '1975-09-25', '059616485', 'Georgia', '2020-09-26', '', '', '', '', 'Attended', 'Attended', 10, 5, 'Transport,Anything else', 1, 1, 0, '2016-07-04 00:39:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(177, 261, 33.789444, -84.689316, 'Cecily ', 'White', 'cecilylong19@gmail.com', '3461 Bankhead Hwy', 'Douglasville ', 'Georgia', '30134', '6788306836', 0, '', 'Cecily Francesca LongWhite ', '4765', '1977-09-26', '054469531', 'Georgia', '2018-09-26', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport , Anything else', 1, 1, 0, '2016-07-04 01:32:55', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(178, 231, 33.536110, -84.048462, 'Alyxandra', 'Pinkston', 'alyxandra.pinkston@gmail.com', '2036 FontainBleau Drive', 'Conyers', 'Georgia', '30094', '6782944973', 0, '', 'Alyxandra Marie Pinkston', '8139', '1992-10-26', '055360135', 'Georgia', '2020-10-26', '', '', '', '', 'Graduated', 'Graduated', 2, 6, 'Transport , Anything else', 1, 1, 0, '2016-07-04 11:22:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(179, 262, 0.000000, 0.000000, 'Taycia', 'Orr', 'taycia675@gmail.com', '200 throop avenue ', 'brooklyn ', 'New York', '11206', '7187089275', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(180, 265, 34.075768, -117.879509, 'Wesley', 'Reeves', 'Wesrvs25@yahoo.com', '769 Peachtree lane', 'Covina', 'California', '91723', '6268064841', 0, '', 'Wesley Nakata Reeves', '4467', '1990-03-22', 'D9114307', 'California', '2017-03-22', '', '', '', '', 'Graduated', 'Graduated', 8, 0, 'Transport , Anything else', 1, 1, 0, '2016-07-04 16:59:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(181, 266, 44.748878, -93.218567, 'Dan', 'Walters', 'danwalters6@gmail.com', '13868 granada ave ', 'apple valley', 'Minnesota', '55124', '6513685913', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(182, 267, 40.676857, -73.780006, 'Adrienne', 'Moore', 'Admoore23@aol.com', '16114 128th Avenue ', 'Jamaica', 'New York', '11434', '9175098032', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(183, 268, 33.670513, -84.370186, 'Avery', 'Calhoun', 'averycalhoun62@gmail.com', '550 hutchens rd se', 'atlanta', 'Georgia', '30354', '4706850090', 0, '', 'Avery Deshon Calhoun', '7545', '1996-07-29', '058879515', 'Georgia', '2018-07-30', '', '', '', '', 'Attended', 'Attended', 3, 3, 'Anything else', 1, 1, 0, '2016-07-04 15:54:05', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(184, 269, 42.372738, -87.869438, 'Jordan', 'Welder', 'jordanwelder09@gmail.com', '918 N Pioneer Rd Apt 1C', 'Waukegan', 'Illinois', '60085', '5159713593', 0, '', 'Jordan Welder', '4045', '1990-08-31', '161bb7992', 'Iowa', '2018-08-31', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Anything else', 1, 1, 0, '2016-07-04 16:18:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(185, 271, 33.765968, -84.768478, 'Crystal', 'Perkins', 'crystalcperkins@icloud.com', '1603 Wembley Dr', 'Douglasville', 'Georgia', '30134', '6785279905', 0, '', 'Crystal Cherise Perkins', '5309', '1991-09-26', '058468717', 'Georgia', '1991-09-27', '', '', '', '', 'Graduated', 'Attended', 8, 4, 'Transport,Anything else', 1, 1, 0, '2016-07-04 19:05:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(186, 272, 40.648502, -75.012558, 'Gilda', 'Palacios', 'gildapalacios18@gmail.com', '11131 172nd St 2 Fl', 'Jamaica', 'New York', '11433', '9294423124', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(187, 273, 0.000000, 0.000000, 'Nykiah', 'Morgan', 'nikkim2@msn.com', '854 sharon lane', 'westbury', 'New York', '11590', '5168526639', 0, '', 'Nykiah Morgan', '5916', '1976-11-14', '174620724', 'New York', '2020-11-15', '', '', '', '', 'Graduated', 'Graduated', 13, 13, 'Transport,Anything else', 1, 1, 0, '2016-07-05 05:06:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(188, 275, 33.590199, -84.491798, 'Michelle ', 'Mosley', 'chelle_4334@yahoo.com', '3200 broadleaf ', 'Atlanta ', 'Georgia', '30349', '4049096627', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(189, 276, 40.706715, -73.909668, 'Jeszenia', 'Jimenez', 'jvjimenez76@yahoo.com', '1878 Bleecker Street', 'Flushing', 'New York', '11385', '9177956847', 0, '', 'Jeszenia V Jimenez', '6466', '1976-07-20', '759586988', 'New York', '2017-07-20', '', '', '', '', 'Graduated', 'Graduated', 19, 5, 'Transport , Anything else', 1, 1, 0, '2016-07-05 16:30:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(190, 277, 40.711098, -73.963943, 'Janiella', 'Franklyn', 'janiellafranklyn11@newdesignhigh.com', '500 Mother Gaston Blvd', 'brooklyn', 'New York', '11212', '3478560739', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(191, 281, 34.233917, -118.565132, 'Ashlyn', 'Nichols', 'ashlyn.nichols@icloud.com', '212 W Garfield St', 'Glendale', 'California', '91204', '13103497018', 0, '', 'Ashlyn Christina Nichols', '2649', '1993-05-22', '8117500', 'California', '2019-05-23', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Transport,Anything else', 1, 1, 0, '2016-07-05 12:14:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(192, 283, 33.343716, -84.201904, 'Shernette', 'Hyatt', 'shernettehyatt@gmail.com', '6089 golf view crossing ', 'locust grove ', 'Connecticut', '30248', '5163680282', 0, '', 'Shernette Reneta Hyatt', '1224', '1982-02-01', '059716336', 'Georgia', '2023-02-02', '', '', '', '', 'Attended', 'Attended', 5, 1, 'Transport,Anything else', 1, 1, 0, '2016-07-05 14:36:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(193, 285, 40.715099, -74.006721, 'Michelle', 'Mayer', 'mellymay643@gmail.com', '7524 11th ave', 'brooklyn', 'New York', '11228', '9175334203', 0, '', 'Michelle Bernadette Mayer', '3333', '1994-09-05', '090128573', 'New York', '1994-09-06', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Anything else', 1, 1, 0, '2016-07-05 14:20:21', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(194, 284, 34.079906, -84.314163, 'Matthew', 'Mcdearmont', 'mmcdearmont@gmail.com', '6001 Lexington Farms Drive', 'Alpharetta', 'Georgia', '30004', '7706807774', 0, '', 'Matthew Bradly Mcdearmont', '0020', '1964-01-14', '053651246', 'Georgia', '2018-01-15', '', '', '', '', 'Graduated', 'Graduated', 30, 2, 'Transport,Anything else', 1, 1, 0, '2016-07-05 14:31:55', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(195, 286, 34.178314, -118.361771, 'Adam', 'Silverstrim ', 'ajsilverstrim@gmail.com', '5921 Cahuenga Blvd Apt 3', 'North Hollywood ', 'California', '91601', '6178187846', 0, '', 'Adam Jacob Silverstrim ', '2050', '1996-09-23', 'Y4293683', 'California', '2017-09-23', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport , Anything else', 1, 1, 0, '2016-07-05 14:49:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(196, 292, 33.527081, -84.373238, 'Teresa', 'Brown', 'tree866@gmail.com', '10602 Almosa Ln', 'Jonesboro', 'Georgia', '30238', '4049529687', 0, '', 'Teresa Melonie Brown', '9376', '1975-02-15', '056978100', 'Georgia', '2020-02-16', '', '', '', '', 'Graduated', 'Graduated', 21, 15, 'Transport', 1, 1, 0, '2016-07-05 18:59:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(197, 293, 33.888073, -84.564499, 'Parasia', 'Cook', 'parasiac@gmail.com', '2665 favor rd 2c01', 'marietta', 'Georgia', '30060', '6784994324', 0, '', 'Paresia Chevell Cook', '1610', '1981-08-04', '066184689', 'Georgia', '2020-08-04', '', '', '', '', 'Attended', 'Attended', 10, 10, 'Transport , Anything else', 1, 1, 0, '2016-07-05 19:04:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(198, 294, 40.666626, -73.864685, 'Brincisky', 'Quinonez', 'brincisky@gmail.com', '1258 loring ave', 'brooklyn', 'New York', '11208', '3476846243', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(199, 298, 40.721775, -73.838715, 'Jessica', 'Braunstein', 'jsbraunstein1@gmail.com', '7140 112th Street Apt 403', 'Forest Hills', 'New York', '11375', '5163828705', 0, '', 'Jessica Eve Braunstein', '0255', '1990-09-29', '402397075', 'New York', '2019-09-29', '', '', '', '', 'Graduated', 'Graduated', 4, 4, 'Transport,Anything else', 1, 1, 0, '2016-07-06 14:00:32', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(200, 299, 34.157585, -118.376129, 'Rebecca', 'Clouse', 'beccaclouse@gmail.com', '11244 Camarillo St', 'West Toluca Lake', 'California', '91602', '9166072043', 0, '', 'Rebecca Clouse', '6098', '1990-02-12', '8716533', 'California', '2020-02-13', '', '', '', '', 'Graduated', 'Graduated', 4, 3, 'Transport,Anything else', 1, 1, 0, '2016-07-06 04:29:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(201, 300, 32.369133, -84.964363, 'Tyneshia', 'Pitts', 'tyandnas@gmail.com', '2302 Enon Rd', 'Atlanta', 'Georgia', '30331', '7064617790', 0, '', 'Tyneshia Rene Pitts', '1238', '1983-02-24', '051776077', 'Georgia', '2023-02-24', '', '', '', '', 'Graduated', 'Attended', 15, 10, 'Transport , Anything else', 1, 1, 0, '2016-07-06 04:45:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(202, 301, 40.856991, -73.899651, 'Ashley', 'Amarante', 'ashleya0730@gmail.com', '2274 Grand Concourse ave 5F', 'bronx', 'New York', '10457', '3475069691', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(203, 304, 33.892307, -84.481636, 'Arian', 'Sanders', 'asanders5138@gmail.com', '2350 Cobb Parkway SE Apt 1K', 'Smyrna', 'Georgia', '30080', '9122282051', 0, '', 'Arian Claudette Sanders', '5138', '1989-03-18', '052112144', 'Georgia', '2020-03-19', '', '', '', '', 'Graduated', 'Graduated', 4, 0, 'Transport,Anything else', 1, 1, 0, '2016-07-06 13:22:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(204, 307, 34.060181, -118.415672, 'Jacqueline', 'Diaz', 'diaz.jackie78@gmail.com', '3714 Roderick Rd ', 'Los Angeles', 'California', '90065', '6193095286', 0, '', 'Jacqueline Diaz', '4943', '1978-01-11', '7267908', 'California', '2018-01-12', '', '', '', '', 'Attended', 'Attended', 15, 10, 'Transport,Anything else', 1, 1, 0, '2016-07-06 14:59:02', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(205, 311, 40.658699, -73.878662, 'Alex', 'Junior', 'alexbadine1@yahoo.com', '1007 Warwick St', 'brooklyn', 'New York', '11207', '3477755975', 0, '', 'Alex Trevon Badine', '0952', '1997-06-30', '903402107', 'New York', '1997-07-01', '', '', '', '', 'Graduated', 'Attended', 0, 1, 'Transport', 1, 1, 0, '2016-07-06 19:04:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(206, 310, 40.879875, -73.898109, 'Janel', 'Wallace', 'jjwallac@aggies.ncat.edu', '3403 Cannon place', 'Bronx', 'New York', '10463', '9803228502', 0, '', 'Janel Jessica Wallace', '0787', '1991-12-31', '36046236', 'North Carolina', '2019-12-31', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 0, '2016-07-06 19:14:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(207, 314, 35.233551, -89.980629, 'Ibinka', 'Stone', 'fullfigureblackbarbie@gmail.com', '3942 Brooksville Dr', 'Memphis', 'Tennessee', '38127', '9013149946', 0, '', 'Ibinka Sade Neilly', '8516', '1986-05-05', '096287232', 'Tennessee', '2021-05-05', '', '', '', '', 'Graduated', 'Graduated', 10, 4, 'Transport , Anything else', 1, 1, 0, '2016-07-06 21:35:58', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(208, 318, 0.000000, 0.000000, 'Nina', 'Blake', 'ninasimone.mb@gmail.com', '50 fleetwood ave', 'mount vernon', 'New York', '10552', '9145229912', 0, '', 'Ninasimone May Blake', '8184', '1994-03-17', '432258371', 'New York', '2023-03-18', '', '', '', '', 'Graduated', 'Attended', 7, 10, 'Transport,Anything else', 1, 1, 0, '2016-07-07 06:52:28', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(209, 320, 40.809921, -73.943420, 'Meaghan', 'Mcleod', 'meaghan.mcleod@yahoo.com', '60 west 129th st', 'NY', 'New York', '10027', '9144717382', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(210, 321, 40.944855, -73.894066, 'Jassiah', 'Mcnulty', 'jassiah96@gmail.com', '300 north broadway', 'yonkers ', 'New York', '10701', '9147519937', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(211, 322, 34.270233, -118.678009, 'Liqun', 'Cai', 'cailiqun123@gmail.com', '1830 Yosemite Ave 210B', 'Simi Valley', 'California', '93063', '8053589458', 0, '', 'Liqun Cai', '8637', '1990-05-27', '8078743', 'California', '1990-05-28', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Transport,Anything else', 1, 1, 0, '2016-07-07 12:44:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(212, 323, 40.695885, -73.944695, 'Priya', 'Bond', 'bondpriyabond@gmail.com', '930 Myrtle Avenue', 'Brooklyn', 'New York', '11206', '8157157079', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(213, 288, 0.000000, 0.000000, 'Kirstin', 'Smith', 'kirstinsmith1420@gmail.com', '1420 pacific ave apt 5 ', 'venice', 'California', '90291', '3105910707', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(214, 325, 40.736671, -73.991142, 'Brittany', 'Louis', 'louisbrit1990@gmail.com', '8100 river rd apt 1203', 'north bergen', 'New Jersey', '07047', '7329771177', 0, '', 'Brittany Ashley Louis', '8066', '1990-02-05', '68021006152902', 'New Jersey', '2015-03-09', '', '', '', '', 'Graduated', 'Graduated', 3, 2, 'Transport,Anything else', 1, 1, 0, '2016-07-07 17:25:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(215, 326, 34.134895, -118.489510, 'Phil', 'Zaikovatyy ', 'pzaikovatyy@yahoo.com', '14520 Dickens St 309', 'sherman oaks ', 'California', '91403', '8186212531', 0, '', 'Fedor Zaikovatyy', '4268', '1981-04-28', 'A9258483', 'California', '2020-04-28', '', '', '', '', 'Graduated', 'Graduated', 12, 12, 'Anything else', 1, 1, 0, '2016-07-07 17:31:01', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(216, 327, 0.000000, 0.000000, 'Shuneka', 'Andrews', 'shuneka.andrews@gmail.com', '55 Maple ST NW Apt 414', 'Atlanta ', 'Georgia', '30314', '4045429503', 0, '', 'Shuneka Nicholoe Andrews', '2457', '1988-11-06', '052522800', 'Georgia', '2020-11-07', '', '', '', '', 'Attended', 'Attended', 8, 4, 'Transport,Anything else', 1, 1, 0, '2016-07-07 20:59:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(220, 339, 21.170240, 72.831062, 'ishani', 'shah', 'lanetteam.ishani@gmail.com', '49cadde68a33b8fa62a2bf5bd82e35f401bc7a1c10df258c761764fec3e89d2ff01eae5bc640fe051baecb4bbeecc7fergxggY24045jQg21MOMN8EQWRsLFN70fhzgI2gDkiJxDJqEmd28kHyEvPGazT/EM', 'surat', 'gujarat', '396445', '1234567808', 0, '', 'ishani jayeshkumar shah', 'ab9c7cb9754a477ac9575a4157f1e85a3aae50295a0e77b7b67885e5d8bcd78791a41b55b0342e07660c91a4fbda39a5aCcAZS5XSmMBDoTt58wtpw==', '1995-07-14', 'cf5deccc654a2e22c849e800ec0d3efa13a9adaf768d03ec25ff74daf4ad56363fa4bcc04095c19f328bc2989a92067exrZSNIKnPj+HaPNd0edvuw==', 'Gujrat', '2032-01-30', '', '', '', '', 'undefined', 'Attended', 0, 0, 'Anything else,Transport', 1, 1, 0, '2016-07-08 17:43:16', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qRequest`
--

DROP TABLE IF EXISTS `qRequest`;
CREATE TABLE IF NOT EXISTS `qRequest` (
`qRequestId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `currentLat` float(9,6) NOT NULL,
  `currentLong` float(9,6) NOT NULL,
  `isTransport` tinyint(4) NOT NULL COMMENT '1 = Transport request 0 =any thing else request',
  `requestVerb` varchar(50) NOT NULL,
  `requestNoun` varchar(50) NOT NULL,
  `qRequiredTime_Hr` varchar(25) NOT NULL,
  `qRequiredPayment` varchar(255) NOT NULL,
  `numberOfStops` int(11) NOT NULL,
  `isRequiredNow` tinyint(4) NOT NULL DEFAULT '0',
  `qRequiredDate` date NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `requestStatus` int(11) NOT NULL COMMENT '1 = submitted, 2 = accepted, 3 = completed',
  `fine` int(11) NOT NULL,
  `cancelDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=400 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qRequest`
--

INSERT INTO `qRequest` (`qRequestId`, `userId`, `currentLat`, `currentLong`, `isTransport`, `requestVerb`, `requestNoun`, `qRequiredTime_Hr`, `qRequiredPayment`, `numberOfStops`, `isRequiredNow`, `qRequiredDate`, `createdDate`, `requestStatus`, `fine`, `cancelDate`) VALUES
(1, 2, 21.147299, 72.760063, 1, 'Transport', 'Uvucj', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-13 12:16:39', 4, 5, '2016-05-13 12:18:16'),
(2, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:19:53', 4, 0, '2016-05-13 12:20:16'),
(3, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:20:19', 4, 0, '2016-05-13 12:20:32'),
(4, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:20:53', 4, 0, '2016-05-13 12:21:00'),
(5, 1, 21.147301, 72.760056, 0, 'Hybyb', 'Bubuvy', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 12:28:00', 3, 0, '0000-00-00 00:00:00'),
(6, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:43:22', 4, 0, '2016-05-13 12:43:37'),
(7, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:43:47', 4, 0, '2016-05-13 12:43:51'),
(8, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 0, '2016-05-14', '2016-05-13 12:44:10', 4, 0, '2016-05-13 12:44:19'),
(9, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:44:39', 3, 0, '0000-00-00 00:00:00'),
(10, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:46:51', 3, 0, '0000-00-00 00:00:00'),
(11, 1, 21.147522, 72.759933, 0, 'Juvu', 'Bgf', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 12:48:32', 3, 0, '0000-00-00 00:00:00'),
(12, 1, 21.147562, 72.760086, 0, 'Juvu', 'Bgf', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 13:01:03', 3, 0, '0000-00-00 00:00:00'),
(13, 5, 21.147984, 72.760773, 0, 'Dghdbd', 'Hrhdd', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-13 13:24:43', 4, 0, '2016-05-13 13:24:47'),
(14, 5, 21.148182, 72.760818, 0, 'Rhrhhr', 'Bhfhf', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-13 13:25:04', 4, 0, '2016-05-13 13:25:57'),
(15, 5, 21.148485, 72.760918, 0, 'Gdgdb', 'Vfbf', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-13 13:26:15', 3, 0, '0000-00-00 00:00:00'),
(16, 5, 21.147966, 72.760735, 0, 'Kyjt', 'Fbfb', '2-3hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 13:31:54', 3, 0, '0000-00-00 00:00:00'),
(17, 7, 34.106121, -118.463852, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-15 00:26:29', -1, 0, '0000-00-00 00:00:00'),
(18, 7, 34.106197, -118.463829, 0, 'Find', 'Fun', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:53:19', 3, 0, '0000-00-00 00:00:00'),
(19, 7, 34.106197, -118.463837, 0, 'Find', 'Fun', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:57:03', 4, 5, '2016-05-15 00:58:00'),
(20, 7, 34.106197, -118.463837, 0, 'Get', 'Help', '> 3 hrs', '>$300', 0, 0, '2016-05-14', '2016-05-15 00:58:35', -1, 0, '0000-00-00 00:00:00'),
(21, 7, 34.106197, -118.463837, 0, 'Get', 'Food', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:59:07', 4, 0, '2016-05-15 00:59:52'),
(22, 7, 34.106197, -118.463837, 0, 'Get', 'Food', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:59:56', 4, 0, '2016-05-15 01:00:16'),
(23, 6, 34.106140, -118.463760, 0, 'Find', 'Flights', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-15 02:58:27', 4, 0, '2016-05-15 02:59:04'),
(24, 6, 34.106110, -118.463882, 1, 'Transport', 'Food', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-05-15 03:02:17', 4, 0, '2016-05-15 03:03:00'),
(25, 8, 21.148430, 72.760971, 1, 'Transport', 'Computer', '2-3hrs', '$20-100', 2, 0, '0000-00-00', '2016-05-17 11:01:33', -1, 0, '0000-00-00 00:00:00'),
(26, 8, 21.148384, 72.760956, 0, 'Arrange', 'Party', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-17 11:02:37', -1, 0, '0000-00-00 00:00:00'),
(27, 12, 19.387451, -99.209839, 1, 'Transport', 'Plumber', '<1hr', '<$20', 2, 0, '0000-00-00', '2016-05-25 19:05:26', 4, 0, '2016-05-25 19:06:29'),
(28, 1, 34.148685, -118.435608, 1, 'Transport', 'Tequila', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-28 18:10:50', 4, 0, '2016-05-31 07:35:37'),
(29, 14, 0.000000, 0.000000, 1, 'Transport', 'Food', '1-2 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-30 01:57:47', -1, 0, '0000-00-00 00:00:00'),
(30, 14, 0.000000, 0.000000, 0, 'Find', 'Plumbers', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 02:00:31', -1, 0, '0000-00-00 00:00:00'),
(31, 14, 0.000000, 0.000000, 0, 'Find', 'Plumbers', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 02:03:49', 4, 0, '2016-05-30 02:03:59'),
(32, 14, 34.106117, -118.463974, 0, 'Find', 'Flights', '1-2hrs', '$20-100', 0, 0, '2016-05-30', '2016-05-30 03:08:04', -1, 0, '0000-00-00 00:00:00'),
(33, 7, 34.106125, -118.463860, 0, 'Find', 'Plumber', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 21:20:33', 4, 0, '2016-05-30 21:20:48'),
(34, 7, 34.106255, -118.463974, 0, 'Find', 'Plumber', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 21:23:07', 3, 0, '0000-00-00 00:00:00'),
(35, 7, 34.106094, -118.463821, 1, 'Transport', 'Groceries', '< 1 hr', '$20-$100', 2, 0, '0000-00-00', '2016-05-30 21:33:03', 4, 5, '2016-05-30 21:36:46'),
(36, 7, 34.106102, -118.463638, 1, 'Transport', 'Dog', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-30 21:38:55', 4, 5, '2016-05-30 21:40:21'),
(37, 7, 34.106033, -118.463875, 1, 'Transport', 'Eggs', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-30 21:53:21', 3, 0, '0000-00-00 00:00:00'),
(38, 7, 34.106163, -118.463821, 1, 'Transport', 'Fun', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-31 04:36:40', -1, 0, '0000-00-00 00:00:00'),
(39, 1, 21.147598, 72.760063, 0, 'Chjj', 'Kvjc', '2-3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-05-31 09:03:12', 4, 5, '2016-05-31 09:04:21'),
(40, 1, 21.147446, 72.760017, 1, 'Transport', 'Uffufh', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-31 09:06:32', 4, 0, '2016-05-31 09:18:05'),
(41, 1, 21.147488, 72.760048, 1, 'Transport', 'Gigiguc', '2-3 hrs', '$100-$300', 3, 0, '0000-00-00', '2016-05-31 09:19:12', 4, 5, '2016-05-31 09:20:21'),
(42, 2, 21.154499, 72.765198, 1, 'Transport', 'Sdfd', '1-2 hrs', '<$20', 3, 0, '0000-00-00', '2016-05-31 09:26:24', 3, 0, '0000-00-00 00:00:00'),
(43, 2, 21.154499, 72.765198, 1, 'Transport', 'Dxsvfds', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 09:31:53', -1, 0, '0000-00-00 00:00:00'),
(44, 2, 21.154499, 72.765198, 1, 'Transport', 'Dxsvfds', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 09:32:36', -1, 0, '0000-00-00 00:00:00'),
(45, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfd', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 09:35:16', -1, 0, '0000-00-00 00:00:00'),
(46, 2, 21.154499, 72.765198, 1, 'Transport', 'Dfg', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 09:37:14', 4, 0, '2016-05-31 09:37:27'),
(47, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfds', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-31 09:40:23', 4, 0, '2016-05-31 09:40:33'),
(48, 1, 21.147596, 72.760071, 0, 'Jviv', 'Jjvu', '2-3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-05-31 11:18:05', 4, 5, '2016-05-31 11:46:18'),
(49, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfsd', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 11:39:50', 4, 5, '2016-05-31 11:40:48'),
(50, 5, 21.146152, 72.760559, 0, 'Arrange', 'Tickets', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-31 12:07:13', 4, 0, '2016-05-31 12:07:24'),
(51, 2, 21.150225, 72.768677, 1, 'Transport', 'Bchc', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 12:08:35', 2, 0, '0000-00-00 00:00:00'),
(52, 5, 21.146152, 72.760559, 0, 'Arrange', 'Ticket', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-31 12:11:17', 4, 5, '2016-05-31 12:11:59'),
(53, 5, 21.146152, 72.760559, 1, 'Transport', 'Goods', '1-2hrs', '$100-300', 2, 0, '0000-00-00', '2016-05-31 12:36:10', 3, 0, '0000-00-00 00:00:00'),
(54, 5, 21.148094, 72.765564, 0, 'Arrange', 'Pizza', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:34:02', 3, 0, '0000-00-00 00:00:00'),
(55, 5, 21.148094, 72.765564, 0, 'Arrange', 'Painter', '2-3hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:40:05', 3, 0, '0000-00-00 00:00:00'),
(56, 5, 21.148094, 72.765564, 0, 'Arrange', 'Teacher', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:44:02', 3, 0, '0000-00-00 00:00:00'),
(57, 22, 31.894056, -106.576904, 1, 'Transport', 'Me', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-02 23:08:05', -1, 0, '0000-00-00 00:00:00'),
(58, 22, 31.912148, -106.573784, 0, 'Fix', 'Kitchen', '> 3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-06-03 04:19:36', -1, 0, '0000-00-00 00:00:00'),
(59, 18, 34.106068, -118.463791, 1, 'Transport', 'Drycleaning', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-04 22:11:48', 4, 0, '2016-06-04 22:12:23'),
(60, 18, 34.106083, -118.463760, 1, 'Transport', 'Drycleaning', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-04 22:29:57', 4, 0, '2016-06-04 22:33:18'),
(61, 18, 34.106098, -118.463776, 1, 'Transport', 'Drycleaning', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-04 22:33:20', 4, 0, '2016-06-04 22:34:21'),
(62, 7, 34.106220, -118.463791, 1, 'Transport', 'Documents', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-06 04:17:34', 4, 0, '2016-06-06 04:17:52'),
(63, 7, 34.106171, -118.463921, 1, 'Transport', 'Documents', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-06 20:26:35', 3, 0, '0000-00-00 00:00:00'),
(64, 22, 31.826063, -106.523560, 1, 'Transport', 'Carry', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-08 01:45:19', -1, 0, '0000-00-00 00:00:00'),
(65, 22, 31.826086, -106.523552, 1, 'Transport', 'Carry', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-08 01:45:30', -1, 0, '0000-00-00 00:00:00'),
(66, 33, 31.912201, -106.573891, 0, 'Find', 'Plummer', '2-3 hrs', '$100-$300', 0, 0, '2016-06-09', '2016-06-10 22:14:45', 3, 0, '0000-00-00 00:00:00'),
(67, 77, 41.672836, -71.163734, 0, 'Arrange', 'Drycleaning', '< 1 hr', '<$20', 0, 0, '2016-08-13', '2016-06-14 22:30:21', 4, 0, '2016-06-14 22:30:31'),
(68, 117, 34.106148, -118.463852, 0, 'Find', 'Flights', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-16 19:54:05', 4, 0, '2016-06-16 19:54:11'),
(69, 67, 31.912218, -106.573799, 1, 'Transport', 'Flights', '1-2 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-06-17 17:09:30', -1, 0, '0000-00-00 00:00:00'),
(70, 67, 31.912411, -106.600494, 0, 'Looking', 'Landscaper', '> 3 hrs', '>$300', 0, 1, '0000-00-00', '2016-06-17 18:46:17', -1, 0, '0000-00-00 00:00:00'),
(71, 67, 31.912556, -106.600319, 0, 'Find', 'Plumer', '> 3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-06-17 18:48:09', 3, 0, '0000-00-00 00:00:00'),
(72, 67, 31.912571, -106.600243, 0, 'Looking', 'Carperter', '> 3 hrs', '>$300', 0, 1, '0000-00-00', '2016-06-17 19:22:19', 3, 0, '0000-00-00 00:00:00'),
(73, 16, 34.153973, -118.451866, 1, 'Transport', 'Groceries', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-17 22:58:47', 4, 0, '2016-06-17 23:25:01'),
(74, 16, 34.153519, -118.451584, 1, 'Transport', 'Groceries', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-17 23:25:09', 2, 0, '0000-00-00 00:00:00'),
(75, 16, 34.151833, -118.453743, 1, 'Transport', 'Dog', '1-2 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-06-17 23:30:00', 4, 0, '2016-06-17 23:48:26'),
(76, 7, 34.106098, -118.463982, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-18 15:29:40', 4, 0, '2016-06-18 15:33:41'),
(77, 7, 34.106125, -118.463829, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-18 15:33:43', 4, 0, '2016-06-18 15:33:47'),
(78, 7, 34.106087, -118.463890, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-18 15:34:05', 4, 0, '2016-06-18 15:34:26'),
(79, 5, 0.000000, 0.000000, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 09:32:54', -1, 0, '0000-00-00 00:00:00'),
(80, 5, 0.000000, 0.000000, 0, 'doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 09:42:51', -1, 0, '0000-00-00 00:00:00'),
(81, 5, 37.332333, -122.031219, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:15:58', -1, 0, '0000-00-00 00:00:00'),
(82, 5, 37.332333, -122.031219, 0, 'Dotcor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:32:43', -1, 0, '0000-00-00 00:00:00'),
(83, 5, 37.332333, -122.031219, 0, 'Hi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:43:25', -1, 0, '0000-00-00 00:00:00'),
(84, 5, 37.332333, -122.031219, 0, 'Hi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:44:41', -1, 0, '0000-00-00 00:00:00'),
(85, 5, 37.332333, -122.031219, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:28:20', -1, 0, '0000-00-00 00:00:00'),
(86, 5, 0.000000, 0.000000, 0, 'Hi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:29:33', -1, 0, '0000-00-00 00:00:00'),
(87, 5, 19.017614, 72.856163, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:36:12', -1, 0, '0000-00-00 00:00:00'),
(88, 5, 21.150000, 72.760002, 0, 'Help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:44:47', -1, 0, '0000-00-00 00:00:00'),
(89, 5, 21.150000, 72.760002, 0, 'undefined', 'Here', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:17:30', -1, 0, '0000-00-00 00:00:00'),
(90, 5, 21.150000, 72.760002, 0, 'undefined', 'Need', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:24:24', -1, 0, '0000-00-00 00:00:00'),
(91, 5, 21.150000, 72.760002, 0, 'undefined', 'Hiiii', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:24:48', -1, 0, '0000-00-00 00:00:00'),
(92, 5, 21.150000, 72.760002, 0, 'undefined', 'Going', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:36:07', -1, 0, '0000-00-00 00:00:00'),
(93, 5, 21.150000, 72.760002, 0, 'undefined', 'Hhhhoiii', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:04:16', -1, 0, '0000-00-00 00:00:00'),
(94, 67, 37.332279, -122.035782, 0, 'Help Me Fix A Flat Tire', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:41:25', 3, 0, '0000-00-00 00:00:00'),
(95, 5, 21.150000, 72.760002, 0, 'undefined', 'Hey guys', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:58:13', -1, 0, '0000-00-00 00:00:00'),
(96, 5, 21.150000, 72.760002, 0, 'undefined', 'Hey guys', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:59:39', 3, 0, '0000-00-00 00:00:00'),
(97, 5, 21.150000, 72.760002, 0, 'undefined', 'Hello', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:00:15', 3, 0, '0000-00-00 00:00:00'),
(98, 5, 21.150000, 72.760002, 0, 'undefined', 'Find a plumber', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:03:27', -1, 0, '0000-00-00 00:00:00'),
(99, 5, 21.150000, 72.760002, 0, 'undefined', 'Find a plumber', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:05:45', 4, 0, '2016-06-21 07:06:58'),
(100, 5, 21.150000, 72.760002, 0, 'undefined', 'Hope', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:07:20', -1, 0, '0000-00-00 00:00:00'),
(101, 5, 21.150000, 72.760002, 0, 'undefined', 'Lanet', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:10:37', 4, 0, '2016-06-21 07:10:57'),
(102, 5, 21.150000, 72.760002, 0, 'undefined', 'Lanetteam', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:11:24', -1, 0, '0000-00-00 00:00:00'),
(103, 67, 37.330433, -122.030090, 0, 'Help Me Clean The Garage, Backyard ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:15:56', -1, 0, '0000-00-00 00:00:00'),
(104, 5, 21.150000, 72.760002, 0, 'undefined', 'Let', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:18:14', -1, 0, '0000-00-00 00:00:00'),
(105, 5, 21.150000, 72.760002, 0, 'undefined', 'Yyy', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:19:28', 4, 0, '2016-06-21 07:19:56'),
(106, 5, 21.150000, 72.760002, 0, 'undefined', 'Pppp', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:20:14', 4, 0, '2016-06-21 07:21:31'),
(107, 5, 21.150000, 72.760002, 0, 'undefined', 'For Old', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:25:18', 3, 0, '0000-00-00 00:00:00'),
(108, 5, 21.150000, 72.760002, 0, 'Hello', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:26:10', 4, 0, '2016-06-21 10:26:23'),
(109, 5, 21.150000, 72.760002, 0, 'Heyyy', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:26:37', -1, 0, '0000-00-00 00:00:00'),
(110, 5, 21.150000, 72.760002, 0, 'Hhiiii', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:54:40', 4, 0, '2016-06-21 10:55:08'),
(111, 5, 21.150000, 72.760002, 0, 'Tdyducjvj', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:55:47', 3, 0, '0000-00-00 00:00:00'),
(112, 5, 21.150000, 72.760002, 0, 'Dydhfjc', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:56:13', 4, 0, '2016-06-21 10:56:32'),
(113, 5, 21.150000, 72.760002, 0, 'Gxhdkfcj', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:56:43', 4, 0, '2016-06-21 10:57:29'),
(114, 5, 21.150000, 72.760002, 0, 'Hhhhhh', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:58:04', -1, 0, '0000-00-00 00:00:00'),
(115, 5, 21.150000, 72.760002, 0, 'hey hii ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 12:02:52', -1, 0, '0000-00-00 00:00:00'),
(116, 5, 21.150000, 72.760002, 0, 'Happy', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 12:03:25', -1, 0, '0000-00-00 00:00:00'),
(117, 5, 21.150000, 72.760002, 0, 'happpp hi mfjfjc gzgxhxjxjcjcjcjcjc', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 12:06:34', -1, 0, '0000-00-00 00:00:00'),
(118, 188, 34.106216, -118.463898, 0, 'Find', 'Horses', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 02:44:46', 4, 0, '2016-06-22 02:45:08'),
(119, 188, 34.106155, -118.463913, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 0, '2016-06-22', '2016-06-22 02:48:47', 4, 0, '2016-06-22 02:49:04'),
(120, 188, 34.106155, -118.463913, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 0, '2016-06-22', '2016-06-22 02:49:07', 4, 0, '2016-06-22 02:49:21'),
(121, 17, 34.106152, -118.463829, 0, 'Help', 'Me', '<1hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 03:04:17', 4, 0, '2016-06-22 03:04:36'),
(122, 188, 34.106140, -118.463814, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 03:05:10', 4, 0, '2016-06-22 03:05:24'),
(123, 17, 34.106155, -118.463829, 1, 'Transport', 'Fun', '<1hr', '<$20', 2, 0, '0000-00-00', '2016-06-22 03:06:12', 3, 0, '0000-00-00 00:00:00'),
(124, 188, 34.106140, -118.463867, 1, 'Transport', 'Gum', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-22 06:47:54', 4, 5, '2016-06-22 06:50:14'),
(125, 188, 34.106148, -118.463852, 0, 'Hit', 'Home', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 06:50:50', 4, 0, '2016-06-22 06:50:58'),
(126, 188, 34.106136, -118.463783, 0, 'Try', 'Harder', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-23 00:57:48', 3, 0, '0000-00-00 00:00:00'),
(127, 188, 34.106167, -118.463989, 0, 'Get', 'Ready', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-23 01:11:37', 3, 0, '0000-00-00 00:00:00'),
(128, 5, 21.150000, 72.760002, 0, 'High', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-23 11:15:03', 4, 0, '2016-06-23 11:15:08'),
(129, 5, 21.150000, 72.760002, 0, 'Not really ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-23 11:15:54', 4, 0, '2016-06-23 11:16:18'),
(130, 205, 31.912302, -106.573540, 1, 'Transport', 'Flights', '1-2hrs', '$100-300', 2, 0, '0000-00-00', '2016-06-23 21:00:31', 4, 0, '2016-06-23 21:01:31'),
(131, 205, 31.912308, -106.573372, 1, 'Transport', 'Flights', '2-3hrs', '>$300', 2, 0, '0000-00-00', '2016-06-23 22:02:37', 4, 0, '2016-06-23 22:02:55'),
(132, 205, 31.912209, -106.573853, 1, 'Transport', 'Friend', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-06-23 22:04:36', 4, 0, '2016-06-23 22:09:07'),
(133, 205, 31.912184, -106.573868, 1, 'Transport', 'Groceries', '2-3hrs', '>$300', 2, 0, '0000-00-00', '2016-06-23 22:10:26', 4, 5, '2016-06-23 22:12:02'),
(134, 205, 31.912308, -106.573372, 1, 'Transport', 'Fligth', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-06-24 09:57:51', 4, 5, '2016-06-24 18:15:12'),
(135, 5, 21.150000, 72.760002, 0, 'help me to fix flat tire', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 12:35:21', -1, 0, '0000-00-00 00:00:00'),
(136, 5, 21.150000, 72.760002, 0, 'find plumber', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 12:50:36', -1, 0, '0000-00-00 00:00:00'),
(137, 5, 21.150000, 72.760002, 0, 'Happy to help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 12:53:26', -1, 0, '0000-00-00 00:00:00'),
(138, 205, 31.910000, -106.570000, 0, 'Help with pergola', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:42:11', 4, 0, '2016-06-24 18:42:27'),
(139, 205, 31.910000, -106.570000, 0, 'Help with deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:43:16', 4, 0, '2016-06-24 18:43:49'),
(140, 205, 31.910000, -106.570000, 0, 'Help with wood deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:44:10', 4, 0, '2016-06-24 18:44:39'),
(141, 205, 31.910000, -106.570000, 0, 'Help getting to party', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:45:05', 4, 5, '2016-06-24 20:18:04'),
(142, 205, 31.910000, -106.570000, 0, 'Get to school', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 19:51:50', 4, 0, '2016-06-24 19:52:13'),
(143, 205, 31.910000, -106.570000, 0, 'Get to work', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 19:52:36', 4, 0, '2016-06-24 19:58:23'),
(144, 205, 31.910000, -106.570000, 0, 'Help build deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 20:18:44', 3, 0, '0000-00-00 00:00:00'),
(145, 5, 21.150000, 72.760002, 0, 'find taxi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-25 11:04:02', -1, 0, '0000-00-00 00:00:00'),
(146, 236, 34.106281, -118.463890, 0, 'Find', 'Hats', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-27 03:51:19', 4, 0, '2016-06-27 03:57:17'),
(147, 5, 21.150000, 72.760002, 0, 'find cab ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 05:38:23', -1, 0, '0000-00-00 00:00:00'),
(148, 5, 21.150000, 72.760002, 0, 'arrange party', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 06:26:39', 3, 0, '0000-00-00 00:00:00'),
(149, 67, 31.912085, -106.573799, 0, 'Hejdjjd', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 18:59:33', 4, 0, '2016-06-27 19:00:58'),
(150, 67, 31.912115, -106.573769, 0, 'Hdidjdj jdjjd', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:04:50', 4, 0, '2016-06-27 19:04:53'),
(151, 67, 31.912123, -106.573807, 0, 'Help with dog', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:13:27', 4, 0, '2016-06-27 19:13:41'),
(152, 67, 31.912098, -106.573792, 0, 'Help with deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:15:25', -1, 0, '0000-00-00 00:00:00'),
(153, 67, 31.912157, -106.573807, 0, 'Help with door', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:17:34', 4, 0, '2016-06-27 19:17:37'),
(154, 67, 31.912167, -106.573906, 0, 'Help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:22:11', -1, 0, '0000-00-00 00:00:00'),
(155, 67, 31.912167, -106.573875, 0, 'Help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:24:11', 4, 0, '2016-06-27 19:24:22'),
(156, 67, 31.912142, -106.573761, 0, 'Please fix my car', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 23:55:07', 4, 0, '2016-06-27 23:55:11'),
(157, 67, 31.912125, -106.573753, 0, 'Please fix my car', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 23:57:34', 4, 0, '2016-06-27 23:57:37'),
(158, 188, 34.106197, -118.463943, 0, 'find a plumber', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 00:36:41', 4, 0, '2016-06-28 01:28:45'),
(159, 188, 34.106197, -118.463943, 0, 'find a plumber ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 00:37:11', 4, 0, '2016-06-28 00:37:14'),
(160, 16, 29.521984, -98.502228, 0, 'Create a vacation plan', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 00:58:34', 3, 0, '0000-00-00 00:00:00'),
(161, 67, 31.912212, -106.573784, 0, 'Help cooking pizza', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 01:19:44', 3, 0, '0000-00-00 00:00:00'),
(162, 188, 34.106152, -118.464043, 0, 'find a plumber ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 01:25:11', 3, 0, '0000-00-00 00:00:00'),
(163, 5, 21.150000, 72.760002, 0, 'Find people', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 06:58:54', 4, 0, '2016-06-28 07:07:46'),
(164, 5, 21.148062, 72.760750, 0, 'Find', 'Cab', '2-3hrs', '$20-100', 0, 1, '0000-00-00', '2016-06-28 07:04:48', 4, 0, '2016-06-28 07:04:59'),
(165, 5, 21.150000, 72.760002, 0, 'Find cab', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 07:08:47', -1, 0, '0000-00-00 00:00:00'),
(166, 5, 21.150000, 72.760002, 0, 'Arrange childcare', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:15:47', 3, 0, '0000-00-00 00:00:00'),
(167, 5, 21.150000, 72.760002, 0, 'Arrange auto', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:29:43', -1, 0, '0000-00-00 00:00:00'),
(168, 5, 21.150000, 72.760002, 0, 'Help to fix problems', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:41:22', -1, 0, '0000-00-00 00:00:00'),
(169, 5, 21.150000, 72.760002, 0, 'Find taxi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:44:53', -1, 0, '0000-00-00 00:00:00'),
(170, 5, 21.150000, 72.760002, 0, 'Help me', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:49:36', -1, 0, '0000-00-00 00:00:00'),
(171, 5, 21.150000, 72.760002, 0, 'Hi there', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 09:00:36', -1, 0, '0000-00-00 00:00:00'),
(172, 5, 37.332333, -122.031219, 0, 'Help me to fix problem', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 09:26:45', 4, 0, '2016-06-28 09:26:58'),
(173, 5, 37.332333, -122.031219, 0, 'Truthful', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 09:36:35', -1, 0, '0000-00-00 00:00:00'),
(174, 5, 0.000000, 0.000000, 0, 'Find can', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 10:35:43', -1, 0, '0000-00-00 00:00:00'),
(175, 5, 21.150000, 72.760002, 0, 'Hey', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 11:26:53', -1, 0, '0000-00-00 00:00:00'),
(176, 5, 21.150000, 72.760002, 0, 'Testing', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 11:31:44', 4, 0, '2016-06-28 11:47:29'),
(177, 5, 21.150000, 72.760002, 0, 'Test', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 11:33:58', 4, 0, '2016-06-28 11:34:06'),
(178, 5, 21.150000, 72.760002, 0, 'Hello testing', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:37:07', 4, 0, '2016-06-28 12:40:00'),
(179, 5, 21.150000, 72.760002, 0, 'Testing', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:40:41', 4, 0, '2016-06-28 12:41:17'),
(180, 5, 21.150000, 72.760002, 0, 'Dhh', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:43:45', 4, 0, '2016-06-28 12:44:53'),
(181, 5, 21.150000, 72.760002, 0, 'Dfduxhjjjjj', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:46:07', 4, 0, '2016-06-28 12:46:36'),
(182, 5, 21.150000, 72.760002, 0, 'Hdjdjdjd', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:46:56', 4, 0, '2016-06-28 12:47:25'),
(183, 5, 21.150000, 72.760002, 0, 'JJjJjdJjdjJjdJj ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:49:44', 3, 0, '0000-00-00 00:00:00'),
(184, 5, 21.150000, 72.760002, 0, 'Yfghhhhhhhh', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:51:52', 4, 0, '2016-06-28 12:52:27'),
(185, 5, 21.150000, 72.760002, 0, 'Hope', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:52:52', 3, 0, '0000-00-00 00:00:00'),
(186, 1, 21.150000, 72.760002, 0, 'Tgggh', '', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 16:47:34', 3, 0, '0000-00-00 00:00:00'),
(187, 1, 21.150000, 72.760002, 0, 'Yxiviboboo', '', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 16:57:05', 2, 0, '0000-00-00 00:00:00'),
(188, 1, 21.150000, 72.760002, 0, 'Hopw a doc', '', '', '', 0, 1, '0000-00-00', '2016-06-28 17:14:55', 4, 0, '2016-06-28 17:15:17'),
(189, 239, 29.522346, -98.501892, 0, 'Find', 'Flight', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-28 22:02:12', 3, 0, '0000-00-00 00:00:00'),
(190, 245, 34.106133, -118.463753, 0, 'Find', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:44:53', 4, 0, '2016-06-29 00:44:56'),
(191, 245, 34.106155, -118.463776, 0, 'Create', 'List', '1-2 hrs', '<$20', 0, 0, '2016-06-29', '2016-06-29 00:46:57', 4, 0, '2016-06-29 00:53:22'),
(192, 245, 34.106163, -118.463799, 0, 'Find', 'Flights', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:56:42', 4, 0, '2016-06-29 01:16:48'),
(193, 245, 34.106167, -118.463799, 0, 'Find', 'Flights', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:58:13', 4, 5, '2016-06-29 00:58:42'),
(194, 245, 34.106167, -118.463799, 0, 'Create', 'List', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:59:11', 4, 0, '2016-06-29 01:00:14'),
(195, 245, 34.106167, -118.463799, 0, 'Create', 'List', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-29 01:00:15', 4, 0, '2016-06-29 01:00:48'),
(196, 18, 34.106197, -118.463531, 1, 'Transport', 'Dog', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 01:06:42', 4, 0, '2016-06-29 01:07:17'),
(197, 18, 34.106144, -118.463554, 0, 'Create', 'List', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 01:08:19', 3, 0, '0000-00-00 00:00:00'),
(198, 245, 34.106178, -118.463867, 1, 'Transport', 'Fun', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-06-29 02:00:19', 3, 0, '0000-00-00 00:00:00'),
(199, 17, 34.106121, -118.463928, 0, 'Find', 'Developer', '<1hr', '$20-100', 0, 1, '0000-00-00', '2016-06-29 02:08:32', 3, 0, '0000-00-00 00:00:00'),
(200, 18, 34.106026, -118.463959, 1, 'Transport', 'Dog', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 02:21:49', 3, 0, '0000-00-00 00:00:00'),
(201, 239, 29.526861, -98.470398, 1, 'Transport', 'Food', '<1hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 02:28:55', 4, 0, '2016-06-29 02:29:50'),
(202, 239, 29.526884, -98.470459, 0, 'Find', 'Flights', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-29 02:30:47', 3, 0, '0000-00-00 00:00:00'),
(203, 5, 65.970001, -18.530001, 0, 'hiii', '', '', '', 0, 1, '0000-00-00', '2016-06-29 05:56:44', -1, 0, '0000-00-00 00:00:00'),
(204, 5, 21.150000, 72.760002, 0, 'Happy ', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:31:10', 4, 0, '2016-06-29 06:31:23'),
(205, 5, 21.150000, 72.760002, 0, 'Happy', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:31:38', 4, 0, '2016-06-29 06:35:46'),
(206, 1, 21.150000, 72.760002, 0, 'Hello', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:33:53', -1, 0, '0000-00-00 00:00:00'),
(207, 5, 21.150000, 72.760002, 0, 'heyhelloinheyhelloin', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:34:16', 4, 0, '2016-06-29 06:35:36'),
(208, 5, 21.150000, 72.760002, 0, 'hello ', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:36:57', 3, 0, '0000-00-00 00:00:00'),
(209, 5, 21.150000, 72.760002, 0, 'testing request', '', '', '', 0, 1, '0000-00-00', '2016-06-29 07:04:56', 3, 0, '0000-00-00 00:00:00'),
(210, 67, 37.331760, -122.030663, 1, 'Bring Doritos', 'Bring Doritos', '0', '0', 2, 0, '0000-00-00', '2016-06-29 09:52:28', 4, 0, '2016-06-29 09:52:48'),
(211, 5, 21.150000, 72.760002, 0, 'request testing', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:12:30', 3, 0, '0000-00-00 00:00:00'),
(212, 5, 21.150000, 72.760002, 0, 'find place', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:18:49', 3, 0, '0000-00-00 00:00:00'),
(213, 5, 21.150000, 72.760002, 0, 'hello', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:22:45', 3, 0, '0000-00-00 00:00:00'),
(214, 5, 21.150000, 72.760002, 0, 'Happy birthday', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:27:51', 4, 0, '2016-06-29 10:33:45'),
(215, 67, 37.324623, -122.019936, 0, 'Help with Home work', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:33:09', 4, 0, '2016-06-29 10:33:11'),
(216, 5, 21.150000, 72.760002, 0, 'Find cab', '', '', '', 0, 1, '0000-00-00', '2016-06-29 12:23:55', -1, 0, '0000-00-00 00:00:00'),
(217, 5, 21.150000, 72.760002, 0, 'fjdjxjffk', '', '', '', 0, 1, '0000-00-00', '2016-06-29 12:49:23', 3, 0, '0000-00-00 00:00:00'),
(218, 18, 34.106209, -118.463837, 0, 'Find', 'Flights', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:11:51', 3, 0, '0000-00-00 00:00:00'),
(219, 18, 34.106186, -118.463905, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:19:42', 4, 0, '2016-06-29 14:20:02'),
(220, 18, 34.106186, -118.463905, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:20:04', 4, 0, '2016-06-29 14:20:11'),
(221, 18, 34.106178, -118.463913, 1, 'Transport', 'Hat', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 14:22:56', 3, 0, '0000-00-00 00:00:00'),
(222, 18, 34.106113, -118.463898, 1, 'Transport', 'Hat', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 14:31:30', 3, 0, '0000-00-00 00:00:00'),
(223, 245, 34.106106, -118.463928, 0, 'Find', 'Sanity', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:46:48', 3, 0, '0000-00-00 00:00:00'),
(224, 17, 34.106178, -118.463860, 0, 'Get', 'Help', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-06-29 14:49:04', 3, 0, '0000-00-00 00:00:00'),
(225, 18, 34.106148, -118.463882, 1, 'Transport', 'Hat', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 15:21:17', 2, 0, '0000-00-00 00:00:00'),
(226, 245, 34.106144, -118.463966, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-06-29 18:28:47', 4, 0, '2016-06-29 18:29:13'),
(227, 245, 34.106144, -118.463966, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-06-29 18:29:28', 4, 0, '2016-06-29 18:29:45'),
(228, 5, 0.000000, 0.000000, 0, 'Gthgtjygj', '', '', '', 0, 1, '0000-00-00', '2016-06-30 04:50:25', -1, 0, '0000-00-00 00:00:00'),
(229, 5, 0.000000, 0.000000, 0, 'H', '', '', '', 0, 1, '0000-00-00', '2016-06-30 05:01:24', -1, 0, '0000-00-00 00:00:00'),
(230, 5, 0.000000, 0.000000, 0, 'Y', '', '', '', 0, 1, '0000-00-00', '2016-06-30 05:23:22', -1, 0, '0000-00-00 00:00:00'),
(231, 5, 21.147984, 72.760704, 0, 'Find', 'Cab', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-30 05:50:17', -1, 0, '0000-00-00 00:00:00'),
(232, 5, 21.147991, 72.760681, 0, 'Arrange', 'Party', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-06-30 05:56:52', 3, 0, '0000-00-00 00:00:00'),
(233, 5, 65.966698, -18.533300, 1, 'Transport', 'Goods', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-06-30 06:05:48', -1, 0, '0000-00-00 00:00:00'),
(234, 5, 21.150000, 72.760002, 0, 'Hello', '', '', '', 0, 1, '0000-00-00', '2016-06-30 10:17:48', -1, 0, '0000-00-00 00:00:00'),
(235, 4, 21.150000, 72.760002, 0, 'Testing', '', '', '', 0, 1, '0000-00-00', '2016-06-30 10:43:37', -1, 0, '0000-00-00 00:00:00'),
(236, 245, 34.106167, -118.463829, 0, 'Gg', 'Cf', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-30 12:09:36', 3, 0, '0000-00-00 00:00:00'),
(237, 18, 34.106144, -118.463928, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-30 19:13:39', 3, 0, '0000-00-00 00:00:00'),
(238, 18, 34.106182, -118.463852, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-30 19:28:11', 3, 0, '0000-00-00 00:00:00'),
(239, 239, 34.165142, -118.449242, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-30 23:57:49', 3, 0, '0000-00-00 00:00:00'),
(240, 239, 34.106155, -118.463821, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-01 00:35:58', 3, 0, '0000-00-00 00:00:00'),
(241, 4, 37.332333, -122.031219, 0, 'Hook', '', '', '', 0, 1, '0000-00-00', '2016-07-01 07:25:35', -1, 0, '0000-00-00 00:00:00'),
(242, 5, 21.150000, 72.760002, 0, 'Transport food', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:45:29', 4, 0, '2016-07-01 13:46:48'),
(243, 5, 65.970001, -18.530001, 0, 'Chvjh', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:45:57', 4, 0, '2016-07-01 13:46:56'),
(244, 5, 21.150000, 72.760002, 0, 'Hello', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:48:03', 4, 0, '2016-07-01 13:52:39'),
(245, 5, 65.970001, -18.530001, 0, 'hjhgj', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:49:24', 4, 0, '2016-07-01 13:52:21'),
(246, 5, 21.150000, 72.760002, 0, 'Hi', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:51:56', 4, 0, '2016-07-01 13:52:01'),
(247, 18, 34.106129, -118.463837, 1, 'Transport', 'Aiden', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-07-02 01:07:03', 4, 0, '2016-07-02 01:36:07'),
(248, 18, 34.106293, -118.463936, 1, 'Transport', 'Aiden', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-07-02 01:36:10', 2, 0, '0000-00-00 00:00:00'),
(249, 5, 21.150000, 72.760002, 0, 'Arrangefood', '', '', '', 0, 1, '0000-00-00', '2016-07-02 06:05:21', -1, 0, '0000-00-00 00:00:00'),
(250, 5, 21.150000, 72.760002, 0, 'Hii', '', '', '', 0, 1, '0000-00-00', '2016-07-02 06:06:28', 4, 0, '2016-07-02 06:07:09'),
(251, 239, 34.106117, -118.463844, 0, 'Find', 'Floghgt', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 06:23:55', 3, 0, '0000-00-00 00:00:00'),
(252, 239, 34.106205, -118.463806, 0, 'Find', 'Floghgt', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 06:28:27', -1, 0, '0000-00-00 00:00:00'),
(253, 239, 34.106236, -118.463821, 0, 'Find a flight', '', '', '', 0, 1, '0000-00-00', '2016-07-02 06:29:15', 3, 0, '0000-00-00 00:00:00'),
(254, 239, 34.106232, -118.463898, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 07:01:06', 3, 0, '0000-00-00 00:00:00'),
(255, 239, 34.106228, -118.463791, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 07:45:34', 4, 0, '2016-07-02 08:10:05'),
(256, 239, 34.106243, -118.463837, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 08:11:07', 4, 0, '2016-07-02 08:11:52'),
(257, 239, 34.106243, -118.463837, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 08:11:55', -1, 0, '0000-00-00 00:00:00'),
(258, 239, 34.106243, -118.463837, 0, 'Hh', 'Fg', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-02 08:12:22', 3, 0, '0000-00-00 00:00:00'),
(259, 4, 65.970001, -18.530001, 0, 'helppp', '', '', '', 0, 1, '0000-00-00', '2016-07-02 10:48:24', 4, 0, '2016-07-02 10:48:27'),
(260, 18, 34.106262, -118.463882, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:24:03', 4, 5, '2016-07-04 05:26:05'),
(261, 18, 34.106232, -118.463829, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:27:17', 4, 5, '2016-07-04 05:27:31'),
(262, 18, 34.106205, -118.463814, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:32:14', 4, 0, '2016-07-04 05:32:33'),
(263, 18, 34.106216, -118.463829, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:32:40', 4, 0, '2016-07-04 05:33:06'),
(264, 18, 34.106224, -118.463867, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:33:25', 3, 0, '0000-00-00 00:00:00'),
(265, 18, 34.106190, -118.463837, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:40:17', 4, 5, '2016-07-04 05:40:23'),
(266, 5, 0.000000, 0.000000, 0, 'Rare', '', '', '', 0, 1, '0000-00-00', '2016-07-04 13:00:59', -1, 0, '0000-00-00 00:00:00'),
(267, 4, 65.970001, -18.530001, 1, 'GFHGF', '', '', '', 2, 0, '0000-00-00', '2016-07-04 13:35:22', -1, 0, '0000-00-00 00:00:00'),
(268, 18, 34.106121, -118.463669, 0, 'Get', 'My', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 20:15:00', 3, 0, '0000-00-00 00:00:00'),
(269, 18, 34.106171, -118.463783, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:22:57', 3, 0, '0000-00-00 00:00:00'),
(270, 18, 34.106102, -118.463844, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:24:35', 4, 5, '2016-07-04 23:24:47'),
(271, 18, 34.106102, -118.463844, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:24:59', 4, 0, '2016-07-04 23:25:21'),
(272, 18, 34.106098, -118.463860, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:25:36', 3, 0, '0000-00-00 00:00:00'),
(273, 18, 34.106033, -118.463844, 0, 'Get', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:59:40', 4, 0, '2016-07-04 23:59:50'),
(274, 18, 34.106033, -118.463844, 0, 'Get', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:59:56', 4, 0, '2016-07-05 00:00:06'),
(275, 18, 34.106087, -118.463814, 0, 'Get', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:00:22', 4, 0, '2016-07-05 00:00:27'),
(276, 18, 34.106110, -118.463814, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:00:46', 4, 0, '2016-07-05 00:01:48'),
(277, 18, 34.106113, -118.463821, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:01:50', 4, 0, '2016-07-05 00:01:53'),
(278, 18, 34.106113, -118.463821, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:03:03', 4, 0, '2016-07-05 00:03:08'),
(279, 18, 34.106113, -118.463821, 0, 'Help', 'Ne', '< 1 hr', '$20-$100', 0, 1, '0000-00-00', '2016-07-05 00:03:39', 4, 0, '2016-07-05 00:14:09'),
(280, 18, 34.106251, -118.464149, 0, 'Help', 'Ne', '< 1 hr', '$20-$100', 0, 1, '0000-00-00', '2016-07-05 00:14:11', 3, 0, '0000-00-00 00:00:00'),
(281, 18, 34.106010, -118.463623, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:51:57', 3, 0, '0000-00-00 00:00:00'),
(282, 5, 21.150000, 72.760002, 1, 'Transport goods', '', '', '', 2, 0, '0000-00-00', '2016-07-05 04:31:22', -1, 0, '0000-00-00 00:00:00'),
(283, 5, 21.150000, 72.760002, 0, 'Help to find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-05 04:36:13', 4, 0, '2016-07-05 04:36:53'),
(284, 5, 21.150000, 72.760002, 0, 'Find food', '', '', '', 0, 1, '0000-00-00', '2016-07-05 04:41:17', -1, 0, '0000-00-00 00:00:00'),
(285, 4, 21.150000, 72.760002, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 04:48:37', 4, 0, '2016-07-05 04:48:53'),
(286, 5, 21.150000, 72.760002, 1, 'Hey', '', '', '', 2, 0, '0000-00-00', '2016-07-05 05:51:54', -1, 0, '0000-00-00 00:00:00'),
(287, 5, 21.150000, 72.760002, 1, 'Hope', '', '', '', 2, 0, '0000-00-00', '2016-07-05 06:05:31', -1, 0, '0000-00-00 00:00:00'),
(288, 5, 21.150000, 72.760002, 1, 'Here', '', '', '', 2, 0, '0000-00-00', '2016-07-05 06:10:24', -1, 0, '0000-00-00 00:00:00'),
(289, 205, 31.912151, -106.573875, 0, 'Help now', '', '', '', 0, 1, '0000-00-00', '2016-07-05 06:27:54', 3, 0, '0000-00-00 00:00:00'),
(290, 4, 21.150000, 72.760002, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 06:41:16', -1, 0, '0000-00-00 00:00:00'),
(291, 4, 21.150000, 72.760002, 1, 'Hello', '', '', '', 2, 0, '0000-00-00', '2016-07-05 07:00:14', -1, 0, '0000-00-00 00:00:00'),
(292, 4, 21.150000, 72.760002, 0, 'Hey', '', '', '', 0, 1, '0000-00-00', '2016-07-05 07:08:40', -1, 0, '0000-00-00 00:00:00'),
(293, 205, 31.912054, -106.573868, 0, 'Help with dog', '', '', '', 0, 1, '0000-00-00', '2016-07-05 07:34:25', 3, 0, '0000-00-00 00:00:00'),
(294, 205, 31.912136, -106.573853, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 07:58:50', 3, 0, '0000-00-00 00:00:00'),
(295, 205, 31.912098, -106.573837, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:07:23', 3, 0, '0000-00-00 00:00:00'),
(296, 205, 31.912125, -106.573807, 0, 'Help with door', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:13:50', 3, 0, '0000-00-00 00:00:00'),
(297, 205, 31.912079, -106.573883, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:17:24', 4, 0, '2016-07-05 08:17:35'),
(298, 205, 31.912067, -106.573822, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:17:42', -1, 0, '0000-00-00 00:00:00'),
(299, 205, 31.912067, -106.573830, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:17:56', -1, 0, '0000-00-00 00:00:00'),
(300, 205, 31.912107, -106.573822, 0, ' Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:18:21', 3, 0, '0000-00-00 00:00:00'),
(301, 205, 31.912113, -106.573792, 0, 'Help with pool', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:22:35', -1, 0, '0000-00-00 00:00:00'),
(302, 205, 31.912157, -106.573792, 0, 'Help with kids', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:23:50', 3, 0, '0000-00-00 00:00:00'),
(303, 205, 31.912090, -106.573853, 0, 'Help with grass', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:25:40', 3, 0, '0000-00-00 00:00:00'),
(304, 205, 31.912083, -106.573807, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:27:11', -1, 0, '0000-00-00 00:00:00'),
(305, 205, 31.912083, -106.573807, 0, 'Need help with game', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:27:46', -1, 0, '0000-00-00 00:00:00'),
(306, 205, 31.912088, -106.573830, 0, 'Help with fridge', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:28:18', 3, 0, '0000-00-00 00:00:00'),
(307, 4, 21.170000, 72.830002, 1, 'help', '', '', '', 2, 0, '0000-00-00', '2016-07-05 09:16:22', -1, 0, '0000-00-00 00:00:00'),
(308, 4, 21.170000, 72.830002, 1, 'find plumber', '', '', '', 2, 0, '0000-00-00', '2016-07-05 09:24:28', -1, 0, '0000-00-00 00:00:00'),
(309, 4, 21.170000, 72.830002, 0, 'find cab', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:26:32', -1, 0, '0000-00-00 00:00:00'),
(310, 4, 21.170000, 72.830002, 0, 'arrange party', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:29:46', -1, 0, '0000-00-00 00:00:00'),
(311, 4, 21.170000, 72.830002, 0, 'arrange partyyy', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:33:36', -1, 0, '0000-00-00 00:00:00'),
(312, 4, 21.170000, 72.830002, 0, 'hjhhg', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:36:39', 4, 0, '2016-07-05 09:37:44'),
(313, 4, 21.170000, 72.830002, 0, 'hello', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:40:09', -1, 0, '0000-00-00 00:00:00'),
(314, 4, 21.170000, 72.830002, 0, 'find auto', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:42:35', -1, 0, '0000-00-00 00:00:00'),
(315, 4, 21.170000, 72.830002, 0, 'gbfch', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:01:13', -1, 0, '0000-00-00 00:00:00'),
(316, 4, 21.150000, 72.760002, 0, 'Helps', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:10:46', -1, 0, '0000-00-00 00:00:00'),
(317, 4, 21.150000, 72.760002, 1, 'Transport luggage', '', '', '', 2, 0, '0000-00-00', '2016-07-05 11:18:37', -1, 0, '0000-00-00 00:00:00'),
(318, 4, 21.150000, 72.760002, 0, 'Find maid', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:20:44', -1, 0, '0000-00-00 00:00:00'),
(319, 4, 21.150000, 72.760002, 1, 'Transport funds', '', '', '', 2, 0, '0000-00-00', '2016-07-05 11:32:00', -1, 0, '0000-00-00 00:00:00'),
(320, 4, 21.150000, 72.760002, 0, 'Help to find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:40:54', -1, 0, '0000-00-00 00:00:00'),
(321, 4, 21.150000, 72.760002, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:49:20', -1, 0, '0000-00-00 00:00:00'),
(322, 4, 21.150000, 72.760002, 0, 'Help to fix flat tire', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:59:30', -1, 0, '0000-00-00 00:00:00'),
(323, 4, 21.150000, 72.760002, 1, 'Help', '', '', '', 2, 0, '0000-00-00', '2016-07-05 12:23:59', -1, 0, '0000-00-00 00:00:00'),
(324, 17, 34.110001, -118.459999, 0, 'Create a vacation itinerary', '', '', '', 0, 1, '0000-00-00', '2016-07-05 15:12:20', 4, 0, '2016-07-05 15:12:49'),
(325, 17, 34.110001, -118.459999, 1, 'Pick up drycleaning', '', '', '', 2, 0, '0000-00-00', '2016-07-05 15:14:38', 4, 0, '2016-07-05 15:14:53'),
(326, 17, 34.110001, -118.459999, 0, 'Create itinerary', '', '', '', 0, 1, '0000-00-00', '2016-07-05 15:20:37', 4, 0, '2016-07-05 15:20:45'),
(327, 17, 34.110001, -118.459999, 0, 'Create itinerary', '', '', '', 0, 1, '0000-00-00', '2016-07-05 15:21:03', 4, 0, '2016-07-05 15:21:13'),
(328, 18, 34.106117, -118.463791, 0, 'Find a good  hearing aid', '', '', '', 0, 1, '0000-00-00', '2016-07-05 18:49:39', 4, 5, '2016-07-05 18:51:15'),
(329, 239, 29.522690, -98.501701, 0, 'Find ginger drink recipe', '', '', '', 0, 1, '0000-00-00', '2016-07-05 18:53:37', 4, 0, '2016-07-05 18:56:44'),
(330, 18, 34.106113, -118.463806, 0, 'Find a dentist ', '', '', '', 0, 1, '0000-00-00', '2016-07-05 18:54:39', 4, 5, '2016-07-05 18:57:07'),
(331, 253, 34.106255, -118.463959, 0, 'find a plumber ', '', '', '', 0, 1, '0000-00-00', '2016-07-05 19:12:07', 4, 0, '2016-07-05 19:12:09'),
(332, 17, 34.110001, -118.459999, 1, 'Pick up drycleaning', '', '', '', 2, 0, '0000-00-00', '2016-07-05 20:36:13', 4, 5, '2016-07-05 20:36:54'),
(333, 17, 34.110001, -118.459999, 1, 'Drop off drycleaning ', '', '', '', 2, 0, '0000-00-00', '2016-07-05 20:41:17', 4, 5, '2016-07-05 20:45:54'),
(334, 253, 34.106197, -118.463943, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:52:40', 4, 0, '2016-07-05 20:53:03'),
(335, 253, 34.106201, -118.463951, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:53:15', 4, 0, '2016-07-05 20:53:26'),
(336, 253, 34.106201, -118.463951, 0, 'get help ', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:54:27', 4, 0, '2016-07-05 20:54:38'),
(337, 253, 34.106201, -118.463951, 0, 'get help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:55:21', 4, 0, '2016-07-05 20:55:47'),
(338, 17, 34.110001, -118.459999, 0, 'Fix my app', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:56:21', -1, 0, '0000-00-00 00:00:00'),
(339, 205, 31.912165, -106.573853, 0, 'Help with guitar', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:51:38', -1, 0, '0000-00-00 00:00:00'),
(340, 205, 31.912159, -106.573883, 0, 'Doritos party', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:53:11', 4, 5, '2016-07-05 22:53:38'),
(341, 205, 31.912218, -106.573875, 0, 'Help with pc issue', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:54:09', 4, 5, '2016-07-05 22:52:24');
INSERT INTO `qRequest` (`qRequestId`, `userId`, `currentLat`, `currentLong`, `isTransport`, `requestVerb`, `requestNoun`, `qRequiredTime_Hr`, `qRequiredPayment`, `numberOfStops`, `isRequiredNow`, `qRequiredDate`, `createdDate`, `requestStatus`, `fine`, `cancelDate`) VALUES
(342, 253, 34.106468, -118.463844, 0, 'get help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:55:25', 4, 5, '2016-07-05 22:56:05'),
(343, 205, 0.000000, 0.000000, 0, 'Help with garage', '', '', '', 0, 1, '0000-00-00', '2016-07-05 22:54:13', 4, 0, '2016-07-05 22:54:38'),
(344, 205, 31.912127, -106.573807, 0, 'Help with backyard', '', '', '', 0, 1, '0000-00-00', '2016-07-05 22:58:27', 2, 0, '0000-00-00 00:00:00'),
(345, 205, 31.912136, -106.573814, 0, 'Help with car', '', '', '', 0, 1, '0000-00-00', '2016-07-05 22:58:54', -1, 0, '0000-00-00 00:00:00'),
(346, 4, 65.970001, -18.530001, 0, 'hgfhgf', '', '', '', 0, 1, '0000-00-00', '2016-07-06 04:27:05', -1, 0, '0000-00-00 00:00:00'),
(347, 4, 65.970001, -18.530001, 1, 'helloo', '', '', '', 2, 0, '0000-00-00', '2016-07-06 05:00:33', -1, 0, '0000-00-00 00:00:00'),
(348, 205, 31.912058, -106.573761, 0, 'Help with homework', '', '', '', 0, 1, '0000-00-00', '2016-07-06 05:18:09', -1, 0, '0000-00-00 00:00:00'),
(349, 205, 31.912064, -106.573784, 0, 'Help w dishes', '', '', '', 0, 1, '0000-00-00', '2016-07-06 05:19:26', -1, 0, '0000-00-00 00:00:00'),
(350, 5, 19.017614, 72.856163, 0, 'Knoll', '', '', '', 0, 1, '0000-00-00', '2016-07-06 06:25:44', -1, 0, '0000-00-00 00:00:00'),
(351, 205, 31.912041, -106.573730, 0, 'Help with rv', '', '', '', 0, 1, '0000-00-00', '2016-07-06 06:26:45', -1, 0, '0000-00-00 00:00:00'),
(352, 5, 19.017614, 72.856163, 0, 'Jeff', '', '', '', 0, 1, '0000-00-00', '2016-07-06 06:39:49', -1, 0, '0000-00-00 00:00:00'),
(353, 205, 31.912121, -106.573753, 0, 'Help cleaning', '', '', '', 0, 1, '0000-00-00', '2016-07-06 07:42:54', -1, 0, '0000-00-00 00:00:00'),
(354, 5, 65.970001, -18.530001, 0, 'ngff', '', '', '', 0, 1, '0000-00-00', '2016-07-06 08:04:25', 4, 0, '2016-07-06 08:49:16'),
(355, 205, 31.912100, -106.573700, 0, 'Help with storage', '', '', '', 0, 1, '0000-00-00', '2016-07-06 08:44:57', -1, 0, '0000-00-00 00:00:00'),
(356, 5, 65.970001, -18.530001, 0, 'gfhgf', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:12:48', 4, 0, '2016-07-06 09:12:59'),
(357, 5, 21.150000, 72.760002, 0, 'Help to find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:32:09', 4, 0, '2016-07-06 09:33:29'),
(358, 205, 31.912102, -106.573776, 0, 'Need help', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:52:40', -1, 0, '0000-00-00 00:00:00'),
(359, 5, 21.150000, 72.760002, 0, 'Test request', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:54:52', 4, 0, '2016-07-06 09:55:20'),
(360, 5, 21.150000, 72.760002, 0, 'Find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-06 10:02:46', 4, 0, '2016-07-06 10:35:48'),
(361, 5, 65.970001, -18.530001, 0, 'help', '', '', '', 0, 1, '0000-00-00', '2016-07-06 10:41:44', 4, 0, '2016-07-06 14:57:43'),
(362, 4, 21.150000, 72.760002, 1, 'Pick up goods ', '', '', '', 2, 0, '0000-00-00', '2016-07-06 10:49:44', 4, 0, '2016-07-06 11:02:36'),
(363, 4, 21.150000, 72.760002, 0, 'Yrehfdfsyausry', '', '', '', 0, 1, '0000-00-00', '2016-07-06 11:03:53', 4, 0, '2016-07-06 11:04:17'),
(364, 4, 21.150000, 72.760002, 0, 'Find food', '', '', '', 0, 1, '0000-00-00', '2016-07-06 11:09:44', -1, 0, '0000-00-00 00:00:00'),
(365, 5, 21.150000, 72.760002, 1, 'pick up goods', '', '', '', 2, 0, '0000-00-00', '2016-07-06 12:40:54', 4, 0, '2016-07-06 12:46:11'),
(366, 18, 34.106197, -118.463783, 0, 'Find', 'Doctor', '< 1 hr', '<$20', 0, 0, '2016-07-05', '2016-07-07 00:02:43', 4, 5, '2016-07-07 00:03:39'),
(367, 205, 31.912149, -106.573845, 0, 'Fix garage', '', '', '', 0, 1, '0000-00-00', '2016-07-07 02:49:36', -1, 0, '0000-00-00 00:00:00'),
(368, 5, 21.150000, 72.760002, 1, 'Pick up toothbrush', '', '', '', 2, 0, '0000-00-00', '2016-07-07 04:31:12', 2, 0, '0000-00-00 00:00:00'),
(369, 205, 31.912062, -106.573898, 0, 'Please help with pool', '', '', '', 0, 1, '0000-00-00', '2016-07-07 04:47:41', -1, 0, '0000-00-00 00:00:00'),
(370, 5, 21.150000, 72.760002, 0, 'Find food', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:31:17', 2, 0, '0000-00-00 00:00:00'),
(371, 5, 21.150000, 72.760002, 0, 'Find goods', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:44:52', 2, 0, '0000-00-00 00:00:00'),
(372, 205, 31.912117, -106.573837, 0, 'Test', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:51:44', -1, 0, '0000-00-00 00:00:00'),
(373, 5, 21.150000, 72.760002, 0, 'Hello testing', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:55:45', 2, 0, '0000-00-00 00:00:00'),
(374, 5, 21.150000, 72.760002, 0, 'Fguub', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:56:57', 2, 0, '0000-00-00 00:00:00'),
(375, 5, 21.150000, 72.760002, 0, 'Tnjk', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:58:05', 2, 0, '0000-00-00 00:00:00'),
(376, 5, 21.150000, 72.760002, 0, 'Test', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:18:06', 2, 0, '0000-00-00 00:00:00'),
(377, 5, 21.150000, 72.760002, 0, 'Testing', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:20:06', 2, 0, '0000-00-00 00:00:00'),
(378, 5, 21.150000, 72.760002, 0, 'Hey', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:25:53', 2, 0, '0000-00-00 00:00:00'),
(379, 5, 21.150000, 72.760002, 0, 'Arrange cab', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:27:24', 2, 0, '0000-00-00 00:00:00'),
(380, 5, 21.150000, 72.760002, 0, 'Bdbnjgng', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:37:06', 4, 0, '2016-07-07 06:41:03'),
(381, 205, 31.912111, -106.573830, 0, 'Help with homework', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:55:01', -1, 0, '0000-00-00 00:00:00'),
(382, 205, 31.912100, -106.573746, 0, 'Help cleaning oven', '', '', '', 0, 1, '0000-00-00', '2016-07-07 08:02:47', -1, 0, '0000-00-00 00:00:00'),
(383, 4, 65.970001, -18.530001, 0, 'help', '', '', '', 0, 1, '0000-00-00', '2016-07-07 09:49:37', 4, 0, '2016-07-07 10:45:12'),
(384, 5, 21.150000, 72.760002, 0, 'Hello hii', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:26:18', 4, 0, '2016-07-07 10:35:46'),
(385, 5, 21.150000, 72.760002, 0, 'Hi', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:29:02', 2, 0, '0000-00-00 00:00:00'),
(386, 5, 21.150000, 72.760002, 0, 'Find cab', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:32:25', 2, 0, '0000-00-00 00:00:00'),
(387, 5, 21.150000, 72.760002, 0, 'Testing req', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:34:25', 2, 0, '0000-00-00 00:00:00'),
(388, 4, 65.970001, -18.530001, 1, 'pic up dress drop at home', '', '', '', 2, 0, '0000-00-00', '2016-07-07 10:44:43', -1, 0, '0000-00-00 00:00:00'),
(389, 5, 21.150000, 72.760002, 0, 'Find more', '', '', '', 0, 1, '0000-00-00', '2016-07-07 11:24:01', 2, 0, '0000-00-00 00:00:00'),
(390, 5, 21.150000, 72.760002, 1, 'Drop everything', '', '', '', 2, 0, '0000-00-00', '2016-07-07 11:25:08', 2, 0, '0000-00-00 00:00:00'),
(391, 5, 21.150000, 72.760002, 0, 'Find auto', '', '', '', 0, 1, '0000-00-00', '2016-07-07 11:43:41', 2, 0, '0000-00-00 00:00:00'),
(392, 5, 21.150000, 72.760002, 0, 'Dnfamstkts', '', '', '', 0, 1, '0000-00-00', '2016-07-07 11:47:27', 2, 0, '0000-00-00 00:00:00'),
(393, 205, 37.332333, -122.031219, 0, 'Help with home improve', '', '', '', 0, 1, '0000-00-00', '2016-07-07 20:38:24', -1, 0, '0000-00-00 00:00:00'),
(394, 205, 37.332333, -122.031219, 0, 'Help dog', '', '', '', 0, 1, '0000-00-00', '2016-07-07 21:42:08', -1, 0, '0000-00-00 00:00:00'),
(395, 205, 37.332333, -122.031219, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-07 22:46:14', -1, 0, '0000-00-00 00:00:00'),
(396, 205, 37.332333, -122.031219, 0, 'Help Now', '', '', '', 0, 1, '0000-00-00', '2016-07-08 01:26:24', -1, 0, '0000-00-00 00:00:00'),
(397, 205, 37.332333, -122.031219, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-08 03:39:06', -1, 0, '0000-00-00 00:00:00'),
(398, 205, 37.332333, -122.031219, 0, 'Help with dishes', '', '', '', 0, 1, '0000-00-00', '2016-07-08 06:47:08', 4, 0, '2016-07-08 07:29:10'),
(399, 205, 37.332333, -122.031219, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-08 07:42:27', 4, 0, '2016-07-08 07:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `qRequestAccept`
--

DROP TABLE IF EXISTS `qRequestAccept`;
CREATE TABLE IF NOT EXISTS `qRequestAccept` (
`requestAcceptId` bigint(20) NOT NULL,
  `qId` bigint(20) NOT NULL,
  `qRequestId` bigint(20) NOT NULL,
  `acceptDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isConfirmedByQ` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 = not completed, 1 = completed, 2 = canceled',
  `isPaymentDone` tinyint(4) NOT NULL DEFAULT '0',
  `requestCompletionDateTime` datetime NOT NULL,
  `receiptTotalBill` float NOT NULL,
  `mapURL` varchar(255) NOT NULL,
  `milesTransported` varchar(100) NOT NULL,
  `paymentDoneDateTime` datetime NOT NULL,
  `paymentDoneByRequestor` float NOT NULL,
  `paymentReceivedByQ` float NOT NULL,
  `requestAmt` float(9,2) NOT NULL,
  `serviceFeeToQ` float(9,2) NOT NULL,
  `serviceFeeToUser` float(9,2) NOT NULL,
  `speedRating` int(11) NOT NULL,
  `qualityRating` int(11) NOT NULL,
  `feedback` varchar(255) NOT NULL DEFAULT ' ',
  `ratingDate` datetime NOT NULL,
  `isReviewed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qRequestAccept`
--

INSERT INTO `qRequestAccept` (`requestAcceptId`, `qId`, `qRequestId`, `acceptDate`, `isConfirmedByQ`, `isPaymentDone`, `requestCompletionDateTime`, `receiptTotalBill`, `mapURL`, `milesTransported`, `paymentDoneDateTime`, `paymentDoneByRequestor`, `paymentReceivedByQ`, `requestAmt`, `serviceFeeToQ`, `serviceFeeToUser`, `speedRating`, `qualityRating`, `feedback`, `ratingDate`, `isReviewed`) VALUES
(1, 1, 1, '2016-05-13 12:17:01', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(2, 2, 5, '2016-05-13 12:28:11', 1, 1, '2016-05-13 07:28:59', 0, '', '', '2016-05-13 07:28:59', 71.48, 65.2, 0.00, 0.00, 0.00, 5, 5, 'Hchchnchxhxjuucjdhxhxhcudjfydjucudcjxhcjxgxhgx xx', '2016-05-13 07:29:24', 1),
(3, 1, 9, '2016-05-13 12:44:54', 1, 1, '2016-05-13 07:45:37', 0, '', '', '2016-05-13 07:45:37', 19.68, 15.2, 0.00, 0.00, 0.00, 5, 5, 'ubtbt g gb', '2016-05-13 07:46:14', 1),
(4, 1, 10, '2016-05-13 12:47:29', 1, 1, '2016-05-13 07:47:53', 0, '', '', '2016-05-13 07:47:53', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(5, 2, 11, '2016-05-13 12:48:38', 1, 1, '2016-05-13 07:51:25', 0, '', '', '2016-05-13 07:51:25', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(6, 2, 12, '2016-05-13 13:01:13', 1, 1, '2016-05-13 08:03:03', 0, '', '', '2016-05-13 08:03:03', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(7, 3, 15, '2016-05-13 13:26:26', 1, 1, '2016-05-13 08:27:07', 0, '', '', '2016-05-13 08:27:07', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(8, 3, 16, '2016-05-13 13:32:02', 1, 1, '2016-05-13 08:32:07', 0, '', '', '2016-05-13 08:32:07', 19.68, 15.2, 0.00, 0.00, 0.00, 1, 2, '', '2016-05-13 08:32:13', 1),
(9, 1, 18, '2016-05-15 00:53:23', 1, 1, '2016-05-14 19:55:03', 0, '', '', '2016-05-14 19:55:03', 19.68, 15.2, 0.00, 0.00, 0.00, 1, 1, '', '2016-05-14 19:55:16', 1),
(10, 1, 19, '2016-05-15 00:57:14', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(11, 10, 34, '2016-05-30 21:23:46', 1, 1, '2016-05-30 16:27:32', 0, '', '', '2016-05-30 16:27:32', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(12, 10, 35, '2016-05-30 21:33:36', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(13, 10, 36, '2016-05-30 21:39:26', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(14, 10, 37, '2016-05-30 21:53:32', 1, 1, '2016-05-30 17:01:38', 0, '', '0.09', '2016-05-30 17:01:38', 52.66, 47.63, 0.00, 0.00, 0.00, 1, 1, 'great!', '2016-05-30 17:01:53', 1),
(15, 2, 39, '2016-05-31 09:03:18', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(16, 2, 41, '2016-05-31 09:19:26', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(17, 1, 42, '2016-05-31 09:26:47', 1, 1, '2016-05-31 05:38:03', 0, '', '0.031412', '2016-05-31 05:38:03', 144.01, 135.8, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(18, 2, 48, '2016-05-31 11:18:12', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(19, 1, 49, '2016-05-31 11:40:08', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(20, 1, 51, '2016-05-31 12:08:44', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(21, 3, 52, '2016-05-31 12:11:25', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(22, 3, 53, '2016-05-31 12:36:23', 1, 1, '2016-06-01 00:27:24', 0, '', '0.41', '2016-06-01 00:27:24', 58.1, 52.86, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(23, 3, 54, '2016-06-01 05:34:11', 1, 1, '2016-06-01 00:36:29', 0, '', '', '2016-06-01 00:36:29', 20.72, 16.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(24, 3, 55, '2016-06-01 05:40:13', 1, 1, '2016-06-01 00:41:10', 0, '', '', '2016-06-01 00:41:10', 20.72, 16.2, 0.00, 0.00, 0.00, 4, 4, '', '2016-06-01 00:41:24', 1),
(25, 3, 56, '2016-06-01 05:44:12', 1, 1, '2016-06-01 00:45:00', 0, '', '', '2016-06-01 00:45:00', 20.72, 16.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(26, 9, 63, '2016-06-06 20:27:22', 1, 1, '2016-06-06 16:30:54', 0, '', '29.96', '2016-06-06 16:30:54', 22.78, 17.59, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-06 16:31:23', 1),
(27, 4, 66, '2016-06-10 22:14:50', 1, 1, '2016-06-10 17:16:15', 0, '', '', '2016-06-10 17:16:15', 45.87, 40.48, 0.00, 0.00, 0.00, 1, 1, 'Great service ! I recomend this q!', '2016-06-10 17:16:50', 1),
(28, 4, 71, '2016-06-17 18:48:40', 1, 1, '2016-06-17 13:49:18', 0, '', '', '2016-06-17 13:49:18', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(29, 4, 72, '2016-06-17 19:22:26', 1, 1, '2016-06-17 14:23:30', 0, '', '', '2016-06-17 14:23:30', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(30, 9, 74, '2016-06-17 23:27:20', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(31, 4, 94, '2016-06-21 06:41:46', 1, 1, '2016-06-21 01:42:14', 0, '', '', '2016-06-21 01:42:14', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(32, 3, 96, '2016-06-21 07:01:16', 1, 1, '2016-06-29 02:03:21', 0, '', '', '2016-06-29 02:03:21', 3630.51, 2871.69, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(33, 4, 107, '2016-06-21 08:03:32', 1, 1, '2016-06-21 03:03:38', 0, '', '', '2016-06-21 03:03:38', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(34, 3, 111, '2016-06-21 10:55:55', 1, 1, '2016-07-01 08:54:33', 0, '', '', '2016-07-01 08:54:34', 4593.33, 3633.19, 4374.60, 874.92, 218.73, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(35, 127, 123, '2016-06-22 03:06:16', 1, 1, '2016-06-21 22:08:25', 0, '', '0.000000', '2016-06-21 22:08:25', 16.78, 13, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(36, 10, 124, '2016-06-22 06:48:01', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(37, 9, 126, '2016-06-23 00:58:01', 1, 1, '2016-06-22 19:58:58', 0, '', '', '2016-06-22 19:58:59', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-22 19:59:07', 1),
(38, 9, 127, '2016-06-23 01:11:41', 1, 1, '2016-06-22 20:12:04', 0, '', '', '2016-06-22 20:12:05', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'swell\n', '2016-06-22 20:12:54', 1),
(39, 39, 133, '2016-06-23 22:10:53', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(40, 39, 134, '2016-06-24 09:57:55', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(41, 39, 141, '2016-06-24 18:45:13', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(42, 39, 144, '2016-06-24 20:18:51', 1, 1, '2016-06-24 15:24:32', 0, '', '', '2016-06-24 15:24:32', 40.95, 36.69, 0.00, 0.00, 0.00, 1, 1, 'great job!!!!\n', '2016-06-24 15:25:24', 1),
(43, 3, 148, '2016-06-27 06:27:05', 1, 1, '2016-06-27 01:30:04', 0, '', '', '2016-06-27 01:30:04', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(44, 127, 160, '2016-06-28 00:59:19', 1, 1, '2016-06-27 19:59:56', 0, '', '', '2016-06-27 19:59:56', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(45, 127, 161, '2016-06-28 01:19:56', 1, 1, '2016-06-27 20:20:05', 0, '', '', '2016-06-27 20:20:05', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(46, 39, 162, '2016-06-28 01:25:30', 1, 1, '2016-06-27 20:26:04', 0, '', '', '2016-06-27 20:26:05', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-27 20:26:09', 1),
(47, 3, 166, '2016-06-28 08:15:59', 1, 1, '2016-07-01 08:26:09', 0, '', '', '2016-07-01 08:26:10', 1459.56, 1154.67, 1390.06, 278.01, 69.50, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(48, 3, 183, '2016-06-28 12:49:55', 1, 1, '2016-06-28 07:50:51', 0, '', '', '2016-06-28 07:50:52', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'ggf\n', '2016-06-28 07:51:18', 1),
(49, 3, 185, '2016-06-28 12:53:20', 1, 1, '2016-07-01 08:33:58', 0, '', '', '2016-07-01 08:33:59', 1374.66, 1087.53, 1309.20, 261.84, 65.46, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(50, 3, 186, '2016-06-28 16:47:45', 1, 1, '2016-06-28 11:48:33', 0, '', '', '2016-06-28 11:48:34', 544.95, 531.3, 0.00, 0.00, 0.00, 1, 1, 'hjfhnhgg', '2016-06-28 11:50:00', 1),
(51, 3, 187, '2016-06-28 16:57:14', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId187.png', '', '2016-07-07 05:07:12', 3957.44, 3015.19, 3768.99, 753.80, 188.45, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(52, 160, 189, '2016-06-28 22:02:18', 1, 1, '2016-06-28 17:03:13', 0, '', '', '2016-06-28 17:03:13', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(53, 164, 193, '2016-06-29 00:58:17', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(54, 164, 197, '2016-06-29 01:08:26', 1, 1, '2016-06-28 20:09:48', 0, '', '', '2016-06-28 20:09:49', 26.77, 22.77, 0.00, 0.00, 0.00, 1, 1, 'Great job', '2016-06-28 20:09:58', 1),
(55, 9, 198, '2016-06-29 02:00:29', 1, 1, '2016-06-28 21:01:13', 0, '', '0.00', '2016-06-28 21:01:13', 16.8, 13.59, 0.00, 0.00, 0.00, 5, 5, 'great', '2016-06-28 21:01:35', 1),
(56, 167, 199, '2016-06-29 02:09:02', 1, 1, '2016-06-28 21:10:05', 0, '', '', '2016-06-28 21:10:06', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-28 21:10:14', 1),
(57, 167, 200, '2016-06-29 02:21:54', 1, 1, '2016-06-28 21:22:18', 0, '', '', '2016-06-28 21:22:19', 16.8, 13.59, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-28 21:22:24', 1),
(58, 167, 202, '2016-06-29 02:31:22', 1, 1, '2016-06-28 21:31:37', 0, '', '', '2016-06-28 21:31:37', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'Good work\n', '2016-06-28 21:34:01', 1),
(59, 3, 208, '2016-06-29 06:37:14', 1, 1, '2016-06-29 01:39:19', 0, '', '', '2016-06-29 01:39:20', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(60, 3, 209, '2016-06-29 07:05:11', 1, 1, '2016-06-29 02:05:35', 0, '', '', '2016-06-29 02:05:35', 19.95, 16.08, 0.00, 0.00, 0.00, 2, 2, '', '2016-06-29 02:05:53', 1),
(61, 3, 211, '2016-06-29 10:13:23', 1, 1, '2016-06-29 05:14:43', 0, '', '', '2016-06-29 05:14:44', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'good service', '2016-06-29 05:15:06', 1),
(62, 3, 212, '2016-06-29 10:19:04', 1, 1, '2016-06-29 05:19:25', 0, '', '', '2016-06-29 05:19:25', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-29 05:19:40', 1),
(63, 3, 213, '2016-06-29 10:23:03', 1, 1, '2016-06-29 05:23:13', 0, '', '', '2016-06-29 05:23:14', 19.95, 16.08, 0.00, 0.00, 0.00, 4, 4, '', '2016-06-29 05:23:23', 1),
(64, 3, 217, '2016-06-29 12:49:54', 1, 1, '2016-06-29 08:14:31', 0, '', '', '2016-06-29 08:14:32', 649.95, 634.35, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(65, 167, 218, '2016-06-29 14:11:54', 1, 1, '2016-06-29 09:13:19', 0, '', '', '2016-06-29 09:13:20', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-29 09:13:26', 1),
(66, 167, 221, '2016-06-29 14:23:00', 1, 1, '2016-06-29 09:24:16', 0, '', '', '2016-06-29 09:24:17', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-29 09:24:21', 1),
(67, 167, 222, '2016-06-29 14:31:33', 1, 1, '2016-06-29 09:31:49', 0, '', '', '2016-06-29 09:31:50', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-29 09:31:53', 1),
(68, 9, 223, '2016-06-29 14:46:59', 1, 1, '2016-06-29 09:47:22', 0, '', '', '2016-06-29 09:47:23', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-29 09:47:31', 1),
(69, 167, 224, '2016-06-29 14:49:12', 1, 1, '2016-06-29 09:49:18', 0, '', '', '2016-06-29 09:49:18', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-29 09:49:25', 1),
(70, 167, 225, '2016-06-29 15:21:20', 1, 1, '2016-06-29 10:21:28', 0, '', '', '2016-06-29 10:21:29', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-29 10:21:32', 1),
(71, 9, 225, '2016-06-29 15:24:55', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(72, 3, 232, '2016-06-30 05:57:12', 1, 1, '2016-06-30 00:57:36', 0, '', '', '2016-06-30 00:57:37', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-30 00:57:46', 1),
(73, 164, 236, '2016-06-30 12:09:38', 1, 1, '2016-06-30 07:10:22', 0, '', '', '2016-06-30 07:10:23', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-30 07:10:29', 1),
(74, 167, 237, '2016-06-30 19:13:42', 1, 1, '2016-06-30 14:14:26', 0, '', '', '2016-06-30 14:14:27', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-30 14:28:00', 1),
(75, 167, 238, '2016-06-30 19:28:13', 1, 1, '2016-06-30 14:28:20', 0, '', '', '2016-06-30 14:28:21', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-30 14:28:25', 1),
(76, 167, 239, '2016-06-30 23:57:56', 1, 1, '2016-06-30 18:58:08', 0, '', '', '2016-06-30 18:58:09', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, 'Good', '2016-06-30 18:58:27', 1),
(77, 167, 240, '2016-07-01 00:36:02', 1, 1, '2016-06-30 19:36:07', 0, '', '', '2016-06-30 19:36:08', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, 'Ok', '2016-06-30 19:36:16', 1),
(78, 167, 248, '2016-07-02 01:36:12', 0, 0, '0000-00-00 00:00:00', 0, '', '0.045466', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 1, 1, '', '2016-07-01 20:39:07', 1),
(79, 167, 251, '2016-07-02 06:24:24', 1, 1, '2016-07-02 01:24:30', 0, '', '', '2016-07-02 01:24:30', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 2, '', '2016-07-02 01:24:50', 1),
(80, 167, 253, '2016-07-02 06:29:40', 1, 1, '2016-07-02 01:29:44', 0, '', '', '2016-07-02 01:29:45', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-02 01:30:42', 1),
(81, 167, 254, '2016-07-02 07:01:08', 1, 1, '2016-07-02 02:01:11', 0, '', '', '2016-07-02 02:01:12', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-02 02:01:22', 1),
(82, 171, 258, '2016-07-02 08:13:30', 1, 1, '2016-07-02 03:13:34', 0, '', '', '2016-07-02 03:13:35', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(83, 171, 260, '2016-07-04 05:24:05', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 1, 1, '', '2016-07-04 00:24:54', 1),
(84, 171, 261, '2016-07-04 05:27:19', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 1, 1, '', '2016-07-04 00:27:27', 1),
(85, 171, 264, '2016-07-04 05:33:27', 1, 1, '2016-07-04 00:34:25', 0, '', '', '2016-07-04 00:34:26', 20.05, 15.3, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 00:34:30', 1),
(86, 171, 265, '2016-07-04 05:40:20', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(87, 171, 268, '2016-07-04 20:15:01', 1, 1, '2016-07-04 15:15:10', 0, '', '', '2016-07-04 15:15:12', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 15:15:18', 1),
(88, 171, 269, '2016-07-04 23:22:58', 1, 1, '2016-07-04 18:24:06', 0, '', '', '2016-07-04 18:24:07', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 18:24:11', 1),
(89, 171, 270, '2016-07-04 23:24:36', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(90, 171, 272, '2016-07-04 23:25:38', 1, 1, '2016-07-04 18:25:45', 0, '', '', '2016-07-04 18:25:46', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 18:25:50', 1),
(91, 171, 280, '2016-07-05 00:14:16', 1, 1, '2016-07-04 19:14:23', 0, '', '', '2016-07-04 19:14:24', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 19:14:30', 1),
(92, 171, 281, '2016-07-05 00:51:59', 1, 1, '2016-07-04 19:52:05', 0, '', '', '2016-07-04 19:52:06', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 19:52:12', 1),
(93, 39, 289, '2016-07-05 06:27:59', 1, 0, '2016-07-05 02:25:46', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(94, 39, 293, '2016-07-05 07:34:28', 1, 1, '2016-07-05 02:57:06', 0, '', '', '2016-07-05 02:57:07', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(95, 39, 294, '2016-07-05 07:58:52', 1, 1, '2016-07-05 03:00:06', 0, '', '', '2016-07-05 03:00:08', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(96, 39, 295, '2016-07-05 08:07:28', 1, 1, '2016-07-05 03:08:11', 0, '', '', '2016-07-05 03:08:12', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(97, 39, 296, '2016-07-05 08:13:53', 1, 1, '2016-07-05 03:14:05', 0, '', '', '2016-07-05 03:14:06', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(98, 39, 300, '2016-07-05 08:19:19', 1, 1, '2016-07-05 03:19:30', 0, '', '', '2016-07-05 03:19:31', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(99, 39, 302, '2016-07-05 08:23:53', 1, 1, '2016-07-05 03:23:59', 0, '', '', '2016-07-05 03:24:01', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(100, 39, 303, '2016-07-05 08:25:42', 1, 1, '2016-07-05 03:25:48', 0, '', '', '2016-07-05 03:25:49', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(101, 39, 306, '2016-07-05 08:28:22', 1, 1, '2016-07-05 03:28:36', 0, '', '', '2016-07-05 03:28:37', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(102, 164, 328, '2016-07-05 18:50:31', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(103, 164, 330, '2016-07-05 18:55:23', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(104, 171, 332, '2016-07-05 20:36:16', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(105, 171, 333, '2016-07-05 20:41:20', 2, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId333.png', '', '2016-07-05 15:44:50', 19.95, 15.2, 19.00, 3.80, 0.95, 4, 4, 'excellent job', '2016-07-05 15:44:29', 1),
(106, 39, 340, '2016-07-05 21:53:14', 2, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId340.png', '', '2016-07-05 16:53:23', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(107, 171, 341, '2016-07-05 21:54:11', 2, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId341.png', '', '2016-07-05 16:54:17', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(108, 39, 342, '2016-07-05 21:55:27', 2, 0, '0000-00-00 00:00:00', 0, 'requestMapURLId342.png', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 4, 9, '', '2016-07-05 16:55:45', 1),
(109, 39, 344, '2016-07-05 22:58:34', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(110, 171, 366, '2016-07-07 00:03:28', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(111, 3, 368, '2016-07-07 04:31:38', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId368.png', '', '2016-07-06 23:34:10', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(112, 3, 370, '2016-07-07 05:31:26', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId370.png', '', '2016-07-07 06:52:07', 124.12, 94.57, 118.21, 23.64, 5.91, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(113, 3, 371, '2016-07-07 05:45:01', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId371.png', '', '2016-07-07 01:00:48', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(114, 3, 375, '2016-07-07 06:01:10', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId375.png', '', '2016-07-07 01:15:33', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(115, 3, 374, '2016-07-07 06:01:29', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId374.png', '', '2016-07-07 05:28:21', 88.27, 67.25, 84.06, 16.81, 4.20, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(116, 3, 373, '2016-07-07 06:01:39', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId373.png', '', '2016-07-07 05:30:16', 88.82, 67.67, 84.59, 16.92, 4.23, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(117, 3, 376, '2016-07-07 06:20:30', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId376.png', '', '2016-07-07 07:37:56', 123.09, 93.78, 117.23, 23.45, 5.86, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(118, 3, 377, '2016-07-07 06:20:44', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId377.png', '', '2016-07-07 01:28:48', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(119, 3, 379, '2016-07-07 06:29:19', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(120, 3, 378, '2016-07-07 06:37:40', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(121, 3, 387, '2016-07-07 11:20:56', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(122, 3, 386, '2016-07-07 11:21:55', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(123, 3, 385, '2016-07-07 11:22:41', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(124, 3, 392, '2016-07-07 11:57:29', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(125, 3, 391, '2016-07-07 11:57:56', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId391.png', '', '2016-07-07 07:22:05', 23.1, 17.6, 22.00, 4.40, 1.10, 4, 4, '', '2016-07-07 07:23:28', 1),
(126, 3, 389, '2016-07-07 11:58:16', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId389.png', '', '2016-07-07 07:06:52', 23.1, 17.6, 22.00, 4.40, 1.10, 4, 4, '', '2016-07-07 07:04:26', 1),
(127, 3, 390, '2016-07-07 11:59:10', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId390.png', '', '2016-07-07 07:01:30', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qRequestBillImages`
--

DROP TABLE IF EXISTS `qRequestBillImages`;
CREATE TABLE IF NOT EXISTS `qRequestBillImages` (
`billImageId` bigint(20) NOT NULL,
  `qRequestId` bigint(20) NOT NULL,
  `billImage` varchar(2000) NOT NULL,
  `billAmount` float(9,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qRequestBillImages`
--

INSERT INTO `qRequestBillImages` (`billImageId`, `qRequestId`, `billImage`, `billAmount`) VALUES
(1, 5, '1463142535884.jpg', 50.00),
(2, 34, '1464643622979.jpg', 0.00),
(3, 37, '1464645517373.jpg', 12.00),
(4, 37, '1464645606745.jpg', 11.32),
(5, 37, '1464645680349.jpg', 11.49),
(6, 42, '1464691071662.jpg', 123.00),
(7, 53, '1464758834752.jpg', 40.00),
(8, 54, '1464759379159.jpg', 1.00),
(9, 55, '1464759645136.jpg', 1.00),
(10, 56, '1464759875619.jpg', 1.00),
(11, 66, '1465596930613.jpg', 25.28),
(12, 71, '1466189347923.jpg', 0.00),
(13, 94, '1466491328262.jpg', 0.00),
(14, 123, '1466564884546.jpg', 0.20),
(15, 144, '1466799856077.jpg', 20.00),
(16, 186, '1467132500013.jpg', 500.00),
(17, 197, '1467162580044.jpg', 6.50),
(18, 217, '1467204633087.jpeg', 600.00),
(19, 248, '1467423531994.jpg', 0.10),
(20, 260, '1467609864749.jpg', 0.00),
(21, 264, '1467610462694.jpg', 0.10),
(22, 289, '1467700165882.jpg', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `reportIssue`
--

DROP TABLE IF EXISTS `reportIssue`;
CREATE TABLE IF NOT EXISTS `reportIssue` (
  `issueDetail` varchar(255) NOT NULL,
  `userId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reportIssue`
--

INSERT INTO `reportIssue` (`issueDetail`, `userId`) VALUES
('Fix bugs  please ', 12),
('i''m having trouble logging in ', 7),
('Trying to become a Q. Recieved an error message that I needed to contact admin.\n\nThanks you', 48),
('test', 7),
('my account is not verified ', 99),
('Hello, it says my accoint is not verified. Please help to ensure account is verified ', 152),
('hii I couldn''t  register my DOB.\nit doesn''t go back. ', 154),
('Hi i received message stating that my Q is not verified.', 211),
('hi I tried to register but former some reason it didn''t work. it''s contact  administration. ', 154),
('also I couldn''t write my DOB. \n01/31/1980.\n', 154),
('How do I get my account verfied?', 224);

-- --------------------------------------------------------

--
-- Table structure for table `requestSentToQ`
--

DROP TABLE IF EXISTS `requestSentToQ`;
CREATE TABLE IF NOT EXISTS `requestSentToQ` (
`notificationId` bigint(20) NOT NULL,
  `qRequestId` bigint(20) NOT NULL,
  `qId` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=947 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requestSentToQ`
--

INSERT INTO `requestSentToQ` (`notificationId`, `qRequestId`, `qId`) VALUES
(1, 68, 8),
(2, 68, 3),
(3, 70, 8),
(4, 70, 3),
(5, 70, 4),
(6, 71, 4),
(7, 71, 8),
(8, 71, 3),
(9, 72, 4),
(10, 72, 8),
(11, 72, 3),
(12, 73, 4),
(13, 73, 8),
(14, 73, 9),
(15, 74, 4),
(16, 74, 8),
(17, 74, 9),
(18, 75, 4),
(19, 75, 8),
(20, 76, 8),
(21, 76, 10),
(22, 77, 8),
(23, 77, 10),
(24, 79, 3),
(25, 79, 4),
(26, 79, 8),
(27, 80, 3),
(28, 80, 4),
(29, 80, 8),
(30, 81, 4),
(31, 81, 8),
(32, 81, 3),
(33, 82, 4),
(34, 82, 8),
(35, 82, 3),
(36, 83, 4),
(37, 83, 8),
(38, 83, 3),
(39, 84, 4),
(40, 84, 8),
(41, 84, 3),
(42, 85, 4),
(43, 85, 8),
(44, 86, 4),
(45, 86, 8),
(46, 87, 4),
(47, 87, 8),
(48, 88, 4),
(49, 88, 8),
(50, 89, 4),
(51, 89, 8),
(52, 90, 4),
(53, 90, 8),
(54, 91, 4),
(55, 91, 8),
(56, 92, 4),
(57, 92, 8),
(58, 93, 4),
(59, 93, 8),
(60, 94, 4),
(61, 94, 8),
(62, 95, 8),
(63, 93, 3),
(64, 95, 3),
(65, 96, 8),
(66, 96, 3),
(67, 97, 3),
(68, 97, 8),
(69, 98, 8),
(70, 99, 8),
(71, 100, 8),
(72, 101, 8),
(73, 102, 8),
(74, 103, 8),
(75, 104, 8),
(76, 105, 8),
(77, 106, 8),
(78, 107, 8),
(79, 98, 4),
(80, 100, 4),
(81, 102, 4),
(82, 103, 4),
(83, 104, 4),
(84, 107, 4),
(85, 100, 3),
(86, 102, 3),
(87, 103, 3),
(88, 104, 3),
(89, 108, 3),
(90, 108, 8),
(91, 109, 3),
(92, 109, 8),
(93, 110, 3),
(94, 110, 8),
(95, 111, 3),
(96, 112, 8),
(97, 114, 8),
(98, 115, 8),
(99, 116, 8),
(100, 117, 8),
(101, 118, 4),
(102, 118, 8),
(103, 119, 4),
(104, 119, 8),
(105, 121, 4),
(106, 121, 8),
(107, 122, 4),
(108, 122, 8),
(109, 123, 127),
(110, 175, 4),
(111, 175, 8),
(112, 175, 39),
(113, 175, 127),
(114, 176, 4),
(115, 176, 8),
(116, 176, 39),
(117, 176, 127),
(118, 178, 4),
(119, 178, 8),
(120, 178, 39),
(121, 178, 127),
(122, 179, 4),
(123, 179, 8),
(124, 179, 39),
(125, 179, 127),
(126, 181, 3),
(127, 181, 4),
(128, 181, 8),
(129, 181, 39),
(130, 181, 127),
(131, 182, 3),
(132, 182, 4),
(133, 182, 8),
(134, 182, 39),
(135, 182, 127),
(136, 183, 3),
(137, 183, 4),
(138, 183, 8),
(139, 183, 39),
(140, 183, 127),
(141, 184, 3),
(142, 184, 4),
(143, 184, 8),
(144, 184, 39),
(145, 184, 127),
(146, 185, 3),
(147, 185, 4),
(148, 185, 8),
(149, 185, 39),
(150, 185, 127),
(151, 186, 3),
(152, 186, 4),
(153, 186, 8),
(154, 186, 39),
(155, 187, 3),
(156, 187, 4),
(157, 187, 8),
(158, 187, 39),
(159, 188, 4),
(160, 188, 8),
(161, 188, 39),
(162, 189, 4),
(163, 189, 8),
(164, 189, 39),
(165, 189, 160),
(166, 190, 4),
(167, 190, 8),
(168, 190, 39),
(169, 191, 4),
(170, 191, 8),
(171, 191, 39),
(172, 191, 3),
(173, 192, 4),
(174, 192, 8),
(175, 192, 39),
(176, 192, 164),
(177, 192, 3),
(178, 193, 4),
(179, 193, 8),
(180, 193, 39),
(181, 193, 164),
(182, 194, 3),
(183, 194, 4),
(184, 194, 8),
(185, 194, 39),
(186, 194, 164),
(187, 195, 3),
(188, 195, 4),
(189, 195, 8),
(190, 195, 39),
(191, 195, 164),
(192, 196, 4),
(193, 196, 8),
(194, 196, 167),
(195, 197, 4),
(196, 197, 8),
(197, 197, 39),
(198, 197, 164),
(199, 197, 167),
(200, 197, 3),
(201, 198, 4),
(202, 198, 8),
(203, 198, 9),
(204, 199, 4),
(205, 199, 8),
(206, 199, 39),
(207, 199, 164),
(208, 199, 3),
(209, 199, 167),
(210, 200, 4),
(211, 200, 8),
(212, 200, 167),
(213, 202, 4),
(214, 202, 8),
(215, 202, 39),
(216, 202, 167),
(217, 202, 3),
(218, 203, 4),
(219, 203, 8),
(220, 203, 39),
(221, 203, 164),
(222, 204, 4),
(223, 204, 8),
(224, 204, 39),
(225, 204, 164),
(226, 204, 3),
(227, 205, 4),
(228, 205, 8),
(229, 205, 39),
(230, 205, 164),
(231, 206, 4),
(232, 206, 8),
(233, 206, 39),
(234, 206, 164),
(235, 207, 4),
(236, 207, 8),
(237, 207, 39),
(238, 207, 164),
(239, 205, 3),
(240, 206, 3),
(241, 207, 3),
(242, 208, 3),
(243, 208, 4),
(244, 208, 8),
(245, 208, 39),
(246, 208, 164),
(247, 209, 3),
(248, 209, 4),
(249, 209, 8),
(250, 209, 39),
(251, 209, 164),
(252, 211, 4),
(253, 211, 8),
(254, 211, 39),
(255, 211, 164),
(256, 211, 3),
(257, 212, 3),
(258, 212, 4),
(259, 212, 8),
(260, 212, 39),
(261, 212, 164),
(262, 213, 3),
(263, 213, 4),
(264, 213, 8),
(265, 213, 39),
(266, 213, 164),
(267, 214, 3),
(268, 214, 4),
(269, 214, 8),
(270, 214, 39),
(271, 214, 164),
(272, 215, 4),
(273, 215, 8),
(274, 215, 164),
(275, 215, 3),
(276, 216, 4),
(277, 216, 8),
(278, 216, 39),
(279, 216, 164),
(280, 216, 3),
(281, 217, 3),
(282, 217, 4),
(283, 217, 8),
(284, 217, 39),
(285, 217, 164),
(286, 218, 4),
(287, 218, 8),
(288, 218, 39),
(289, 218, 164),
(290, 218, 167),
(291, 219, 4),
(292, 219, 8),
(293, 219, 39),
(294, 219, 164),
(295, 219, 167),
(296, 219, 3),
(297, 221, 4),
(298, 221, 8),
(299, 221, 164),
(300, 221, 167),
(301, 222, 4),
(302, 222, 8),
(303, 222, 164),
(304, 222, 167),
(305, 223, 4),
(306, 223, 8),
(307, 223, 9),
(308, 223, 39),
(309, 223, 164),
(310, 223, 3),
(311, 224, 4),
(312, 224, 8),
(313, 224, 39),
(314, 224, 164),
(315, 224, 167),
(316, 224, 3),
(317, 225, 4),
(318, 225, 8),
(319, 225, 9),
(320, 225, 164),
(321, 225, 167),
(322, 226, 4),
(323, 226, 8),
(324, 226, 39),
(325, 226, 3),
(326, 228, 3),
(327, 228, 4),
(328, 228, 8),
(329, 228, 39),
(330, 229, 3),
(331, 229, 4),
(332, 229, 8),
(333, 229, 39),
(334, 230, 3),
(335, 230, 4),
(336, 230, 8),
(337, 230, 39),
(338, 231, 3),
(339, 231, 4),
(340, 231, 8),
(341, 231, 39),
(342, 232, 3),
(343, 232, 4),
(344, 232, 8),
(345, 232, 39),
(346, 234, 4),
(347, 234, 8),
(348, 234, 39),
(349, 235, 4),
(350, 235, 8),
(351, 235, 39),
(352, 236, 4),
(353, 236, 8),
(354, 236, 39),
(355, 236, 164),
(356, 237, 4),
(357, 237, 8),
(358, 237, 164),
(359, 237, 167),
(360, 238, 4),
(361, 238, 8),
(362, 238, 164),
(363, 238, 167),
(364, 239, 4),
(365, 239, 8),
(366, 239, 39),
(367, 239, 167),
(368, 240, 4),
(369, 240, 8),
(370, 240, 39),
(371, 240, 167),
(372, 241, 4),
(373, 241, 8),
(374, 241, 39),
(375, 241, 164),
(376, 241, 167),
(377, 242, 4),
(378, 242, 8),
(379, 242, 39),
(380, 242, 164),
(381, 242, 167),
(382, 243, 4),
(383, 243, 8),
(384, 243, 39),
(385, 243, 164),
(386, 243, 167),
(387, 244, 4),
(388, 244, 8),
(389, 244, 39),
(390, 244, 164),
(391, 244, 167),
(392, 245, 4),
(393, 245, 8),
(394, 245, 39),
(395, 245, 164),
(396, 245, 167),
(397, 246, 4),
(398, 246, 8),
(399, 246, 39),
(400, 246, 164),
(401, 246, 167),
(402, 247, 4),
(403, 247, 8),
(404, 247, 164),
(405, 247, 167),
(406, 248, 4),
(407, 248, 8),
(408, 248, 164),
(409, 248, 167),
(410, 249, 4),
(411, 249, 8),
(412, 249, 39),
(413, 249, 164),
(414, 250, 4),
(415, 250, 8),
(416, 250, 39),
(417, 250, 164),
(418, 249, 167),
(419, 251, 4),
(420, 251, 8),
(421, 251, 39),
(422, 251, 167),
(423, 252, 4),
(424, 252, 8),
(425, 252, 39),
(426, 252, 167),
(427, 253, 4),
(428, 253, 8),
(429, 253, 39),
(430, 253, 167),
(431, 254, 4),
(432, 254, 8),
(433, 254, 39),
(434, 254, 167),
(435, 255, 4),
(436, 255, 8),
(437, 255, 39),
(438, 255, 167),
(439, 256, 4),
(440, 256, 8),
(441, 256, 39),
(442, 256, 167),
(443, 256, 171),
(444, 257, 4),
(445, 257, 8),
(446, 257, 39),
(447, 257, 167),
(448, 257, 171),
(449, 258, 4),
(450, 258, 8),
(451, 258, 39),
(452, 258, 167),
(453, 258, 171),
(454, 260, 4),
(455, 260, 8),
(456, 260, 39),
(457, 260, 164),
(458, 260, 167),
(459, 260, 171),
(460, 261, 4),
(461, 261, 8),
(462, 261, 39),
(463, 261, 164),
(464, 261, 167),
(465, 261, 171),
(466, 262, 4),
(467, 262, 8),
(468, 262, 39),
(469, 262, 164),
(470, 262, 167),
(471, 262, 171),
(472, 264, 4),
(473, 264, 8),
(474, 264, 39),
(475, 264, 164),
(476, 264, 167),
(477, 264, 171),
(478, 265, 4),
(479, 265, 8),
(480, 265, 39),
(481, 265, 167),
(482, 265, 171),
(483, 266, 4),
(484, 266, 8),
(485, 266, 39),
(486, 266, 167),
(487, 266, 171),
(488, 268, 4),
(489, 268, 8),
(490, 268, 39),
(491, 268, 167),
(492, 268, 171),
(493, 269, 4),
(494, 269, 8),
(495, 269, 39),
(496, 269, 167),
(497, 269, 171),
(498, 270, 4),
(499, 270, 8),
(500, 270, 39),
(501, 270, 167),
(502, 270, 171),
(503, 272, 4),
(504, 272, 8),
(505, 272, 39),
(506, 272, 167),
(507, 272, 171),
(508, 278, 4),
(509, 278, 8),
(510, 278, 39),
(511, 278, 167),
(512, 278, 171),
(513, 279, 4),
(514, 279, 8),
(515, 279, 39),
(516, 279, 167),
(517, 279, 171),
(518, 280, 4),
(519, 280, 8),
(520, 280, 39),
(521, 280, 167),
(522, 280, 171),
(523, 281, 4),
(524, 281, 8),
(525, 281, 39),
(526, 281, 167),
(527, 281, 171),
(528, 283, 4),
(529, 283, 8),
(530, 283, 39),
(531, 283, 167),
(532, 283, 171),
(533, 284, 4),
(534, 284, 8),
(535, 284, 39),
(536, 284, 167),
(537, 284, 171),
(538, 285, 4),
(539, 285, 8),
(540, 285, 39),
(541, 285, 167),
(542, 285, 171),
(543, 289, 4),
(544, 289, 8),
(545, 289, 39),
(546, 289, 167),
(547, 289, 171),
(548, 290, 4),
(549, 290, 8),
(550, 290, 39),
(551, 290, 167),
(552, 290, 171),
(553, 292, 4),
(554, 292, 8),
(555, 292, 39),
(556, 292, 167),
(557, 293, 4),
(558, 293, 8),
(559, 293, 39),
(560, 293, 167),
(561, 294, 4),
(562, 294, 8),
(563, 294, 39),
(564, 294, 167),
(565, 295, 4),
(566, 295, 8),
(567, 295, 39),
(568, 295, 167),
(569, 296, 4),
(570, 296, 8),
(571, 296, 39),
(572, 296, 167),
(573, 297, 4),
(574, 297, 8),
(575, 297, 39),
(576, 297, 167),
(577, 298, 4),
(578, 298, 8),
(579, 298, 167),
(580, 299, 4),
(581, 299, 8),
(582, 299, 167),
(583, 300, 4),
(584, 300, 8),
(585, 300, 167),
(586, 298, 39),
(587, 299, 39),
(588, 300, 39),
(589, 301, 4),
(590, 301, 8),
(591, 301, 39),
(592, 301, 167),
(593, 302, 4),
(594, 302, 8),
(595, 302, 39),
(596, 302, 167),
(597, 303, 4),
(598, 303, 8),
(599, 303, 39),
(600, 303, 167),
(601, 304, 4),
(602, 304, 8),
(603, 304, 39),
(604, 304, 167),
(605, 306, 4),
(606, 306, 8),
(607, 306, 39),
(608, 306, 167),
(609, 305, 4),
(610, 305, 8),
(611, 305, 39),
(612, 305, 167),
(613, 309, 4),
(614, 309, 8),
(615, 309, 39),
(616, 309, 167),
(617, 310, 4),
(618, 310, 8),
(619, 310, 39),
(620, 310, 167),
(621, 311, 4),
(622, 311, 8),
(623, 311, 39),
(624, 311, 167),
(625, 312, 4),
(626, 312, 8),
(627, 312, 39),
(628, 312, 167),
(629, 313, 4),
(630, 313, 8),
(631, 313, 39),
(632, 313, 167),
(633, 314, 4),
(634, 314, 8),
(635, 314, 39),
(636, 314, 167),
(637, 315, 4),
(638, 315, 8),
(639, 315, 39),
(640, 315, 167),
(641, 316, 4),
(642, 316, 8),
(643, 316, 39),
(644, 316, 167),
(645, 318, 4),
(646, 318, 8),
(647, 318, 39),
(648, 318, 167),
(649, 320, 4),
(650, 320, 8),
(651, 320, 39),
(652, 320, 167),
(653, 321, 4),
(654, 321, 8),
(655, 321, 39),
(656, 321, 167),
(657, 322, 4),
(658, 322, 8),
(659, 322, 39),
(660, 322, 167),
(661, 324, 4),
(662, 324, 8),
(663, 324, 39),
(664, 324, 167),
(665, 324, 171),
(666, 325, 4),
(667, 325, 8),
(668, 325, 167),
(669, 325, 171),
(670, 326, 4),
(671, 326, 8),
(672, 326, 39),
(673, 326, 167),
(674, 328, 4),
(675, 328, 8),
(676, 328, 39),
(677, 328, 167),
(678, 328, 164),
(679, 328, 171),
(680, 329, 4),
(681, 329, 8),
(682, 329, 39),
(683, 329, 167),
(684, 329, 171),
(685, 330, 4),
(686, 330, 8),
(687, 330, 39),
(688, 330, 164),
(689, 330, 167),
(690, 331, 4),
(691, 331, 8),
(692, 331, 39),
(693, 331, 164),
(694, 331, 167),
(695, 332, 4),
(696, 332, 8),
(697, 332, 167),
(698, 332, 171),
(699, 333, 4),
(700, 333, 8),
(701, 333, 167),
(702, 333, 171),
(703, 334, 4),
(704, 334, 8),
(705, 334, 39),
(706, 334, 164),
(707, 334, 167),
(708, 336, 4),
(709, 336, 8),
(710, 336, 39),
(711, 336, 164),
(712, 336, 167),
(713, 337, 4),
(714, 337, 8),
(715, 337, 39),
(716, 337, 164),
(717, 337, 167),
(718, 338, 171),
(719, 338, 4),
(720, 338, 8),
(721, 338, 39),
(722, 338, 164),
(723, 338, 167),
(724, 339, 4),
(725, 339, 8),
(726, 339, 39),
(727, 339, 164),
(728, 339, 167),
(729, 340, 4),
(730, 340, 8),
(731, 340, 39),
(732, 340, 164),
(733, 340, 167),
(734, 341, 171),
(735, 339, 171),
(736, 342, 4),
(737, 342, 8),
(738, 342, 39),
(739, 342, 164),
(740, 342, 167),
(741, 343, 4),
(742, 343, 8),
(743, 343, 39),
(744, 343, 164),
(745, 343, 167),
(746, 344, 4),
(747, 344, 8),
(748, 344, 39),
(749, 344, 164),
(750, 344, 167),
(751, 345, 4),
(752, 345, 8),
(753, 345, 164),
(754, 345, 167),
(755, 346, 4),
(756, 346, 8),
(757, 346, 164),
(758, 346, 167),
(759, 348, 4),
(760, 348, 8),
(761, 348, 164),
(762, 348, 167),
(763, 349, 4),
(764, 349, 8),
(765, 349, 164),
(766, 349, 167),
(767, 350, 4),
(768, 350, 8),
(769, 350, 164),
(770, 350, 167),
(771, 351, 4),
(772, 351, 8),
(773, 351, 164),
(774, 351, 167),
(775, 352, 4),
(776, 352, 8),
(777, 352, 164),
(778, 352, 167),
(779, 353, 4),
(780, 353, 8),
(781, 353, 164),
(782, 353, 167),
(783, 354, 4),
(784, 354, 8),
(785, 354, 164),
(786, 354, 167),
(787, 355, 4),
(788, 355, 8),
(789, 355, 164),
(790, 355, 167),
(791, 356, 4),
(792, 356, 8),
(793, 356, 164),
(794, 356, 167),
(795, 357, 4),
(796, 357, 8),
(797, 357, 164),
(798, 357, 167),
(799, 358, 4),
(800, 358, 8),
(801, 358, 164),
(802, 358, 167),
(803, 359, 4),
(804, 359, 8),
(805, 359, 164),
(806, 359, 167),
(807, 360, 4),
(808, 360, 8),
(809, 360, 164),
(810, 360, 167),
(811, 361, 4),
(812, 361, 8),
(813, 361, 164),
(814, 361, 167),
(815, 363, 4),
(816, 363, 8),
(817, 363, 164),
(818, 363, 167),
(819, 364, 4),
(820, 364, 8),
(821, 364, 164),
(822, 364, 167),
(823, 366, 4),
(824, 366, 8),
(825, 366, 164),
(826, 366, 167),
(827, 366, 171),
(828, 367, 4),
(829, 367, 8),
(830, 367, 164),
(831, 367, 167),
(832, 368, 3),
(833, 369, 4),
(834, 369, 8),
(835, 369, 39),
(836, 369, 164),
(837, 369, 167),
(838, 369, 3),
(839, 370, 3),
(840, 370, 4),
(841, 370, 8),
(842, 370, 39),
(843, 370, 164),
(844, 370, 167),
(845, 371, 3),
(846, 371, 4),
(847, 371, 8),
(848, 371, 39),
(849, 371, 164),
(850, 371, 167),
(851, 372, 4),
(852, 372, 8),
(853, 372, 39),
(854, 372, 164),
(855, 372, 167),
(856, 373, 4),
(857, 373, 8),
(858, 373, 39),
(859, 373, 164),
(860, 373, 167),
(861, 374, 4),
(862, 374, 8),
(863, 374, 39),
(864, 374, 164),
(865, 374, 167),
(866, 375, 4),
(867, 375, 8),
(868, 375, 39),
(869, 375, 164),
(870, 375, 167),
(871, 372, 3),
(872, 373, 3),
(873, 374, 3),
(874, 375, 3),
(875, 376, 3),
(876, 376, 4),
(877, 376, 8),
(878, 376, 39),
(879, 376, 164),
(880, 376, 167),
(881, 377, 3),
(882, 377, 4),
(883, 377, 8),
(884, 377, 39),
(885, 377, 164),
(886, 377, 167),
(887, 378, 4),
(888, 378, 8),
(889, 378, 39),
(890, 378, 164),
(891, 378, 167),
(892, 379, 4),
(893, 379, 8),
(894, 379, 39),
(895, 379, 164),
(896, 379, 167),
(897, 378, 3),
(898, 379, 3),
(899, 380, 4),
(900, 380, 8),
(901, 380, 39),
(902, 380, 164),
(903, 380, 167),
(904, 381, 4),
(905, 381, 8),
(906, 381, 39),
(907, 381, 164),
(908, 381, 167),
(909, 382, 4),
(910, 382, 8),
(911, 382, 39),
(912, 382, 167),
(913, 383, 4),
(914, 383, 8),
(915, 383, 39),
(916, 383, 167),
(917, 384, 4),
(918, 384, 8),
(919, 384, 39),
(920, 384, 167),
(921, 385, 4),
(922, 385, 8),
(923, 385, 39),
(924, 385, 167),
(925, 386, 4),
(926, 386, 8),
(927, 386, 39),
(928, 386, 167),
(929, 387, 4),
(930, 387, 8),
(931, 387, 39),
(932, 387, 167),
(933, 385, 3),
(934, 386, 3),
(935, 387, 3),
(936, 389, 3),
(937, 390, 3),
(938, 391, 3),
(939, 392, 3),
(940, 393, 3),
(941, 394, 3),
(942, 395, 3),
(943, 396, 3),
(944, 397, 3),
(945, 398, 3),
(946, 399, 3);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
`state_id` int(11) NOT NULL,
  `state_name` varchar(50) NOT NULL,
  `state_ab` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`, `state_ab`) VALUES
(3, 'Alaska', 'AK'),
(4, 'Alabama', 'AL'),
(6, 'Arkansas', 'AR'),
(8, 'Arizona', 'AZ'),
(9, 'California', 'CA'),
(10, 'Colorado', 'CO'),
(11, 'Connecticut', 'CT'),
(12, 'District of Columbia', 'DC'),
(13, 'Delaware', 'DE'),
(14, 'Florida', 'FL'),
(16, 'Georgia', 'GA'),
(18, 'Hawaii', 'HI'),
(19, 'Iowa', 'IA'),
(20, 'Idaho', 'ID'),
(21, 'Illinois', 'IL'),
(22, 'Indiana', 'IN'),
(23, 'Kansas', 'KS'),
(24, 'Kentucky', 'KY'),
(25, 'Louisiana', 'LA'),
(26, 'Massachusetts', 'MA'),
(27, 'Maryland', 'MD'),
(28, 'Maine', 'ME'),
(30, 'Michigan', 'MI'),
(31, 'Minnesota', 'MN'),
(32, 'Missouri', 'MO'),
(34, 'Mississippi', 'MS'),
(35, 'Montana', 'MT'),
(36, 'North Carolina', 'NC'),
(37, 'North Dakota', 'ND'),
(38, 'Nebraska', 'NE'),
(39, 'New Hampshire', 'NH'),
(40, 'New Jersey', 'NJ'),
(41, 'New Mexico', 'NM'),
(42, 'Nevada', 'NV'),
(43, 'New York', 'NY'),
(44, 'Ohio', 'OH'),
(45, 'Oklahoma', 'OK'),
(46, 'Oregon', 'OR'),
(47, 'Pennsylvania', 'PA'),
(48, 'Puerto Rico', 'PR'),
(50, 'Rhode Island', 'RI'),
(51, 'South Carolina', 'SC'),
(52, 'South Dakota', 'SD'),
(53, 'Tennessee', 'TN'),
(54, 'Texas', 'TX'),
(56, 'Utah', 'UT'),
(57, 'Virginia', 'VA'),
(59, 'Vermont', 'VT'),
(60, 'Washington', 'WA'),
(61, 'Wisconsin', 'WI'),
(62, 'West Virginia', 'WV'),
(63, 'Wyoming', 'WY');

-- --------------------------------------------------------

--
-- Table structure for table `stopDetail`
--

DROP TABLE IF EXISTS `stopDetail`;
CREATE TABLE IF NOT EXISTS `stopDetail` (
  `stopDetailId` bigint(20) NOT NULL,
  `qRequestId` varchar(255) NOT NULL,
  `stopLat` float(9,6) NOT NULL,
  `stopLong` float(9,6) NOT NULL,
  `address` varchar(255) NOT NULL,
  `isQReachedAtStop` tinyint(4) NOT NULL,
  `reachedAtTime` datetime NOT NULL,
  `distanceTravelled` float(9,2) NOT NULL,
  `timeTakenForTravel` float(9,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stopDetail`
--

INSERT INTO `stopDetail` (`stopDetailId`, `qRequestId`, `stopLat`, `stopLong`, `address`, `isQReachedAtStop`, `reachedAtTime`, `distanceTravelled`, `timeTakenForTravel`) VALUES
(1, '1', 21.146875, 72.759598, 'Luxuria Business Hub, Beside Dumas Resort, Dumas Rd, Vesu, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '123', 34.106163, -118.463692, '1954-1980 Roscomare Rd 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '124', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '130', 31.805334, -106.382439, 'El Paso International Airport 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '131', 31.805334, -106.382439, 'El Paso International Airport 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '132', 31.912289, -106.573288, '7640 Crest Creek Ln 7640 Crest Creek Ln, Canutillo, TX 79835, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '133', 31.836048, -106.565727, 'Walmart Supercenter 7555 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '134', 31.805334, -106.382439, 'El Paso International Airport 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '17', 34.152893, -118.448975, 'Domino''s Pizza, 4467 Van Nuys Blvd, Sherman Oaks, CA 91403, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '196', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '198', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '200', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '201', 29.531197, -98.468346, 'San Antonio International Airport 9800 Airport Blvd, San Antonio, TX 78216, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '210', 31.829082, -106.447067, '5631 Dyer St, El Paso, TX 79904, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '221', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '222', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '225', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '233', 21.204893, 72.840843, 'Surat Railway Station Station Road, Suryapur Gate, Varachha, Railway Station Area, Varachha, Surat, Gujarat 395003, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '237', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '238', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '24', 34.105061, -118.463203, 'Haines Obtains Ltd 1924 Roscomare Rd, Los Angeles, CA 90077, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '247', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '248', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '25', 21.150036, 72.761703, '(21.1500353, 72.7617048) ', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '267', 21.170240, 72.831062, 'shop,7 ,krishna com,modi mohollo a,k,road surat, Laxmi Nagar, Udhna, Surat, Gujarat 395008, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '27', 19.386772, -99.210098, 'Cto de la Unidad 33 Cto de la Unidad 33, Sta Fé IMSS, 01170 Ciudad de México, D.F., México', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '28', 34.152534, -118.453819, 'CVS Pharmacy, 14735 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '282', 21.146473, 72.759399, '18/2, Dumas Road, Rundh, Rundh, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '286', 21.147245, 72.762794, 'Near VR mall opp Vastu Luxuria, Udhana-Magdalla Rd, Piplod, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '287', 21.150949, 72.760376, 'Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '288', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '29', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '291', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '307', 21.167906, 72.834969, 'Samithi English & Gujarati Medium School S Zone Rd, Opp. Akshar Kunj Apartment, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '308', 21.168407, 72.834763, 'Shiv Shakti Apartment S Zone Rd, Samity School, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '317', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '319', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '323', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '325', 34.156895, -118.490967, 'Hilltop Cleaners 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '332', 34.156895, -118.490967, 'Hilltop Cleaners 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '333', 34.106117, -118.463875, '2001 Roscomare Rd 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '347', 65.967606, -18.530159, 'Dalvík Vegamót Cottages??????????? Dalvik, Iceland', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '35', 34.153294, -118.456673, 'Pavilions, 14845 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '36', 34.106052, -118.463676, '1954-1980 Roscomare Rd, 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '362', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '365', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '368', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '37', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '38', 34.106125, -118.463692, '1954-1980 Roscomare Rd, 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '388', 21.145103, 72.757027, 'VR Surat Dumas Road, Magdalla, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '390', 21.148567, 72.760490, 'Raj Palace Dumas Rd, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '40', 21.147446, 72.759575, 'Vastu Luxuria | Surat, Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '41', 21.147026, 72.759743, 'ASK-EHS Engineering & Consultants Pvt. Ltd., 214 to 217 | Luxuria Business Hub | Besides Dumas Resort | Dumas Road, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '42', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '43', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '44', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '45', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '46', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '47', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '49', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '51', 21.150087, 72.768715, 'Raghuvir Party Plot, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '53', 21.146473, 72.759399, 'Dumas Resorts Pvt Ltd 18/2, Dumas Road, Rundh, Rundh, New Magdalla, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '57', 31.760315, -106.488647, 'Coffee Box, 401 N Mesa St, El Paso, TX 79901, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '59', 34.157021, -118.490662, 'Hilltop Cleaners, 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '60', 34.157021, -118.490662, 'Hilltop Cleaners, 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '61', 34.157021, -118.490662, 'Hilltop Cleaners, 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '62', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '63', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '64', 31.825670, -106.523575, 'Cafe Grille, 5860 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '65', 31.825670, -106.523575, 'Cafe Grille, 5860 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '69', 31.760881, -106.488350, 'Downtown El Paso, 201 E Main St #107, El Paso, TX 79901, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '73', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '74', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '75', 34.151253, -118.454292, '14724 Ventura Blvd, 14724 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '76', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '77', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '78', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '1', 21.153954, 72.763397, 'Nidhi impotrade pvt ltd, New Magdalla, Surat, Gujarat, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '123', 34.106163, -118.463692, '1954-1980 Roscomare Rd 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '124', 34.107975, -118.463478, '2003 Roscomare Rd, 2003 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '130', 31.752808, -106.488701, 'Downtown Transit Ctr Bay #P United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '131', 31.760881, -106.488350, 'Downtown El Paso 201 E Main St #107, El Paso, TX 79901, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '132', 31.912127, -106.573792, '7637 Crest Creek Ln 7637 Crest Creek Ln, Canutillo, TX 79835, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '133', 31.834141, -106.560448, '200 Desert Pass St 200 Desert Pass St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '134', 31.841196, -106.591515, 'El Paso Country Club 5000 Country Club Pl, El Paso, TX 79922, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '17', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '196', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '198', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '200', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '201', 29.522495, -98.502075, '613 NW Loop 410 613 NW Loop 410, San Antonio, TX 78216, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '210', 31.834141, -106.560448, '200 Desert Pass St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '221', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '222', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '225', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '233', 21.145103, 72.757027, 'VR Surat Dumas Road, Magdalla, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '237', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '238', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '24', 34.106400, -118.465675, 'Brentwood Express 1978 Linda Flora Dr, Los Angeles, CA 90077, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '247', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '248', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '25', 21.147640, 72.765335, '(21.1476404, 72.7653356) ', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '267', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '27', 19.388283, -99.210121, 'Cto de la Unidad 5 Cto de la Unidad 5, Maria G. de García Ruiz, 01160 Ciudad de México, D.F., México', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '28', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '282', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '286', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '287', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '288', 21.149733, 72.759399, 'P R Khatiwala Vidya Sankul Subhash Nagar, New Magdalla, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '29', 34.151253, -118.454292, '14724 Ventura Blvd, 14724 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '291', 21.147245, 72.762794, 'HEERA MOTI Wedding Lawn Near VR mall opp Vastu Luxuria, Udhana-Magdalla Rd, Piplod, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '307', 21.168367, 72.835182, 'S E M High School Behind Postal Society,Udhna Gam, Gayatri Society - 2, Gayatri Society, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '308', 21.168459, 72.834564, 'Ramji Nagar Souh Zone Road, Near Samithi School, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '317', 21.150949, 72.760376, 'C K Pithawala College Dumas Road Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '319', 21.150949, 72.760376, 'C K Pithawala College Dumas Road Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '323', 21.150415, 72.758652, 'S.B.R. Maheswari VidyaPeeth School Behind Rundnath Temple,, Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '325', 34.106117, -118.463875, '2001 Roscomare Rd 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '332', 34.106117, -118.463875, '2001 Roscomare Rd 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '333', 34.106159, -118.463524, '2002 Roscomare Rd 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '347', 65.967621, -18.532349, 'Fosshotel Dalvik Dalvik, Iceland', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '35', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '36', 34.161167, -118.510155, 'Bubbles Pet Spa Encino, 17301 Ventura Blvd, Encino, CA 91316, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '362', 21.147179, 72.759789, 'La Net Team Software Solutions Pvt. LTD. 405/406 Luxuria Business Hub, Near VR mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '365', 21.147026, 72.759743, 'ASK-EHS Engineering & Consultants Pvt. Ltd. 214 to 217 | Luxuria Business Hub | Besides Dumas Resort | Dumas Road, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '368', 21.148567, 72.760490, 'Raj Palace Dumas Rd, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '37', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '38', 34.106400, -118.465675, 'Brentwood Express, 1978 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '388', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '390', 21.147543, 72.759384, 'Garvi Films 611, Luxuria Business Hub, Beside Dumas Resort, Dumas Road, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '40', 21.151699, 72.762497, 'Empire Chevrolet, Plot No. 3, Dumas Road, Near Rangoli Hotel, Rundh, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '41', 21.147179, 72.759789, 'La Net Team Software Solutions Pvt. LTD., 405/406 Luxuria Business Hub, Near VR mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '42', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '43', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '44', 21.154350, 72.764778, 'Blaster Family Spot, Mall Gaurav Path,, Dumas Rd, Central Revenue Colony, Athwa, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '45', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '46', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '47', 21.154457, 72.764816, 'Gili, Mahrana Pratap Marg, Athwalines, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '49', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '51', 21.149622, 72.767448, 'DMD Party Plot, Piplod, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '53', 21.148399, 72.765404, 'Safal Square,UM Rd,Vesu Udhana-Magdalla Rd, Vesu, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '57', 31.895943, -106.575722, 'BizLink Technology, 1790 Commerce Park Dr, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '59', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '60', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '61', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '62', 33.985039, -118.390709, '6167 Bristol Pkwy, 6167 Bristol Pkwy, Culver City, CA 90230, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '63', 33.985039, -118.390709, '6167 Bristol Pkwy, 6167 Bristol Pkwy, Culver City, CA 90230, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '64', 31.833464, -106.536072, 'Julian''s Doggie Daycare & Boarding, 6330 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '65', 31.833464, -106.536072, 'Julian''s Doggie Daycare & Boarding, 6330 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '69', 31.805334, -106.382439, 'El Paso International Airport, 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '73', 34.151821, -118.454262, '14742 Ventura Blvd, 14742 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '74', 34.151821, -118.454262, '14742 Ventura Blvd, 14742 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '75', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '76', 34.106876, -118.466980, 'Puerta Grande Productions, 2007 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '77', 34.106876, -118.466980, 'Puerta Grande Productions, 2007 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '78', 34.106876, -118.466980, 'Puerta Grande Productions, 2007 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '1', 21.136570, 72.751862, 'Players Sports & Cafe, Cityplus Multiplex Front Parking Lot, Surat Dumas Road, Near Opp L & T Colony, Magdalla Port Road, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '40', 21.141336, 72.754982, 'Mataji hardware, Gail Colony, Vesu, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '41', 21.147442, 72.759575, 'Om Meditronics Pvt. Ltd., 506, Vastu Luxuria, Near Dumas Resort, Near VR Mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '42', 21.154417, 72.764633, 'Central Mall, Opp. Valentine Multiplex, Surat - Dumas Road, Athwa, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '47', 21.154417, 72.764633, 'Central Mall, Opp. Valentine Multiplex, Surat - Dumas Road, Athwa, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
`userId` bigint(20) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isEmailVerified` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=verified 0 = not verified ',
  `passcode` int(11) NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userProfile` varchar(255) NOT NULL,
  `deviceToken` varchar(255) NOT NULL,
  `deviceType` int(11) NOT NULL COMMENT '1 = android 0= IOS',
  `forgotRandom` int(11) NOT NULL,
  `userType` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 for user and 1 for admin',
  `changedEmail` varchar(255) NOT NULL,
  `changedMobile` varchar(255) NOT NULL,
  `isMobileverified` tinyint(4) NOT NULL,
  `mobilePasscode` int(11) NOT NULL,
  `isDeleted` int(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=340 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userId`, `firstName`, `lastName`, `email`, `mobile`, `password`, `isEmailVerified`, `passcode`, `createdDate`, `userProfile`, `deviceToken`, `deviceType`, `forgotRandom`, `userType`, `changedEmail`, `changedMobile`, `isMobileverified`, `mobilePasscode`, `isDeleted`) VALUES
(1, 'Tilak', 'Jethva', 'lanetteam.tilak@gmail.com', '9537624401', 'Lanetteam@123.123', 1, 223440, '2016-05-13 11:42:23', '1463140084582.jpg', 'fs-T7YFmZM4:APA91bG_xQU4224jLDFTS-nJTox3Oi5UXYv3lpS4aBDwqWUSNP-DntzBThMy0SKNLnKq8jDmlqvsS8ZztNQQ0teaNIoQKuo-XyIQQEYj3aXILznVRi4CyHV1da49C0e2Q1yNfZe66kJ1', 1, 0, 0, '', '', 1, 366021, 0),
(2, 'Riken', 'Doshi', 'lanetteam.riken@gmail.com', '9913060874', 'Lanet@123', 1, 396276, '2016-05-13 11:53:51', '1463140878975.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 641974, 0),
(3, 'Admin', 'Admin', 'admin@qapp.com', '', 'admin@123', 1, 223440, '2016-05-13 11:42:23', '1463140084582.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 1, '', '', 1, 311586, 0),
(4, 'Tapan', 'Gohil', 'lanetteam.tapan@gmail.com', '9898304401', 'Lanet@123', 1, 994616, '2016-05-13 12:25:18', '1464696868232.jpg', 'dZXD52Bfj-Q:APA91bF1WOpY4FDP1N3PfBA8DhwVzV0gO0v38OjKh7005unvS5U7NL1G0QqwRtTp67y3gFFnQ6ge22wHo2IamJeMh64N1EmeeWpIQ0PbgtVITLyQfV0wT7UA-2rjB2CDK_FFdLJuvaiO', 1, 0, 0, '', '', 1, 707978, 0),
(5, 'Vimal', 'Gajera', 'lanetteam.vimalgajera@gmail.com', '9998078073', 'Lanet@123', 1, 837844, '2016-05-13 12:51:50', '1466852327484.jpg', 'fmAANqn9tYQ:APA91bG4D4rxK7AcKiwO-YJ75nQhel1lehp9m2YY5X0GjUDvutho3GcEzPHwzPJ33jWYIG7TvIBMCsXO5XK0OGDIR3aL9hWTJ4kD0mzjsaxYU23UHIwFOYflzR9bkkfhNHrkGzGrHJ6g', 1, 0, 0, '', '', 1, 792848, 0),
(6, 'Felix', 'Odigie', 'felix@valdecapital.com', '6173881912', 'Rico@860424', 1, 102349, '2016-05-14 15:10:18', 'user-profile.png', 'fztKILuB0Ks:APA91bEBYSJKnMapew_-T6uMNykmI35xXgnbmpzKry_4imGjY3ArGqphXkKtC-d31BHWFAYZw8FIr3aWFUpnBHkWM82LTHKCH7Tpes3Alx_t6xfg8a7k2lgjjMBiGGXs_97UbBeKudEp', 1, 0, 0, '', '', 1, 699296, -1),
(7, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '8184658228', 'Justice2!', 1, 437133, '2016-05-15 00:24:24', '1464634891868.jpg', '3accd036208c70ed66fa1b5cc862b6e5edd62dcb86070da0ee2701168eabae56', 0, 753044, 0, 'kimberly.odigie@myqapp.com', '', 1, 149125, -1),
(9, 'Test', 'User', 'test@gmail.com', '9998078073', 'Abc@1234', 0, 114006, '2016-05-18 11:27:39', 'user-profile.png', 'fy4rcoxZiP4:APA91bHAc0J3_EVO6etx6UhMEkfWfYKRvZFctodFGYy66WDTt4iFcLyGTjmz2v8Y_taT5Uy97G-v8SHhz8klr2UtVOM1zjZKpHkHAR-3BR8Uzabi2JltsfsSRQxDNyK0fSFkyVjkzOOW', 1, 0, 0, '', '', 0, 416426, -1),
(10, 'Demo', 'User', 'demo@qapp.com', '9998887770', 'Qapp@123', 1, 636797, '2016-05-18 11:29:35', 'user-profile.png', 'b8bdd16a19a78c5e6a33d98958ea8bc94ef5249eaaa47761e8fbcdf553957e2d', 0, 0, 0, '', '', 1, 289355, -1),
(11, 'Fly', 'Flyerson', 'flyflyerson@gmail.com', '4088214398', 'Apple123!', 1, 997161, '2016-05-19 19:04:39', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 514664, 0),
(12, 'Cristian ', 'Try', 'lokinenuco@gmail.com', '9153556813', 'Salomon123!@', 1, 338221, '2016-05-23 21:24:12', 'user-profile.png', 'fdlsbwWEYBs:APA91bFS1umeDo6B7VAXleg3DbP5HYBqLm9o0OBeDA82U345nqnHXRWM4FEan4wd79JznzyDoVUBOmneMtrilUQxkX2EfzoCgBSpuXNy7otUANObo7rv5omSNdV_Kgw1GIh9SDDNI1MJ', 1, 0, 0, 'criptoc@hotmail.com ', '', 1, 588823, 0),
(13, 'Deric', 'Mccloud', 'dericrmccloud@gmail.com', '13342210826', 'Mccloud#1', 1, 102562, '2016-05-28 03:18:13', 'user-profile.png', 'f3eekuv74bs:APA91bHmR7_02FB-a07Cmn7en996QJ3wbEXCSm3uK2UmjgPjVoDuxtU2Nw_img8xN2qC6mv1Y371L7VZ8MjTOXTNB79YojItmxtimkBXFWOguyl8lumXp6cYU5EhAtb5tFQCspuEFLDq', 1, 0, 0, '', '', 1, 115515, 0),
(14, 'Felix', 'Odigie', 'felix@myqapp.com', '6173881912', 'Ric0860424!', 0, 797199, '2016-05-29 04:04:39', '1464628686642.jpg', 'fztKILuB0Ks:APA91bEBYSJKnMapew_-T6uMNykmI35xXgnbmpzKry_4imGjY3ArGqphXkKtC-d31BHWFAYZw8FIr3aWFUpnBHkWM82LTHKCH7Tpes3Alx_t6xfg8a7k2lgjjMBiGGXs_97UbBeKudEp', 1, 0, 0, 'felix.odigie@gmail.com', '', 1, 845208, -1),
(15, 'Angela', 'Ciochetti', 'am.ciochetti@gmail.com', '8604178983', 'Angela19!', 1, 353389, '2016-05-30 14:26:17', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 647736, 0),
(16, 'Felix', 'Odigie', 'felix.odigie@gmail.com', '6173881912', 'Ric0860424!', 1, 301756, '2016-05-30 17:25:01', '1466054826108.jpg', 'b9820a03e650f7b08fbc56c9acb075875cdf36e087e4fe9e6af0b8fb3031300f', 0, 0, 0, '', '', 1, 745696, 0),
(17, 'Kevin', 'Robinson', 'thomas77607@aol.com', '8185197366', 'Johnson7!', 1, 239592, '2016-05-30 17:36:06', 'user-profile.png', 'dHmsoDeFcyY:APA91bGZ8nEHs69wfL2G82eMTXKPw8A_TpFmVG48ePVz6bCdlT6D1b-4fuVlwBboyB7fxpQq24_VcAzGQLm7NtDSQZ94WkejK1BEzXJuYLd6iJgY0e97LdCAfukev_GYibPrOfdJsmty', 1, 0, 0, '', '', 1, 571912, 0),
(18, 'Paulette', 'Simone', 'rapturre@gmail.com', '8189179171', 'Kimberly22!', 1, 187942, '2016-05-30 17:43:45', '1465077736480.jpg', '9efa2a9d2f0d61893b01b6eb83b1292100f88b23113adf2e27859ae24b1d5812', 0, 0, 0, '', '', 1, 812346, 0),
(22, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '9154746047', 'Th3qp@ss', 1, 677408, '2016-06-01 16:08:36', 'user-profile.png', '6e68823f06cad38eefd7519db4f414eedfb7874b3218560aa67b056dcc0760af', 0, 998005, 0, '', '', 1, 475552, -1),
(23, 'Shivani', 'Chauhan', 'ldeveloperl1985@gmail.com', '9974072410', 'Lanetteam@1', 0, 710662, '2016-06-03 11:24:21', 'user-profile.png', '1b3dace55fc1988720eeffd8ee0a58e0b1e608e6969fac9b565443e09bf6eaf8', 0, 0, 0, '', '', 0, 972593, 0),
(24, 'Derrick', 'Smith', 'iderricksmithjr@gmail.com', '2096403224', 'Smitty24!', 0, 779906, '2016-06-06 18:51:26', 'user-profile.png', '3a56cee42b656de01c2d2f612eb86726076c44d124ae9c0c4bf2a92075934019', 0, 0, 0, '', '', 0, 720221, 0),
(25, 'Ivan', 'Cerezo', 'ivan.cerezo28@gmail.com', '3234701069', 'nbkNAVH23!@', 1, 908984, '2016-06-06 22:45:40', 'user-profile.png', 'fmTcfX4p38A:APA91bHAqeAgy_jQ0carHqZFJTojt19GkIT8FtfqK5gYvYXV2c-gFg844rI3YdQj8qStdmWwbr75UsinDlv0y7G3wgly0AUGa__aTy6RkYj1ZvmQYq8zKY9brLXtXu_usm_sGhxMxU-0', 1, 0, 0, '', '', 1, 525646, 0),
(26, 'Erin', 'Wilber', 'forever4learning@yahoo.com', '3235433435', 'Dexter1994!', 1, 135672, '2016-06-07 23:06:07', 'user-profile.png', '6e3714dee7436b73a992624638096d2e76899acb527cf01f6cd4c26695e490d8', 0, 0, 0, '', '', 1, 801138, 0),
(27, 'Rubot', 'H', 'vauxxer@gmail.com', '9154746047', 'Qn0wp@ss', 1, 541412, '2016-06-07 23:39:38', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 901327, -1),
(28, 'Sajid', 'Ansari', 'sajidansari0605@gmail.com', '7069995161', 'Sajid65@', 1, 989434, '2016-06-08 10:51:42', 'user-profile.png', 'e2-XkYWhsZ8:APA91bFMBUNVWBL_H9iIHUKkqzsOWwwY8ZO9JKgep3_Dbc56SCQZUEB-NkkrGB-OGWCoSlb43I6v8DFqExCvM_SBWyuIHHtSTbDhWy8GsR6ODcHHBXd2qBTD8vjR6TNmGoT3Iresvzub', 1, 0, 0, '', '', 0, 514731, -1),
(29, 'Jessica', 'Walton', 'jesssicaalexine@gmail.com', '4705648397', 'Alexine1!', 0, 694235, '2016-06-08 16:46:53', '1465404688893.jpg', '068264385dde1b5cfdc37827e1e5b68930db08a3cdeb9a578f6bcb9771ab4d5a', 0, 0, 0, '', '', 0, 903714, 0),
(30, 'Kristeen', 'Washington', 'kristeen.washington@gmail.com', '7078535100', 'Muffy2008!', 1, 114397, '2016-06-08 19:43:51', 'user-profile.png', '1a80e15c979bfc2a7c6a99e4a19762777f75d5774f4679fd7c150910c4c05b24', 0, 0, 0, '', '', 1, 994338, 0),
(31, 'Fanny', 'Lin', 'fannylinnn@gmail.com', '19178856565', '1L0v3icecr3am*', 0, 976998, '2016-06-08 19:51:04', 'user-profile.png', '47a55523b1fa27b79be020e036189db4758e7fd26e7fadeb11179872da6642db', 0, 0, 0, '', '', 0, 564688, 0),
(32, 'Kimberly', 'Odigai', 'kimberly.odiag@gmail.com', '2038849349', 'Qn0wp@ss', 0, 594534, '2016-06-08 20:21:12', 'user-profile.png', 'dgV3ek707-0:APA91bHrlZ3M4TFBzUuE1dYd0uiEpw25iW69sEOKr43yBdcjsS_Y8FmhKVJpmfg7FrLPZ0qtvzt4umqkBDbidI7NuvZg0GLSGRipeDyGvU9nvwLwgE_CzlNAcST3K7LVhgSQhrAnWUJo', 1, 0, 0, '', '', 0, 454969, -1),
(33, 'Ruben', 'Dev', 'ruben.h.dev@gmail.com', '9154746047', 'Qn0wp@ss', 1, 246191, '2016-06-08 20:30:42', 'user-profile.png', '6e68823f06cad38eefd7519db4f414eedfb7874b3218560aa67b056dcc0760af', 0, 0, 0, '', '', 1, 822700, -1),
(34, 'Ruben', 'Tester', 'ruben.h.hpe@gmail.com', '9154746047', 'Qn0wp@ss', 0, 485203, '2016-06-08 20:44:15', 'user-profile.png', '777949bc8e6a3de0ebc2ecd368f03654a716957dc8e31f37223101d40a12a000', 0, 0, 0, '', '', 0, 923696, 0),
(35, 'Rub', 'Hern', 'jrhernandez2@miners.utep.edu', '9154746047', 'Qn0wp@ss', 1, 485162, '2016-06-08 20:49:13', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 579924, -1),
(36, 'Judi', 'Figueroa', 'figueroaissa@yahoo.com', '3868820792', 'Chispito99$', 1, 819861, '2016-06-08 21:49:50', 'user-profile.png', 'e7bc6UWjsVQ:APA91bFEM_yqaEPNjFiVaErESyt_QGelx6GmYifX3w0pUB5Yk7bILCy7VBn_5URsfHJDxSuKVQtu4M1284DnZBeuYw8jTmHuMX8u4rh_rXPjB8APsEbFutFMpnjyxbmKqZH9vkDuy14b', 1, 0, 0, '', '', 1, 267066, 0),
(37, 'Rachel', 'Fulgencio', 'rfulgencio@outlook.com', '6175050713', 'Rachelf1.', 1, 783091, '2016-06-08 23:30:25', '1465827013992.jpg', '1c6c6082dc79280a588ec392761168e1f1d079779a013c1584bd31e026fb8b7c', 0, 0, 0, '', '', 1, 389678, 0),
(38, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '8184658228', 'Justice2!', 1, 989849, '2016-06-09 04:32:55', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 417914, 0, '', '', 1, 891993, -1),
(39, 'Tapan', 'Gohil', 'tapanmyid@gmail.com', '9998078073', 'Lanet@123', 0, 366440, '2016-06-09 07:01:21', 'user-profile.png', 'cLAqmD11_1A:APA91bFYcBqB6f3zD6Zox1FJHF5vIALaiYrzqkV9TKMAJ3EAylf1ysSz8NtGJJvptEImlxHwuIRzITCX5jOUR5K2f4w1GLuUF6mUwhazSBuWG5bjan0cqs-CLNH4xiKB26W_B27tvi_u', 1, 0, 0, '', '', 0, 720472, 0),
(40, 'Abc', 'Test', 'abc@gmail.com', '99998880', 'Lanet@123', 0, 946520, '2016-06-09 07:28:11', 'user-profile.png', 'e2-XkYWhsZ8:APA91bFMBUNVWBL_H9iIHUKkqzsOWwwY8ZO9JKgep3_Dbc56SCQZUEB-NkkrGB-OGWCoSlb43I6v8DFqExCvM_SBWyuIHHtSTbDhWy8GsR6ODcHHBXd2qBTD8vjR6TNmGoT3Iresvzub', 1, 0, 0, '', '', 0, 685449, -1),
(41, 'New', 'User', 'testuserandroid@gmail.com', '1234567890', 'Lanet@123', 0, 748176, '2016-06-09 07:58:57', 'user-profile.png', 'e2-XkYWhsZ8:APA91bFMBUNVWBL_H9iIHUKkqzsOWwwY8ZO9JKgep3_Dbc56SCQZUEB-NkkrGB-OGWCoSlb43I6v8DFqExCvM_SBWyuIHHtSTbDhWy8GsR6ODcHHBXd2qBTD8vjR6TNmGoT3Iresvzub', 1, 0, 0, '', '', 0, 367523, 0),
(42, 'Tyneshia', 'Stephenson', 'tyneshiastephenson@gmail.com', '6176026526', 'Footlocker123!', 0, 710398, '2016-06-09 18:20:58', 'user-profile.png', '36b6942d397995c0372bb396a88e6fd0de0874078179cb2a7bbfa142bee39b4c', 0, 0, 0, '', '', 0, 261336, 0),
(43, 'Foluke', 'Arogundade', 'folukearogundade@yahoo.com', '6785239128', 'Luludade@82', 0, 685164, '2016-06-09 18:43:16', 'user-profile.png', 'e8995593849189b5b90f3a1d26c8f015b535ce9ddf1379d75cdfdb9e8a2a625f', 0, 851506, 0, '', '', 0, 383337, 0),
(44, 'Vanessa', 'Jean Louis', 'vanessa19jl91@gmail.com', '6174129581', 'jeanlouisV0717$', 1, 337429, '2016-06-09 19:51:41', '1465502403381.jpg', 'elvxbc5czYU:APA91bGY0BzzzsUQ-0WYM7C5FNwxe76TTZbwTI8uV7vefAMa5fbczpsFZyZUkaDaOwn8dqkxpHxkpe4bnTmGAr3P-5RLhBsTFsWUjjalGx-9BP7aJLma3NSwqEBr6Td2RLvGyOndLy5K', 1, 0, 0, '', '', 1, 989323, 0),
(45, 'Kiron', 'Harper', 'KOHARPER92@gmail.com', '9543973616', 'Skindred2246!', 0, 505602, '2016-06-09 21:55:44', 'user-profile.png', 'c7f435bde1b6b3226929d3cfb3710caa3fa3516be88a7b2997bc7b6c7edcc84b', 0, 0, 0, '', '', 0, 734969, 0),
(46, 'Ruben', 'Her', 'je@gh.com', '9154746047', 'Qn0wp@ss', 0, 903193, '2016-06-09 22:58:23', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 147204, -1),
(47, 'Kimberly', 'Idoko', 'kimberly@myqapp.com', '2038879349', 'Justice2!', 0, 536322, '2016-06-09 23:27:11', 'user-profile.png', 'ddcb406d04bd741fe9c172726aa1fd3408a5cd334190679bee8fb5f9e02496a2', 0, 0, 0, '', '', 0, 778186, -1),
(48, 'Katie', 'Toups', 'katietoups@gmail.com', '9177537604', 'Brooklyn1!', 1, 863104, '2016-06-09 23:46:08', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 877637, 0),
(49, 'Phoeniix', 'James', 'phoeniix.james@gmail.com', '8189833739', 'Jarhead1!', 1, 294061, '2016-06-10 03:05:16', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 222978, 0),
(50, 'Sophia', 'Nairima', 'nairimah@yahoo.com', '8183107143', 'so0925luckY!', 1, 423946, '2016-06-10 03:06:35', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 765545, 0),
(51, 'Kimberly', 'Idoko', 'dr.idoko@primeneurology.com', '8184658228', 'Justice2!', 1, 565046, '2016-06-10 03:14:33', 'user-profile.png', 'ddcb406d04bd741fe9c172726aa1fd3408a5cd334190679bee8fb5f9e02496a2', 0, 0, 0, '', '', 1, 498259, -1),
(52, 'Kimberly', 'Odigie', 'kimberly@theqnowapp.com', '8184658228', 'Justice2!', 0, 865675, '2016-06-10 16:25:36', 'user-profile.png', 'ddcb406d04bd741fe9c172726aa1fd3408a5cd334190679bee8fb5f9e02496a2', 0, 0, 0, '', '', 0, 479003, -1),
(53, 'Jesse', 'Ferguson', 'j.ferguson1@lafilm.edu', '4236939242', 'My_namescharlie10', 0, 208829, '2016-06-10 17:14:34', 'user-profile.png', '1e04f5bfc7e30fc6e595cc616a797b3e5f6eb99310123ebfad26acdbadd95e18', 0, 0, 0, '', '', 0, 958115, 0),
(54, 'Vanice', 'Simpson', 's.vanice@ymail.com', '9548026914', 'Nrlcbx*2!', 1, 514076, '2016-06-10 18:09:14', 'user-profile.png', '6214b866cb5dabe41b414773a0370a94040487e2a778d0376fa1cdb9107d7b15', 0, 0, 0, '', '', 1, 132591, -1),
(55, 'Fati', 'Haruna', 'haruna.fati@gmail.com', '6463398454', 'Gemini123@', 1, 572351, '2016-06-10 18:58:40', 'user-profile.png', '37fa6451be0a0de75e9a4d436fd938bff44d7d70150fa41278cbfe5fda0f0e7d', 0, 0, 0, '', '', 1, 107011, 0),
(56, 'Richard', 'Sherlock', 'richard77sherlock@gmail.com', '9092243168', 'Ricky000#', 1, 840069, '2016-06-10 19:22:14', '1465587120048.jpg', 'f4da13e64da29be65701bffd7577759927bf046788a880cfc9414548392ba17b', 0, 0, 0, '', '', 1, 957850, 0),
(57, 'Kiah', 'Cronin', 'kiah.cronin@yahoo.com', '8145746755', 'Incorrect123!', 1, 882093, '2016-06-10 22:49:51', 'user-profile.png', 'e36457f1dc302dbee7a220b330c14e36813e529bff87f74dd0056699466c5597', 0, 0, 0, '', '', 1, 613925, 0),
(58, 'Kimberly', 'Odigie', 'kimberly@continuitycall.com', '2038879349', 'Justice2!', 0, 423927, '2016-06-10 23:36:32', 'user-profile.png', 'a27039c201ba41689160df3f81892591469a8f0f48e3f880cd6931922bc9bef9', 0, 0, 0, '', '', 0, 849587, -1),
(59, 'Raven', 'David', 'rdavid_18@yahoo.com', '9293925629', 'Kenny123!', 0, 348516, '2016-06-11 00:26:25', '1465605149786.jpg', 'ae7372609ca7a147c1d2e9c936bde454ae8c399c10e99202e3b5c473887c3de6', 0, 0, 0, '', '', 0, 164889, 0),
(60, 'Martine', 'Koenigsberger', 'mpk6@caa.columbia.edu', '9174464792', 'Niwpfytr!21', 0, 739671, '2016-06-13 06:04:13', 'user-profile.png', '40ceac9f5b30c770f2b97b637a2db3660bb95e3391ff89a6862c900e40cbc06f', 0, 0, 0, '', '', 0, 668506, 0),
(61, 'Salim', 'Diakite', 'sdiakite16@yahoo.com', '3478216504', 'Nbakobe24!', 0, 475995, '2016-06-13 08:20:35', 'user-profile.png', 'b51c8380fa3621acbe193159e31239149f4991c32e25c05d268debdbb8ab1e51', 0, 0, 0, '', '', 0, 412681, 0),
(62, 'Theresa', 'Avila', 'tmavila2@gmail.com', '9174002843', 'Damiana42!', 1, 899834, '2016-06-13 14:55:25', 'user-profile.png', 'bcd66382622b174ececeb0d594d9d4c5bec2d53ba9788c8e084f7b5a47969bb7', 0, 0, 0, '', '', 1, 605221, 0),
(63, 'Denise', 'Decicco', 'denisedec424@gmail.com', '5082467666', 'Spring14!', 0, 674114, '2016-06-13 15:18:32', 'user-profile.png', 'bb6fdfa602c61ba2cbf6a5e45b3c4b915ebf20d5e68d7058c572f8267700696a', 0, 0, 0, '', '', 0, 754473, 0),
(64, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', '7817312269', 'Sebastian29@', 0, 799503, '2016-06-13 15:27:27', 'user-profile.png', '38df8b5f43f8c4e36913c9f5b729b7e7dad86865252519588c4f5c3f1bc85aed', 0, 0, 0, '', '', 0, 188912, -1),
(65, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', '7817312269', 'Sebastian29@', 1, 908422, '2016-06-13 16:15:42', 'user-profile.png', '219eccfe5224305858d751b3510e48c82d2198baf4fe14cb52d39988dc57be95', 0, 0, 0, '', '', 1, 127768, 0),
(66, 'Rebekah', 'Pelzel', 'rebekahpelzel@gmail.com', '5756404303', 'FAith.628', 1, 899057, '2016-06-13 18:09:23', 'user-profile.png', '7d205fca05dd1dfd2da57a057fd1f13f932bf62b8247acca34fcf9bf9d41c032', 0, 0, 0, '', '', 1, 659117, 0),
(67, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '9154746047', 'Qn0wp@ss', 1, 403991, '2016-06-13 20:45:44', 'user-profile.png', '741b9bc3cedad0bdda701e75108da16836d703a088236957b4db726401dd0342', 0, 998005, 0, '', '', 1, 591663, 0),
(68, 'Seth', 'Sharbono', 'sethsharb@gmail.com', '3202491523', 'Sseame11!', 0, 645129, '2016-06-13 21:39:01', 'user-profile.png', '6f0ec751b8c1711b3be6c3f0147a652952d3d4d863226dcb767d7a45da0667b2', 0, 0, 0, '', '', 1, 578998, 0),
(69, 'Nerishka', 'Jeanty', 'Nerishkaj@icloud.com', '3474099134', 'Nolovecity1!', 0, 899428, '2016-06-13 23:14:49', 'user-profile.png', 'd4eac9134e7fd956cebf61ec9128b98a5ed3e776a687ae8c0bda3cb6c6033cca', 0, 0, 0, '', '', 0, 120896, 0),
(70, 'Bianca', 'Latham', 'balatham@ymail.com', '3107437584', 'Woodbird1@', 1, 248444, '2016-06-14 00:51:56', '1465866875786.jpg', 'cheVh3kFDM4:APA91bEh5_eqPiLC9t_gRcdXqAPnml9RTGcWyGoJTXRnHqSqexjmegALrzEimIMLQ0qcoKvlCHZ9XXo98EiLHbif5w8Z70KP_6GvAwT-G9vyDg_oJGc3jorTwHkJtIPqTIGvudQPTLW_', 1, 0, 0, '', '', 1, 110086, 0),
(71, 'Richard', 'Ramirez', 'richardramirez5@hotmail.com', '3476912171', 'Diablitox7$', 0, 118584, '2016-06-14 01:53:09', 'user-profile.png', 'a715329bb0f654afe211311cb1394fe40021a74323a7a1c25f1cdc7856971842', 0, 0, 0, '', '', 0, 412778, 0),
(72, 'Ruben', 'Hernandez', 'vauxxer@gamil.com', '9154746047', 'Qn0wp@ss', 0, 377676, '2016-06-14 06:36:53', 'user-profile.png', '6e68823f06cad38eefd7519db4f414eedfb7874b3218560aa67b056dcc0760af', 0, 0, 0, '', '', 0, 360714, -1),
(73, 'Ruben', 'Hernandez', 'ruben.h.dev@gmail.com', '9154746047', 'Qn0wp@ss', 1, 421330, '2016-06-14 06:40:40', 'user-profile.png', 'daUSFGJi9Ro:APA91bHvePrtSlairXbhHL8pJYF7IDo8xNCKgYoU6gxLlB7kX0tvmVnkEWo8DZtByYngfl66cDvzjS1JbOQLnRkRuU269I6o5-F6hTzpARwrv7BzE-9UawDJ5CzR1QqFse4opfe4037Q', 1, 0, 0, '', '', 1, 442633, 0),
(74, 'Michelle', 'Barrionuevomazzini', 'mbmazzini@me.com', '4157061677', 'Ilovejulian29!', 0, 202230, '2016-06-14 07:44:20', '1465890378013.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 329477, 0),
(76, 'Tori', 'Uvaas', 'toriuvaas@gmail.com', '5624479004', 'Steven14!', 0, 200299, '2016-06-14 16:08:10', 'user-profile.png', '423d6156777fd54ab871881f606a4b105b1993cbd3c283fee468db051b65bb1f', 0, 0, 0, '', '', 0, 357014, 0),
(77, 'Alexandra', 'Arruda', 'alexarrruda@gmail.com', '7742949489', 'Arruda11!', 0, 399568, '2016-06-14 17:04:35', 'user-profile.png', 'de74bb0c693c0c0602dd37ff0d9632a5f1a66b683c4f80704bc6951a2ce6c35a', 0, 0, 0, '', '', 0, 255557, 0),
(78, 'Courtney', 'Siwek', 'csiwek13@gmail.com', '4196109863', '5Appnxyb7!', 1, 593365, '2016-06-14 17:13:16', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 674641, 0),
(79, 'Ruben', 'H', 'jrhernandez@gami.com', '9154746047', 'Qn0wp@ss', 0, 575991, '2016-06-14 18:13:54', 'user-profile.png', 'daUSFGJi9Ro:APA91bHvePrtSlairXbhHL8pJYF7IDo8xNCKgYoU6gxLlB7kX0tvmVnkEWo8DZtByYngfl66cDvzjS1JbOQLnRkRuU269I6o5-F6hTzpARwrv7BzE-9UawDJ5CzR1QqFse4opfe4037Q', 1, 0, 0, '', '', 0, 851384, -1),
(80, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '8184658228', 'Justice2!', 1, 716816, '2016-06-14 18:16:18', 'user-profile.png', 'a27039c201ba41689160df3f81892591469a8f0f48e3f880cd6931922bc9bef9', 0, 417914, 0, '', '', 1, 650657, -1),
(81, 'Ruebn', 'H', 'jejd@hdjd.com', '9154746047', 'Qn0wp@ss', 0, 741461, '2016-06-14 18:16:40', 'user-profile.png', 'daUSFGJi9Ro:APA91bHvePrtSlairXbhHL8pJYF7IDo8xNCKgYoU6gxLlB7kX0tvmVnkEWo8DZtByYngfl66cDvzjS1JbOQLnRkRuU269I6o5-F6hTzpARwrv7BzE-9UawDJ5CzR1QqFse4opfe4037Q', 1, 0, 0, '', '', 0, 311713, 0),
(82, 'Deandra', 'Egusquiza', 'deandraelise@yahoo.com', '9085149546', 'Corona0219.', 0, 594810, '2016-06-14 18:22:40', '1465929016928.jpg', 'a5b5d7a6200cb8ae7027b4e017875dba5278fb4e23136f13d382f51fb14631e8', 0, 0, 0, '', '', 0, 766012, 0),
(83, 'Aliza', 'Greenstein', 'lizadancesandswims@gmail.com', '5085051534', 'Aliza8isabel!', 0, 866202, '2016-06-14 23:09:57', 'user-profile.png', 'f24d54f28821e8d638a9a91e602e8b2d48df56a5b42a9918e250277a4bf6570a', 0, 0, 0, '', '', 0, 522440, -1),
(84, 'Helena', 'Cohen', 'helenacohee@gmail.com', '3235612620', 'C@meron26', 0, 649295, '2016-06-14 23:10:10', 'user-profile.png', 'd31f5ac4cb318c0ce4d88af7caec8f7771d4d9ff7570b9e18c09cd5799826622', 0, 0, 0, '', '', 0, 116551, 0),
(85, 'Imani Shadae', 'James', 'imanis.ajames@gmail.com', '7189159713', 'Sapphire21@', 1, 212322, '2016-06-14 23:21:21', 'user-profile.png', 'dLPeDk8i5m0:APA91bEWhqFg5G0ebnZHrftsQO2Wtuefoh7CqGLdibwLlsDvT1YQwbK5g63NsI_Q4xu-xooCgUFSV85_IZYBrRvCD2-wHz-8tp26MPrpCsZ0EbzKr4NP-2I6rE9ujVDtx_oU7QWY9giB', 1, 0, 0, '', '', 1, 933789, 0),
(86, 'Lissette', 'Gomez', 'lisyvictoria@hotmail.com', '5083950641', 'Lvg@2525', 1, 514387, '2016-06-14 23:57:20', 'user-profile.png', 'd45OfxmErRM:APA91bG4IHHPxEfNpblByXDxHE6gflpDw-V0Qzopp6qKTe0tB_cKW5OZZJLkoTfEkF_MXN_Fxe33a4gYEFNYb6cbrri-GiphJhagxjvtyS4SE0xD1l1Bf5zVbqHklvunomfAWiBPLd0V', 1, 0, 0, '', '', 1, 367522, 0),
(87, 'Michele', 'Brown', 'm_brown18@yahoo.com', '7604152638', 'Michele18$', 0, 725998, '2016-06-15 00:01:46', '1465949035235.jpg', '5a8a57dd7e04fb300c44184acd4453a364bf140e7582c92e664f87934efe1d12', 0, 0, 0, '', '', 1, 141642, 0),
(88, 'Andrew', 'Neal', 'andrewxxneal@gmail.com', '7146252326', 'Bushwick123!', 0, 162031, '2016-06-15 03:01:13', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 434312, 0),
(89, 'Drayton ', 'Hiers', 'drayton.a.hiers@gmail.com', '9172028396', 'l0nd0nB@nk', 1, 782845, '2016-06-15 03:02:18', 'user-profile.png', 'cuKCzlwEmjs:APA91bF_E9sr10L2J3zjcX6JAlERAwfKa_Ayx3zreilnGnyLTjW50owrdbiTo_TTYxiRedm3rEAwHLB6AtTgCb2sCpRARILASJ5gSUfcPSjL4mnBoZtSLxD2rz0mA51FXTqWvFO5pyPH', 1, 0, 0, '', '', 1, 747969, 0),
(90, 'Chantell', 'Lawson', 'chantellandreina@yahoo.com', '6786126696', 'Channie.<33', 0, 370915, '2016-06-15 06:16:35', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 733604, 0),
(91, 'Shermayne', 'Butts', 'sheabee09@gmail.com', '9312167534', 'Aspu1003!', 0, 642331, '2016-06-15 07:56:10', '1465977659701.jpg', 'cf66facf9cb9033c7db14e3a5105eaf82fbcf68958836b133b2ab2c7f5a05e1c', 0, 0, 0, '', '', 0, 955522, 0),
(92, 'Kyandra', 'Richardson', 'kyandra919@gmail.com', '3475819741', 'Cupcake19-', 0, 930832, '2016-06-15 10:33:47', 'user-profile.png', '88972ef77353f415759245d0ae0e2cc17c2b7bbd3fd3c820ab1e1df3c1e598d6', 0, 0, 0, '', '', 0, 654873, 0),
(93, 'Zelmia', 'Harvey', 'kimera.draven@gmail.com', '7815100227', 'Loki1788*', 0, 497746, '2016-06-15 12:57:36', '1465998689387.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 632369, 0),
(94, 'Jasmin', 'Rodriguez', 'jasminvrodriguez@outlook.com', '3472170160', 'Miszjaz1!', 1, 670284, '2016-06-15 16:29:12', 'user-profile.png', '658088d2864e421e7b23aaea239d0056dea589d1c05ed0784cda336839ffae1c', 0, 0, 0, '', '', 1, 295883, 0),
(95, 'Ashley', 'Dibson', 'ashley.62497@gmail.com', '9178612391', 'Ashcash241!', 0, 346094, '2016-06-15 16:56:52', 'user-profile.png', '20bfe0ec59f63abd8890b138a4dc10bc780d859de8eef52165a54429b4ac6d99', 0, 0, 0, '', '', 0, 512185, 0),
(96, 'Jonathan', 'Shelton', 'jshelton85@gmail.com', '2132801920', 'Sfa232_5@', 1, 622349, '2016-06-15 16:59:57', '1466010599418.jpg', 'e3fP94IFjbA:APA91bHbymGwc5-SZuUGCLsDKF-JQyshMEkoj3ORoT_ab8zFSUJ5sFvGvnSTJQLTLPwqeJly5f0QIEhyxiIfkDmnM6fEEZNeBDLz86CAk0_oDZ0c7gJfIZ_SsRdFPWXToYNMTtU5tG1c', 1, 0, 0, '', '', 1, 862862, 0),
(97, 'Kary', 'Hudson', 'Karyh92@gmail.com', '9177547685', 'Iverson@3', 1, 402785, '2016-06-15 21:15:56', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 831471, 0),
(98, 'Catherine', 'Pena', 'cpena100@gmail.com', '9176560076', 'Getiton12@', 1, 298398, '2016-06-16 00:12:22', 'user-profile.png', '19e79c597c98598b216bb9263af2c6a2c29fda90b1247297a4dd2bcc75dfece0', 0, 0, 0, '', '', 1, 787770, 0),
(99, 'Lisa', 'Willis', 'michell_willis64@yahoo.com', '4242326790', 'Charles@37', 1, 747778, '2016-06-16 00:43:49', 'user-profile.png', 'cItFUqgbvVY:APA91bE1qg_Hysr_imMSd2_udFL0ReHQycb76hqcp3t_mBKaHN17y52k-qXBbKmpICznHYmDUFPDERsy8p6xx2Xs5bi_IklfWEpihDQoxcWVd4mRMdyJRFvs4e3gpMse7Y6d89ejrO0R', 1, 0, 0, '', '', 1, 593369, 0),
(100, 'Jeff', 'Lazelle', 'jefflazelle@gmail.com', '3235921641', '3Pancakes#', 1, 474501, '2016-06-16 00:51:25', 'user-profile.png', 'fzHRxMxrflA:APA91bH47cDWxOCBv57uTEBGMx4EJmDpbNUnLQhyTFv3o_eJifuTVgRj9uD7ygb_JbhapqKknoV-eM69ubxigvYRE45GmbjkScVD6VInpW7koQdSJ_eexXwbeuTlu-zFB0vBnzwNpXDu', 1, 0, 0, '', '', 1, 847890, 0),
(101, 'Melissa', 'DeJesus', 'sweetie081402@gmail.com', '6464108525', 'Lucky@777', 1, 366418, '2016-06-16 02:14:43', 'user-profile.png', 'fciH0X1JY2I:APA91bEAd5Ry3Kh-acrDxtWrdnomsNXMV5ew0AFWbuLW6NBmrl_pDxxhbCHVeBnT0vKZBvaTPtVUwOU_ln3e9NTlbtsn755Hffr83f8mF1h2jgGZNTlUvtGvMrgKiTcju2bHrSBg6bKE', 1, 0, 0, '', '', 1, 552595, 0),
(102, 'Paulina', 'Tamayo', 'paulinaadrian917@yahoo.com', '5624517983', 'Adrian917!', 1, 413182, '2016-06-16 02:26:56', 'user-profile.png', '67e6fab9d4a3f4fdb988deddd4aae842d9431dfd310a277bd9332167f49bfb5d', 0, 0, 0, '', '', 1, 807112, 0),
(103, 'Nicholas', 'Kasule', 'kasule23n@gmail.com', '4242139725', 'Warrens2*', 1, 105996, '2016-06-16 03:47:07', '1466050052377.jpg', '0cfb56603c4bf2b95f3c9b898cd08551b30faa79880e1ee8d1226bcb4827f27f', 0, 0, 0, '', '', 1, 992338, 0),
(104, 'Maria', 'Caraballo', 'aradia097@gmail.com', '3475206899', 'Lovelove1@', 1, 799226, '2016-06-16 07:38:10', 'user-profile.png', 'cFJo7jJLoXo:APA91bFrroBhHbVFjsTrSjCsso-vFfLxPRCaqBHGrCryBOc2OoKIoDjoFcrbiwm1bid6lAzYFdKAYyVj2K4Ig3pVOcw2ooO8LhAhebZ_7YKpt7mDVXQUrwTH00Lzb7N6Dwk3zEVfQ-0o', 1, 0, 0, '', '', 1, 217686, 0),
(105, 'Bijal', 'Tailor', 'lanetteam.bijal@gmail.com', '9876543210', 'Lanet@123', 1, 451271, '2016-06-16 08:10:20', 'user-profile.png', 'dg2_OGyDN-E:APA91bGsoxfXIvo7GsA--l1OI7waFfKI61WgTO0ccKT7v3q6za0qqy-o4Kj6STSvjIXGTp-dQiRGeRp544AYTKJWbeIgP3Vx0nSg_G8kMxLyWWrdx0k6b9lJbAiR7SZezndcc67c9O27', 1, 0, 0, '', '', 0, 131146, 0),
(106, 'Tyechia', 'Spann', 'tyspann82@yahoo.com', '4042002525', 'Tyechia@82', 1, 413927, '2016-06-16 08:23:32', 'user-profile.png', 'eJdrDqzVits:APA91bHN8lHVxcWQ6rsHu2dxEpNTch-1dXNiTbNx361ebxR5yRANCC60HHAYVfip0p6Qc1jGA4oLk18XBTdbw5vSywEYqHxAdVFDGrivhpHu8ZIQ_h6hAal_FSiIc__D4llURPwmuQFx', 1, 0, 0, '', '', 1, 590487, -1),
(107, 'Nathan', 'Fisher', 'nateafisher@gmail.com', '3236202111', 'P@ssword2016', 1, 897436, '2016-06-16 10:08:04', 'user-profile.png', '05bca0668cf31b3ede799d05f455113775eccfba6ca8dc1535fa4346b98ba6a9', 0, 0, 0, '', '', 1, 247367, 0),
(108, 'Victoria', 'Graham', 'jvgraham2014@gmail.com', '6787554500', 'W@ll@c3™', 1, 588010, '2016-06-16 12:20:34', 'user-profile.png', 'dv9vUbADXSs:APA91bEcv3e2RM-Qr4xe8BC4kK0v034-_lMNqLWlBQdvFr4j30GVdDiyuEwPzxEpvkyRE3GLMCMnGQgti5Im6i44lThFBEQaOdcu4ByTS7BHhuNgPs8dWBu1Gjbrts85vY7QeDaC8FmB', 1, 0, 0, '', '', 1, 804396, 0),
(109, 'Ciera', 'Crossling', 'cieracrossling@gmail.com', '4437864318', 'Donell10!', 1, 369708, '2016-06-16 14:46:20', 'user-profile.png', 'ab315eadc1344f51035a2df368c3d0fd3ec103643ffb1f703142b27ecc0f91ab', 0, 0, 0, '', '', 1, 267118, 0),
(110, 'Whitney', 'Pensinger', 'whitneypensinger@gmail.com', '6179453117', 'KingLeo08#', 1, 469182, '2016-06-16 15:09:53', 'user-profile.png', 'cEkgXidSD1M:APA91bGhBeKqziiNpC6oxH4KVw9k8t5wZ0kVbLqIt37r61a7Tz7uB4ugZqSoK_ZBSNTffKrkQ1VNk3YM37n3GdRIT8XMkrLA7GJwyaZA2Oil-JOClWwi-YH0CeM094HDl0RsY0WITrQD', 1, 0, 0, '', '', 1, 217161, 0),
(111, 'Christine', 'Thomas', 'kristine318@me.com', '6788365439', 'Mitchyy*01', 1, 962558, '2016-06-16 15:39:27', '1466166985020.jpg', '9d3028d055c217c3cceed1f98efd273dbfa56e48435eeb4c5fca71cd9aa598ed', 0, 0, 0, '', '', 1, 335103, 0),
(112, 'Ruben', 'Hernandez', 'jdjsjs@jdjdjd.com', '9154746047', 'Qn0wp@ss', 0, 750945, '2016-06-16 17:17:25', 'user-profile.png', 'cSZsKQSWeQU:APA91bGSCLckozHn1eEb2LT1GJgKb5QAs82VUb4bJddy9w1Xo6q0UxqaF5x4DVKTQtN_xL8e-enoRK7M7p3KgAQqzZse_zJM14enxNNA9rQaNNkJQz5XWVKSwHUq91I_NyEgURKcHxKn', 1, 0, 0, '', '', 0, 663582, -1),
(113, 'Felix', 'Odigie', 'felix.o@valdecapital.com', '6173881912', 'Ric0860424@', 0, 474870, '2016-06-16 17:33:35', 'user-profile.png', 'eFqeOR5Ps9Q:APA91bGyVI2HdUQY4ePRiAC6Xe3uM3loHxxGUCtNAp89dyEO1MvT5fc6TsFeb_DuI56-wwr6rP7IBq0jKbziVK1VL0luWYTLUEn4yrHkrRmknHNmctwMdpC6zticfbzVuqNqtGFineS3', 1, 0, 0, '', '', 0, 607623, -1),
(114, 'Test', 'Test', 'hdjsj@jdjd.com', '9154746047', 'Hospice1!', 0, 495759, '2016-06-16 17:52:26', 'user-profile.png', 'djfkMDAJCp8:APA91bHcmsdR575xAp0FFat-96sewUNdZPTt2VsnIVBwxRWboSilj7Ulsl2_YY0cPQ2n57Q8CEMvjpGnVEaf0vjn8hBl-chmbzf-f9aM-YJmpWbWd2IPvyq1YMWkUAXtjJZwBuCPEsFa', 1, 0, 0, '', '', 0, 594686, 0),
(115, 'Zeinab', 'Golbaz', 'asal.golbaz@gmail.com', '8187939840', 'Imanjoonam110$', 1, 458787, '2016-06-16 19:37:03', 'user-profile.png', '265c03667211ee3c03279089bb64a4189d23c9e38578be6e66fdee302f4331e4', 0, 0, 0, '', '', 1, 655757, 0),
(116, 'Nicholas', 'Ruck', 'ruck.nick@gmail.com', '9197706024', '#Cally124', 1, 162004, '2016-06-16 19:38:00', 'user-profile.png', 'c--H4akpy8M:APA91bEoJOSWoG8YC3CR-uyXD6ikf1Ix-vALCvdsO8pLKbYFIBGqiE4QjE7GsdzNr5SQbRg7m0BIGmJ3Y5Rgwl2II2LrYlt5E-i626lpQxfM0SijNkhxz_Hr49C5tVPZHu-7ojBfocPx', 1, 0, 0, '', '', 1, 465941, 0),
(117, 'Felix', 'Odigie ', 'felix@myqapp.com', '2104644634', 'Ric0860424!', 1, 267543, '2016-06-16 19:45:51', 'user-profile.png', 'fIOm6x6c0rk:APA91bEmCj_LCfjKT_kr-C-Gpb_hueLaoVt5H0ZC-jPdMQUyrU_44do_x7JJ2Kgfxtu5m96hVhOzpnuf5JSSR83TP-Ts0hdyCcc301jwP2L9ZuSo2-xcQQue2Z5sDBcPI1EpSWSHrmP2', 1, 0, 0, '', '', 1, 106793, -1),
(118, 'Camille', 'Norwood', 'kidcami@yahoo.com', '5102133564', 'caymilleN2.', 0, 568502, '2016-06-16 20:54:25', 'user-profile.png', '0ae317fb28fead3b29973e9d9d4affe36e0b4634d05432a43fc1a8c0b1e8c378', 0, 0, 0, '', '', 0, 808835, 0),
(119, 'Daniela', 'Lopez', 'danielaylopez02@gmail.com', '8185682927', 'Monkeybutt08061992#', 1, 649657, '2016-06-17 00:56:50', 'user-profile.png', 'd1H3w8fvjB0:APA91bGT8Ph8Dp_ih1eQhKXoSEE53uZXnELPVppbXQpMYSlZhneGuGJgeKTjZha19wMS6x2mg0fLzz_9OECwIGHa8-L71-gBgtIy1wQWJqoEvDpzGqtGQQ0aH9i1UxMUiDplLsEQtaSE', 1, 0, 0, '', '', 1, 555661, 0),
(120, 'Shaharazaad', 'Carter', 'shaharazaadc92@gmail.com', '3238843496', 'Promise@b1', 1, 420921, '2016-06-17 01:08:20', '1466125890884.jpg', '3549fc4b58efdae34d7c6084cf45d26d0e7eeb8e938f2c589f5911f38c041ae7', 0, 0, 0, '', '', 1, 689044, 0),
(121, 'Thomas', 'Avilla ', 'thomasavilla@gmail.com', '6463728159', 'Pennino1!', 1, 379181, '2016-06-17 01:17:33', 'user-profile.png', 'fnFIi-AZchk:APA91bH4Q9QZguNMxTdmZRjR6l00Bwj4Twbohm4s64aCkeVQmNHrbM-SuGbzFR8fJwpejiYkAHmHhKC4k8t6rUFawhxL9fwYEluDyYWxR94lEM3cyGE_8y_0ivMt9X39gTt0l8uB9z10', 1, 0, 0, '', '', 1, 226086, 0),
(122, 'Maritza', 'Dominguez', 'dmaritza721@gmail.com', '2014668111', '7Spiderman$', 1, 394992, '2016-06-17 02:14:46', 'user-profile.png', 'fHnEnL3SIPw:APA91bEHriQtP9ntNiEvTeKXuK-nhUMM62WLjgJ-enHWH9SnkQ_T7V_lZZ48wC6icHGONdi8_9HcBwQ2WAne7sGF8xYgfwVoEpGp-hlDIotYpcL7Fpz7_-nGgx944kEGGq1DVGzqwaKR', 1, 0, 0, '', '', 1, 803759, 0),
(123, 'Tiana', 'Pope', 'tianapope7@yahoo.com', '4043122186', 'TiandTe12!', 1, 309868, '2016-06-17 02:37:15', '1466131840008.jpg', '2ff631c775ae09a51e5caddd1ebc20b94ad5e5a154ead78ba8363b6aadfa0f8e', 0, 0, 0, '', '', 1, 310539, 0),
(124, 'Machella', 'Anthony', 'manthony2007@yahoo.com', '6785884574', 'C$tate2014', 1, 216226, '2016-06-17 14:33:32', '1466878671314.jpg', 'feocJDEXqXU:APA91bHsPI3f9LRJnxGijQrGA8VAsMtlnR6zbKJOEaIU_B0I5NzLYqKZNJelc_cKp_DW65DRfaSpajWgTfnMpZn6hPGaYw-EWQm1NvPr0yMdtw3cdIAcnFHG6d8aW5oeW-_bnTglY9GV', 1, 0, 0, '', '', 1, 584122, 0),
(125, 'Dawn', 'Davis', 'ddlonglegs@me.com', '3104889677', 'Longlegs#511', 1, 513692, '2016-06-17 17:49:26', '1466186043837.jpg', 'd9uSkrhAzDQ:APA91bHXS9nm6Cm8egliJwum-LTYWq8b5cdWOon5yTBpJ0PVSjmQaga4toX9pXHZC33SFDWGBhsCrM8O0jzJy7vpEJPn0LchTqup7ObkqLZ-PNkBsSagGafj05rVcurrgWOoU9yYc6-M', 1, 0, 0, '', '', 1, 414365, 0),
(126, 'Tarian', 'Bullock', 't.bullock@lafilm.edu', '6616747084', 'Tete1675.', 1, 824521, '2016-06-17 19:04:31', 'user-profile.png', 'f_7hcmvCfiM:APA91bEBTcG-owoNRmLHp-MzsmrpK3t5t_4pryAtLT8-c5Yka9zhQeoVVmIOqqAIBUs4U7V4gWfuTyGDVir76hJNJW6V3An5pAgJCnlqx_yNlCXKFotzjFbzU0Rsx2BjjyKmTw8kIjO5', 1, 0, 0, '', '', 1, 556949, 0),
(127, 'Aliyah', 'Burroughs', 'burroughsaliyah@yahoo.com', '2145859419', 'A22burro!', 1, 846955, '2016-06-17 22:05:14', 'user-profile.png', '624bfd74864a7425041e4ee325f78cb477c5da7c5b45e4b40eafe3d94ac79d00', 0, 0, 0, '', '', 1, 899760, 0),
(128, 'Conzady ', 'Sullivan ', 'conzadys@yahoo.com', '4047480362', '1Cbembry+', 1, 925320, '2016-06-17 23:07:18', 'user-profile.png', 'dOwSMUAhNPM:APA91bG05fzQhzDjwb6u-wWV8XBZNQjXXj6-2HDeVo4e9jm4BRlPpO-oC98A-0xREHV4pFXDbEoeJyytso1rfnWqsIejWl_AVmTVlLIVYuklqBENzWpRb1ZEb1jXwU3EzwIa0O4fWPuT', 1, 0, 0, '', '', 1, 116854, 0),
(129, 'Chaquita', 'Bascom', 'chaquita0102@icloud.com', '7815106952', 'December$3rd', 1, 718227, '2016-06-17 23:16:23', 'user-profile.png', '12f7d8cf59be5f929c4e893301308f815ee0954db3e68efbe0da209e65b621f2', 0, 0, 0, '', '', 1, 173934, 0),
(130, 'Jonathan', 'Karp', 'jonkarp01@gmail.com', '5169022916', 'MgSa2007!', 1, 820762, '2016-06-17 23:17:04', 'user-profile.png', 'e0003da719b9a1645e508d773f050f0ff1064a239d421331bfe8af9dc0696eaa', 0, 0, 0, '', '', 1, 210743, 0),
(131, 'Ruben', 'He', 'jrhernandez@gma.com', '9154746047', 'Hospice1''', 0, 135177, '2016-06-17 23:27:05', 'user-profile.png', '741b9bc3cedad0bdda701e75108da16836d703a088236957b4db726401dd0342', 0, 0, 0, '', '', 0, 333627, 0),
(132, 'Jannai', 'Calderon', 'jannaicalderon@ymail.com', '3234121141', 'April241992!', 1, 424126, '2016-06-17 23:30:31', 'user-profile.png', 'f2V35x6_HpU:APA91bEKO2yqfXxvMIBfbeyuO46AQrgSkqkvQ5kTXmOqJnEWO6xOBMt8Xb8HoaLxW60Z0QPfogvuv9P9tNvcwHjqhZvkKm9rChsWMcQ0qQOWutWMPwXOor9M7v4vNKxrX_Yiz6nhI5rR', 1, 0, 0, '', '', 1, 992479, 0),
(133, 'Felicia', 'Reed', 'feliciareeed12@gmail.com', '3478588329', 'Samantha45*', 1, 744704, '2016-06-17 23:30:59', 'user-profile.png', 'fKRu9_Y7O7I:APA91bEgq40phqyU4NcN-3aI7xopnVTBHWsS--neKnTNfG_8AuiBxBOn39JB4RfrkpskCIPKETDmOhDnXYGtkDTdrMwjlE97ms3Rcpqh_NJsXrfJ2kgfW5e9suj0htz5QKwcAlPZUIH5', 1, 0, 0, '', '', 1, 229769, 0),
(134, 'Stephanie', 'Breen', 'SAB934@gmail.com', '6034016617', '3Turtles!', 1, 667519, '2016-06-17 23:35:58', '1466206760190.jpg', 'b3f1dda0187485bd25a5e72c7d5ea831cafc7bc2d107994c8aaa6421877f57ac', 0, 0, 0, '', '', 1, 105307, 0),
(135, 'Perry ', 'Wade ', 'pwade16@gmail.com', '8573338308', 'Wade789)', 1, 986801, '2016-06-18 00:31:32', 'user-profile.png', 'fAcAphk4yCg:APA91bEgbb3sOKlsZb7VIxej4Osd7-ZRH-8LSVDtsy9WBL-mlTR0-do2mPzzvpJD4QEFpftEUx71p059wY_AvKNpqW3LFNogTt4rKQdaTb2x-mzVRaFLrgGQD1h6qvMEqKl6yipD1Wmi', 1, 0, 0, '', '', 1, 807301, 0),
(136, 'Amber', 'Guidry', 'AmbercadeG@gmail.com', '9162302551', 'Freedom23:)', 1, 914452, '2016-06-18 06:30:18', 'user-profile.png', 'fc410a5b62d228f3f0ef2f9749e2433bcba437e4608b821a2fb0a5e32b6019cb', 0, 0, 0, '', '', 1, 772367, 0),
(137, 'Yulimar', 'Andrade cordova', 'yuls2000@hotmail.com', '8579910489', 'Jio122003#', 1, 886687, '2016-06-18 10:58:29', 'user-profile.png', 'eVaEZCCf05I:APA91bEuUIh-JYP3VSmX0a37ReZuPkyAwD99NbD9he6vK9SMkIW9XOTSccgKmez-kuKVErF69TRBFPBR9kHm2UjLdhnnERiYC3QceNbAEjYUix8diqAeZ_zEzt_4iWgOsZTk4tGgauUE', 1, 0, 0, '', '', 1, 377462, 0),
(138, 'Lee', 'Bash', 'shopeditplus@gmail.com', '6464949412', '#Lbash210', 1, 823957, '2016-06-18 15:21:09', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 586726, 0),
(139, 'Brittney', 'Jackson', 'b.jackson1390@icloud.com', '6466205308', 'Faith_Loves523', 1, 545282, '2016-06-18 16:22:44', 'user-profile.png', '9f6af74ccb4b7fb712460595229874504b2ce96bb0f15b8c61ec3957ba50871f', 0, 0, 0, '', '', 1, 106115, 0),
(140, 'Jamie ', 'Gonzales ', 'jammiller16@yahoo.com', '2135704712', 'QNow@Assistant1', 1, 819430, '2016-06-19 03:49:07', 'user-profile.png', 'fSLjx3GXizw:APA91bGlGEljEGcqdR3I8YM8o1I2OQwhn1RqKWFXjfxzeC1ZwN6B3deppJsZg2UjRSsyYfZEA6N4DX3tTnS1_uYFLUUzauk5C1g9T50vgwIOKy7lI8hQrwIGNPJq1Z4aYg83VARbhwH1', 1, 0, 0, '', '', 1, 251278, 0),
(141, 'Shaina', 'Lavind', 'shainarlavone3@gmail.com', '9492915650', 'Starfucker1!', 0, 470371, '2016-06-19 03:53:31', 'user-profile.png', '5116125df6341934873b621c86761db5a5f7f7c0fb3e2e2468270a64454d925c', 0, 0, 0, '', '', 0, 332524, 0),
(142, 'Shaina', 'Lavind', 'shainarlavine3@gmail.com', '9492915650', 'Starfucker1!', 1, 574469, '2016-06-19 03:55:01', 'user-profile.png', '5116125df6341934873b621c86761db5a5f7f7c0fb3e2e2468270a64454d925c', 0, 0, 0, '', '', 1, 590604, 0),
(143, 'Arielle', 'Harness', 'aharness@iastate.edu', '7124902165', 'Samson1$', 1, 497085, '2016-06-19 14:27:21', 'user-profile.png', 'euRz11aHaGs:APA91bHGQR0cqolajcDkXRXt9KsM99MmA7k9q0AOWBVL3IL5gcepTV4LBkB9BLcUUu_XOKp0XCMmcSoGDmuEUTj9bZhkd2TKYvw7seMD--nupFVYAvSKsiiUW0rJYxY7utNCEs3wkRFC', 1, 0, 0, '', '', 0, 889804, 0),
(144, 'Laura', 'Martellino', 'lmartellino@gmail.com', '4018553322', 'Elephant226!', 1, 757099, '2016-06-19 20:07:03', 'user-profile.png', 'dadc642d584dc8513c0c404a16629c94acd46fb9cfbb05f08ff2b12a5dfc216b', 0, 0, 0, '', '', 1, 894565, 0),
(145, 'Esther', 'Lenderman', 'Estherlenderman@yahoo.com', '6314137352', 'Girlsrule1.', 1, 466305, '2016-06-19 21:07:29', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 800217, 0),
(146, 'Pamela', 'Towner', 'cr8nheat1@yahoo.com', '6613130073', 'Darin0214$', 1, 840960, '2016-06-20 01:53:41', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 216352, 0),
(147, 'Tranise', 'West', 'slimprissi@gmail.com', '5162326116', 'Prissi718!', 1, 188386, '2016-06-20 14:03:09', 'user-profile.png', 'e2d7862610929ed92c368e90e2313e6e6d2a9a508c73b688ac4d8218db847891', 0, 0, 0, '', '', 1, 659309, 0),
(148, 'Tiffany', 'Glass', 'lalee2@aol.com', '3107760597', 'Angelina1!', 1, 395416, '2016-06-20 14:33:01', 'user-profile.png', '00222514e241a8607a572c86e33ebdc0b956b9302ab328305215ca8c93365f2d', 0, 0, 0, '', '', 1, 233033, 0),
(149, 'Nicholas', 'Oliver', 'nsoliver@outlook.com', '3472487239', 'Nick1994!', 1, 251517, '2016-06-20 15:58:59', 'user-profile.png', '313dd764858dff70c200430c3804a5f54240601c4cfb5771cd84f63f95a0e263', 0, 0, 0, '', '', 1, 504901, 0),
(150, 'John ', 'Nunez', 'john.e.nunez@gmail.com', '3479333141', 'Johnnunez1!', 1, 292020, '2016-06-20 15:59:26', 'user-profile.png', 'f8gePpFlFik:APA91bH0rjo1Lb77vpNOIo5-Ay5xO-72u9papyPTxGrwk-x7M7LEm4YYyXsL8kZZY_vOdis7ekqWpv-YgsKASEFMK14hfy9gFYy0WbobwUL7WFYYFuUimCAKREFA3FYZ_s08cXllFnMF', 1, 0, 0, '', '', 1, 675042, 0),
(151, 'Carla', 'Onofri', 'carlaonofri@gmail.com', '2134223232', 'Orange0708!', 1, 984811, '2016-06-20 16:11:30', 'user-profile.png', '8e00910d02bf13a49855249a9cc4f4763fbf7b436e2ae0cbe34051141b28edad', 0, 0, 0, '', '', 1, 771205, 0),
(152, 'Talia', 'Davis', 'talia.ashanti@gmail.com', '9725051301', 'Iamchosen1!', 1, 438959, '2016-06-20 17:03:14', '1466442684794.jpg', '9f23195088c4b75835d752cf04477cdf40c5c68228d4db3f9e32129c3c315634', 0, 0, 0, '', '', 1, 281524, 0),
(153, 'ShaQuisha', 'DILLARD', 'sydillard@gmail.com', '6784128727', 'Qb22232223*', 1, 641441, '2016-06-20 18:30:24', 'user-profile.png', 'drcuynZMLnA:APA91bF9kgEXz2JJHYPoeRYgDO0nxXDw7lVMwMg4a3JpHYHVZrlVDxVr7bruHn_29egb_Wk67v71mslKcHic1DD0m9_WtgkgH5iCR8DqGZRZiUda1di5RYBG6l7HiSIAlKgaB8pMOwvL', 1, 0, 0, '', '', 1, 705107, 0),
(154, 'Yasmin ', 'Salah ', 'salamconsulting7@gmail.com', '2405511111', 'Aster777$', 1, 882469, '2016-06-20 21:03:30', '1466456934587.jpg', 'fyvUQs0mL4E:APA91bErt2DCaOzpvY0GhCj8qWoJvI_pgMolkKP_70en52H8U3_ib8Yzh0vjsmVqVQJYiw1mv_uLF__atU7MeevlkVsXjIVfCKDABvJouVsyFiJjGuQDLTQpuGZIfRIJlsl3qtkI5z78', 1, 0, 0, '', '', 1, 177105, 0),
(155, 'Gina', 'Ramos', 'gramos98@yahoo.com', '3472556470', 'Sd02190^', 1, 700754, '2016-06-21 01:56:03', '1467325710119.jpg', 'db3b68742e289a6c9d07a7a1a05d4d34aafe4a914871e18576cf12fdb34c17b9', 0, 0, 0, '', '', 1, 482137, -1),
(156, 'Equanda', 'Willis', 'quandak282@gmail.com', '3473044544', 'Qualasia18_', 1, 151592, '2016-06-21 04:57:55', '1466485329207.jpg', 'c_j_AqeGrUE:APA91bH7oe_choHTQF9IYYQRWG5KfFg96x9XQMqnIv_CWMSDgLhiosnpTDpYfS0B2efrh69KqYtzKIAJvEBfE_hI9f0qEM5PDQWA3J7uxc6F3UgcdSEbZ7LhI53pDws0yoEkyJlsT4Mf', 1, 0, 0, '', '', 1, 274350, 0),
(157, 'Bryan', 'Brea', 'bryan.brea11@gmail.com', '3475641493', 'Carmen-809', 1, 335973, '2016-06-21 05:19:21', 'user-profile.png', 'df152b828c8700aa6aeffc45bd2898304a47f86a39ba42f81dfb0a7a1407f948', 0, 0, 0, '', '', 1, 597475, 0),
(158, 'Ellis', 'Clayton', 'ellislclaytonlll@gmail.com', '3477985460', 'Wisdom25!', 1, 212681, '2016-06-21 05:26:37', 'user-profile.png', '8b90b1a79ccb4400e727f5ed386e9dc1da7c1e759089768d16dd3de246cf6bda', 0, 0, 0, '', '', 1, 400155, 0),
(159, 'Queenie', 'Lin', 'lin.qing.624@gmail.com', '6463713510', 'Longitude@7', 1, 948550, '2016-06-21 05:38:12', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 460679, 0),
(160, 'Julio', 'Zavala', 'zavala.julio125@gmail.com', '4243942798', 'Zavala.Julio123', 1, 199499, '2016-06-21 05:48:48', 'user-profile.png', 'c78c27d9bee2d9d94454acf5adf603411ed93b788c48abc6c6a107f12bbd6d81', 0, 0, 0, '', '', 1, 992460, 0),
(161, 'Kennedy', 'Barnett', 'kennedybarnett1@yahoo.com', '3238778250', 'Kennedy1*', 1, 674398, '2016-06-21 06:28:48', 'user-profile.png', 'ac32432888969db0ea36e78f888dea151d2564978a5e43382f6c321270abb1ef', 0, 0, 0, '', '', 1, 316516, 0),
(162, 'Linda', 'Caceres', 'lchcfan@yahoo.com', '8184689779', 'Sally23!', 1, 886893, '2016-06-21 07:00:56', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 126831, 0),
(163, 'Waulinda', 'Harris', 'waulinda@Gmail.com', '3476849032', 'Jolene@87', 1, 197569, '2016-06-21 11:27:23', 'user-profile.png', 'fdhWodZTkTs:APA91bFMG3j9nR_7GFfi8EIT_zr2sF7M7FouzDculdERO9hJoipmi4l7fMlCx5fuWZw3IJ-pkkbFFkSLVW-HfzTt_m9bW5sn5jMhYS5PYQ2lpt8CCHsK9JffVIgBzxOuJnyxn_A8Bjoj', 1, 0, 0, '', '', 1, 294435, 0),
(164, 'Lenicia', 'Appleton', 'leniciaappleton@yahoo.com', '3473102305', 'M!ssfit8', 1, 580376, '2016-06-21 15:30:59', 'user-profile.png', '00c48cbfca7eb2ac0f77e224b95ea5814ea35c31041f26b31e75f3806f6fa09d', 0, 0, 0, '', '', 1, 761585, 0),
(165, 'Melissa', 'Lehman', 'meemee920@gmail.com', '6786701717', 'Trentmel15!', 1, 832365, '2016-06-21 15:49:04', 'user-profile.png', 'fuQIVxN0moI:APA91bFJH7sRCrZ8v245nmFGgSaF1xsGwt6boJUqxYSs8Zkl2gVGB285ave0voyMBH-SxUVL6pk9ey7a12LCGOgSWcsfcI6lhMm33kmSEsrBdAalDtFYXff_LQgm5FBP-B4Ofn1AaZcL', 1, 0, 0, '', '', 1, 714989, 0),
(166, 'Francesca', 'Pagano', 'fcp16@me.com', '9178172822', 'Chessie16!', 1, 882242, '2016-06-21 15:52:05', '1467312283812.jpg', '43aee4f851dc85648b497190a8fb0691d2214f63d3a51a34958b08e10dd902d4', 0, 0, 0, '', '', 1, 843843, 0),
(167, 'Christian', 'Allemand', 'christianallemand91@gmail.com', '4044347941', '200153846cA$', 1, 820824, '2016-06-21 16:07:49', 'user-profile.png', 'dc_bsahuPgs:APA91bHgf6j7OfhWf3QaPvPa6YmmtuBhazI6kh2sj-xDvcNK9HNFUI9YBIVYbmkYkpKtS1ihhLld2ynun6CfAUu7fOchAOr7ZFykInwXJ3dFj907W86YieT6SqyB1edKrEfDuhyzecgr', 1, 0, 0, '', '', 1, 458797, 0),
(168, 'Cindy', 'Murphy', 'dcset2024@gmail.com', '6785889848', 'Beachlover1963!', 1, 432521, '2016-06-21 16:43:01', 'user-profile.png', 'fbe14bd30eb7b6b400b85687131ff15136e3318d8a74b54ff136b81823953a64', 0, 0, 0, '', '', 1, 192997, 0),
(169, 'Elizabeth', 'Brown', 'fairfaxb@hotmail.com', '3479223551', 'Frankie_15', 1, 209869, '2016-06-21 16:54:56', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 274596, -1),
(170, 'Rhiannon', 'Briggs', 'rhiannonmbriggs@hotmail.com', '7708625816', 'Laughing4$', 1, 317555, '2016-06-21 17:22:01', 'user-profile.png', '0f6f8bb9ca7eb83756a2f16f0905d99c2ce90a320dfc798dcd3a60f61f8a8945', 0, 0, 0, '', '', 1, 812698, 0),
(171, 'Brianna', 'Williams', 'b.williams850@yahoo.com', '7137033002', 'ItsDaddyB1!', 1, 206558, '2016-06-21 17:41:01', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 917858, 0),
(172, 'Victoria ', 'Lash', 'serendipity736@gmail.com', '6786877924', 'Andrew1!', 1, 475361, '2016-06-21 17:56:50', '1466532125497.jpg', 'cdtnp2A_Ueo:APA91bFsEsr0HjN03VbUBSwDHHnUPjMw024dNPGmu0e5AYW8t6yULGqaoFzc_OAhC5A0__K8Wr2BZtU4kDuKmuUooeRZ7g4Rh00X8KSKgB4PrjEOScz9Vy7w5vMnofc2Thpe-JvGqEf5', 1, 0, 0, '', '', 1, 708478, 0),
(173, 'Ricardo', 'Willis', 'rickyw796@gmail.com', '7706084841', 'Samsung@12', 1, 418520, '2016-06-21 18:16:34', 'user-profile.png', 'e_45fu6FSq4:APA91bHgc51gncn_o3A09gA3h8IrbjF9cJf5b0L8aNm3the5yZn8gFw1arZsbGXTmeN5riZIAfPwtbF2R53TWE1N49Fyhy4Su0jd4rQJlWQNd07L9Tolc2PVcvXYrxf2L4hooQGqdfgA', 1, 0, 0, '', '', 1, 802780, 0),
(174, 'Jessica', 'Caceres', 'jessmcaceres@yahoo.com', '8188499593', '@1147Mzft', 1, 891977, '2016-06-21 18:31:19', 'user-profile.png', 'dRSUUML4LSI:APA91bEvq51ulG5EhWXNKWdvfPbRg9V75kbP5Ncl93ZeFZpS6mWinHIoHuh3d1fi-ayRTGOYEUheaYjYI3A9FgwgnO7Knbce3qTVHOQFdjOsKZ2tDlKXnJRajTeq134uXOshfI1nnS-_', 1, 0, 0, '', '', 1, 751793, 0),
(175, 'Kesia', 'Poole', 'kesiashani@icloud.com', '9293400542', 'Shani*1990', 1, 315474, '2016-06-21 18:54:30', 'user-profile.png', '48266696dfaeda4354de7ca272d7a357b4986ef60b852e8d115bbc02dca5ea72', 0, 0, 0, '', '', 1, 239162, 0),
(176, 'Loleka', 'Hudson ', 'Lolekah@gmail.com', '3364570430', 'Eulish@1', 1, 521142, '2016-06-21 19:07:42', 'user-profile.png', 'f2K46wERFlw:APA91bG7ouk7qJ9e-qtjMul7BtDFH10K8UYo-Krp4XA7RrwoftIpwbltPPP2DGiWDWB2ffQW1xs_4g8aXC9a8RdRjXc4tKEC75UlRwYmtpK34Ew_JBzxzb-Gqfj4dHDD9X2c5Akj-Fu2', 1, 0, 0, '', '', 1, 963572, 0),
(177, 'Jodi', 'John', 'jodilynn0511@gmail.com', '5303000763', 'gradCBU2011!', 1, 265338, '2016-06-21 19:09:16', 'user-profile.png', '492ce51658373d6c9d956aefeccd3caabe4d91ae22b4ab2de6e6bd7b0eedd834', 0, 0, 0, '', '', 1, 517704, 0),
(178, 'Yseult', 'Polfliet', 'ypolfliet@gmail.com', '6095766606', 'toy9Wowfod!', 1, 404190, '2016-06-21 20:06:11', 'user-profile.png', '91d9a7eb23421e8183838bcf0531c57cda65ff5e1095a1aaa0d18448b1fa9154', 0, 0, 0, '', '', 1, 749166, -1),
(179, 'Luisa', 'Gonzalez', 'lgmusic24@gmail.com', '9203092712', 'Musicgirl@24', 1, 137455, '2016-06-21 20:38:34', 'user-profile.png', '4acb07ca5c3de2a80af9e3032e591cca3cfe1dc9241432d4f72fcb49adfc2858', 0, 0, 0, '', '', 1, 659119, 0),
(180, 'Melanie', 'Binet', 'melalexa88@gmail.com', '5163757956', 'Iloveyou2!', 1, 948024, '2016-06-21 21:27:50', '1467313903822.jpg', 'f9b1e9fd7a3c413760a9492641260e270480c110cda60c4eb6eb22d9c69273f7', 0, 0, 0, '', '', 1, 244005, 0),
(181, 'Hailey', 'Brock', 'hb_080995@icloud.com', '6784464892', 'Diana#95', 1, 783571, '2016-06-21 21:34:56', 'user-profile.png', 'dc_bsahuPgs:APA91bHgf6j7OfhWf3QaPvPa6YmmtuBhazI6kh2sj-xDvcNK9HNFUI9YBIVYbmkYkpKtS1ihhLld2ynun6CfAUu7fOchAOr7ZFykInwXJ3dFj907W86YieT6SqyB1edKrEfDuhyzecgr', 1, 0, 0, '', '', 1, 940514, 0),
(182, 'Alexis', 'Hart', 'lexihart1216@gmail.com', '4043246252', 'Redmonkey@12', 1, 539090, '2016-06-21 22:06:50', 'user-profile.png', 'dZ6sfzO1mvA:APA91bHZOVbvPAn-wX9cqL2Xe82FvyI61ADOmq5TV7JpXPCYlWIOQZRnAq8bvs_fYCrk5Z_Q4GkCLKOaSCrn-OFU3uQGS07FfQ7umQwEesY4VK5uOP5MmHjr0Fr7080_Us9FsjNm4Wbh', 1, 0, 0, '', '', 1, 396508, 0),
(183, 'Eileen', 'Pena', 'penaeileen27@gmail.com', '3478321895', 'Miss0409!', 1, 120366, '2016-06-21 23:31:27', 'user-profile.png', '874a8353647bb5c36da0bf790d7ec26335804d759f179c76327a7bad98a60e06', 0, 0, 0, '', '', 1, 312613, 0),
(184, 'Altovice', 'Williams', 'altovicewilliams3@gmail.com', '3164694030', 'Alto0103!', 1, 210982, '2016-06-21 23:31:46', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 547638, 0),
(185, 'Darius', 'Byrd', 'dbyrd10@hotmail.com', '2533895939', 'Totight1!', 1, 778975, '2016-06-22 00:30:50', 'user-profile.png', '2f6cf461ad983473347c3e195f89279dfcc28315695b5f028daab53109966968', 0, 0, 0, '', '', 1, 698143, 0),
(186, 'Vanessa', 'Mark', 'vanessajacquelyn@gmail.com', '7818126330', 'Wygrac1!', 1, 937735, '2016-06-22 01:15:39', 'user-profile.png', 'cufjSp8AD4k:APA91bG3mjZ2lSzbCN-gSgB79c609Jvof4UqwS_Lm1N1PP4O5_HjQorRPinAo-fhWHpCV8EifhpDhcHV_bt7ayhBD_9Ynx6bEns1QqZaKmcgA44Bq9YS5FXcNEJLwL4i-0RpW0smnfnL', 1, 0, 0, '', '', 1, 104219, 0),
(187, 'Cheyenne', 'Motayne', 'cheyennemotayne@gmail.com', '3476610801', 'Gail1956&', 1, 292758, '2016-06-22 01:41:32', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 270242, 0),
(188, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2038879349', 'Justice2!', 1, 334453, '2016-06-22 02:26:15', '1466563539803.jpg', '3accd036208c70ed66fa1b5cc862b6e5edd62dcb86070da0ee2701168eabae56', 0, 753044, 0, '', '', 1, 847287, -1),
(189, 'Diane', 'Lester', 'dmlester21@gmail.com', '7033177869', 'Timsmiled3@', 1, 605043, '2016-06-22 03:15:24', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 907417, 0),
(190, 'Elisha', 'Sostre', 'lisha1018@gmail.com', '9293652284', 'Jas*marie03', 1, 647366, '2016-06-22 03:21:49', 'user-profile.png', 'fFx4O_wb5kA:APA91bHlAo_18uX48DOdqXxqfWBnVBKfbxQO2dAPm1hv7669sDWtZj_aJvlm-DNetoEK3foqD1YINW-1kDZxEeNG3Dlcch9PP2Q6nuVxXSChxWYaLwM3S6GwhAfjNVNMz6_1_ccoClCg', 1, 0, 0, '', '', 1, 488826, 0),
(191, 'Patricia', 'Sapp', 'tatersapp@gmail.com', '9044381521', 'Rite4this!', 1, 141423, '2016-06-22 13:08:37', 'user-profile.png', 'cda8cGmp1yg:APA91bHBvzeDzI59ITzZ9_G2Ih9hkdru0dvuSSRjJWzv6kUHFMr33HOsoHF_cBHgfrbFqBCAbgT-v0vovOw2jxuqGQ_iISMjGciPI6OFpD1T-OK96YPXNFR__dLhgpfmIZPbVt2aByoc', 1, 0, 0, '', '', 1, 569825, 0),
(192, 'Caitlin', 'Siney', 'caitlinsiney@gmail.com', '6102031445', 'C8slife4eva2!', 1, 244480, '2016-06-22 13:41:52', 'user-profile.png', '037cb2b0b503b361f3ca2b4a5df5e33613ac37eddb68c29c9c580360cbe3ae44', 0, 0, 0, '', '', 1, 141907, 0),
(193, 'Christopher ', 'Garlin', 'clgarlin2006@gmail.com', '4047044737', 'Jassiah3!', 1, 750722, '2016-06-22 15:45:43', 'user-profile.png', 'fpN6ZAPLfzc:APA91bG7RV7sxZtkWmBSo-LoQG_Qe6e6GCQGMbyC4Y82qxhg9nJQ6aUWKfL6nksLMwkfh4U3a2bWrTGaXB_vpteBKFUFawLb5FG8WNbxixHbfvF1n0UDKv1vXKGBocqv6KwQ9aemgcE6', 1, 0, 0, '', '', 1, 749034, 0);
INSERT INTO `user` (`userId`, `firstName`, `lastName`, `email`, `mobile`, `password`, `isEmailVerified`, `passcode`, `createdDate`, `userProfile`, `deviceToken`, `deviceType`, `forgotRandom`, `userType`, `changedEmail`, `changedMobile`, `isMobileverified`, `mobilePasscode`, `isDeleted`) VALUES
(194, 'Genesis', 'Munoz', 'gnssmz@gmail.com', '9298881148', '$agitariO8', 1, 555010, '2016-06-22 16:12:31', 'user-profile.png', 'c316eaaa4aa5eca763d10bac4c8886868b6fc2e414be0cf424f4d6f0c15f4a55', 0, 0, 0, '', '', 1, 160371, 0),
(195, 'Curry', 'Winkfield', 'currywinkfield@yahoo.com', '3472445083', '$Gudda145', 1, 307854, '2016-06-22 17:42:47', 'user-profile.png', '837bf2c1b3b24c9d2561621cbaa95860ddbd719673609c68ebfa6ab0c361c923', 0, 0, 0, '', '', 1, 416939, 0),
(196, 'Tanner', 'Lewis', 'tannerlewis99@gmail.com', '4239337281', '@Catgone1', 1, 685871, '2016-06-23 00:40:45', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 309627, 0),
(197, 'Morgan', 'Lucas', 'morg.lucas96@gmail.com', '6784384363', 'Ang-morg123', 1, 943790, '2016-06-23 01:13:35', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 934151, 0),
(198, 'Daisha', 'Price', 'daishaprice23@gmail.com', '6787781757', 'Macmiller<3', 1, 673155, '2016-06-23 01:49:35', 'user-profile.png', '3eb1b9fe9a23b9036d2105aaeadc3156fd987acd62e4bcc9e2c578d738468d89', 0, 0, 0, '', '', 1, 964913, 0),
(199, 'Stephanie ', 'Skinner', 'stephanie32391@gmail.com', '6786508848', 'Garrett1!', 1, 352787, '2016-06-23 02:00:50', '1466647932522.jpg', 'fWkb0vMzewM:APA91bFE9O4kymMu9P0ZJFHJyybbq79FCpPySnRfROJ7P95138otGBy_pawMPztCZaLBjtgStYw6k_TcCyh7WUzpfFqcUeQcCRwnNN5ry1yu_c5gqdQiZCiflEF3SYdsKHrZreOaQax5', 1, 0, 0, '', '', 1, 757880, 0),
(200, 'Erick', 'Torres', 't.erick94@yahoo.com', '8189164353', 'Oswaldo420$', 1, 630927, '2016-06-23 02:46:41', 'user-profile.png', '0608db7cc971b086a4e5d494310cd663d85a828d59c309fa97ffcc1cdce376f3', 0, 0, 0, '', '', 1, 307636, 0),
(201, 'Lola', 'Lopez', 'lola9lopez@gmail.com', '6266930169', 'Warhero9!', 1, 691825, '2016-06-23 02:59:38', 'user-profile.png', '0bb69dc0ded3eadbe7b47bb069ae5fce7e9c62ded681def7a7a9322b27f90737', 0, 0, 0, '', '', 1, 391535, 0),
(202, 'Montana', 'Pickens', 'mpickens2014@yahoo.com', '7067410591', 'Montana12.', 1, 834279, '2016-06-23 03:01:14', 'user-profile.png', 'd8aa425c0700cb906e0ca7d09cd4781880c82aaaa67b8045730814355ae3bffd', 0, 0, 0, '', '', 1, 216224, 0),
(203, 'Joi', 'Allen', 'joi.allen210@yahoo.com', '5743443401', 'Superwoman06!', 1, 411062, '2016-06-23 03:08:52', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 817058, 0),
(204, 'Omer', 'Choudhry ', 'Omerchoudhr@gmail.com', '6017507351', 'Knightsbridge!1', 1, 431106, '2016-06-23 03:35:33', 'user-profile.png', 'da2Hzhv-lIA:APA91bGjgFO0zu3C4x_N0PPGu-WC1ifCllO9vgzJ7NtgnHlK9baz0EOKGVgy_IEYChu6aaT-TaoZy0pMu8cEI4vHQYWs5t-uGLr19AGCd5x8ezrHbGqrFFjNSE8nC0zipUodq_cyjpfh', 1, 0, 0, '', '', 0, 921209, 0),
(205, 'Jose', 'Hernandez', 'vauxxer@gmail.com', '9154746047', 'Qn0wp@ss', 1, 264533, '2016-06-23 04:30:04', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 448777, 0),
(206, 'Charity', 'Wise', 'charityiswise@gmail.com', '2026158832', 'Iamme623*', 1, 935962, '2016-06-23 04:58:38', 'user-profile.png', '02adfc0f4f5bb1c80bd7f64d7a871b0b4292a4eeb62054d0480f72712437cbe6', 0, 0, 0, '', '', 1, 250154, 0),
(207, 'Leanne', 'Stella', 'lstella147@aol.com', '9172734405', '1749Elina!', 1, 911192, '2016-06-23 12:58:53', 'user-profile.png', 'f3b0100512650e4fe8aa4276ace10834d7a598a23fcfc439fb6a8e806240fad6', 0, 0, 0, '', '', 1, 632131, 0),
(208, 'Ryan', 'Williams', 'weryanwilliams@hotmail.com', '6465459236', '1ryanisdope@W', 0, 393843, '2016-06-23 16:15:13', 'user-profile.png', 'fn4VgLOssGw:APA91bHUy9C2cq2VGvFuZvJrSCfZjSJMAxrrlnyYZz4MpLD4F5Lu8h1XrQKsy7bzndgR78WNgSW8Qm97uzbKS77D-NLUfgnq6mioOWZgA9Pu4pWBtp2KN-43ZCJtrtNuQcGU8_QZ73Dq', 1, 0, 0, '', '', 0, 676664, 0),
(209, 'Elina', 'Stella', 'elinastella9@gmail.com', '9175754425', 'Pets1996*', 1, 709077, '2016-06-23 16:52:56', 'user-profile.png', '9b2d101f235f70277de99e9d7c9b09d463239c7e0da55e1538650dacaafce878', 0, 0, 0, '', '', 1, 809877, 0),
(210, 'Dailyn', 'Santana', 'santanadaii@gmail.com', '9082175067', 'Reality35!', 1, 717930, '2016-06-23 17:38:52', 'user-profile.png', '5b8d8d56c5efb7a165eaaa85985feda50566cc48b2dbe94fdead7a855dd9002e', 0, 0, 0, '', '', 1, 998546, 0),
(211, 'Monique', 'Williams', 'moniqueshavon@gmail.com', '6785232604', 'Employment1$', 1, 511824, '2016-06-23 17:52:59', '1466705542507.jpg', 'c3d3ae13b5e5bc73acf0c8ae693a3f069be59227cb1f8630dfa184042164568e', 0, 0, 0, '', '', 1, 950501, 0),
(212, 'Darius', 'Taylor', 'dariustaylor16@gmail.com', '6782879404', '@3Dd5545120', 1, 352906, '2016-06-23 18:04:05', 'user-profile.png', '55634236f43d4814dbe707d4d4ff5a093b2b6d3b76e6cd6beccdd8cb707cdeb4', 0, 0, 0, '', '', 1, 915083, 0),
(213, 'Jacquelin', 'Jenkins', 'jacquelin.jenkins@outlook.com', '6306774269', 'Dancer09*', 1, 255818, '2016-06-23 18:35:34', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 895926, -1),
(214, 'Romaldo', 'Arteaga', 'romyazteka7@gmail.com', '5622907557', 'Ram090589!', 1, 564149, '2016-06-23 18:42:41', 'user-profile.png', '6a60165918079364fa6ee1da5c3cef1473fef77f6c2a759d489aff562a099421', 0, 0, 0, '', '', 1, 302594, 0),
(215, 'Josh', 'Mann', 'jsmact@gmail.com', '3108509839', 'Kafkajew1979!', 1, 577884, '2016-06-23 19:58:12', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 843000, 0),
(216, 'Jai', 'Patel', 'jaipatel850@gmail.com', '8503778952', 'Jj33160,', 1, 820420, '2016-06-23 20:47:47', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 165884, 0),
(217, 'Alisha', 'Watkins', 'alishakenshe@icloud.com', '6789797024', '08312009Aw!', 1, 866646, '2016-06-23 21:30:15', 'user-profile.png', '7ec65e7d8401a031ca242915395b45933f939f1ecaab6b50faea141f5b860e12', 0, 0, 0, '', '', 1, 535259, 0),
(218, 'Sarah', 'Nee', 'nee.sarah.88@gmail.com', '4079231221', '$Sept012007', 1, 505357, '2016-06-23 22:01:03', 'user-profile.png', 'fCQkpFwRtOM:APA91bFb-ts8nz8jChFNBRtlBGPntQDH6j4stNuRHqglvrPnbyg6FTeVj9AFvera4d0tMj1IJfQtbVNMlDcNvIleGceROK03-K0vc9UzGIVviocYfoWzutu1Hgf8sELMyXoasskDaBS0', 1, 0, 0, '', '', 1, 786810, 0),
(219, 'Alicia', 'Hosey', 'alicia.hosey7@gmail.com', '3232517866', 'Divababy1$', 1, 872088, '2016-06-23 23:08:24', 'user-profile.png', '3034c812cf7a1c2951612358b4d9fe56f0eb55548888702bc56626b62a508b6c', 0, 0, 0, '', '', 1, 466921, 0),
(220, 'Zarina', 'Jaeger', 'zarinajaeger@yahoo.com', '9258764947', 'Heaven11!', 1, 666248, '2016-06-23 23:09:29', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 319193, 0),
(221, 'Deshawn ', 'Millien ', 'deshawnmillien97@gmail.com', '7186631598', 'Swagtastic1!', 1, 302708, '2016-06-24 00:13:32', 'user-profile.png', 'dkmnQv0RslM:APA91bEWuOc9I3coH38ZxZXaiaZxrV3x_X-0ATf6DfEvgNsmVW_LhXRchHGbRNXrG66_XoDwa3Ijpy-N7o_wAXncrk-oh7Qd6LnBy-SzfuSM4jBbO1N7Qrgiw7p8MdOWTM2rGUcF0ind', 1, 0, 0, '', '', 1, 521898, 0),
(222, 'Yasmine', 'Christian', 'y.christian312@hotmail.com', '2015899013', 'Brooklynn0607@', 1, 694565, '2016-06-24 03:01:58', 'user-profile.png', '9cc215a79229560e152a8cb982f2b3f1d5480dccaa9cd5bd6aea66c6d6badf84', 0, 0, 0, '', '', 1, 978747, 0),
(223, 'Merlin', 'Vinegradova', 'merlinvinegradova@gmail.com', '3233339554', 'Merlie12!', 1, 993881, '2016-06-24 03:04:49', '1467306226586.jpg', '91c34d708f4fafe49d87dee3870f43729b245b27924851d6db7c390c5ec13eea', 0, 0, 0, '', '', 1, 516725, 0),
(224, 'Cassandra', 'Ball', 'cassandrakball@yahoo.com', '4049532117', 'Lynetta1!!', 1, 723292, '2016-06-24 08:54:57', '1467612515165.jpg', '4b9bfed602c1d742b35c64825f142c95a7403755ef4aadccabdd93ef51cdf94a', 0, 0, 0, '', '', 1, 764605, 0),
(225, 'Olajauwon ', 'Andrews', 'olajauwon27@gmail.com', '2162174450', 'Blazers1!', 1, 769163, '2016-06-24 16:52:25', 'user-profile.png', 'ed-hneREOWo:APA91bHMmjup-EiCnCsa9Qn7krpRPjW5W8ai-9W0-5tK7n0MKsQv4X8toy3GKur7lU26FKttu5ViSM6ffNObsJUrmV76nx8kpgfBXhAqEkERl6Mzst3KIGoalR4_RmwQYrmNtN98LoCH', 1, 0, 0, '', '', 1, 744875, 0),
(226, 'Jessica', 'Alexander', 'jeshalex23@gmail.com', '6304006824', 'Rocky!123', 1, 443349, '2016-06-24 17:28:06', 'user-profile.png', '5d238ae9184ee06eabc556fce6f6e7b009c251f6b01dc3782eedf17565e056ab', 0, 0, 0, '', '', 1, 814065, 0),
(227, 'Yamel', 'Favela', 'ya.fav@me.com', '3475754836', 'Hannia0!', 1, 936166, '2016-06-24 18:07:04', '1466791875274.jpg', 'c6b42e60599393cbf9e66b2df937471b68237af6349f8ea6d9e1b8127035f89a', 0, 0, 0, '', '', 1, 616873, 0),
(228, 'Sarah', 'Aviles', 'sarahaviles10@yahoo.com', '9174369769', 'University17!', 1, 159944, '2016-06-24 18:13:07', 'user-profile.png', 'f99bbe42be707806cb7477f229110f3fbd0a4386a357b1f6d5078e5e9cf2b2cf', 0, 0, 0, '', '', 1, 130287, 0),
(229, 'Sarah', 'Crain', 'ms.sarahdc@gmail.com', '5183214881', 'P@dric4454', 1, 763862, '2016-06-24 18:56:23', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 298889, 0),
(230, 'Paulo R', 'Abesamis', 'pau.is.fit5@gmail.com', '8186755243', 'Pauloabe21!', 1, 575852, '2016-06-25 01:59:13', 'user-profile.png', 'dRG3OKLe-qY:APA91bFvyWHIN2U5P_bIeXeA2MOtS85xJel5mb-e6K7IQpnoa8A7HT_HbO7AcyD2IJdXqzsQAeYQPNX8iZmVeYvMBNRU8M4VjjF4IYwvoPhClX4_7NABL6tOKxqxxHUYiy0b6e-OSK4N', 1, 0, 0, '', '', 1, 502328, 0),
(231, 'Alyxandra', 'Pinkston', 'alyxandra.pinkston@gmail.com', '6782944973', 'J-esus4me!', 1, 927633, '2016-06-25 19:31:11', 'user-profile.png', 'fzT2IkmrQe4:APA91bEkTccVPSFW5mSgvLiyi841paC9PYFEIbgmqKDqHTs9B5v1xXpveOdUiLZRg_TtCNMfu1FexvU63L4X4mrovqscu8eg9acNcOOYirF5TfrXQXw8qdPE-ssDYn7Lvb-GCGjAlWkS', 1, 0, 0, '', '', 1, 623039, 0),
(232, 'Ericka', 'Andrews', 'ericka_martin91@outlook.com', '6789000701', 'Andre17$', 1, 471481, '2016-06-26 15:44:01', '1466956308555.jpg', '21e6be1751554c4f2d52b2c9fdd69de844c6c47c17093653668218b7119c9b5e', 0, 0, 0, '', '', 1, 219058, 0),
(233, 'Jacob', 'Beckham', 'jacobbckhm@gmail.com', '7066147163', 'Jwb30504!', 1, 713790, '2016-06-26 17:28:02', 'user-profile.png', 'f_mOOmHy2D8:APA91bEZDlyrOKnPx1_bboC1iufsVyVjFkOjo9Kq_vgOZzzHUiKTyLgJ2EnUCJ_A423_ysSg4f3g39soSFWv_6oL3FK3g0cPjHCs46UiK6DE4z98dCnQnnwOwaE8AVnNzf1MQqaMqX7o', 1, 0, 0, '', '', 1, 220512, 0),
(234, 'Tanika', 'Kennedy', 'tanikakennedy@yahoo.com', '6787990823', 'EvaDiva30349*', 1, 970477, '2016-06-26 19:22:56', '1467043419375.jpg', '7e3d74940af98163959031756c7098ae37ed05dd6041478f2fede59854c316f5', 0, 0, 0, '', '', 1, 550469, 0),
(235, 'Candace', 'Carter', 'candycolette@gmail.com', '8187383337', 'Imblowed1!', 1, 902718, '2016-06-27 00:51:02', 'user-profile.png', '13878cf7da85051d0d11ea29f7f43553c7334c1a5b10ebeaf24ba1a39ad08a3d', 0, 0, 0, '', '', 1, 498103, 0),
(236, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '8184658228', 'Justice2!', 1, 114050, '2016-06-27 03:48:58', 'user-profile.png', '3accd036208c70ed66fa1b5cc862b6e5edd62dcb86070da0ee2701168eabae56', 0, 0, 0, '', '', 1, 832513, -1),
(237, 'Michael', 'Galloway', 'buckcitynow@gmail.com', '8044055055', '#Galloway1', 1, 327618, '2016-06-27 13:51:30', 'user-profile.png', '5c35104f45c0d963c7996830e13c4a9f2d8f56a25d98eb037783179eaa1e7b8e', 0, 0, 0, '', '', 1, 674078, 0),
(238, 'Antonett', 'Young', 'ayoung81@aol.com', '3478161779', 'Malakah12$', 1, 452473, '2016-06-27 15:45:30', '1467043371565.jpg', 'f7t4LCUsYDg:APA91bG8Qk3rVk8Gtf7Zy4syUCkqzsUy39bdtG869lJLzgs_zySevq-qsjUL149RUwivEOP1hXzOPjqmwEldnFO69xKO7ejgqashLCVCshd8PNvwdOQkYA_5Jc9qAr12e25Om13dLQR7', 1, 0, 0, '', '', 1, 469116, 0),
(239, 'Felix', 'Odigie', 'felix@myqapp.com', '6173881912', 'Ric0860424!', 1, 926552, '2016-06-28 03:08:08', 'user-profile.png', 'c39b042eb85b911d4fa8945e74347c1c5f93bb0531c42a89d2f5cfdca0c621e7', 0, 0, 0, '', '', 1, 931178, 0),
(240, 'Anita', 'Boateng', 'anitaboateng1@aol.com', '3474062535', 'Anita123@', 0, 802437, '2016-06-28 04:45:29', 'user-profile.png', '3d29c7ce5f53eb01c67f5d40aeee9960a3083e4c121197d2878db82cba0940f9', 0, 0, 0, '', '', 0, 288547, 0),
(241, 'Jessenia', 'Carrasquillo', 'jcarrasquillo90@icloud.com', '4049914198', 'Infinite23!', 1, 828183, '2016-06-28 06:35:49', 'user-profile.png', '1869f4809fdf09d82e55a05767bb4d6d526855e82190bf0b89c6958c0353f124', 0, 0, 0, '', '', 1, 326444, 0),
(242, 'Barbara', 'Horsley', 'barbiebabe115@gmail.com', '8018886538', 'H3llfir3##!', 1, 870374, '2016-06-28 12:32:19', '1467360201779.jpg', 'cEMf7-GxBtc:APA91bGiijQoGc77feHGKVqymJfQfKGQm-xeEAhbGB2F5eDUOXVNHNwuz89ykuE0KJmHb4jBByto9VJMOUN0n4ve07ZO4BPJpF1rmDBbD0gd7wnjqWXI3fRwXWqPCeIbvKARVWg-FKag', 1, 0, 0, '', '', 1, 957107, 0),
(243, 'Brijesh', 'Bhakta', 'brijesh.lanetteam@gmail.com', '9898304401', 'Lanet@123', 1, 896596, '2016-06-28 16:37:04', 'user-profile.png', 'dxlr38zW-dY:APA91bHym0V7YxLKy7v8LaCnHBByUFKm9gRWvOdNTuu7uvg9JeFbHySB8hNw9_UrrQEmt2mddeptgrIYTGytOK_ltz6Rii59Y1YleRxIU3EKmmBLjCd2ZgWymDYy4qORXwOseLEop4ba', 1, 0, 0, '', '', 1, 351846, 0),
(244, 'Kamilah', 'Carter', 'mimicarter007@gmail.com', '6783589025', 'Kayden32$', 1, 590824, '2016-06-28 18:57:50', 'user-profile.png', 'fX58MgkrqT4:APA91bHontaLLI6egTbp6pGfg2D36hOcD3TT4RsYhdgMtZ9JLT-TLvmAQ9UpKLphUv3MJ8x6TLSEqwwcRFWkbU0D0xt2Z3IWCdcEL3d-V7rJucmjlx9QEjgDW0nJCOsC4vxAA1nd7u1U', 1, 0, 0, '', '', 1, 915480, 0),
(245, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2038879349', 'Justice2!', 1, 882594, '2016-06-29 00:41:51', '1467161162621.jpg', '22baf75fb0f44f6139b10e4cc4b6df17682dee1458fba13df930a3d77ffe7423', 0, 753044, 0, '', '', 1, 881608, -1),
(246, 'Angelo', 'Pullen', 'apullen@mac.com', '4408044548', 'Dologrolo09*', 1, 230109, '2016-06-29 04:23:16', 'user-profile.png', '9a82a7a8e64eb53dd313b895cde9220230c1ec62d71ac8ae465469cf9473583f', 0, 0, 0, '', '', 1, 551893, 0),
(247, 'Alan', 'Liu', 'llwwzz36@gmail.com', '4122457236', '54Wzl_36', 1, 561829, '2016-06-29 04:27:05', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 728601, 0),
(248, 'Kamilah', 'Carter', 'kcarter25@yahoo.com', '6783589025', 'Kayden32$', 1, 409307, '2016-06-30 14:34:18', '1467298113376.jpg', 'fX58MgkrqT4:APA91bHontaLLI6egTbp6pGfg2D36hOcD3TT4RsYhdgMtZ9JLT-TLvmAQ9UpKLphUv3MJ8x6TLSEqwwcRFWkbU0D0xt2Z3IWCdcEL3d-V7rJucmjlx9QEjgDW0nJCOsC4vxAA1nd7u1U', 1, 0, 0, '', '', 1, 243913, 0),
(249, 'Waulinda', 'Harris ', 'Waulinda@Gmail.com', '3476849032', 'Jolene@87', 1, 375474, '2016-06-30 15:19:29', 'user-profile.png', 'fdhWodZTkTs:APA91bFMG3j9nR_7GFfi8EIT_zr2sF7M7FouzDculdERO9hJoipmi4l7fMlCx5fuWZw3IJ-pkkbFFkSLVW-HfzTt_m9bW5sn5jMhYS5PYQ2lpt8CCHsK9JffVIgBzxOuJnyxn_A8Bjoj', 1, 0, 0, '', '', 1, 854164, 0),
(251, 'Ashley', 'Anthony', 'ashleynnanthony@gmail.com', '7703046301', 'Ihateu22!', 1, 149512, '2016-06-30 16:09:01', 'user-profile.png', 'b43b90e08991e5508308cea0a5f827ece75fb3c71d6861cb89e944f134f17813', 0, 0, 0, '', '', 1, 349614, 0),
(252, 'Ashley', ' Bennia', 'ashley.bennia@gmail.com', '9737276699', 'Ab!052494', 1, 160705, '2016-07-01 00:53:58', 'user-profile.png', 'dQjS7K7dxS0:APA91bELEywQXAULVjaP1xsor3m9xa7d8--X8JAbowpVEjFPA2dI1RL6p72rbA9rDzMLwKjm77MyrDBHsFiWAurxXRKyZQwErIi-zmK_sc18QFu6qUXAPj-3KOaod3kJ_K2IhA2bs3pc', 1, 0, 0, '', '', 1, 570128, 0),
(253, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2038879349', 'Justice2!', 1, 654513, '2016-07-02 07:42:54', 'user-profile.png', 'c848829c74dcf48d3c7a109256d6b0bc39df06b66ace0e3dda95fda949f53442', 0, 753044, 0, '', '', 1, 868410, 0),
(254, 'Ruben', 'He', 'jrhernandez2@miners.utep.edu', '9154746047', 'Qn0wp@ss', 0, 815917, '2016-07-02 08:55:32', 'user-profile.png', '741b9bc3cedad0bdda701e75108da16836d703a088236957b4db726401dd0342', 0, 0, 0, '', '', 0, 907785, 0),
(255, 'Cheadee', 'Doe', 'cheadeedoe@gmail.com', '4043751600', 'College_2016', 1, 862204, '2016-07-03 19:08:04', 'user-profile.png', 'eeb5373f8ddfdfe065dba28d7beaed59ab3fe48f861f252c9310e5c052391f9d', 0, 0, 0, '', '', 1, 361787, 0),
(256, 'Taja', 'Jackson', 'hill_taja@yahoo.com', '4192604385', 'Malani1989!', 1, 599197, '2016-07-04 01:04:47', 'user-profile.png', 'fITkxkxGw88:APA91bHXdyJm5nf6ZtYepySbHHc2v9cG1goiKakyKbpkhNYxFn6ssKWFtL2c6MsuJx21HDes2j5SBhQ0yJwls_pdPA0_6RD61yPCnyueQyZdYvlEF-bIzu4WtCPLGSWqEbxNwScmZ8TZ', 1, 0, 0, '', '', 1, 473011, 0),
(257, 'Jamal', 'Jones', 'jamal.and.jones@gmail.com', '6099297013', 'kr!@t0RR', 1, 227437, '2016-07-04 01:45:27', 'user-profile.png', '7ea7db180c4716030c1d1d334037daa701552e4ead9ff471162826f2f389da17', 0, 0, 0, '', '', 1, 656650, 0),
(258, 'Jake', 'Montagnino', 'jmonte98@gmail.com', '3478160721', '#EvilRegal1', 1, 127593, '2016-07-04 03:04:05', 'user-profile.png', 'b3c20c74154fbea1bc84c754c251be519238da2cab70bf33413490874d54fdb4', 0, 0, 0, '', '', 1, 180770, 0),
(259, 'Gina', 'Ramos', 'gramos98@yahoo.com', '3472556470', 'Sd02190^', 1, 321526, '2016-07-04 04:17:01', 'user-profile.png', 'db3b68742e289a6c9d07a7a1a05d4d34aafe4a914871e18576cf12fdb34c17b9', 0, 0, 0, '', '', 1, 524627, 0),
(260, 'Michele', 'Sawka', 'michelesawka@gmail.com', '4128979809', 'Iluvjeff11!', 1, 864681, '2016-07-04 05:33:48', 'user-profile.png', '79277066c43c76795ca34a7b64335efa2266a899179d0d3f35a77b9750889c0c', 0, 0, 0, '', '', 1, 307045, 0),
(261, 'Cecily ', 'White', 'cecilylong19@gmail.com', '6788306836', 'Ceecee77!', 1, 568361, '2016-07-04 06:15:02', '1467613369139.jpg', 'dTvqRJC8Xqk:APA91bEKU39PhLVHPF3C17eeCJy3hrrAs00PmepDLpBPeQkZTuswiNjx5Oxv5kBMwk_RrfTm-RF-8aEchOJ57W8ozCi4uhKap8SLU42xFdvCST16FlC7WylgotTLDEFadfneWKRZYzx9', 1, 0, 0, '', '', 1, 348003, 0),
(262, 'Taycia', 'Orr', 'taycia675@gmail.com', '7187089275', 'Yasmine.675', 1, 273636, '2016-07-04 17:25:18', 'user-profile.png', '6e5f6aa1b885da415d11da102ec890057de8b03771e225e2b1b6054e5b55f384', 0, 0, 0, '', '', 1, 511379, 0),
(263, 'David', 'Parmet', 'david@parmet.net', '9144004120', 'Kirkland.1', 1, 848186, '2016-07-04 18:15:14', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 334836, 0),
(264, 'Malene', 'Noel', 'malenenoel20@gmail.com', '3474854222', 'Loveyou201!', 1, 868030, '2016-07-04 18:48:40', 'user-profile.png', 'e9RVEhv1_QY:APA91bH0J71q_ZIpQGdychqURXKUxMso6ZED8KBuOIJ1mwAzQdWb7NUzbx8MVBu74IHxU9_xM_5vxrcHqBN6wct8T48P-i1gL2VUM1gi0sdJ8YoiLwdRkDaQvE0h_RvxeC4DdXyUFORc', 1, 0, 0, '', '', 1, 549669, 0),
(265, 'Wesley', 'Reeves', 'Wesrvs25@yahoo.com', '6268064841', 'Shirtpants1!', 1, 592480, '2016-07-04 19:06:49', 'user-profile.png', 'fpfmRh8Ydkg:APA91bFU0EnSzWb_st1akoyK1YJscEj2OmUyqKz1DXwzMFdSrwgddx2zJU0JbyISpE2T7I5jIIhBpA3eOI0tJUXiry7XOYrwKRzUjKJnqdMYBgGaIP2BxGU328M7Dnvq_S-tqdaAvD0T', 1, 0, 0, '', '', 1, 288553, 0),
(266, 'Dan', 'Walters', 'danwalters6@gmail.com', '6513685913', 'Rebound06!', 1, 136635, '2016-07-04 19:14:49', 'user-profile.png', 'f0df2df87a58bb53fc9cebe6d46f4ee3409e34b44f8f2b84ecb34f17ab7fe80a', 0, 0, 0, '', '', 1, 651304, 0),
(267, 'Adrienne', 'Moore', 'Admoore23@aol.com', '9175098032', 'Milove123@', 1, 924392, '2016-07-04 19:16:30', 'user-profile.png', 'eS4OmUBqDyg:APA91bGz_gueUU0sdrYnrwom7xC4w-6Bgh05T-Pt1l92Pw-UE5yHPEINK9NubQNwU9mHRlcijAK68wIXNbGgKbX9eiUaAxl1YaU19V1u3w45JyHZLdzmluQNd5sohVKVnBGsDuAjmjX2', 1, 0, 0, '', '', 1, 852940, 0),
(268, 'Avery', 'Calhoun', 'averycalhoun62@gmail.com', '4706850090', 'Moneyteam55$', 1, 766400, '2016-07-04 20:44:30', 'user-profile.png', '4939b24c2e0a85627813139ab7661ca1cc23d40a6895419794ee57f14f7812cc', 0, 0, 0, '', '', 1, 976013, 0),
(269, 'Jordan', 'Welder', 'jordanwelder09@gmail.com', '5159713593', 'Loveyou1./', 1, 539767, '2016-07-04 21:08:57', 'user-profile.png', 'cYOyQuii598:APA91bESa6Yaa5ZKJZ77CnjL7oGNen-upxKW8HPmAZDHazt3Qm7qF8hdXTxfHWfNu4WPVnLcXYXhQuNx1dETkJ54u3xqvfFBRM41HXWeBsJdq0bi5A7x3Yy8SBIUziUwgglvI9XXhuvi', 1, 0, 0, '', '', 1, 296336, 0),
(270, 'Monica ', 'Kornblum ', 'monica.kornblum@gmail.com', '9177501482', 'Mons1018!', 1, 424102, '2016-07-04 23:44:20', 'user-profile.png', 'eP4VVDl0uwk:APA91bGcNReyIYU0xb2OSdsKVc74JK6lR3js-dfKi45QYhoukE2r3sEtUHvguCj93oQ6nNNJbQHdLlE4MGy8ikVeoBjo1PgJTEcrg59gTf-4xcTN6BBM86Ux3Wg-8OcHgeZHf4YysD3o', 1, 0, 0, '', '', 1, 504611, 0),
(271, 'Crystal', 'Perkins', 'crystalcperkins@icloud.com', '6785279905', 'G0DisLove7!', 1, 286031, '2016-07-05 00:00:17', '1467679589418.jpg', '6ed8dfd5cadf0c50e82d43af95e8adaa1c3813aade07909444ca4fd82f0a2a9c', 0, 0, 0, '', '', 1, 461650, 0),
(272, 'Gilda', 'Palacios', 'gildapalacios18@gmail.com', '9294423124', 'Sexybab3!', 1, 685454, '2016-07-05 02:51:58', 'user-profile.png', '684d50c7c65b03dfa735eac39ea366b4f6c8060fab96156f6c565716d06fdf35', 0, 0, 0, '', '', 1, 209599, 0),
(273, 'Nykiah', 'Morgan', 'nikkim2@msn.com', '5168526639', 'Despyne2!', 1, 500057, '2016-07-05 10:01:30', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 563035, 0),
(274, 'Stephanie', 'Barquero', 'sbarquero91@aol.com', '9177036651', 'Scarface_91', 0, 192668, '2016-07-05 12:34:26', 'user-profile.png', '6c50c52d1b6b55f683df30f0c300bf0ce5d9826bb0de61bab5325ad0ffe4638a', 0, 0, 0, '', '', 0, 679922, 0),
(275, 'Michelle ', 'Mosley', 'chelle_4334@yahoo.com', '4049096627', 'Georgia!22', 1, 270597, '2016-07-05 13:18:57', 'user-profile.png', 'eFNgPSOry5Y:APA91bGwtRqRlvCAjZnnOiE8L38HPR9ep-_K2MhZZdx35GHBKCCDTzmjgr187PBKCEqI_rPIjedAe6Prf9e3X488JIyDN3O7yUN4CXx_HEMj7_T-5poxydFBqQWTMtra_BaGFRFydw1V', 1, 0, 0, '', '', 1, 710764, 0),
(276, 'Jeszenia', 'Jimenez', 'jvjimenez76@yahoo.com', '9177956847', 'Dream1975!', 1, 271590, '2016-07-05 13:38:28', 'user-profile.png', 'eX1ccW6yAws:APA91bFRKUA4TcyjIyoqt2umtXhkg0q9ioXzOjPZPuliPM8Cfcj4PnBX8Wi9UStw-pfvObWoEfnxDlwll0Js8mATARcjvLGfgozxpoGhlWexlunNP7TmUggffY5YKj32t_DfjfjJO5Kf', 1, 0, 0, '', '', 1, 941669, 0),
(277, 'Janiella', 'Franklyn', 'janiellafranklyn11@newdesignhigh.com', '3478560739', 'Barbie123@', 1, 867161, '2016-07-05 14:33:25', 'user-profile.png', '29307fbc596acd43c0ffe4714ebea094de449b2a817d5bfe932a5dd88952c9db', 0, 0, 0, '', '', 1, 890862, 0),
(278, 'Kassi', 'Lopez', 'kasilopez7@gmail.com', '6785992467', 'Shs100024829!', 1, 252582, '2016-07-05 16:52:15', 'user-profile.png', '4a0535f79c7acdab8225d2f1488d7592dabc53b842b2f9929aeda7cc0a8994d2', 0, 0, 0, '', '', 1, 550516, 0),
(279, 'Passion', 'Sims', 'passionmakella@gmail.com', '4703343939', 'Cream101!', 1, 167781, '2016-07-05 16:56:52', 'user-profile.png', 'fe9d5f2a5e4acf0ca2548dc6281875f799c5bd1000de29f739728e4522ad04ad', 0, 0, 0, '', '', 1, 745880, 0),
(280, 'Marisa', 'Peragine', 'marisaasaurus@gmail.com', '6316627942', 'Peraginem1-', 1, 846888, '2016-07-05 17:01:16', 'user-profile.png', '5c6a78f86be165370672faff49fb3a9d8835b28f4b732939ae4282a799d33dfd', 0, 0, 0, '', '', 1, 636261, 0),
(281, 'Ashlyn', 'Nichols', 'ashlyn.nichols@icloud.com', '13103497018', 'Ashlyn93#', 1, 718913, '2016-07-05 17:09:19', '1467738683747.jpg', '4e86eb2a3e4d77dd653d4d21d34bed4099b8b863ed2d953739a7fc73f078482b', 0, 0, 0, '', '', 1, 559894, 0),
(282, 'Trashekia', 'Herndon ', 'trashekiaherndon@yahoo.com', '3343843502', 'ChristianP14!', 1, 689588, '2016-07-05 17:14:15', 'user-profile.png', 'e9emDEebF5E:APA91bHOudrGcwjnSeN587aaqErIKtFk2A9GuX-C0JOg_OzCil0bLaW7xhQXw5XD3CgzpSlcBVLHN6a0OI5O-dRXGdTMxOok0MxV825IoIiEiLh5bOXueoeh5kwAroAvkoVjklZZLehQ', 1, 0, 0, '', '', 1, 125703, 0),
(283, 'Shernette', 'Hyatt', 'shernettehyatt@gmail.com', '5163680282', 'Duanvale$1293', 1, 734297, '2016-07-05 18:34:51', 'user-profile.png', '30619990e8252860b00412048fe87e5be2db5ded119ec5f6dcc387b1d2abd5e9', 0, 0, 0, '', '', 1, 730108, 0),
(284, 'Matthew', 'Mcdearmont', 'mmcdearmont@gmail.com', '7706807774', '!nf1niasAccess1', 1, 697951, '2016-07-05 19:03:01', 'user-profile.png', '123d2d42704763833af88d27fa1a6fef5c7dfcb318245c57052672d6a6cbf473', 0, 0, 0, '', '', 1, 858176, 0),
(285, 'Michelle', 'Mayer', 'mellymay643@gmail.com', '9175334203', 'Lovemylife94!', 1, 202856, '2016-07-05 19:14:51', 'user-profile.png', 'e0243d176420efc440f7bc0fed786f44bd4d10b7ccc5889d6afb68b0650d9b93', 0, 0, 0, '', '', 1, 349171, 0),
(286, 'Adam', 'Silverstrim ', 'ajsilverstrim@gmail.com', '6178187846', 'Margin_calL11', 1, 435220, '2016-07-05 19:43:19', 'user-profile.png', 'fw_CdOy7f9g:APA91bF34EUts0sR0nTibREgtwpzaPeYiS4m3OsDUHH1Etdt2easc-cWM7ZUeQSM1SzjCJ6m_Xuxr2HgmLkzfObgcrjumQT4zs0CNx4p_SBlz72W6HlsQHYKUGDRO5Y7bQeHE8pHJ2_4', 1, 0, 0, '', '', 1, 611575, 0),
(287, 'Shirley', 'Rocha', 'sjr0115@gmail.com', '3479771733', 'Idontno21!', 0, 733876, '2016-07-05 20:58:04', 'user-profile.png', '3d33d5a1c657eb83924dff96325a978756e9666d92a5e13f379282b0b1a5fb40', 0, 0, 0, '', '', 0, 143720, 0),
(288, 'Kirstin', 'Smith', 'kirstinsmith1420@gmail.com', '3105910707', 'Tonette01!', 1, 981305, '2016-07-05 21:30:08', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 897034, 0),
(289, 'Dafanie', 'Chikumo', 'jolea21@yahoo.com', '7708829565', 'Please88!', 1, 982980, '2016-07-05 21:39:33', 'user-profile.png', 'dSW-uh6SpB8:APA91bFx9as6F80jNzbbLiaHA3ppJqGwlLCwZA1lf1K6GXHbBFYG9f0SOzDV6ikAURHMS3RaDdg5QwgNA7i75ak4UzYfngLj6qdEKm0a3ZuYzFK9g-Q-j8kEuGFLzRz3JoiSlIxzTGWj', 1, 0, 0, '', '', 1, 338818, 0),
(290, 'Roxie', 'Lewis', 'roxiedlewis@gmail.com', '6616749056', 'Love1family#', 1, 364175, '2016-07-05 21:47:25', 'user-profile.png', 'euyjj2FsFfg:APA91bHWh3MuOw2_ELVxia0dYhlbmTksl3SvTIlg1OiDxP5xhRm_LeW9oYS1F4gJE0qQ_L2Rsp4LQrHqdrSMdTmr4aH_wSTBhjSuI-OMiJikGyJ2jhg2pgcPZ0uqJbCK1mozVft6iuyR', 1, 0, 0, '', '', 1, 442187, 0),
(291, 'Robin', 'Coleman', 'rcoleman1218@gmail.com', '6786700360', 'Rlc2982801#', 1, 524942, '2016-07-05 23:23:51', 'user-profile.png', 'eySK2I7M1Hs:APA91bFPE1oCrSux2DreTU_IQvz5u1KFGdwUlYWk8jhK6lDWD30fyhhfXkRq-QVNCuBOyVoqep6vXZ15WUiGdm0EvqTel3AkzSbCa8TBPp96F1fSN8abCnPsBMB8CjnFL7AfK70Q1net', 1, 0, 0, '', '', 1, 909311, 0),
(292, 'Teresa', 'Brown', 'tree866@gmail.com', '4049529687', 'Boldness#16', 1, 739000, '2016-07-05 23:42:48', '1467762869330.jpg', '383903216e2cf117cb4255ab27b4947e304886bd468a1802d0ae282d9b4d7843', 0, 0, 0, '', '', 1, 732268, 0),
(293, 'Parasia', 'Cook', 'parasiac@gmail.com', '6784994324', 'Lovesgod12$', 1, 124297, '2016-07-05 23:56:17', 'user-profile.png', 'dXy2_4guH-U:APA91bG5bRpWbTjHwesEtmK0YhjfRC0ny07D7RAeSEbnUj_eDdtpReHHUl4I0CWDyq8vn9mAtVgVfAgLb3ciZj33unrO16068FyklJRWcU3ECM7A0-E0HI_SlE4v0rDK0gXBKcA_WQng', 1, 0, 0, '', '', 1, 430525, 0),
(294, 'Brincisky', 'Quinonez', 'brincisky@gmail.com', '3476846243', 'Bloo1234!', 1, 344002, '2016-07-06 04:11:39', 'user-profile.png', '1fd6bdbb64a3bcc5db709e570af0c00519d83fa2ba24f4c8448b31aece685141', 0, 0, 0, '', '', 1, 241551, 0),
(295, 'Kibwei', 'Mckinney', 'kibweim@gmail.com', '2022564753', 'SaAj312725!', 1, 238591, '2016-07-06 04:54:37', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 110700, 0),
(296, 'Darshea ', 'Allen', 'darsheaa@gmail.com', '6785166504', 'Sincere1!', 0, 802229, '2016-07-06 05:11:00', 'user-profile.png', 'dy74663LFZY:APA91bEak8t6-FwV-IJg9R86vT1NL4kt2-86Z-kQq7MVrQnhWABfizwaCxcY-aeoA7N46fEjiV0uBv-UO_BSTUJSgX7bP5Q75eyuj0AylamC1co39iHKO1QT3BCnimOc7KPUa1XhXb_2', 1, 0, 0, '', '', 0, 560732, 0),
(297, 'Tara', 'Sazegar', 'tsazegar40@gmail.com', '3103876275', 'Tvproduction@15', 1, 730074, '2016-07-06 05:33:55', 'user-profile.png', '6672c48ad3de05ec273eccb668ee677b54dd01e35b2218fc4397af105a88de3a', 0, 0, 0, '', '', 1, 413899, 0),
(298, 'Jessica', 'Braunstein', 'jsbraunstein1@gmail.com', '5163828705', 'Jb121151!', 1, 311098, '2016-07-06 05:47:45', 'user-profile.png', '71c2af5223a3f0365571284be2a6efbfc01dd9cbd156d0b47e2dda04a0a02b1b', 0, 0, 0, '', '', 1, 218843, 0),
(299, 'Rebecca', 'Clouse', 'beccaclouse@gmail.com', '9166072043', 'Fightfire1!', 1, 626622, '2016-07-06 09:25:41', 'user-profile.png', 'a78e4523e670f9c2a5c37e4a43831801d2475f5d41628fcc2344178100c99de3', 0, 0, 0, '', '', 1, 789475, 0),
(300, 'Tyneshia', 'Pitts', 'tyandnas@gmail.com', '7064617790', 'Antanasia8$', 1, 536647, '2016-07-06 09:30:33', 'user-profile.png', 'fmMzJxEDpDs:APA91bF5kmPpS3niN5AjR4Xx7Cbe29ZwZT6zBi2iFJ4d-3iim9wH8ofG9vuS2fwaSwprXzvDcK2Gb3sNxD5Mm0xqvxZrZ4x_jWYlx4LufYQjaqKajUydC_phzAsM3IbCc6-k8rGeN-Ny', 1, 0, 0, '', '', 1, 257324, 0),
(301, 'Ashley', 'Amarante', 'ashleya0730@gmail.com', '3475069691', 'July301995*', 1, 491209, '2016-07-06 16:06:30', 'user-profile.png', '49091b0e36c4f12f7aa7c31104540de2ea01b18eda66ff0100492298fd16c21d', 0, 0, 0, '', '', 1, 470130, 0),
(302, 'Star', 'Davis', 'stardavis8@gmail.com', '7062063919', 'I*likepie7', 1, 298743, '2016-07-06 16:15:49', 'user-profile.png', '4eb9be953fffd3607d1a3da2044485582fbb111fc44dc13cf4d818bb9dbc91b1', 0, 0, 0, '', '', 1, 478215, 0),
(303, 'Shakeshia', 'Cole', 'shakeshiac1@gmail.com', '7737260802', 'shakeC11!', 1, 145210, '2016-07-06 17:58:02', 'user-profile.png', 'c6diyZLjmpA:APA91bH0sdeLb8wXbzOw2idiavcfEtHKI98PN7ujlckekbLMkTABMKP1ZDLvLDUFpdBNPp1nn6BhVSdac3d2hSmjE6cwEnNp03iOLgXSOsmhz-v7LGuy7Xy2ueP3fhPKkSXxnNUC-FNm', 1, 0, 0, '', '', 1, 618122, 0),
(304, 'Arian', 'Sanders', 'asanders5138@gmail.com', '9122282051', 'Omega0319#', 1, 389544, '2016-07-06 18:14:26', '1467829439209.jpg', 'b0019caab399ed2aeab1d2bf564498285cea0e185ac50a7ff8c8d8d750603a15', 0, 0, 0, '', '', 1, 455424, 0),
(305, 'Kiana', 'Sledge', 'kianadionee@aol.com', '7188254729', 'Asaprocky17$', 1, 818026, '2016-07-06 18:24:47', 'user-profile.png', 'ce6a52f1b8beeaa5446e136dce8abbaab217064b6c80af57e1dc6bd4f51b5ec1', 0, 0, 0, '', '', 1, 159894, 0),
(306, 'Tanner', 'Akman', 'tanner.akman@gmail.com', '3109209612', 'Gamespot1!', 1, 114321, '2016-07-06 19:13:14', 'user-profile.png', 'dKhOo-Kd2SA:APA91bEy-_4PiHEfGJ2U4rwp08iazSMEQLA0HIizg0kl2ORTeYArtNFlU8InRrLt1uNV-S5RM50ccMQRi-z0xZSefPlOeR4puthDQMeeE48foxIGYVkkLSH8WER6pL4POQgLU_-6S4KA', 1, 0, 0, '', '', 1, 162190, 0),
(307, 'Jacqueline', 'Diaz', 'diaz.jackie78@gmail.com', '6193095286', 'HustleQ@1', 1, 262343, '2016-07-06 19:43:34', 'user-profile.png', '6e5614252a15e1abaf2c8463c2a70af370102d3f4ecae82d08a4a95d2c516f36', 0, 0, 0, '', '', 1, 261735, 0),
(308, 'Janequa ', 'Johnson ', 'janequanixon4@yahoo.com', '4049075860', '$Almostfamous1', 1, 689719, '2016-07-06 22:55:40', 'user-profile.png', 'cdUPXZGAETc:APA91bHcJ_AXDVo_p0CjCEnMXAw1LkZB85s6gEh_ZEjk7y9sdkmiZuqQEqEXwPTA_zMqre902-P4FOmDkkRBaA288F0klbRqqflVlH7qrby2noFTkDD4KjwFq2ddEtQ1IYCc6UqX-hlZ', 1, 0, 0, '', '', 1, 541345, 0),
(309, 'Tetrianna', 'Beasley', 'tetriannas@gmail.com', '4046808694', 'Omarion1!', 1, 191560, '2016-07-06 23:41:03', 'user-profile.png', 'f1c43aec82638ea1e927a32d95b731cbe0218ccec2e6501ac648ee55c40ef002', 0, 0, 0, '', '', 1, 227081, 0),
(310, 'Janel', 'Wallace', 'jjwallac@aggies.ncat.edu', '9803228502', 'Jjwa9081!', 1, 202286, '2016-07-06 23:55:10', '1467849756159.jpg', 'c0tD-1Ca0Ao:APA91bFG_usRF5cxyiQRl---YqZnkmOvHPJlMWNp3uKiTJdcfv5DEtA7vjsF4gIBxXyfStYCqes2tR62_se31t7bgQQkkaIJZqnec_A4PzC_vaRF3mmw8alBF6M_Z3AxiF2DbV5TVl24', 1, 0, 0, '', '', 1, 806971, 0),
(311, 'Alex', 'Junior', 'alexbadine1@yahoo.com', '3477755975', 'Badine123$', 1, 343333, '2016-07-06 23:59:14', 'user-profile.png', '82dab30d5fafda14a9529035d33ba5a498c8d2ef644bb3ba2b08de0476567d72', 0, 0, 0, '', '', 1, 627977, 0),
(312, 'Carmen', 'Echeverria', 'ecarmen99@yahoo.com', '3238757411', 'Carmen123!', 1, 942818, '2016-07-07 00:19:28', 'user-profile.png', '4bc4111bd840001df1d82877de5767bb0517fe4633e5234f628f7e59fefbbd9e', 0, 0, 0, '', '', 1, 623843, 0),
(313, 'Brandon', 'Lowmark', 'lowmarkb123@gmail.com', '5703509005', 'Pencil12&', 1, 452382, '2016-07-07 00:40:55', 'user-profile.png', '824ba3d3b82cb88621aa7c6421d601782ce3c062b79f5660f269067f3406d14a', 0, 0, 0, '', '', 1, 885956, 0),
(314, 'Ibinka', 'Stone', 'fullfigureblackbarbie@gmail.com', '9013149946', 'Sade1986$', 1, 223943, '2016-07-07 02:25:22', '1467859032684.jpg', 'cL6u4WOdCJo:APA91bFDStL-mqLpvFOqLCD4bzcCpqwF9vGTXatmYVjXxpgz6quygouU62oF0-DoLb2pKqAsxc-I2AgZrRxF7FfizjM3H5nv_zP-xwoqxqNiV55Z4GMt3iPTh9XVWJ6gDBnbl5r1V-Vd', 1, 0, 0, '', '', 1, 798493, 0),
(315, 'Diogenes', 'Dejesus', 'diogenesdejesus1995@gmail.com', '3474916064', 'LILcoco188!', 1, 380066, '2016-07-07 03:00:20', 'user-profile.png', 'eA3ztT4ADsk:APA91bF7OjbhyX461adhQEr1t6gp7xhbi-xIUlno8TW03jWnyVkcbePqtdXfPmCbyVrUyf81q0ihcWmumBWekeLP0Al4NUREw1Idm2xHq_Ix0gDoixzmuTHul1F250zH2KAz_9APg55O', 1, 0, 0, '', '', 0, 418789, 0),
(316, 'Juan', 'Ramos', 'juanramos285@gmail.com', '3473394119', 'Ramos1125!', 1, 431569, '2016-07-07 04:32:16', 'user-profile.png', 'fEYBhQNWWVI:APA91bGzpTG_WlzcgWKPnTnYrCBHqfMuuwy_4rjXpDPpVzW3masa4fXQWFLFnOYwY9UElWdUx-4TFLD1TLH1H4TqgbB-4ArPPn_3q__8PDGU0MBUxIa3ttbLKwSl66mE08IjqGl3c0Hh', 1, 0, 0, '', '', 1, 573466, 0),
(317, 'Vanessa', 'Lemaistre', 'vanessadiane7@gmail.com', '3236312434', 'Batman217!', 1, 766867, '2016-07-07 07:24:11', 'user-profile.png', 'fe2d87a04741d6a90330266f38772f8b7b24091027eff4ba1591bded18cb4b3b', 0, 0, 0, '', '', 1, 488822, 0),
(318, 'Nina', 'Blake', 'ninasimone.mb@gmail.com', '9145229912', 'Aninenomi$3', 1, 435186, '2016-07-07 11:39:13', 'user-profile.png', '4fc12fa22125ee4d022561e3cb52186f5968ebeb6d094dd2c44a9e1089feb50d', 0, 0, 0, '', '', 1, 934636, 0),
(319, 'Niyan', 'Richardson', 'niyanrdson@gmail.com', '3479251526', 'Aneiya27!', 1, 226367, '2016-07-07 12:25:47', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 304669, 0),
(320, 'Meaghan', 'Mcleod', 'meaghan.mcleod@yahoo.com', '9144717382', 'Infinitebones1!', 1, 969923, '2016-07-07 13:22:24', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 276727, 0),
(321, 'Jassiah', 'Mcnulty', 'jassiah96@gmail.com', '9147519937', 'Siah1234!', 1, 531845, '2016-07-07 17:10:38', 'user-profile.png', '1e03f4f5fe89a2c76e1f00d970badba795e87916f897b72aab4ed05b90a5c808', 0, 0, 0, '', '', 1, 456782, 0),
(322, 'Liqun', 'Cai', 'cailiqun123@gmail.com', '8053589458', 'Cailiqun111!', 1, 955140, '2016-07-07 17:23:10', 'user-profile.png', '3ac37d56c8a05e83317d512d1451aa0c83707d87f500fa82f19434653f9d83b5', 0, 0, 0, '', '', 1, 969850, 0),
(323, 'Priya', 'Bond', 'bondpriyabond@gmail.com', '8157157079', 'Acting3!', 1, 751511, '2016-07-07 19:41:42', 'user-profile.png', '47ef063a0d24161d186587c1fef0be7fbd1251dbb94664f826b938f2671ee682', 0, 0, 0, '', '', 1, 170876, 0),
(324, 'Anjanette', 'Woods', 'anjanetteceo@aol.com', '3235612151', 'Getmoney91!', 1, 650658, '2016-07-07 20:14:15', 'user-profile.png', 'ac627617ffd4d8c3284608e475deb20fae01660c52e10142f51e7091aad159c6', 0, 0, 0, '', '', 1, 869132, 0),
(325, 'Brittany', 'Louis', 'louisbrit1990@gmail.com', '7329771177', 'Couture90!', 1, 875839, '2016-07-07 22:20:10', 'user-profile.png', '2a834e07205b143cd74a4ed5234a92a33c688b619a78c9217e8f47bd99978c2c', 0, 0, 0, '', '', 1, 273178, 0),
(326, 'Phil', 'Zaikovatyy ', 'pzaikovatyy@yahoo.com', '8186212531', 'Irina280!', 1, 600128, '2016-07-07 22:23:21', 'user-profile.png', 'fUBseVCBY9w:APA91bFBMgZOErrcaaFb-PAnTim2XaIrlk8xm4gVM_FOYOPjYJ-MFyNodfSTfMja19AKojDfhSQq3r52jPKWa-zJmgPRZJfwdJcwHsy838mleYKi15f3VDKsXngmQ_dJu2scufZ3jm48', 1, 0, 0, '', '', 1, 931668, 0),
(327, 'Shuneka', 'Andrews', 'shuneka.andrews@gmail.com', '4045429503', 'Junebug@89', 1, 163346, '2016-07-08 01:27:28', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 301344, 0),
(328, 'Ivy', 'Ayling ', 'ivy.ayling@gmail.com', '3474441071', 'Goldlabel1!', 1, 100647, '2016-07-08 02:49:47', 'user-profile.png', 'evXxotpoQ7M:APA91bGUV6dOqOVV5HLn6fxCu6mJbyhHACBnmBbxpM3ITbAW9vrkOxRMmhS9S9AZmEuoNfptmRCA5XlVWJmTZ7IEzDreNkdoCl6wT_QXyFOF4Y-M1k4WTihU_1jsTpJxZ760Hgq4kt7_', 1, 0, 0, '', '', 1, 136230, 0),
(339, 'ishani', 'shah', 'lanetteam.ishani@gmail.com', '9429796373', '585567ba43ff0d73e254728ec98a4cc2', 1, 415453, '2016-07-08 09:46:27', 'user-profile.png', 'fs-T7YFmZM4:APA91bG_xQU4224jLDFTS-nJTox3Oi5UXYv3lpS4aBDwqWUSNP-DntzBThMy0SKNLnKq8jDmlqvsS8ZztNQQ0teaNIoQKuo-XyIQQEYj3aXILznVRi4CyHV1da49C0e2Q1yNfZe66kJ1', 1, 0, 0, '', '', 1, 640898, 0);

-- --------------------------------------------------------

--
-- Table structure for table `userCard`
--

DROP TABLE IF EXISTS `userCard`;
CREATE TABLE IF NOT EXISTS `userCard` (
`userCardId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `cardNumber` int(11) NOT NULL,
  `cardToken` varchar(255) NOT NULL,
  `stripeCustomerAccount` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userCard`
--

INSERT INTO `userCard` (`userCardId`, `userId`, `cardNumber`, `cardToken`, `stripeCustomerAccount`) VALUES
(1, 1, 4242, 'tok_18AemjFPPcEdaZL8RS6rjEW3', 'cus_8RXsS0g3uozXSc'),
(2, 2, 4242, 'tok_18AfD8FPPcEdaZL8u3kFrnh7', 'cus_8RYJrDrcx7Eyxi'),
(3, 5, 4242, 'tok_18S33fFPPcEdaZL8g0ulJ3jE', 'cus_8RZQ5ejN8CRkVk'),
(4, 7, 4242, 'tok_18BD4eFPPcEdaZL8aK9A6FJp', 'cus_8S7JDOPgPIYP8m'),
(5, 6, 4242, 'tok_18BHVPFPPcEdaZL8YfrRjDBN', 'cus_8SBssB9YPve2od'),
(6, 8, 4242, 'tok_18C5w8FPPcEdaZL8uxM2BHug', 'cus_8T200vTYt887GA'),
(7, 12, 9936, 'tok_18EiJQJxXxi1ARvC8YA5Oglz', ''),
(8, 14, 3015, 'tok_18Gf5FFPPcEdaZL8jxOwIlJA', ''),
(9, 19, 4242, 'tok_18GvbuFPPcEdaZL8f9R8hMpN', ''),
(10, 22, 4242, 'tok_18HcFrFPPcEdaZL8e3ne9dub', ''),
(11, 18, 4993, 'tok_18TPfvJxXxi1ARvCUKBLoNC0', 'cus_8kvXrtLwIdKUC9'),
(12, 33, 4242, 'tok_18KxsrFPPcEdaZL8c2Ehj2HF', ''),
(13, 59, 604, 'tok_18L041FPPcEdaZL8JjplkRrC', ''),
(14, 63, 9855, 'tok_18LwrpFPPcEdaZL8Fv8uwbZT', ''),
(15, 64, 9501, 'tok_18LxVDFPPcEdaZL8xymks8jv', ''),
(16, 77, 1751, 'tok_18ML3GFPPcEdaZL8jnwr7J8n', ''),
(17, 117, 3015, 'tok_18N6YbJxXxi1ARvClAg38ClU', 'cus_8ePNYIbKPMB11e'),
(18, 120, 9212, 'tok_18NBVlFPPcEdaZL8n4bNwKIh', ''),
(19, 98, 1284, 'tok_18NCMaFPPcEdaZL8fEGLxCiE', ''),
(20, 67, 4242, 'tok_18TdiSJxXxi1ARvCxaz92bqG', 'cus_8jhy6aNHj4Nwdy'),
(21, 16, 3691, 'tok_18NVssFPPcEdaZL80Kx3gtHF', ''),
(22, 147, 2719, 'tok_18OT9rFPPcEdaZL8JprC2XKw', ''),
(23, 188, 4993, 'tok_18P1JMFPPcEdaZL8zAigF6BD', ''),
(24, 17, 4993, 'tok_18P1egJxXxi1ARvCXcvWfdUE', 'cus_8gORau5YbRJ55m'),
(25, 156, 5739, 'tok_18P5r1JxXxi1ARvCK3zWkVXK', 'cus_8gSmZUXlA8xRng'),
(26, 205, 4242, 'tok_18ToPRJxXxi1ARvCSgzcMCxT', 'cus_8lL41Gp8rWqjGK'),
(27, 210, 4472, 'tok_18PbroFPPcEdaZL8ZkzTEg1a', ''),
(28, 209, 844, 'tok_18PcW8FPPcEdaZL8g8SGMoJV', ''),
(29, 166, 3018, 'tok_18QH22FPPcEdaZL8fTnPMhcn', ''),
(30, 236, 4993, 'tok_18QqlmFPPcEdaZL8WLR3Btbj', ''),
(31, 239, 3015, 'tok_18SFbXJxXxi1ARvCzyFvJdfd', 'cus_8jj3T72fy7o2nU'),
(32, 123, 4423, 'tok_18RQmYFPPcEdaZL8PfzYoB7l', ''),
(33, 245, 4993, 'tok_18ShcUFPPcEdaZL8MCyU5GWp', ''),
(34, 223, 8066, 'tok_18RpaEFPPcEdaZL8cHSdu3zx', ''),
(35, 4, 4242, 'tok_18S2cZFPPcEdaZL89RsfhioX', 'cus_8jVdGbCCHks3ho'),
(36, 54, 3902, 'tok_18Sy0VFPPcEdaZL8wf12oBbA', ''),
(37, 253, 4993, 'tok_18TyavFPPcEdaZL8hdQGEpBZ', ''),
(38, 268, 7666, 'tok_18TyyqFPPcEdaZL8MPfXIUs7', ''),
(39, 322, 7697, 'tok_18UgFvFPPcEdaZL841P9gxXQ', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `qProvider`
--
ALTER TABLE `qProvider`
 ADD PRIMARY KEY (`qId`);

--
-- Indexes for table `qRequest`
--
ALTER TABLE `qRequest`
 ADD PRIMARY KEY (`qRequestId`), ADD KEY `qrequest_ibfk_1` (`userId`);

--
-- Indexes for table `qRequestAccept`
--
ALTER TABLE `qRequestAccept`
 ADD PRIMARY KEY (`requestAcceptId`);

--
-- Indexes for table `qRequestBillImages`
--
ALTER TABLE `qRequestBillImages`
 ADD PRIMARY KEY (`billImageId`), ADD KEY `qRequestId` (`qRequestId`);

--
-- Indexes for table `requestSentToQ`
--
ALTER TABLE `requestSentToQ`
 ADD PRIMARY KEY (`notificationId`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
 ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `stopDetail`
--
ALTER TABLE `stopDetail`
 ADD PRIMARY KEY (`stopDetailId`,`qRequestId`), ADD KEY `qRequestId` (`qRequestId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `userCard`
--
ALTER TABLE `userCard`
 ADD PRIMARY KEY (`userCardId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `qProvider`
--
ALTER TABLE `qProvider`
MODIFY `qId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=221;
--
-- AUTO_INCREMENT for table `qRequest`
--
ALTER TABLE `qRequest`
MODIFY `qRequestId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=400;
--
-- AUTO_INCREMENT for table `qRequestAccept`
--
ALTER TABLE `qRequestAccept`
MODIFY `requestAcceptId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `qRequestBillImages`
--
ALTER TABLE `qRequestBillImages`
MODIFY `billImageId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `requestSentToQ`
--
ALTER TABLE `requestSentToQ`
MODIFY `notificationId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=947;
--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `userId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=340;
--
-- AUTO_INCREMENT for table `userCard`
--
ALTER TABLE `userCard`
MODIFY `userCardId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
