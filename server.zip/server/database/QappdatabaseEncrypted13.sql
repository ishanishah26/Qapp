-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u1build0.15.04.1
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jul 13, 2016 at 06:41 PM
-- Server version: 5.6.28-0ubuntu0.15.04.1
-- PHP Version: 5.6.4-4ubuntu6.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `finalQapp`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`test`@`%` PROCEDURE `cancel_Request`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE t1 INT;
	DECLARE t2 INT;
	IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 2) THEN
		SELECT TIMESTAMPDIFF(MINUTE, (SELECT acceptDate from qRequestAccept where qRequestId = r_requestId), NOW() ) into t1;
		IF(t1 < 3) THEN
			select 'time < 180' as msg;
		ELSE
			select 'cant cancel' as msg;
		END IF;
	ELSE 
    IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 3) THEN
    select 'Cannot cancel the request. It is already completed.' as msg;
    ELSE
			select 'canceled' as msg;
			update qRequest set requestStatus = "4", cancelDate = NOW() where qRequestId = r_requestId;
		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);
        END IF;
	END IF;
END$$

CREATE DEFINER=`test`@`%` PROCEDURE `changeProfile_Email`(IN `id` BIGINT, IN `new_email` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	IF EXISTS (select userId from user where email = new_email) THEN
		select 'exists' as msg;
	ELSE 
		select 'not exists' as msg;
    	UPDATE user SET passcode = random, isEmailVerified = "0", changedEmail = new_email WHERE userId = id;
		select firstName from user where userId = id;
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `change_Email`(IN `id` BIGINT(20), IN `new_email` VARCHAR(100), IN `random` INT)
    NO SQL
BEGIN
	IF EXISTS (select userId from user where email = new_email) THEN
		select 'exists' as msg;
	ELSE 
    	UPDATE user SET email = new_email, passcode = random WHERE userId = id;
		select 'update' as msg;
		select firstName from user where userId = id;
	END IF;
END$$

CREATE DEFINER=`test`@`%` PROCEDURE `confirmCalcel_Request`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 2) THEN
		
		select 'canceled' as msg;
        update qRequest set requestStatus = "4", cancelDate = NOW(), fine = "5" where qRequestId = r_requestId;
		update qRequestAccept set isConfirmedByQ = "2" where qRequestId = r_requestId;
		SELECT qRequestAccept.qId, qProvider.userId, qRequest.requestVerb, qRequest.requestNoun, user.deviceToken, user.deviceType
		FROM qRequestAccept
		INNER JOIN qProvider ON qRequestAccept.qId = qProvider.qId
		INNER JOIN qRequest ON qRequestAccept.qRequestId = qRequest.qRequestId
		INNER JOIN user ON qProvider.userId = user.userId
		WHERE qRequestAccept.qRequestId = r_requestId;
		select stripeCustomerAccount from qRequest qr join  userCard uc on qr.userId = uc.userId where  qRequestId = r_requestId;
		
		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);

	ELSE
		select 'canceled' as msg;
        select stripeCustomerAccount from qRequest qr join  userCard uc on qr.userId = uc.userId where  qRequestId = r_requestId;
        		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);


	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `confirm_Request`(IN `r_qRequestId` BIGINT)
    NO SQL
BEGIN
	DECLARE amt float(9,2);
    
    	IF EXISTS (select * from qRequest where qRequestId = r_qRequestId and requestStatus = "4") THEN
					select 'Request Already Cancelled. You cannot complete it.' as msg;

        
       	Else
    
	UPDATE qProvider,qRequestAccept SET qRequestAccept.isConfirmedByQ = 1, qRequestAccept.requestCompletionDateTime = NOW(), qProvider.TotalRequestCompleted = qProvider.TotalRequestCompleted + 1  WHERE qProvider.qId = qRequestAccept.qId AND qRequestId = r_qRequestId; 
	UPDATE qRequest SET requestStatus = "3" WHERE qRequestId = r_qRequestId;
    
    Select sum(billAmount) into amt from qRequestBillImages where qRequestId = r_qRequestId group by qRequestId; 
    
	SELECT qRequest.currentLat, qRequest.currentLong,qRequestAccept.receiptTotalBill, qRequestAccept.milesTransported, qRequestAccept.acceptDate, qRequestBillImages.billImage, qProvider.qId, qProvider.firstName, qProvider.lastName,
	qProvider.qStripeId, qRequest.requestVerb, qRequest.requestNoun, user.firstName as u_name, user.email, user.deviceToken, user.deviceType,amt,
	qRequest.isTransport, quser.userProfile
	FROM qRequestAccept 
	LEFT JOIN qRequestBillImages ON qRequestAccept.qRequestId = qRequestBillImages.qRequestId
	INNER JOIN qProvider ON qRequestAccept.qId = qProvider.qId
	INNER JOIN qRequest ON qRequestAccept.qRequestId = qRequest.qRequestId
	INNER JOIN user ON qRequest.userId = user.userId
	LEFT JOIN user quser ON qProvider.userId = quser.userId
	WHERE qRequestAccept.qRequestId = r_qRequestId;
	
    Update qProvider set isPerformingRequest=0 where qId = (select qId from qRequest where qRequestId =r_qRequestId);
    
	SELECT userCard.userId , userCard.cardNumber, userCard.stripeCustomerAccount FROM userCard WHERE userId IN(SELECT userId FROM qRequest WHERE qRequestId = r_qRequestId);
    
    SELECT deviceToken AS qDeviceToken, deviceType AS qDeviceType FROM `user` WHERE userId IN ( SELECT userId FROM qProvider WHERE qId IN(SELECT qId FROM qRequestAccept WHERE qRequestId = r_qRequestId));
    
    SELECT stopLat, stopLong FROM stopDetail WHERE qRequestId = r_qRequestId;

	End if;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `create_userCard`(IN `r_userId` BIGINT, IN `r_cardNumber` INT, IN `r_cardToken` VARCHAR(255))
    NO SQL
BEGIN
	IF EXISTS (SELECT userId FROM userCard WHERE userId = r_userId) THEN
		UPDATE userCard SET cardNumber = r_cardNumber, cardToken = r_cardToken WHERE userId = r_userId;
        SELECT cardToken, stripeCustomerAccount, userId FROM userCard where userId = r_userId;
	ELSE 
    	INSERT INTO userCard(`userId`,`cardNumber`,`cardToken`) values(r_userId, r_cardNumber, r_cardToken);
        SELECT cardToken, stripeCustomerAccount, userId FROM userCard where userId = r_userId;
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_Account`(IN `id` BIGINT(20))
    NO SQL
BEGIN
	UPDATE user SET isDeleted=-1 WHERE userId = id;
	IF EXISTS(SELECT userId FROM qProvider WHERE userId=id) THEN
		UPDATE `qProvider` SET `isDeleted`=-1 WHERE userId = id;
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_qProvider`(IN `id` BIGINT(20), IN `curLat` FLOAT, IN `curLong` FLOAT, IN `q_fname` VARCHAR(50), IN `q_lname` VARCHAR(50), IN `q_email` VARCHAR(100), IN `q_zip` VARCHAR(50), IN `q_mobile` VARCHAR(50), IN `q_address` VARCHAR(255), IN `q_city` VARCHAR(50), IN `q_state` VARCHAR(50))
    NO SQL
BEGIN
	DECLARE qProviderId bigint;
	IF EXISTS (select qId from qProvider join user on qProvider.userId = user.userId  where user.IsDeleted=0 AND qProvider.email = q_email) THEN
		select 'exists' as msg;
	ELSE IF EXISTS(select qId from qProvider where userId = id) THEN
		select 'exists' as msg;
	ELSE
    	insert into qProvider(userId,currentLat,currentLong,firstName,lastName,email,address,city,state,zipCode,mobile,registrationStepCompleted) values(id,curLat,curLong,q_fname,q_lname,q_email,q_address,q_city,q_state,q_zip,q_mobile,1);
		select  LAST_INSERT_ID() into qProviderId;
		select 'insert' as msg, qProviderId;
	END IF;
END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qAverageRating`(IN `p_qId` BIGINT)
    NO SQL
BEGIN
	
	IF EXISTS (select qId from qRequestAccept where qId = p_qId) THEN
		SELECT (AVG(speedRating+qualityRating)+4)/3 AS averageRating 
		FROM qRequestAccept 
		WHERE qId=p_qId AND isReviewed=1;
		SELECT u.firstName,u.lastName,qreqa.feedback,qreqa.ratingDate 
		FROM qRequestAccept AS qreqa INNER JOIN qRequest AS qreq 
		ON qreq.qRequestId=qreqa.qRequestId AND qreqa.qId=p_qId AND isReviewed=1
		INNER JOIN user AS u ON qreq.userId=u.userId
		ORDER BY qreqa.ratingDate DESC;
	ELSE
		SELECT 4 AS averageRating;
		SELECT u.firstName,u.lastName,qreqa.feedback,qreqa.ratingDate 
		FROM qRequestAccept AS qreqa INNER JOIN qRequest AS qreq 
		ON qreq.qRequestId=qreqa.qRequestId AND qreqa.qId=p_qId AND isReviewed=1
		INNER JOIN user AS u ON qreq.userId=u.userId
		ORDER BY qreqa.ratingDate DESC;
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_anyThingElse`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT, IN `verb` VARCHAR(255), IN `noun` VARCHAR(255), IN `time` VARCHAR(255), IN `price` VARCHAR(255), IN `requiredNow` INT, IN `requiredDate` DATE, OUT `qRequsetId` BIGINT)
    NO SQL
BEGIN
	insert into qRequest(userId,currentLat,currentLong,requestVerb,requestNoun,qRequiredTime_Hr,qRequiredPayment,isRequiredNow,qRequiredDate,requestStatus) values(id,curLat,curLong,verb,noun,time,price,requiredNow,requiredDate,1);
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 3000;
    	select LAST_INSERT_ID() into qRequsetId;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_anyThingElse_resend`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT)
    NO SQL
BEGIN
	
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 
	having temp < 3000;
    
   update qProvider set LastRequestSent =  now() where qId in (SELECT qId FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 3000);
    
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_HistoryById`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE reimbursementAmount float(9,2);


 Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = r_requestId group by qRequestId; 
	SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.createdDate, qRequest.numberOfStops, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, qRequest.requestStatus,
qRequestAccept.qId,  qRequestAccept.paymentDoneByRequestor AS totalPayment, "16 + 0.20/min" AS baseRate , qRequestAccept.milesTransported , (qRequestAccept.milesTransported*0.20) AS distanceFee, qRequestAccept.paymentDoneByRequestor AS subTotal, qRequestAccept.paymentReceivedByQ AS TotalPaymentToQ , (qRequestAccept.paymentDoneByRequestor-qRequestAccept.paymentReceivedByQ) AS QAdminFee, reimbursementAmount, TIMESTAMPDIFF(MINUTE, qRequestAccept.acceptDate , qRequestAccept.requestCompletionDateTime) AS timeElapsed ,
qProvider.firstName, qProvider.lastName, qProvider.email, qProvider.mobile, user.userProfile, 
stopDetail.stopDetailId,stopDetail.stopLat, stopDetail.stopLong, stopDetail.address 
FROM qRequest LEFT JOIN qRequestAccept ON qRequest.qRequestId = qRequestAccept.qRequestId 
LEFT JOIN qProvider ON qRequestAccept.qId = qProvider.qId 
LEFT JOIN user ON qProvider.userId = user.userId
LEFT JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId 
WHERE qRequest.qRequestId = r_requestId ORDER BY stopDetail.stopDetailId ASC;
SELECT userId, cardNumber FROM userCard where userId IN(SELECT userId FROM qRequest WHERE qRequest.qRequestId = r_requestId);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_HistoryById_ruben_test`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE reimbursementAmount float(9,2);


 Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = r_requestId group by qRequestId; 
	SELECT qRequest.isTransport, qRequest.currentLat, qRequest.currentLong, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.createdDate, qRequest.numberOfStops, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, qRequest.requestStatus,
qRequestAccept.qId, qRequestAccept.mapURL, qRequestAccept.paymentDoneByRequestor AS totalPayment, "16 + 0.20/min" AS baseRate , qRequestAccept.milesTransported , (qRequestAccept.milesTransported*0.20) AS distanceFee, qRequestAccept.paymentDoneByRequestor AS subTotal, qRequestAccept.paymentReceivedByQ AS TotalPaymentToQ , (qRequestAccept.paymentDoneByRequestor-qRequestAccept.paymentReceivedByQ) AS QAdminFee, reimbursementAmount, TIMESTAMPDIFF(MINUTE, qRequestAccept.acceptDate , qRequestAccept.requestCompletionDateTime) AS timeElapsed ,
qProvider.firstName, qProvider.lastName, qProvider.email, qProvider.mobile, user.userProfile, cu.firstName as cFirstName, cu.lastName as cLastName, cu.userProfile as cUserPrifile,
stopDetail.stopDetailId,stopDetail.stopLat, stopDetail.stopLong, stopDetail.address ,
qRequestAccept.receiptTotalBill,  qRequestAccept.paymentDoneByRequestor, qRequestAccept.paymentReceivedByQ, qRequestAccept.requestAmt, qRequestAccept.serviceFeeToQ, qRequestAccept.serviceFeeToUser,
qRequestAccept.MapURL
FROM qRequest LEFT JOIN qRequestAccept ON qRequest.qRequestId = qRequestAccept.qRequestId 
LEFT JOIN qProvider ON qRequestAccept.qId = qProvider.qId 
LEFT JOIN user ON qProvider.userId = user.userId
LEFT JOIN user cu ON cu.userId = qRequest.userId
LEFT JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId 
WHERE qRequest.qRequestId = r_requestId ORDER BY stopDetail.stopDetailId ASC;
SELECT userId, cardNumber FROM userCard where userId IN(SELECT userId FROM qRequest WHERE qRequest.qRequestId = r_requestId);
SELECT * FROM stopDetail WHERE stopDetail.qRequestId = r_requestId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Resend_anyThingElse`(IN `p_qRequestId` BIGINT)
    NO SQL
BEGIN
	SELECT qRequest.qRequestId, qRequest.requestVerb, qRequest.isTransport, qRequest.requestNoun, qRequest.qRequiredPayment, qRequest.qRequiredTime_Hr, qRequest.currentLat, qRequest.currentLong, qProvider.qId, 
    ( 3959 * acos( cos( radians( qRequest.currentLat ) ) * cos( radians( qProvider.currentLat ) ) * cos( radians( qProvider.currentLong ) - radians( qProvider.currentLong ) ) + sin( radians( qRequest.currentLat ) ) * sin( radians( qProvider.currentLat ) ) ) ) AS temp 
    FROM qProvider,qRequest 
    WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = 1 and qProvider.userId != qRequest.userId AND qId NOT IN (SELECT qId FROM requestSentToQ WHERE qRequestId=p_qRequestId ) and isPerformingRequest =0 AND 
    qRequest.requeststatus =1 AND isTransport=0 AND qRequest.qRequestId= p_qRequestId and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 having temp < 3000;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Resend_Transport`(IN `p_qRequestId` BIGINT)
    NO SQL
BEGIN
	SELECT qRequest.qRequestId, qRequest.requestVerb, qRequest.isTransport, qRequest.requestNoun, qRequest.qRequiredPayment, qRequest.qRequiredTime_Hr, qRequest.currentLat, qRequest.currentLong, qProvider.qId, 
    ( 3959 * acos( cos( radians( qRequest.currentLat ) ) * cos( radians( qProvider.currentLat ) ) * cos( radians( qProvider.currentLong ) - radians( qProvider.currentLong ) ) + sin( radians( qRequest.currentLat ) ) * sin( radians( qProvider.currentLat ) ) ) ) AS temp 
    FROM qProvider,qRequest 
    WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = 1 and qProvider.userId != qRequest.userId AND qId NOT IN (SELECT qId FROM requestSentToQ WHERE qRequestId = p_qRequestId ) and isPerformingRequest =0 AND 
    qRequest.requeststatus =1  AND isTransport=1 AND  qRequest.qRequestId=p_qRequestId and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 having temp < 10;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Tranport`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT, IN `verb` VARCHAR(255), IN `noun` VARCHAR(255), IN `time` VARCHAR(255), IN `price` VARCHAR(255), IN `nStops` INT, OUT `qRequsetId` INT)
    NO SQL
BEGIN
	insert into qRequest(userId,currentLat,currentLong,isTransport,requestVerb,requestNoun,qRequiredTime_Hr,qRequiredPayment,numberOfStops,requestStatus) values(id,curLat,curLong,1,verb,noun,time,price,nStops,1);
	select  LAST_INSERT_ID() into qRequsetId;
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 10;
	select LAST_INSERT_ID() into qRequsetId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Tranport_resend`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT)
    NO SQL
BEGIN
	

	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 
	having temp < 10;
    
    update qProvider set LastRequestSent =  now() where qId in (SELECT qId FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 10);

	END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reached_AtStop`(IN `q_RequestId` BIGINT, IN `Lat` FLOAT, IN `c_Long` FLOAT)
    NO SQL
BEGIN
	UPDATE stopDetail SET isQReachedAtStop = "1" WHERE qRequestId = q_RequestId and stopLat = Lat  and stopLong = c_Long ;
	SELECT address FROM stopDetail WHERE qRequestId =  q_RequestId and stopLat = Lat and stopLong = c_Long and isQReachedAtStop = "1";
	SELECT user.userId, user.mobile FROM user INNER JOIN  qRequest 
	ON qRequest.userId = user.userId WHERE qRequestId =  q_RequestId;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `request_Accept`(IN `requestId` BIGINT, IN `qId` BIGINT)
    NO SQL
BEGIN
	IF EXISTS (select * from qRequest where qRequestId = requestId and requestStatus = "2") THEN
		select 'already accepted' as msg;	
	ELSE IF EXISTS (select * from qRequest where qRequestId = requestId and requestStatus = "4") THEN
		select 'request canceled' as msg;	
	ELSE
		Update qRequest set requestStatus = "2" where qRequestId = requestId;
		Update qProvider set isPerformingRequest =1 where qProvider.qId = qId;
		insert into qRequestAccept (qId,qRequestId)	values(qId,requestId);	
		select 'accept now' as msg;
		select qRequest.requestVerb, qRequest.requestNoun, qRequest.isTransport, user.userId, user.deviceToken, user.deviceType from qRequest 
		INNER JOIN user
		ON qRequest.userId = user.userId
		where qRequestId = requestId;
		#select firstName from qProvider where qId = qId;
	END IF;
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `resendOtp_email`(IN `id` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	DECLARE mail varchar(255);
		UPDATE user SET passcode = random WHERE userId = id;
		select email as mail,firstName from user where userId = id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `resendOtp_mobile`(IN `id` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	DECLARE num varchar(255);
		UPDATE qProvider SET mobileVerificationCode = random WHERE userId = id;
		select mobile as num from qProvider where userId = id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `reverse_Confirm_Request`(IN `r_qRequestId` BIGINT)
    NO SQL
BEGIN

	UPDATE qProvider,qRequestAccept 
	SET qRequestAccept.isConfirmedByQ = 0, 
	qRequestAccept.requestCompletionDateTime = 0000-00-00, 
	qProvider.TotalRequestCompleted = (qProvider.TotalRequestCompleted - 1)  
	WHERE qProvider.qId = qRequestAccept.qId AND qRequestId = r_qRequestId; 
	
	UPDATE qRequest 
	SET requestStatus = "2" 
	WHERE qRequestId = r_qRequestId;
    
	-- UPDATE qProvider 
	-- SET isPerformingRequest=1 
	-- WHERE qId = (SELECT qId FROM qRequest WHERE qRequestId =r_qRequestId);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `show_Request`(IN `requestId` BIGINT)
    NO SQL
BEGIN
DECLARE reimbursementAmount float(9,2);
	IF EXISTS (select * from qRequest where qRequestId = requestId and isTransport = "1") THEN
		SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.currentLat, qRequest.currentLong, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.numberOfStops, qRequest.createdDate, user.userId, user.firstName, user.lastName, user.email, user.mobile, user.userProfile, stopDetail.stopDetailId, stopDetail.stopLat, stopDetail.stopLong, stopDetail.address
		FROM qRequest
		INNER JOIN user ON qRequest.userId = user.userId
		INNER JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId
		WHERE qRequest.qRequestId = requestId 
		ORDER BY stopDetail.stopDetailId ASC;	
	ELSE 
		SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.currentLat, qRequest.currentLong, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, user.userId, user.firstName, user.lastName, user.email, user.mobile, user.userProfile
		FROM qRequest
		INNER JOIN user ON qRequest.userId = user.userId
		WHERE qRequest.qRequestId = requestId;
	END IF;
    
        Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = requestId group by qRequestId; 

    
    SELECT paymentDoneByRequestor AS userPayment , paymentDoneByRequestor AS subTotal, paymentReceivedByQ AS TotalPaymentToQ , (paymentDoneByRequestor-paymentReceivedByQ) AS QAdminFee, reimbursementAmount ,
	requestAmt, serviceFeeToQ, serviceFeeToUser, paymentReceivedByQ, paymentDoneByRequestor
	 FROM `qRequestAccept` WHERE qRequestId = requestId;
	SELECT qBankAccountNumber FROM qProvider WHERE qId IN (SELECT qId FROM qRequestAccept WHERE qRequestId = requestId);
END$$

CREATE DEFINER=`test`@`%` PROCEDURE `update_Email`(IN `id` BIGINT, IN `random` INT)
    NO SQL
BEGIN
	DECLARE new_email VARCHAR(100);
	SELECT changedEmail into new_email FROM user where userId = id;
	IF EXISTS (select * from qProvider where userId = id) THEN
		UPDATE user, qProvider SET user.isEmailVerified = "1", user.email = new_email, user.changedEmail = "" ,
		qProvider.email = new_email
		WHERE user.userId = qProvider.userId AND
		user.userId = id AND user.passcode = random;
	ELSE 
		UPDATE user SET isEmailVerified = "1", email = new_email, changedEmail = "" WHERE userId = id AND passcode = random;
	END IF;
END$$

CREATE DEFINER=`test`@`%` PROCEDURE `update_Mobile`(IN `id` BIGINT, IN `random` INT)
    NO SQL
BEGIN
	DECLARE new_mobile VARCHAR(100);
	SELECT mobile into new_mobile FROM user where userId = id;
	IF EXISTS (select * from qProvider where userId = id) THEN
		UPDATE user, qProvider SET user.isMobileverified = "1", user.mobile = new_mobile, user.changedMobile = "" ,
		qProvider.mobile = new_mobile
		WHERE user.userId = qProvider.userId AND
		user.userId = id AND user.mobilePasscode = random;
	ELSE 
		UPDATE user SET isMobileverified = "1", mobile = new_mobile, changedMobile = "" WHERE userId = id AND mobilePasscode = random;
	END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `user_register`(IN `p_email` VARCHAR(255), IN `mobile` VARCHAR(50), IN `password` VARCHAR(50), IN `random` INT, IN `fname` VARCHAR(100), IN `lname` VARCHAR(100), IN `p_image` VARCHAR(255), IN `p_deviceToken` VARCHAR(255), IN `p_deviceType` INT, IN `mobileRandom` INT)
    NO SQL
BEGIN
	DECLARE userId BIGINT;
	IF EXISTS (select userId from user where email = p_email AND isDeleted <>-1) THEN
		select 'exists' as msg;
	ELSE 
    	insert into user(firstName,lastName,email,mobile,password,passcode,userProfile,deviceToken,deviceType,mobilePasscode) values(fname,lname,p_email,mobile,password,random,p_image,p_deviceToken,p_deviceType,mobileRandom);
		select  LAST_INSERT_ID() into userId;
		select 'insert' as msg, userId;
	END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `qProvider`
--

CREATE TABLE IF NOT EXISTS `qProvider` (
`qId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `currentLat` float(9,6) NOT NULL,
  `currentLong` float(9,6) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(5000) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zipCode` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `isMobileVerified` tinyint(4) NOT NULL COMMENT '0 = not varified 1 = verified',
  `mobileVerificationCode` varchar(100) NOT NULL,
  `nameOnDL` varchar(255) NOT NULL,
  `socialSecurityNo` varchar(1000) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `dlNo` varchar(1000) NOT NULL,
  `dlState` varchar(255) NOT NULL,
  `dateOfDlExpiration` date NOT NULL,
  `highSchoolName` varchar(255) NOT NULL,
  `highSchoolCity` varchar(255) NOT NULL,
  `highSchoolState` varchar(255) NOT NULL,
  `highSchoolYOGrad` varchar(255) NOT NULL,
  `hsInfo` varchar(50) NOT NULL,
  `collegeInfo` varchar(255) NOT NULL,
  `totalYearOfProfExp` int(11) NOT NULL,
  `personalAssistantExp` int(11) NOT NULL,
  `roleOfQ` varchar(255) NOT NULL,
  `isStateDisclouserAcknowledged` tinyint(4) NOT NULL,
  `isBackgroundCheckAuthorized` tinyint(4) NOT NULL,
  `isQVerified` tinyint(4) NOT NULL DEFAULT '0',
  `registrationDate` datetime NOT NULL,
  `isQOnline` tinyint(4) NOT NULL,
  `registrationStepCompleted` int(11) NOT NULL COMMENT '1 = first step completd, 2= verification done, 7 =  completed all step',
  `TotalRequestCompleted` bigint(20) NOT NULL,
  `TotalPaymentReceived` float NOT NULL,
  `qBankAccountNumber` varchar(1000) NOT NULL,
  `qStripeId` varchar(100) NOT NULL,
  `qStripeBankTokenId` varchar(100) NOT NULL,
  `qStripeBankId` varchar(100) NOT NULL,
  `isPerformingRequest` int(1) NOT NULL DEFAULT '0',
  `LastRequestSent` datetime NOT NULL,
  `isDeleted` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qProvider`
--

INSERT INTO `qProvider` (`qId`, `userId`, `currentLat`, `currentLong`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipCode`, `mobile`, `isMobileVerified`, `mobileVerificationCode`, `nameOnDL`, `socialSecurityNo`, `dateOfBirth`, `dlNo`, `dlState`, `dateOfDlExpiration`, `highSchoolName`, `highSchoolCity`, `highSchoolState`, `highSchoolYOGrad`, `hsInfo`, `collegeInfo`, `totalYearOfProfExp`, `personalAssistantExp`, `roleOfQ`, `isStateDisclouserAcknowledged`, `isBackgroundCheckAuthorized`, `isQVerified`, `registrationDate`, `isQOnline`, `registrationStepCompleted`, `TotalRequestCompleted`, `TotalPaymentReceived`, `qBankAccountNumber`, `qStripeId`, `qStripeBankTokenId`, `qStripeBankId`, `isPerformingRequest`, `LastRequestSent`, `isDeleted`) VALUES
(1, 1, 21.148766, 72.762474, 'Tilak', 'Jethva', 'lanetteam.tilak@gmail.com', 'a2fe405d97b8dd7bef67cbc37f96f0deadafad4b100e5d8c2a6ba260fd2ce2ad34d13801ad36656d7cdd2e8e42c3037d91gxoLP7TgGg3Z6D31EC6A==', 'surat', 'Connecticut', '79119', '8758504790', 0, '', 'Tilak Ckj Jethva', '221c411cb0e6f806f57c71bc18e7d33202c94dc3053e87a765aa2dda84154f8b627edf46fc1bc97aec9ed87353534c24vlQq9bkPNUD236xzKzsSZg==', '1988-05-13', '3057bbdcb10049d059a556adf25bd6fbe2d63c371a1fc5045fbeebfb6eaacaf2b67b3ac506e8a8ff4b922e7441ef2104UBCaPypY6Gf6OKWiWNnZhA==', 'Arizona', '2014-05-13', '', '', '', '', 'Attended', 'Attended', 5, 5, 'Transport , Anything else', 1, 1, 1, '2016-05-13 06:47:45', 0, 7, 4, 4560, '6789', '', '', '', 0, '2016-06-01 00:44:02', 0),
(2, 2, 37.332333, -122.031219, 'Riken', 'Doshi', 'lanetteam.riken@gmail.com', '6390926dc088b6af6c344591c16fb7e87ec4edeeca7906ea9b2f8340557dfdd428919474593a03585cfbe530b019038esvnSovEiZQ6VN3jEUyupvw==', 'surat', 'Armed Forces Americas', '99501', '9913060874', 0, '', 'Riken Vipul Doshi', '8fe33738794d1284416a8ced92a0015357c39b8ba1817ce6a53d685ec42e9357bde6a19031ea228676bcfb82311b21d0tE3rQvurBQM43jx6HdlMlw==', '1983-05-13', '66e3d5ac8d6e890ed1e3644398af2dfa08d0aa262de81d36e9f6cbae0bb6acb42a15609344431654fd5cacc508b6a9a9RLIQldzOj1gZopxq8grbVA==', 'Armed Forces Americas', '2021-05-13', '', '', '', '', 'Attended', 'Attended', 5, 5, 'Transport , Anything else', 1, 1, 1, '2016-05-13 06:59:28', 0, 7, 3, 9560, '6789', 'acct_18Aex6CEQO8c82kx', 'btok_8RY4nPdMY9y4iB', 'ba_18AeyYCEQO8c82kx9VGIRIhW', 0, '2016-06-01 00:44:02', 0),
(3, 4, 21.148085, 72.760704, 'Tapan', 'Gohil', 'lanetteam.tapan@gmail.com', 'cef561672dc0a2298e562de41ca22f962b46fca564ff6a7a71526d37433674776c8175b318df3fcd5452bb51bb30652fzhUcjZ1BOL4HNMYZK7Zhkw==', 'surat', 'Federated Micronesia', '72201', '9998078073', 0, '', 'Tapan Rajeshbhai Gohil', 'f9eb033bcebe0351bd7787a84554a3a52a2e76640f5e13385eb5c7438b2023361b74ab05d6baca057e7a8a1959952756rT1HNONt+n7JoJ3smNAImw==', '2010-05-13', 'dadedb0c1664ce6c120ae38021f51af85b89be01580ae0a8bd45c40147f155829740833ebc3409027d0c0786e52fc1d37jkOoh9/ds5+xu4V81qYmWCTLQ2D+hsepBuxylox0XQ=', 'Federated Micronesia', '2021-05-13', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 1, '2016-05-13 08:01:49', 0, 7, 24, 185266, '6789', 'acct_18AfziJwcSQT5h5t', 'btok_8RZR0xBqOlvZe6', 'ba_18AgIcJwcSQT5h5tAMjYLq7W', 0, '2016-07-08 02:42:30', 0),
(4, 7, 34.106323, -118.463943, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '6f8a0c3ecc8e66df48c3fa7ad9741e978b623118057eb7468f3b399d2a4a84f5656632d58dd259e3225347f4ef05a406q+gspiqVoshBPbDAKSJp6w==', 'los angeles ', 'California', '90077', '2038879349', 0, '', 'Kimberly Ann Idoko', '463f53d9d5e0f1742742089aea430ec6ad4fd389c670b798a4e02cab9ebfb038bb03b6d438b053d0997c24afde8caf2bCy7UxiBsW5/J8Aw/3CyB9Q==', '1979-05-13', '45cc9531942a20f932e32bc16168774f202dd0b54ab88a307411630e56ca4566ab938683a7b1665a95f0dc7eaf47468fGRmFyb7Bnk+ZIc9K+gzTVA==', 'California', '2018-05-14', '', '', '', '', 'Graduated', 'Graduated', 12, 2, 'Transport,Anything else', 1, 1, 1, '2016-05-14 19:27:51', 0, 7, 5, 0, '1273', 'acct_18GsunLAzuI16PIU', 'btok_8Y1nxDG6fU90kY', 'ba_18GvjZLAzuI16PIUtom5sHKi', 0, '2016-07-07 05:34:30', -1),
(5, 8, 21.148390, 72.760948, 'Test', 'User', 'lanetteam.sajid@gmail.com', '73665e99edd35b6e522a16c49553f2792f75a8bd959632fad4491543b38da376842cc58dc4cbac96bf114de430448b29LRbUus3nU1OWtmBSyYq21g==', 'surat', 'New Mexico', '72201', '9998078073', 0, '', 'Test Android User', '89775b5d59c972aa28d36907ee197b7a51e286f7cda8e7118e8c22b6de9dd9b4293892e697513dcc5b06c7a0316c16c3UTMcN++J+4U7RqK/oiJvHQ==', '1992-05-17', '39fd587168244d4335b88888e0bf561e4d3f9d9e06bc8b5aa8e9f881741bb66faad3f24557dd06593d9f1bd3f2cc6be6/ziFvSge414/sC908jpPjQ==', 'Nevada', '2038-05-17', '', '', '', '', 'Graduated', 'Graduated', 2, 3, 'Transport , Anything else', 1, 1, 1, '2016-05-17 06:04:49', 0, 7, 0, 0, '6789', 'acct_18C61qHqdzl1ODcq', 'btok_8T27o4ZEdqsc22', 'ba_18C62xHqdzl1ODcqesrZkUko', 0, '0000-00-00 00:00:00', 0),
(6, 10, 34.151836, -118.453987, 'Demo', 'User', 'demo@qapp.com', 'f71830c5054588799a287a1cd5f8240221a5f2535dc8bba151b16a5767f77aca4840b7a6e448cd9b8ffeec30e2492d6eQXFxvSVzyk8/Bt5EMVOMEQ==', 'surat', 'Nevada', '72201', '9998887770', 0, '', 'Test Iphone User', '3bf1119b9a3dd4ba098ed5bde347a7f166029b561b3a6fbbb6f0f7f6e1cff6acf5c63490e9e0e66f57eae3b3a30b7c4dwMlm2BwX7AEG+NqP3inWJA==', '1991-05-18', '2683757ed2865ce2b798e701ccbb73e63a27ebe4473113de0e8f6f600bea074b86bdca3fffe6dcee433605a8e86d9a8cdTASGATA6S1yLnq5X1StvA==', 'Northern Mariana Islands', '1993-05-18', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 1, '2016-05-18 06:32:00', 0, 7, 0, 0, '', 'acct_18CSuxGbOmsFu2tW', '', '', 0, '0000-00-00 00:00:00', 0),
(7, 12, 19.387493, -99.209747, 'Cristian ', 'Try', 'lokinenuco@gmail.com', 'f8131f6ab6288c7f801a9dd41e5c6b0e90881852dd494e551b283431a3dca98537153a0a0b069877db6f622090bec41bSDUxItH2BB4XlOitShjSxQ==', 'El paso', 'Texas', '79912', '9153556813', 0, '', '', '138ae851e7b53da3c16456bf5700773629f25f9c4f7dfc44fa157496c9bb133485c70242b422157e413d954ea3301be6Bu9XS7bfLZl/O46VxxhYqg==', '0000-00-00', '62d7d2a6c3e2b4ba242e84d169dfe53db426916af76745267eb5d8a196132123a9c964fc13edc65e4837c3e674e7f520g20diEQAS7Ly6vmL0YE2hg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(8, 14, 34.106091, -118.463913, 'Felix', 'Odigie', 'felix@myqapp.com', 'c603b68bc7d4dfd5105fcaafdfdf3ed2c7c1239bf26de2d35dbe4255555f9e0c48a584e3b8cb516dffc4da269cb5eea3P15kL3YcECQPmoSKRajlTg==', 'los angeles', 'California', '90077', '6173881912', 0, '', 'Felix Armstrong Odigie', '7b881f76faffa86e508e3c50c857435267a62b7c5d6b541ae3b4a664f8608a495d1425e30f7c0660eedd32a84a72e1028h0Xkw5J9spTFPuvk0UUDg==', '1976-09-30', '83119cc94717a6b9d3ec91ac3d9ea6d327d36f950a797e829a91e9aeff8b234b44eb56df8e860b77a66035c8a2ce3d0dtJUuwd5uFNHiRaFLaFlWWg==', 'California', '2020-10-01', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport,Anything else', 1, 1, 0, '2016-05-29 21:09:02', 0, 7, 0, 0, '1912', 'acct_18GsufB2LZy7CiFA', 'btok_8XzoopMPMQB73D', 'ba_18GtoYB2LZy7CiFAcljMaM5w', 0, '2016-07-07 05:34:30', 1),
(9, 17, 34.106194, -118.463921, 'Kevin', 'Robinson', 'thomas77607@aol.com', 'f4b59420ce4c87438f290b9a36355ee0ec48d4d6ac84595b79533d58dc84bb0f8eaf701c8cf08ee46c9a1a42457bfaa2wcjlc8nOtvsFB4v7vi8lvJwcQzYAGZN4XzyuAb30PzA=', 'Los  Angeles ', 'California', '90077', '8185197366', 0, '', 'Kevin Varden Robinson', 'b91dc22e485e7061f6b8c6db7e75aaee210207837ae6ec732916ddd3907f12510b3d9f79aa2e74f0f403e0e8dd0f31d1lSucXyRECOqBPJCCmQSV+g==', '1956-05-23', '0f0d1d1a733d3e7f62bcbec0b1c73a8f36b5c1dff4b6a08041488049c98568647a0610749d4f48c6588a90317c8ab02cKZGp6BUdyYhjmLN5YWwxzQ==', 'California', '2019-05-23', '', '', '', '', 'Graduated', 'Attended', 25, 5, 'Transport', 1, 1, 1, '2016-05-30 12:51:34', 0, 7, 5, 0, '9934', 'acct_18Gub1JTf5hIBqmy', 'btok_8ZwwTzv97Hb8Fa', 'ba_18In2pJTf5hIBqmyjyQKFP5T', 0, '2016-06-29 10:21:17', 0),
(10, 16, 34.106140, -118.464005, 'Felix', 'Odigie', 'felix.odigie@gmail.com', 'd786308fb7a53533e80090761c9c79d6613f572662d64cba350aa90141f3545a33d8917c4ef3157ada5cbbb4c7a8a783k8oSDAoSagp6LmMV2I2digBWVLJyl/zj3gL7+4Tswhk=', 'Los Angeles ', 'California', '90077', '6173881912', 0, '', 'Felix Odigie Odigie', 'f4ba01a6bd295b0f0945e5534993b9bd46b8c69f2eef8f995713b56c683522b8f3564b6721ef7f92e805bf977b914730M/aEoOnvOThlNU0TBIJq5w==', '1976-10-01', '1b92f92519787a700c85b2d144da2552f263d35a56cdf7448ae79bee69224036f849b6fb0dbb5e8aa75348bb12a04a9fZ1+BVl9cUigp3zYxjQqQSA==', 'California', '2020-10-02', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport , Anything else', 1, 1, 1, '2016-05-30 15:39:09', 0, 7, 2, 0, '1912', 'acct_18GxEOIY5VeKvAum', 'btok_8Y3xmoWa1Us56T', 'ba_18GxprIY5VeKvAumVqSTF0bP', 0, '2016-06-22 01:50:50', 0),
(11, 24, 33.858624, -117.998375, 'Derrick', 'Smith', 'iderricksmithjr@gmail.com', 'ba53ad4b9c2c29c380296f8ac375ff2e9e007328de3293e7d976964d36ccc6248f467db6a8bacea635463bb4f2249219OfmwQOIMoa4TFXTOn+nnR1RhDCBmL0w0Qsd/kkBcfPg=', 'Tracy', 'California', '95376', '2096403224', 0, '', 'Derrick Lynn Smith', 'ac7ccf9f18573e0643e3ce86d85b2a34a4203a8620257175c34b083bc946d238053ea725a35532d44476b713c4467d58gOf9r5oLMduEooux2d8eeg==', '2016-06-05', '07cd650d5379e93225078ebbbbf7566b94fd70cbf3d54c7e84c6c693fd347fdbd4ea791982913263b1db47eda63e9f1dFWJxXAT+NwO71ZqzImvg2w==', 'California', '2019-11-16', '', '', '', '', 'Graduated', 'Attended', 4, 1, 'Transport', 1, 1, 0, '2016-06-06 13:54:16', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(12, 25, 34.045151, -118.279182, 'Ivan', 'Cerezo', 'ivan.cerezo28@gmail.com', 'a20ab5b3618122c9387d469a1428d395acc184e420826601b46264f73181293b2e8728d02030f10e1bf8191eb5023b0777RwPtoaKMs9HyEb+lAsaUEFJEvvfmKTD+Z0Oa/sf1kgUQ/prJjxMlACcQ9CrYnx', 'Los Angeles', 'California', '90006', '3234701069', 0, '', 'Ivan   Cerezo', '8dbe7240749da99cf5c72d100d28a58705ccb983ba00d2cb438be2468e7f2cb4a77ad32258bb70cab523ae5a11da4bf8WzCvd30vuu9CZd+nIfypww==', '1990-06-28', 'ee5c7411255a8ea82c02ed579fb4d012743a6e97e8136c10d265a9c0d970973589486b9e233700da2a2f7eda53bd195ay1ghgolSjfr+rd1Z52XSQQ==', 'California', '2020-06-28', '', '', '', '', 'Graduated', 'Attended', 8, 1, 'Transport', 1, 1, 0, '2016-06-06 17:53:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(13, 26, 31.912424, -106.585587, 'Erin', 'Wilber', 'forever4learning@yahoo.com', 'dfe20d542d35e6410bc52506d15d194467339190e376c4ade369a3f13f16dcc3367906ae643795eff19f45667b33dae6CW15cOBod66Wj0fuCPgNOg+Ub3L+BJFWZpm7vV8wuzg=', 'Los Angeles', 'California', '90047', '3235433435', 0, '', 'Erin Mariebell Wilber', '70f562b67786c8bc19349b9faaf5b089c1429f9559f3d45abd7c53a9fa356b79cf59c9c1ca69f16dce3ecd64b50e828ezybXgGV+Eb18lcQQhkd+BA==', '1995-09-16', '9bf29e988136512ddadb03257f505be0d75a22cd0b88ce97ab0df0366a07b6f11187a80b3cf7ca49c097de069e1f80eeXemq5zwHjrIZ6kJ7Ak+uFw==', 'California', '2012-12-24', '', '', '', '', 'Graduated', 'Attended', 3, 4, 'Transport', 1, 1, 0, '2016-06-07 18:10:29', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(14, 22, 31.912230, -106.573906, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', 'c97f89c708ec7e33018d781779f40ed48bbc5f7d4a23b4ba8f695c988e5db38fbdf4950ca48e160525325f7d9a55c7262BQvIOehHqb4Mv/FK4rmDG4e9rZuUoww6gNIefXLaPg=', 'El paso', 'Texas', '79911', '9154746047', 0, '', 'Ruben Ruben Hernandez', '79f0cda94dcaa3f057bbea6034567549a7bcf0b9ebce5a87a634ae129625c2ee00ff06492de44db92b01d64c2a842763gebdPSroKH2AX0Ft4H37ng==', '2016-06-06', '4d561fbcbd618ca2e986d5d8c058b38dd9a6df9b27cfbd31c1097825a8d32aaacf9cc30ec0c3127d2fbb8af64630d9e2cq/JZ9gSYoq+aoOWNLmZdA==', 'Texas', '2032-06-07', '', '', '', '', 'Graduated', 'Graduated', 12, 25, 'Transport,Anything else', 1, 1, 0, '2016-06-07 19:04:13', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(15, 29, 34.592793, -83.741531, 'Jessica', 'Walton', 'jesssicaalexine@gmail.com', '4bd74f934e48d2328c20b9e7e304f5098665393f713218474bed4df37b27fc22d62f578b9f82bb2952807aee5539b713aUAHyiFf+vHbp9PRSRplWNgdjlGdvqYKtSBk1w1A4u0=', 'decatur', 'Georgia', '30033', '4705648397', 0, '', 'Jessica Alexine Walton', '8fc1d0f1a99c27e8c2a2054aaf9e2755070cb702cde22ea57f89decbd75c087752fa5599b03299df97624731fe0f5d35WyV/JuhRU6yLIfE0vnxRXA==', '1992-08-20', '138a67297def5583d3cc50043eee131cede3dc09198e02dbefb9344990b0b6138b26b001c260d0f29273683ae3f16831GgjpoRz9/B71l68Yr0qqgQ==', 'Georgia', '2017-08-21', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-08 11:50:44', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(16, 30, 40.838219, -73.900307, 'Kristeen', 'Washington', 'kristeen.washington@gmail.com', '4ba9708e0ed363eb0ef2cd2f1fb252387cb97642c871e327e16e81ec933069c2b691e0fde3a7e9f58e2755f0ffa44f0doHaBvMkIxRq940vvUqdh3CWiFPI6QNFdxb0bRtRT0kA=', 'north hollywood', 'California', '91606', '7078535100', 0, '', 'Kristeen Antoinette Washington', '9e9ca1e0b20eec401fa27452da13629f19f534f9216e43f874494b295c22ccce7dc7c3335e0f6fdaec125eb55c0e21a4Jm5rmYxJnCqclvkBs1PY+Q==', '1990-01-01', 'eaab77a0fce4f4446b1f61ea46a0cd1fe8d447268a8527c643fc8f6a3afd11463fd69ac530192bc072be23de3cb4120dsTaLxvu/VjBmIag6Yep6gw==', 'California', '2018-01-02', '', '', '', '', 'Graduated', 'Graduated', 10, 5, 'Transport', 1, 1, 0, '2016-06-08 14:53:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(17, 31, 40.715889, -73.984024, 'Fanny', 'Lin', 'fannylinnn@gmail.com', '6877c9dad128a56a9a71f2b4518d05b1d571e3df2cdd451ea0d8df00125c2e9121f3e98ad1008ef8a9c52e5ddc86eca4KBThE0AVqfhR/SdaEkQBbHaliRme64OlzqPnmhXAYuw=', 'New York', 'New York', '10002', '19178856565', 0, '', '', '8b616e299ffc81e1b40c9ea2b85d21cba110b9836d0e563e411e1b19682545977c32cab2632b50faf674d5488ceff2dd2//0W2ECeyCpUdMQhR+sbg==', '0000-00-00', '958462b68b1cfc0d8f47ebe8e5f15d89d5784f049c9b484cfdf7bdaa8a726f4741a4755d8976a05ac401cd70e1b8f23dpGvyASuxyhIQmOyCN/vX0g==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(18, 35, 31.912189, -106.573875, 'Rub', 'Her', 'jrhernandez2@miners.utep.edu', 'a45483028adffe1b9f13741bf14eae0e04bc84dd260c49a7ec745e834519411d73631f99fb3ef7d0d5effd76946d2c85fT/mj0nf2Sktv2e7N/3GgplhVXxLzax1kkKTdIZIysk=', 'el paso', 'Texas', '79911', '9154746047', 0, '', 'Ruben Jos Hern', '24c52d2316ff42a303ce9a1fa0c1aa0a0f70c66d14b931d06e576979bbae3768752d36889fe4d8f00788e24ba7d2ccffvIvkZtJb1K5VJ75htzpoxg==', '1970-04-04', '0c67fab97087e933f8e7445ff8ba2771c9342fc2f0753ac53838999e72e163e1509a31adf8e4294f23694555b2400358XVqEPPZazpDPP1vbJDmdVw==', 'Texas', '1970-04-05', '', '', '', '', 'Graduated', 'Graduated', 25, 23, 'Transport,Anything else', 1, 1, 0, '2016-06-08 23:40:53', 0, 7, 0, 0, '3786', 'acct_18KKzQEyXWFq4B99', 'btok_8bY7jZUvN3BWWk', 'ba_18KL1YEyXWFq4B99RYz6Buzy', 0, '0000-00-00 00:00:00', 1),
(19, 37, 42.464367, -70.956039, 'Rachel', 'Fulgencio', 'rfulgencio@outlook.com', '490a569271a19dc2d6dd30466b467c39b2939563fd1beda7c51ea40c79630f090c02718aeab8213e8eb48149d570bf1dkmEu+8BU3nSvoxywxuO1lg==', 'Lynn', 'Massachusetts', '01903', '6175050713', 0, '', 'Rachel None Fulgencio', '9336c9bfa0c88940e84b8774747f5e205fc05bf13352b24acdd66605b61965988cca4e9c834762f08f671eccfe5dd426T+L2YZVXft79peubv+9nCg==', '1993-01-17', 'a215d877ae3343bca6c0679e946a553eec2573da0a6c8ade68b38348be287564e03423c268a826f1b331e266e1db4619uKBO8XE2x4JmslkPMPjp0g==', 'Massachusetts', '2019-01-18', '', '', '', '', 'Graduated', 'Attended', 5, 4, 'Transport', 1, 1, 0, '2016-06-09 12:52:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(20, 38, 33.938370, -84.499992, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', 'e9bebec23aae6f12640f0618212cf3af82a1a270dcb562fab4e09b71039f4ed2db360c5aeb38b45e5ff6e90bc75fd888NQmON6hU+grQNZZh29Q2M4BVJPflgBqktikw9UmgnMY=', 'los angeles', 'California', '90077', '8184658228', 0, '', 'Kimberly Liz Odigie', '8db796f87d28d4665c6cd4ea7ac97c0ebe4d6b7d9348482ede3e35cc036ca960d526f412a0c8f1c559d2d5d1b55abc131ngnhnx+PIm8Pe7i4C7Ezg==', '1982-06-08', 'ad22f51d3ede12d164fc7ccc909c168df5b5dede73a442ea54da1695a5ae5c6d9cfa18ed5bc7cf1514c2afd4266944a8B4iOfDkkBSp1Ukih24aWiA==', 'New York', '2020-06-09', '', '', '', '', 'Graduated', 'Graduated', 8, 8, 'Transport', 1, 1, 1, '2016-06-09 12:30:05', 0, 7, 0, 0, '', 'acct_18KX04F1yquyNukN', '', '', 0, '0000-00-00 00:00:00', 1),
(21, 42, 42.263481, -71.109978, 'Tyneshia', 'Stephenson', 'tyneshiastephenson@gmail.com', '283f6238483d6aeec4c71ea2fbb829c8dbd04d62c605a9da44e76a1d9f5657cdb0a6c90881e37160a500597ac037d1d0J1B6nlGCcztCNTZULLwKsBy+o9H9Zgc39SXrADYed8I=', 'hyde park', 'Massachusetts', '02136', '6176026526', 0, '', 'Tyneshia Shawne Stephenson', '9021697c33eed0615c9688e8913ef8f287d2e8a71d29218ac2db5a4364bdc2a20846a800ebe31b56956c22d1959b66d5mTfoJPH4CA+g9ameukwT4Q==', '1990-01-08', 'bf9b02a1d3d91e38042ef298d3dce40b0352b2e9ebefd05f314789f4625b10a879623df975c715a24605bf51da88a098SX/+s/33tCgHyVDVZV+9qA==', 'Massachusetts', '2019-01-09', '', '', '', '', 'Graduated', 'Attended', 8, 8, 'Transport', 1, 1, 0, '2016-06-09 13:25:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(22, 43, 34.077709, -84.637848, 'Foluke', 'Arogundade', 'folukearogundade@yahoo.com', 'f3f64834ac16c1a97da259724455a10e01c1a5b57c9817def77ca48788474588c1844f8c55ef587ddc6b71573ceab210saOvLPFT6wItjlqhi7xhcgjI1gRdcQA1ORfzSEaq2CQ=', 'Acworth', 'Georgia', '30101', '6785239128', 0, '', 'Foluke Adetokunbo Arogundade', '4ad225472d045904c41038389ad0473334d275466106a33579665c901fa7986239a4b8d84074f4477a149d44a89de5c0WwNSaoBJpNx5TdhT/TH7jQ==', '1982-04-23', '9b3d6aa7cb4e6f3ad652efb00362f7c3b7b00579455c28e48bf337e525c810150c34fd4df833e787b5fdcf6feac89b00whzWER9G5mF+910YXwLvMQ==', 'Georgia', '2017-04-24', '', '', '', '', 'Graduated', 'Graduated', 10, 1, 'Transport', 1, 1, 0, '2016-06-09 13:47:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(23, 44, 42.264076, -71.103775, 'Vanessa', 'Jean Louis', 'vanessa19jl91@gmail.com', 'c5206e05de41042aa20fd06f4993741edcd8509d5c83e18bc18be48772d3d0d312d5098baee64007565f568ed11083906TktcfbvX1e/bzJolVh1CaSYuYaaEUa7BNlfSBtCQyE=', 'randolph', 'Massachusetts', '02368', '6174129581', 0, '', 'Vanessa N/A Jean Louis', '827d1c294e9c051b3c7888cc9aa070b0daeae953e955d08ec58f0178a2ad7e56b1cad9ebab3b688794099f5f055ff17d5Jg5f3sISrMV6+td2Jodkw==', '1991-07-17', 'e0a2829f9777bc14fadcfa933896c1c53e359776c8257d18182a3e806e1f275270383f48b4fe02919f98b9f2d9fc64b7wJwQlXZgoYjlRzJbdt2UUg==', 'Massachusetts', '2018-07-17', '', '', '', '', 'Graduated', 'Attended', 2, 2, 'Transport', 1, 1, 0, '2016-06-09 15:13:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(24, 27, 40.689346, -73.870537, 'Rubot', 'H', 'vauxxer@gmail.com', '9031517908c1c5d016a49fbd4e3e9150248cd5244f987f4971a843a3525a9c110f4df3d69e56fd9809ef66ac1d3d1c8ceFyQP1bTdDKUWrLiaEB0BQ==', 'el paso', 'Louisiana', '79911', '9154746047', 0, '', 'Ruben J Hernandez', 'fc7e2a7f7d2ca886d422a5834ce2e694bd9a16ecfeca218cd0108a7705c61b610a448f214cca687429d897e4cab4d8f0BENhU0d2SfbbInoYPWzukw==', '1971-06-08', '4c2d74a1251908bc94a4c4812c1f8a9baecb12a62067c8018883143f1bf13efa161e24497ad1bef62153bf0a0a6b49d3okwGlYT44dbk5cmu8VA7Nw==', 'Florida', '2021-06-09', '', '', '', '', 'Graduated', 'Graduated', 54, 54, 'Transport,Anything else', 1, 1, 0, '2016-06-09 17:28:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(25, 45, 40.693497, -73.946793, 'Kiron', 'Harper', 'KOHARPER92@gmail.com', '5fd7fed552edd56d2a4da3d9a765ad06843e68d301dac12e01d2b8520b2a36b6b49cdb0911216f4bbb34095e5beb5c23BTzWV/A4LnFxTWvJr33g9eLY/lUQgsBvOx4z7lob3Vg=', 'Brooklyn ', 'New York', '11206', '9543973616', 0, '', 'Kiron Okero Harper', '7550f28f0d9af1495a4fe7a2d5f30e261c7bcec1a8a16a572930e65faf891264b7eb5b3cef639613f1d62bde5d91f27eu12r6Y+Qr897If5GtjJ4qQ==', '1992-12-03', '691e18732ab64fc9db6e29f407317ac0b7678bd554e030fffed1e95115484dcb2849c398e125c998ac470464c26d3ebf9a8u215/571OfkDTfvuASg==', 'Florida', '2018-12-03', '', '', '', '', 'Graduated', 'Attended', 4, 1, 'Transport', 1, 1, 0, '2016-06-09 16:58:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(26, 33, 37.332333, -122.031219, 'Ruben', 'Dev', 'ruben.h.dev@gmail.com', 'd7faa448f1486064a13ffbf53172beb3f5e4c7545069082ed4d7b005e54ee02803d936c8c371c7c7496dd6ab09d50447Q7gFBels0KQHYKkMAQkWtA==', 'el paso', 'Guam', '22256', '9154746047', 0, '', '', '2a30f6bf9a6c55df4f4c1069b74f9068c5ca81d7174aea03d7486a43d29b269bb85b3fb38699abe7ce8d6bdd29db9d073KJKV1d9O8iOEfObS0GyZA==', '0000-00-00', '5587c5f87a28369f0e1cb01a256e81a2c91f089938476d2aaf9b18002dbf438fc3d13caaac1fa1d8616007ab7d04b8abW2E642H4POHSfkLw/1auzw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, 'Transport', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(27, 48, 0.000000, 0.000000, 'Katie', 'Toups', 'katietoups@gmail.com', 'c73595133466bc4150b5cdac4f3fe665c9fc899b478a65de3af8e020e29125edc0c6fbda5d50bf7f284829d9273cae51QQeZUw6Dso8t31wlemvjfh9Xzo5gx56DXjPg0suJd2M=', 'Brooklyn', 'New York', '11208', '9177537604', 0, '', 'Katie Lynn Toups', 'f4a31292ee3cff76b18282ede68bd4102d1cdd7ad70c1b61851d19171b0f648b9aafe6b035b7913869b52bf0f5f383e9wVB2qXzk3NErtOC9KYugyw==', '1988-02-26', '921e6ae88e9b82fe166a970c5641d997c8a394f80b28e6c534093be0bdbd5a303fa02c80b41752f770d7d3b669d9be8dCUPpFSulaYZERL0N/V1Xag==', 'California', '2019-02-27', '', '', '', '', 'Graduated', 'Attended', 8, 3, 'Transport', 1, 1, 0, '2016-06-09 18:49:48', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(28, 52, 34.106045, -118.464035, 'Kimberly', 'Odigie', 'kimberly@theqnowapp.com', 'a48b5510c86b34218e9654a94b883e964797947052223ce3adf646f395f7d5a8682c0533b93f8c089c600c9357113e36PHyRG2Ki4wPASTkSuuiNWg==', 'los angeles', 'California', '90077', '8184658228', 0, '', 'Kimberly Ray Odigie', '24f2e75418e8df5e9cde7ee4c00d4ac40842667a6cf7d99b5ff8fe9541774e4a59d8a3f82bedfcaf12979656a786d3d9vDGXW7wUQo+FEq/2digHAQ==', '1985-06-09', '347013b7930624e62d7e0e5dcc2c94e5d3a26618be58dab917d4dd283e3061bd03c6e6e42c85501a4793226a0cff886fVGnhSWwVBtNz/EjBK1Uq+w==', 'California', '2021-06-10', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-10 11:30:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(29, 53, 33.839886, -83.886940, 'Jesse', 'Ferguson', 'j.ferguson1@lafilm.edu', '18a2a18e27bae1d502a3305d0de98c1956e0675b982c0e17a84841ab8cb58bfc138fc134b83760f53174ab988da11ee413KZLVvXolfQ/zQLS2JvKWJEroLSKWgnPD7ecArfiTY=', 'Loganville', 'Georgia', '30052', '4236939242', 0, '', 'Jesse Austin Feeguson', 'c6b0ec560735135475b0be494e6f8be8bd4bd437a0602c11605e3cc8e652047c3ac0c579b81704a434874e7c9cf4a5baBabYcAIHd56sacebrk35rg==', '1995-10-09', '8a2f70c5895f2cc2a417c7aec7c851b630bcfe12ae51369be67b8794e10b587de723be56698088732759504a3c0fa302uNWPtw0Q+2tB6msmigkGnw==', 'Georgia', '2018-10-27', '', '', '', '', 'Graduated', 'Attended', 2, 1, 'Transport', 1, 1, 0, '2016-06-10 12:20:51', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(30, 55, 40.838230, -73.899910, 'Fati', 'Haruna', 'haruna.fati@gmail.com', '1e50f23101cc7f797a62f20009b29fe5f7e03ca71c2e5ba3e25ce0c630a01d8b460b5c5af8f8123b9c3e90c9417c4468J5PBGnLQpTuBrAIMyztr/tFW9V+HOeBhSzu+uZGuqLU=', 'bronx', 'New York', '10457', '6463398454', 0, '', 'Fati None Haruna', '280baa9ba5b59382698e437ae096de151c0507d50c509689d149fb7a736b88110125cc5b3d7f1d1fe8f357cd5f300aa81LaSD/l7YNAGxA1dRUZK/A==', '1996-05-26', '5706e51fa013ec9141b1572cef56e412bf7d5ef12d5721f89f8e005b6b0145063a2423699d48353bc7aa59d9a08524041TTzrWE+kNCf6POvdEcNMA==', 'New York', '2019-05-27', '', '', '', '', 'Graduated', 'Attended', 0, 1, 'Transport', 1, 1, 0, '2016-06-10 18:42:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(31, 56, 33.710094, -117.853897, 'Richard', 'Sherlock', 'richard77sherlock@gmail.com', 'ddd4ebdbcea67f330931b65b145f3dbf1cee7ec3e954eab37d783a6e3d41dd3190b7899f632a68a24695fb6089ca2cd0SIdydt7NAvBwrZPoYTOX4p1KhIuSIkZKusv4eYi8PII=', 'Rancho Cucamonga', 'California', '91739', '9092243168', 0, '', 'Richard Christian Sherlock', '8ee1080beee78d5028060e661c317274645b28edcc936e69231cc483f9ff546a58365bfcc5d98df2ff077fc032656ef1OWxVCkXXkp46w7GsFKu+KA==', '1990-04-18', '7a373932d792b9b109943536ab6cdb00f75ef21ed3f434fcd51f1f698ccbfeb71c9af7f2a36ba84d81203011332ef9acVMM3KutUwyVxSOKBpB4Oyg==', 'California', '2021-04-18', '', '', '', '', 'Graduated', 'Attended', 8, 4, 'Transport', 1, 1, 0, '2016-06-10 14:25:58', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(32, 54, 33.900692, -84.238327, 'Vanice', 'Simpson', 's.vanice@ymail.com', '9d38a5d344974505da028fbd1060687a02aa36be5587822105faadeb3c1e4145d464623992ca2226db9d01f8706fc3c30ETFwuQmYD1HwnBZuySppfhyrNZrrG4FC/olNUPIkVw=', 'Atlanta', 'Georgia', '30340', '9548026914', 0, '', 'Vanice Nichole Simpson', '2df33032da14e998d5f10fc145a0cbe1efdfce27776c18f11f96d2759141b098e44d2243165af3fbb56b2b07ef33f1a17Qdwvl9+ZohVNdApaFcQpw==', '1991-04-02', '02b9979707584d89d18a031174190c5cbb8e5c79b396c9d66acea0b24d8611e20aa575c4d9a433af4f30721067403cc8G9ROfOnko8qx3/Qia90N8w==', 'Georgia', '2021-04-03', '', '', '', '', 'Graduated', 'Attended', 9, 4, 'Transport', 1, 1, 0, '2016-06-10 17:07:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(33, 57, 33.678871, -84.441261, 'Kiah', 'Cronin', 'kiah.cronin@yahoo.com', '4ac50a9c8bd2f7a0c3376d3b09ea8a3c0f57a02de7b155cc8170f542a836b859e1ffb6ef80f23de3312832563eb1160fbj6e/153m6PsaEHmr6b3f+mzBFOdyb7V8XsFyiElUoM=', 'East Point', 'Georgia', '30344', '8145746755', 0, '', 'Kiah Nicole Cronin', 'b59c53ea3e758a2bc923b715c30909f1d7b6360c934dae01ee0c46271edd99925aa7c419db5daa2f790103be954e1ff7FvRggT4xcdXW9YRE1iJ17w==', '1995-10-19', '95c4eadba6ac90b3cb1a95066114128b374a01189496a2dc5abe2c6000cfeb0b1b713d44f310c26c162b275d9e9a3c07JYN3BjPV7zm9DXJlBSZ4sA==', 'South Carolina', '2025-10-19', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-10 17:56:59', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(34, 59, 40.663719, -73.940697, 'Raven', 'David', 'rdavid_18@yahoo.com', '6d8dcdab60afcf1c2c364fadca5c8ee3f281b8420f6235d51bc65378055abced6b76f49ae62dd848f8fc2a6e2aa3a7a89ghSu7R6M93UcHdVhWIpJmc8EdT7NcJ/LX/5yXaa1Jg=', 'Brooklyn', 'New York', '11226', '9293925629', 0, '', 'Raven None David', 'fadcf300b1d96598835e1a48f61a1fa7dbf5b362fe2fd770eb2a940254bf0809202220e9f541cb2d21576ac531effc8551qGJDFl4EpTBc5yXu3pjA==', '1992-04-24', '1178b46be84e462e8cec9a6100cc08e8d5eb09ed5477cc349258d64bc5dda3f361ab1d707a0c3547a83c5d504f07f6346VCzoYgm822UjeymB2rc5Q==', 'New York', '2018-04-24', '', '', '', '', 'Graduated', 'Attended', 4, 4, 'Transport', 1, 1, 0, '2016-06-10 19:30:27', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(35, 61, 40.867050, -73.841263, 'Salim', 'Diakite', 'sdiakite16@yahoo.com', 'bfc88d10d5b7457236add33bef51b91f90c4211e24824e1cc175f7ead9c6cd02f248db435b8cbad9d12b9d773094e8c5KHLDcw2+gvq3NlsIh7ni/f1HqF3x4WZP1sw+I2wfWKs=', 'Bronx ', 'New York', '10469 ', '3478216504', 0, '', '', '0623a4eed38818841730bc161a0942b0a81be04664c5113c1c7d59b161532e4db14c25f2eac605d31944920c402a18dbFyQagPJd3tRYoNyAq15sZw==', '0000-00-00', 'b42e5b61dc0e295756ee5f464ce2f14c6879fd5d14bdb91cee56fc153a67c772ed90b6fc68720f055a90d44bb16c6aeabqQZNDfugNvkTUmUQb/Ehw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(36, 64, 42.485149, -70.899422, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', 'a5bbd887b23a2612ec13a31993712f2b3ccdf1ab2941d5171d94b8ac5eeaa5f61538e5cdc6b83c1dd50b0ae59a15d01fZo7W3UpIKIVQfj8u2+et5RsHO32KHI8/jrVMlBcl8kg=', 'lynn ', 'Massachusetts', '01902', '7817312269', 0, '', '', '268d34e5fe4fe6eec803e8b47d07ba905b51ff5d4a0aabdc90e4d5c7eea2cbfae2cce16248d662edc545b1ff986b1c05g8Ts8VzfyxsxVT/Z+pJSLQ==', '0000-00-00', '39cd2b4041d3cd32ae55463b2c1165daa2eab55671b1634a52e47538d8d6e2d3420e1b03cd9b84586fbacdca931d371esM6ziWJHRpUCGoLIqXsGkg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(37, 65, 42.462654, -70.950279, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', '58191bbfa752cec7efb3681c80f72f96ca5eb517d8819108446f9d95b46d67251ef7252ff3708271c3d55ae82dfb03cdcB0JUjoDmP/vqcRzEbQEc3QhqUaLCtH7tQJDiM/1hdg=', 'Lynn ', 'Massachusetts', '01902', '7817312269', 0, '', 'Natasha Marie Diaz', '386257d2eb20a43f1e36e9666dfb3216763e25d942d9ed8ea9f02b05f13c8e924dac6f509496e3e8dba4c0aa34b6a1e9SIeGLtVBqM+Jksfd4VrTCA==', '1994-05-24', 'ce53197d93459189d0b368bca66186792a9087e57cd28c7b48f17b224f9f9ec45b656269d4de776cc0726cffc8200cb53R/6wckQ6Y8P0rDGxP0m1Q==', 'Massachusetts', '2020-05-24', '', '', '', '', 'Graduated', 'Attended', 0, 0, 'Transport', 1, 1, 0, '2016-06-13 11:33:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(38, 66, 34.204670, -118.446411, 'Rebekah', 'Pelzel', 'rebekahpelzel@gmail.com', '4ca0519e058a7a6e4c770fd101fd3ebd0b252e446881c4e1dba97dd36f0ed77dea0629ef122726ed4e60a812d49c5577OXd3IQxTIRruIBnJ2YGDQg==', 'woodstock', 'Georgia', '30188', '5756404303', 0, '', 'Rebekah Faith Pelzel', '91ed1c8d7cf42b49d86fc0039f0d4d9494152385d7efd6387827f7bae3d7f3abf2285f58946ef50aecab91777992cb981mAtGORGQIAdpqShIqAL0w==', '1992-06-27', '1be710a52cb27ac174d32bc16bc4f6542616c8765fef467d304c675f30bc0105232e0885227840d3a7c6d22077e58506YGDUnPKBOPws4s0lXukpzg==', 'Georgia', '2016-07-29', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport', 1, 1, 0, '2016-06-15 08:03:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(39, 67, 31.912004, -106.573738, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '80234c9591a16b8a29617ba8e23147ef1eceb463ef4580efe2f9c309df4b13da6b9961e36a71655e7f4fed8c7be9b333NhHj17urqm94M4BQJHvjdw==', 'el paso', 'American Samoa', '91423', '9154746047', 0, '', 'Jose Hernandez', '8e7672804ccf25a567c30759ce8cea45260bd7880f694f5b44291309cad9acc6b99f8363a4d3b939e5d6d5371b7ba845bev5gsMGQPfo82KRMMURDw==', '1970-06-21', '055a35e2ecd99cc1b11c1306f50e49a840d9f0b9bae0c39d5eb46ce93d51935555d929b4ddb0bf6d53ae47667a113d8b+/rnJKb0ZVsixY70yRYFVg==', 'Texas', '2035-06-22', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Transport , Anything else', 1, 1, 1, '2016-06-22 23:51:02', 0, 7, 15, 3040, '6702', 'acct_18PPpwJoR1VUISMG', 'btok_8gpdaSxGAKvxtH', 'ba_18PRydJoR1VUISMG16WtQb0J', 0, '2016-07-07 05:34:30', 0),
(40, 68, 45.620949, -94.213211, 'Seth', 'Sharbono', 'sethsharb@gmail.com', 'e2d57d66812d50933e65c989622bd269f49efc811879531313c9a17c539297208d4ac15f0f38dc702acb90db74e298f0ht3n5HqdpXWhm+pMKoD9v9T0WO8ermCFFt/7LllInyA=', 'New York', 'New York', '10013', '3202491523', 0, '', '', '5865bc3f3d9a2affaaa9add310561a944489271787bc97c2a6e339514507bba4c917e5295db7e8047e55260142ebf212blxTWhxSb68RABbIIlSSRA==', '0000-00-00', 'bcf60dab29576d36533b252a84d98231fcfe56f2b5f90769e69bf0769ba4a541a2df8823157ce530f5ba0ed9bd472ca898QUViOnNVLn6AP3rnAjVA==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(41, 69, 40.630604, -73.903221, 'Nerishka', 'Jeanty', 'Nerishkaj@icloud.com', '0d97842868e92043362c18a91e27c4e14136c359f8a5a6428fbad577d44b503489bf35ad27c16c64de9aeb46e67a0738m0p7i0CEv8I0NGFfNkJfFI0X9JYGxSGgxafugZw6Wxo=', 'Brooklyn', 'New York', '11236', '3474099134', 0, '', '', 'd11788de621ce9a520ce0bf495d2bc86d507bc60a8737c94c705f38bf34a26854568bfc59df858b4edb44a3f269c30f0pwEA7wMX45gfZwDKRtZGAQ==', '0000-00-00', '000362b94fa948a48a3fdcae26ae679e446e919de0a98a68bd59aaf6f25a253903e30fce5eac0d36403c41bab00c0ae9cvGHFSozhHn+pCi3UAV3TQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(42, 70, 33.929123, -118.331505, 'Bianca', 'Latham', 'balatham@ymail.com', 'dcba0ae803fd2e9d79c49fd9ecde09464b386f13f55fd5011d9e2d17ccb26e54ff46f6793bf77270dfefef7c33d0b9d0f/S9XtIHVLDrU6DlA+ag1g8twZrr1kVdA0hwFRKXyIw=', 'Inglewood', 'Armed Forces Americas', '90303', '3107437584', 0, '', 'Bianca A Latham', '89a39e927ede2145fde4631a08c2fb86efb139d6891e2a1f4bdcbabf63f783254f501d2bec8fb0ccf5af3447cc3249b60R1GF2F2whnOHmIgVZshlQ==', '1988-12-19', '1faab6397859be92c74cef16c36e040b8fe5626b80597fb2e47b111307b40e062b4c81f3e4dd5833795566d93b4d76baJmhBCDeV+NDJc69UCHZxug==', 'Armed Forces Americas', '2016-12-19', '', '', '', '', 'Graduated', 'Attended', 10, 6, 'Transport', 1, 1, 0, '2016-06-13 19:57:03', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(43, 71, 40.821831, -73.878044, 'Richard', 'Ramirez', 'richardramirez5@hotmail.com', '84aff6e7913192c52b2c056453844ea171958cd9a6d8e873c8d0dd2ae5816b749fc92c9c0749d669ad3fa16d326d3a07caSAt/4nSwzz1/tiQSkuptwWFxy5Y9Mkv2rAngNRFts=', 'bronx ', 'New York', '10473', '3476912171', 0, '', '', '20ef13a75aa167179f20fc4d32d9509fdcaf50c0ce386284085d46f91236c1ff599ba9525248e4ce3afa9ac5ecfba5e9R5LdRZkclnKFiXWo0Z/MtA==', '0000-00-00', '5e4ac9f70ab633f295e7ee2aae92f173f2614a8d69074384e3fd0d3c3028b27cd228d52e0264dcbec780eaa7c00cea78bE7KYp6oOOigt+Co6gKOuw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(44, 74, 33.644077, -117.746819, 'Michelle', 'Barrionuevomazzini', 'mbmazzini@me.com', '315170a9434bbfb7aaae33686094b587dc696c464c55757cadb4dc166fcdbbc819487b0ec9f5c49c574811b2e761c5730577P4hLfNQc4DDBf09LnQ==', 'Irvine', 'California', '92618', '4157061677', 0, '', 'Michelle Mavel Barrionuevomazzini', '29d3d6c7bbd7da203d5db4d4abe40aa302f2c9e61c48d1206312c072525d4f7522c29e49fe1ee8692dc2e665f3e8ea0djt+Gu3hLsSBo1oKKhYoK5g==', '2016-06-13', '67c1c6de4f7c4943be8e7ce95f260798572ac1233d3c4be0c12b52529088b65cd23be34988e758b6dbd829f4c0cc941aErtpXK23u2sXQZ6jgrIBnQ==', 'California', '2017-06-02', '', '', '', '', 'Attended', 'Attended', 16, 13, 'Transport', 1, 1, 0, '2016-06-14 02:51:05', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(45, 76, 34.009239, -118.300179, 'Tori', 'Uvaas', 'toriuvaas@gmail.com', '186cfa9a96b07d32f0cfed28e5a467b99cb78d3cde181d51cebf0ef25d662b443aba874ea56ff69f5fc133ff5ddeacf5ezYB/jgZnDBQH19ZjaoRKqWLip/T12l7f57ijBzhcug=', 'whittier ', 'California', '90604', '5624479004', 0, '', 'Tori Anne Uvaas', 'bd3c38e52b593117040a3608b130db662ca7bb2ed896bbe01781bf1fe2796cf907a72a0da4012c2276642e92f68fc467ST5gKgZPjzB27eOp2KHY8w==', '1995-10-24', '86a0e314060382ba0e5f04bd23d5b3733989b994efdcfef9deff4c6c2ae0f2c6f30c971950211ce5d64bd2f1f6a84b7ehmG0stUVJNlsTkL3HTTIyQ==', 'California', '2020-10-25', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-14 11:14:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(46, 78, 0.000000, 0.000000, 'Courtney', 'Siwek', 'csiwek13@gmail.com', 'dc0980c09cd315ba2b2b0ecffa2879fb0d58988f9f9d7e51a7d89cca002a159416df787e4286c838948bfe2be58bd693Ym7Pw6eCiufGxU3VlGkNF88b8l4PZ4g9uXuRVfCs7m4=', 'North Hollywood', 'California', '91601', '4196109863', 0, '', 'Courtney Ann Siwek', '2f527df4a805eeacb4f18008c634531e960f08d42061df30d66a114b8203de84b635c0aca1a2210cce958fd283d02147rGF45nj6cjNCOPi78fIa3A==', '1993-05-15', '067c00a908f8cf55786cc1ba269998df51bd5430836459efeec2bf4b085c7fca2638d7f95e3d211076e9dc2a1f284623fmDOA9GmE9BmNVmLgX3/dw==', 'Ohio', '2018-05-16', '', '', '', '', 'Graduated', 'Graduated', 4, 3, 'Transport,Anything else', 1, 1, 0, '2016-06-14 12:18:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(47, 80, 34.106144, -118.463882, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '91d66d5f246258418dbd8879545aa236680b7e5dfa4e53329bb0556e8738f5feea57c5010705f6c752bfbe092603ca141DcUjvEVsuHH+FqPuJSodQfzgZd5waPX+Ns2PcYWoQ8=', 'los angeles', 'California', '90049', '8184658228', 0, '', 'Kimberly Liz Odigie', '4801976152d2aa467984356743ae06454b735441b5ee9ca599d02c6138d03be82b00a10f2f9e5e4ab91a6ac520e5a663loGAs4fwVs8gbGdgjQ2J4w==', '2016-06-13', '027db0bfb5f32e16dd7185396bd25f0180d11846ea25daab4629308c3c5bf1f489009b9ae0cc3f31b081eaa1fb8f7d59bBH94ss8xJopAhZwTJd5IQ==', 'California', '2019-06-14', '', '', '', '', 'Attended', 'Attended', 2, 2, 'Transport', 1, 1, 0, '2016-06-14 13:19:04', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(48, 82, 40.682350, -74.331223, 'Deandra', 'Egusquiza', 'deandraelise@yahoo.com', '624d169c02f03fd48f13d0e4f3711fdb15fedbd99990a9ff459eaaa55e50f6de17c7d4d26333b9ce37756b973160219a0aHcCOGW2/yI0KCezUuP4Q==', 'hillside', 'New Jersey', '07205', '9085149546', 0, '', 'Deandra Elise Egusquiza', 'a711068ac4323e38a7ab44a6108dbe3ed845bb358e9349c66dfaae27f546f47df36af36fc29c7b968fc6605c3319323eyj35A5Borg76oA6o3aKkUQ==', '1988-02-19', 'b83b48c3be13d019bcab3e82ec1c5c6b6c319503c7be5285bea6084217f59c93e0913038f83b296e522a9def8870b73caa9ykamdnsXe5HRBrzZpCPwJNtG0PVZ95XuD7fSaQis=', 'New Jersey', '2018-11-30', '', '', '', '', 'Attended', 'Attended', 5, 0, 'Transport,Anything else', 1, 1, 0, '2016-06-14 13:26:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(49, 73, 31.912167, -106.573845, 'Ruben', 'Hernandez', 'ruben.h.dev@gmail.com', 'fb4082c11cb3592e8453d5c22a7dcfb2b255b9fbd3f8d7385eaf417b427b53dc537ffff7afeb9f0ac10e5b4f1baeedc3WBi1wLU5DNOu/59t99jeRQ==', 'hdjdkdk', 'Delaware', '61616', '9154746047', 0, '', '', '0373b964fa35e2db63cbe7dbb9840ff8dff27c0d7b7077bae0e239d54b7e47b4194a3ebc72fc77c2962c1f387c5eec47GYtju0Yj47kj3rnpKGXhxQ==', '0000-00-00', 'b3de28e09f73408762c2aa15dfe4af6a19a5a5286cee9298c57474eb28502a4eca0aa1f6be09b649edf6b80f8a880651/AJgXoQsQX6fQ1u2UYxjjQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(50, 83, 42.264492, -71.354477, 'Aliza', 'Greenstein', 'lizadancesandswims@gmail.com', 'f5908de6d13daa4011ac0cd87a0197dc71c290406049e621b6ce746da4b85a44cf40090e44a57a0fd180b2f11c69e667LDE30mMLuUuvOrHDhUFPRg==', 'natick', 'Massachusetts', '01760', '5085051534', 0, '', 'Aliza Rose Greenstein', '99e0972f39923ca36a966a62d0f0b80d25ef406ac9a110bc39ca61cbc1ed348bd8b9aac94f61366b9afd33c46df3f9e3Gjdjv1Fqxszh48XYjFFuuA==', '1998-05-15', '5d70b19169376f388a3a4a25230057e9a1b48b9664957fa4fdf12a5561879f06021ff8f550e8331af1584daba46f84f8tP/IqD38kRHmnTaCc3nJlQ==', 'Massachusetts', '2019-05-15', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport,Anything else', 1, 1, 0, '2016-06-14 18:13:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(51, 84, 33.965286, -118.364838, 'Helena', 'Cohen', 'helenacohee@gmail.com', 'c616a3e3edeb3347b084235645f39b954218fe6d2256943403101a82d4516b1157a35f1fc2504f90bdc14b59256f229fUh8dzRw1XIeWRgVDHSYr5YaBlpsbbEJ1tstq2ydm674=', 'Inglewood', 'California', '90301', '3235612620', 0, '', 'Helena Beth Cohen', 'e05bab0686cc77c96e0790b48964cbf7841f65da2b6ddd3868fc7207d284a884d80c604f8118e30d1c9643b899ef00f4m0qdyfB27jWGVnM6rqmIKg==', '1986-12-06', '985252550fd5b155b85b8e26d02ab99079e1df550023ef85e898e0dbfe6d9314c125f1129fe2c134dcf9f84c31c0d749jFCNCBwHuDWR7Ebr55n+BQ==', 'California', '2017-12-07', '', '', '', '', 'Graduated', 'Graduated', 14, 10, 'Transport,Anything else', 1, 1, 0, '2016-06-14 18:13:10', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(52, 85, 40.785500, -73.946495, 'Imani Shadae', 'James', 'imanis.ajames@gmail.com', '84b2d66087a7e02573813ad57b4a816a7f7df208f638365539b15d00f0c45c1ec632434787aa1af8b5aa68f83d079ad3r0xHJC/p9kaAQEHUAjl7a8xdi2YJxuLOsh/DPx5fvvU=', 'New York ', 'New York', '10029', '7189159713', 0, '', '', 'bab9ac3f0daa522c88f483ae4c7c6f05faa1b09cec72fa36b0f15a622b6436f56fc057350603c3a792d4790fb1b5a02fRBgSXEqR9AChHHr2yzRkJw==', '0000-00-00', 'bd43cc67c91e23f63cf4fee30c2a46b183f8f596d08d0c828e32b9ef32b83891420f6a4fb913691bbccebf295976f496Sc/IpjgUkx6o7UYri6vg6w==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(53, 87, 34.156578, -118.347374, 'Michele', 'Brown', 'm_brown18@yahoo.com', 'ef066c7585e37056015627b0e1a3f798c4e6e6bc1d8419ac42c636c225f5ddeeae941fb4e04ee737f6fafb86b036c960+pGirqII8/WEHhXRkRxHOKkuctgRCgUSbRDgAolZ2ZA=', 'Burbank', 'California', '91505', '7604152638', 0, '', 'Michele Elise Brown', '49d827222db97d8adf8d05304186bcdf179e1bba9a8fdff60ea32784fe40fc17d4478d2e4582a53975a6fc98ec3337c0EFDQx6EBdpqjCjqYMou13Q==', '1990-09-17', 'a38c353b51ca7163f093dcf043241509d26fe8c996d7b7c78edfb180e55cccaab023f2b34678f46ab01b83cbf1597018DYzTcDCcYs21pd+c5EKAjg==', 'California', '2016-09-18', '', '', '', '', 'Graduated', 'Graduated', 7, 2, 'Transport', 1, 1, 0, '2016-06-14 19:07:20', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(54, 89, 40.649578, -74.011368, 'Drayton ', 'Hiers', 'drayton.a.hiers@gmail.com', '4c86e2d252216df20927fd811e2b8ad82576c73956805dad9d4615687b3a83ebba76d213412d245b17a2af52eb1fd52eCcARe2wrntA4H6tfAoR3LLLFRTxYjMyXbIhCBElxps4=', 'Brooklyn', 'New York', '11220', '9172028396', 0, '', '', '5c22c8e2c899f777cb3ca34b74968b7dbdbae743e174ce88eb396f5d3ca5992b9442327cf334583febfb760c9033f141d2I/aeikwLaAs4vx2wtkQA==', '0000-00-00', '58acd680e270e406bfa268789f5179f9f3fbd847e79cfc393cbeb85ca1eea6b3cb42e6174e6ba59a60d8fb77e3bebced4Yzh8BSCavNq+FMsE9675A==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(55, 88, 33.696392, -117.958588, 'Andrew', 'Neal', 'andrewxxneal@gmail.com', '744731fe033dee070a2068789d67e1a0868c0d3788336caf0c95540f58cdd6a3f3a25fe4a3c04764da1c0497ff604dfeNVut0IIe/Xt98sWZIdLlQkgrBoIRxFOE8IFm7Hxm7cg=', 'Fountain Valley', 'California', '92708', '7146252326', 0, '', 'Andrew Michael Neal', 'abf4c7d7380a8a7eb6f48b183900c396e845d142d4b818ee2b4c7e4f3951416d1e2ec979bd7347d8fe1ac63a7dc90dc5rvZDmTcH8bHD3wqKb2O4lw==', '1993-03-30', '51222239795e15c3c7e94721b37f82c0c99817bff1d7a32fc4e16e8dae18b635a403c7f241c22de54352d9b6dca2ae6ezd5Igq50BAxV4IkEnFUMNg==', 'California', '2019-03-30', '', '', '', '', 'Graduated', 'Attended', 4, 0, 'Transport,Anything else', 1, 1, 0, '2016-06-14 22:27:22', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(56, 90, 33.922409, -83.993401, 'Chantell', 'Lawson', 'chantellandreina@yahoo.com', '39b1541180c7ad7d0dbcbadab98773e9e1efab6f24039105cd7eb64cb1cfce18576c9b742757a77e60531cca050f841aKxJmgzbH+W4SfKtNu2tq1x2DB9EsgnewrK+vrGCZKQE=', 'lawrenceville', 'Georgia', '30046', '6786126696', 0, '', 'Chantell Andreina Lawson', 'adde3f31adb3f221080617d9d363ac46a1f3de327f09b008b66bfac6d89ad4e742734f910b308bda698413970126190e0WWlrudkdVuihZF3oSjGuA==', '1997-07-11', 'e3cfb04c54fbee38ecc80a68d02136b57b36b0bc1eef3a71daa4227b9e65743eb1d493e6a90140558af80aeb672ec0274DyR0MYbax2rHenF0f0O3g==', 'Georgia', '2017-07-12', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport', 1, 1, 0, '2016-06-15 01:21:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(57, 91, 33.963821, -84.377045, 'Shermayne', 'Butts', 'sheabee09@gmail.com', '0e8476882d522e48f256b997cd8899f894864e8c1458d49f51427f7335235c0637185a20b94dbd7ef6f4c72bc06fad47xxyoAIfApArzRzKh0Rqzww5nPbcLiWavGGQFDLbqKZo=', 'atlanta', 'Georgia', '30350', '9312167534', 0, '', 'Shermayne Mikel Butts', '934838c9607cc89075122f1fddf6f4544173ea976f84ee39a70312766df42de86bfff30ab04a772bd147669481dcc06fZuooVJlHGvAWv/X037+kCA==', '1991-10-02', 'fe6eb1ce1527dc0c83721c9ab6b4ed450e44bd024a704fc65e2c5c227ef45464813a9ae1174a06cc79646457af7f280cr6HUv8ruDPfpvYJI86hD4g==', 'Tennessee', '2021-10-03', '', '', '', '', 'Graduated', 'Graduated', 7, 2, 'Transport', 1, 1, 0, '2016-06-15 02:59:18', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(58, 92, 40.671150, -73.915756, 'Kyandra', 'Richardson', 'kyandra919@gmail.com', '3d00ee2a86f62f75e9b8d9abd3de5902e186264c9294378b6e72b131cad7d0e967d788343960240d922531feb4dcd57bhH+7c4f4tMl460fj/4QlWBzdFn1FmFovbX/zaLj5MWE=', 'Brooklyn', 'New York', '11233', '3475819741', 0, '', '', 'fe007e5fa1957e97dc46d9a8edc005daf99033c4b954a97ae37cdd25ba1946dd71b2d85c5a70565979d0798061845965arPFfldD2LCnQitSFUjqxQ==', '0000-00-00', 'e81dbc846a59796521025172c33f14af61b2a3fec160fd2323285bd6929d9dc4407ce8d8a404cf2a41a574ceaa928dceX6pWA1iTSttlYzKS1kcOeg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(59, 93, 42.212193, -71.036499, 'Zelmia', 'Harvey', 'kimera.draven@gmail.com', 'cf7724a30cd3f31fd105369dbaba566a36f4f582ee60882313710d21dcf2fa3b5e03461254b584b5b24606f0b731f2f8rrBYiQwsr4qrWNnBVpC+uw==', 'randolph', 'Massachusetts', '02368', '7815100227', 0, '', 'Zelmia Ameera Harvey', '781a0c0c054069633a765a45d155ae485f8003fc5eb9fa45defcf59cf33b3e986f989814c58eecc37f4164606a8f43b5UeaUg3K6OPNLSi3zODsuhA==', '1987-11-15', '6c188bb9a3afb7befac896f4d1ce6210f2054a496b298dbed7d1c77536e7252ebfa0f9da4d32a283e3302e167a000008idVfNofKEJOJoFehG0a+dQ==', 'Massachusetts', '2017-11-16', '', '', '', '', 'Graduated', 'Graduated', 5, 2, 'Transport', 1, 1, 0, '2016-06-15 08:54:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(60, 94, 40.756351, -73.909332, 'Jasmin', 'Rodriguez', 'jasminvrodriguez@outlook.com', 'e4bba1b72c87925977bf5b453c75cd597556328f251de8fe0224ed1fe2c3f58dd16b27b3accfaf9e3e3f11caeb080f18BY2D20kALiqb1xm1pEK8IIIK2e03+LhneiU7bZRd1i4=', 'Woodside', 'New York', '11377', '3472170160', 0, '', 'Jasmin V Rodriguez', 'c45da5706a2d84eb58d2ae724bea9e6969bcc6aa06ed4df7eedfb5d52528e2528ce2f26e6ea256f61b51db88dab3e9985CBnp69ztW6nguMsa9wUTA==', '1991-10-02', 'b21afa056bc352f5cf68e82d17dd42fa1bab1165722da5eddcef47168f916eb975a264a6c753b63a6a1186e5d09af120h4QIL0xGIRnKUrO8+zc1Aw==', 'New York', '2022-10-02', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Transport', 1, 1, 0, '2016-06-16 15:51:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(61, 96, 34.088638, -118.291252, 'Jonathan', 'Shelton', 'jshelton85@gmail.com', '27367a10fc26f9dc3cbeeac26ca2514798d1ef3401cd8e10ed3a4de6e39b5bf363795b939aeda77eb65b2047a7466b7dw+ds1My93lj5ICyUgqdfNJpl3qWTh+X/4hSw06Fdkqk=', 'Los Angeles', 'California', '90029', '2132801920', 0, '', 'Jonathan Lee Shelton', '3924f0ff7a814d312da990007cbe467e7fa656ee027b709616eb23c7dec66da903bbefda861b37f8d6e89d883f184a2250EVDGgadJyfREBeGiGGFg==', '1985-04-24', '7d60491e5a2004f2b0290a02a1ceaed58b1c1a46ada52e7eb54b84127365834fca530cf4693d1d5ae092c9fab50ea552OZP8JR+mWvxQU7fHN3RBFg==', 'California', '2020-04-24', '', '', '', '', 'Graduated', 'Attended', 14, 5, 'Transport', 1, 1, 0, '2016-06-15 12:05:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(62, 97, 0.000000, 0.000000, 'Kary', 'Hudson', 'Karyh92@gmail.com', '34ab1e8028d1ff025b035a2769c8d3e9ec85e16672ff15dca74f491a3fe21a006cbfe598c01be3ac27be5d96b0b244654rRrCCw0suxIByBQ4JGH8PHTVe849hUfNDjAjlZhGrk=', 'Brooklyn', 'New York', '11203', '9177547685', 0, '', 'Kary Andre Hudson', '1ce6b4ddcab7fe70d76c8d98480a8cd3d7229aedef8a8fdc3571226e8affe6de1bd8096a9beeb9fc61a44db1879fcdbed0WnecG0L7nRXbKP6Q0RGQ==', '1992-03-07', '540d089d7bcdc7077b9efe4672537c2c38f7cc68049275a94301d95f6b8e9727d4d0c4c701eabb370de1c8dbd2597239klRpaiHH0rF/UTojMWiCVQ==', 'New York', '2023-03-08', '', '', '', '', 'Attended', 'Attended', 9, 6, 'Transport', 1, 1, 0, '2016-06-15 16:21:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(63, 100, 34.172703, -118.367485, 'Jeff', 'Lazelle', 'jefflazelle@gmail.com', '56e100b65b1f6a0cec6586831360a39ebd3efa5c097233f69bfcae5eddbbabe6d28c316269ce81e19ae77bc8707ce67fo4+yqQOGLhPieKH98z3lXRsfEtrHgnpWjtIkdn5fkio=', 'North Hollywood', 'California', '91601', '3235921641', 0, '', 'Jeffrey Adam Lazelle', 'fa4b0dff4e14e011f08f2dc618043dd0f7d97b1261d5b50d8a476cec70462019ee76e468465f31b7771aa9abbca38858/81kZgjUH5+yWVHA8IKCOQ==', '1989-01-03', '28cefaf483195cd1e14dd43bcfd1081b7bcf5e04e51d7f8ca61def21f693e2523d1fad36d4e48f2aee9c793ca88b72a4TBUbbHnHYP9lwfuAtpvGsA==', 'California', '2020-01-03', '', '', '', '', 'Graduated', 'Graduated', 1, 1, 'Transport', 1, 1, 0, '2016-06-15 19:58:27', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(64, 99, 33.929359, -118.200256, 'Lisa', 'Willis', 'michell_willis64@yahoo.com', 'cbd8a08da651715e328deb1ee2916ba733c51c826a8228cfd188d6a3538f5bc70cd74bd9043a7f12abd3ae47341701d3pXkxgb6S0Yo3M9usGa7Z3h/oXSeP21NuQuKPMZtMmhY=', 'Lynwood', 'California', '90262', '4242326790', 0, '', 'Lisa Michell Willis', '6c6d7b152ce668606163347980bd0d0ebe2f1540dbb4bda5097b94a80d06d658ed9ff848d0aa23748eea877552307d76fgc7XtZ+KDAZcN2/u8tokw==', '1964-03-30', '9ea17f76667c3be59890a897d16fe47c0736c024734333c15dfd52727eea0ec049b2bc9844652b2e56a1408c091d4576rXUxdL51VHKe4EfMLDKDpA==', 'California', '2016-06-15', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Transport', 1, 1, 0, '2016-06-15 20:17:53', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(65, 102, 33.863052, -118.352798, 'Paulina', 'Tamayo', 'paulinaadrian917@yahoo.com', '000f734f4c05cc4aa128bc712791e83365b9d088510bdd662b12e452533a5a618e1016f5c8cc17020f915b121d3d59a3sopNIXJM7zjpDsZzRBSHmfmWLJ3JNSI3CcVjF1StlUQ=', 'los angeles', 'California', '90059', '5624517983', 0, '', '', '5315a91fd7dc0fecd11235fc3afd99992bdc5f28c7be0f5e00bd70c9ec710022f62c8e2987f22dbd65972e0e01e90c82I88w0X21KWKXZ6IyPym87A==', '0000-00-00', '7c238b29c8c6e1a3a6127b8c794281c830bc19db3dc1eac8140abd9a393c35a16298a90cbc85551cdbc53be2fa04a6bdfXpRdpOYX9Ho4BKIvcMZIw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(66, 103, 34.204685, -118.446358, 'Nicholas', 'Kasule', 'kasule23n@gmail.com', 'cbca940f703c991dd06154bf8a0106cc5a80c2d3d5a4d809bc3e4bd420e08ed96f65e333870bba8aa923b51c3089997ev1VfwqBF98qdvLGoB5UduK+f7aLLY6/ORA/SEe0UN+4=', 'Van nuys', 'California', '91405', '4242139725', 0, '', '', 'db8f81e865289c059bd8707e4820594a2048f9742c3faa0ef27e81bb7db2e55dace314730cee589722dbf6b2488e4ed2Rz5uKNtuZP63F0J+GgTrGw==', '0000-00-00', '0c661315e514d85c71de18050f9422713d2c04007ff2d651916c1d66a6c7bbd3dff85d480c84a0481eb7172bd39f7c8clvr6oHlilUCrWV4vcEUkqA==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0);
INSERT INTO `qProvider` (`qId`, `userId`, `currentLat`, `currentLong`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipCode`, `mobile`, `isMobileVerified`, `mobileVerificationCode`, `nameOnDL`, `socialSecurityNo`, `dateOfBirth`, `dlNo`, `dlState`, `dateOfDlExpiration`, `highSchoolName`, `highSchoolCity`, `highSchoolState`, `highSchoolYOGrad`, `hsInfo`, `collegeInfo`, `totalYearOfProfExp`, `personalAssistantExp`, `roleOfQ`, `isStateDisclouserAcknowledged`, `isBackgroundCheckAuthorized`, `isQVerified`, `registrationDate`, `isQOnline`, `registrationStepCompleted`, `TotalRequestCompleted`, `TotalPaymentReceived`, `qBankAccountNumber`, `qStripeId`, `qStripeBankTokenId`, `qStripeBankId`, `isPerformingRequest`, `LastRequestSent`, `isDeleted`) VALUES
(67, 104, 40.839348, -73.864784, 'Maria', 'Caraballo', 'aradia097@gmail.com', '37b2e209ddd94b06eb4aff7c3a979c914f78609d830136df9c875097eadb6a29df6697093f78cf4afc6775af33a30d27umG9RVfCxGI2cLTtwYjz4/MTASbjhN/lGK+EDv2tEcg=', 'Bronx', 'New York', '10460', '3475206899', 0, '', '', '74181e0d3128b54c2a6695607cbbd5fa9826f4a7467a253a0b1d055a29c12b495eb7a3a7e332458f40ac2285c1076c0bBcMWe4zmfQ1HJep9sK2pVg==', '0000-00-00', '71f4cac80c4b48f50582208fbad174bb97c52bea9888c4f57879e0591a53035727d876976b574d23b8d04470932d0ae6kPb142aZps59860Uvx2cRg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(68, 107, 34.087547, -118.385895, 'Nathan', 'Fisher', 'nateafisher@gmail.com', 'd601fd1d7219426f4938f6f187187995d6c7cae223c63ed9b678812836dacc2dcf07c091828766c2862d9e4aeef4cbd6VH++RkY1hCZzeqLv1WSVM+rHVVn9ey6JEVxMZ2SLWfA=', 'West Hollywood', 'California', '90069', '3236202111', 0, '', 'Nathan Allen Fisher', '50093ad563b1b12f59d3486a5158500f6b7be7cad3816a6c50e3f35e06d446d4bbae1a7eb586296de2a783ee712ac7d61In4CAtjgnp3k/kKrBGKMw==', '1984-06-24', 'f295e9e1e99106bb56ca3fcbe1659658d3c024d8b3ac31e84d1e6e2eb6e4b0f96d86468353068164abe221493a448366fgvirSA3lLOqyIb2GOYKSQ==', 'California', '2019-06-24', '', '', '', '', 'Attended', 'Attended', 6, 6, 'Transport', 1, 1, 0, '2016-06-16 05:13:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(69, 108, 33.850815, -84.368019, 'Victoria', 'Graham', 'jvgraham2014@gmail.com', '90c375b39c9cd60131e3fb2a847a08c3a52f11f0a497687d89e8505b87f4c8b1df02262c49b7bfe59846ff13352a8dfbc5MZXfnbAlGbrAXVWfk2RDCR4V5+/wadWRo7W0+mzZQ=', 'Roswell ', 'Armed Forces Americas', '30075', '6787554500', 0, '', 'Victoria LisaRuth  craft perez', '925acb5b7da8482d8389f06089ac60a365eb5dce6000d33f58c00f4d17e491e0ce0d5cf9fe5ebf94b3bc27adcc3343e92m4awjH3SPu9hRqAQ4c49g==', '1994-09-07', 'abee5367bc239ca1272943d4fda93234929aab2108bb29836f4b41015c3778d18febfe820ae6ed415b1217e14bb25b71uT/Ga1/e0Y+H63QSM7K66Q==', 'Armed Forces Americas', '2023-09-09', '', '', '', '', 'Graduated', 'Attended', 1, 1, 'Transport', 1, 1, 0, '2016-06-16 07:25:45', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(70, 109, 0.000000, 0.000000, 'Ciera', 'Crossling', 'cieracrossling@gmail.com', 'd9560c871803b48e515e077dd29e7046e2330f534a68a55dbc77531256fac1af990b2389da25fee61fd996fb22755fcfpFOETrVvukf9PDOwS2OK+g==', 'los angeles', 'California', '90002', '4437864318', 0, '', 'Ciera Gene Crossling', '293a649fe721952e23a8a688437cf8527f96185afa9a8febfdfe5dfdedad7eb32a94c68ca537160df6bf7a6a6cbd750eHesloPo2xKD7H1yZIHaSNw==', '1988-01-28', '018113ce729f95761ea512c25bb0225b0a93fa9bec5eeba68acbf7ca960bd33b3708b27f68c39db825a6903d05224e75/5nSfLYWUT3eSb8hv6HY1g==', 'Maryland', '2018-01-29', '', '', '', '', 'Graduated', 'Attended', 7, 7, 'Transport', 1, 1, 0, '2016-06-16 09:52:59', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(71, 110, 42.365501, -71.103722, 'Whitney', 'Pensinger', 'whitneypensinger@gmail.com', 'a9653d550d94060a46798ef14377c6dcf0d1b2de6844ee6304dab00219f23a7992c2e01eafd7f078e131cd019f3225c5RvtNAgIFKyvSYp1vTVukpQTionvh49nudEVnfvbOGbs=', 'cambridge ', 'Massachusetts', '02140', '6179453117', 0, '', 'Whitney C Pensinger', '2d1d56e2c5c098107e96915ffbaa63f4232edfa0f6f02d831022c62554e1e82ac96dda0d5961855812ebe4efe23e5d24oMZZgPLpu8MkmlQhEqSy3g==', '1986-05-22', '5349a0d89eb4e3558e6270b80863e5bfdc00df25d07ce25fd02472fd8e8457112304a2612d804f3bede5871b1d7fb3cfAfbVz3T5hM1xx8mWvjLLug==', 'Massachusetts', '2017-05-22', '', '', '', '', 'Graduated', 'Graduated', 12, 1, 'Transport', 1, 1, 0, '2016-06-16 10:16:22', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(72, 106, 33.930279, -84.348526, 'Tyechia', 'Spann', 'tyspann82@yahoo.com', '79888be35c82214fc8c186feb33730837144eb7001c04fe544a03d0d29ef95e09093dab20a554d064450a6368544a0e65RecRIyHmN0EJHL2qwExpQ==', 'Austell', 'Georgia', '30106', '4042002525', 0, '', 'Tyechia N Spann', '8478973cdade9ea505e6461cfe1f01825139c2a6683272c382608fc52ad3de394d81fa9018193e94361a414512cfb835IYrDsA4GX3P1cr2apOvDTg==', '1982-10-03', '9e227e393583dd6c24a44815692454314d5d8b57ac95c1ae1adc0b2d28eb6b415665be610e4d30f9b9a04368a0d9d035VGd3eaud9X9B6WTXhuYUUg==', 'Georgia', '2022-10-03', '', '', '', '', 'Graduated', 'Graduated', 9, 3, 'Transport , Anything else', 1, 1, 0, '2016-06-16 16:52:29', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(73, 117, 34.106236, -118.463425, 'Felix', 'Odigie ', 'felix@myqapp.com', '49302270eb81b2a4f3c8cc50640ae52e16dd257aed74f85ab7bdafb8a9d26d1fb962f8c8f3750bc560f6aa468096906bk4Qc/fSz1MdJ+KH8ell0/jz5ZiO9I7DKCZG8f+IeRuY=', 'Los Angeles ', 'Armed Forces Americas', '90077', '2104644634', 0, '', 'Felix Odigie', '18eeb01c906a6247e0d6df462d446d78581ae2c508f8222370c9b47a723ae492e43073b4e7cfe9ddaf53b05b3fdd9fecjzMGtgPRx353feQTLEY/Vw==', '1976-10-01', '1597f1d1c9c978245007980edd884858469ffd702ab0fa7ed58f74407ac46882b3e3986b7235be031da77b0574794db8K8obwyvlg9fz0kAESpfaMw==', 'Armed Forces Americas', '2022-10-03', '', '', '', '', 'Graduated', 'Graduated', 5, 6, 'Transport , Anything else', 1, 1, 0, '2016-06-16 14:50:45', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(74, 115, 34.215473, -118.598007, 'Zeinab', 'Golbaz', 'asal.golbaz@gmail.com', 'c495e89b3f61b7aae99a69ff6fbae4b47d753d2899255c0441787459f6c462bc111af2ac4f782561b879a64f12c6de4cW6UgkYPtV18Vultn+wGGGvg9t6k4Ek5Xqoh+LGQS89Q=', 'west Hills', 'California', '91307', '8187939840', 0, '', '', 'b3ed19de053f405e09a6467023c636b9a6c11eef31d46cf9ccc3314442228535af6c96e0c3979a94843f3bf2d3a658d8MQqCeD9FE2q22n8YvmHVeQ==', '0000-00-00', 'ff0d42c9ef565d41b6104856538160055b6c5f9beac7d03b55113f0638905de6a764a719e0bbe28cc2bb9e0b768346456mCTYEI6XJzg+EDk7Frv8g==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(75, 119, 34.212814, -118.387390, 'Daniela', 'Lopez', 'danielaylopez02@gmail.com', '9124b88b4ea52c302efff2b530be10c396a79b3b2a227ba0c525b0413536609d916c424e35148e35cd410b094b172ba1vpBVfjSMBNDEyqGLA/7aOCjmS/DP1uIjq6o1u7SevoA=', 'North Hollywood ', 'California', '91605', '8185682927', 0, '', 'Daniela Yocelyn Lopez', '8959bf1354edb6919001b10830a6c62cc0d9dd2b0077482adeea0af1a9072ebd01ce66eabc4a46f84ef3725f45d0f6afDe6Cmw/XoojRO3aVsIN62w==', '1992-08-06', 'd155a7206a828749b64c1c331029c95b84a5efc00b9d959218b811815e313d40889aa3267c876d49641691e156b9e169MsR3diu8hCKPpgYFXGiLEQ==', 'California', '2016-08-06', '', '', '', '', 'Graduated', 'Attended', 5, 5, 'Transport', 1, 1, 0, '2016-06-16 20:04:16', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(76, 120, 33.972263, -118.261749, 'Shaharazaad', 'Carter', 'shaharazaadc92@gmail.com', '5b035ae1153fb61475499a6c22714d2937cb69deff66dfd76c2478fab25226611e4f1313178c6b9fe59259f58218ef2cB+ADOcT6g9xKGmanuZLtdw==', 'Los Angeles', 'California', '90001', '3238843496', 0, '', 'Shaharazaad Evalena Carter', 'b0748885cc1543a1117a99949dc3b410a45e11b53fc74e4b8b4af4b101d6d250df54930bd21c04d07ba6d92b2baf81507jLdWKIqBb54bZABQpUc0g==', '1992-05-15', '4575a204c54250ee5e56e45812f2c11b7b28afbd0423dacb81653112e0df53bd0f23cbca18fbbf70e93821b836c71327QnqmI6QUlvgu8IAMQx7APw==', 'California', '2020-05-16', '', '', '', '', 'Graduated', 'Attended', 11, 1, 'Transport', 1, 1, 0, '2016-06-16 21:52:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(77, 123, 33.785896, -84.400406, 'Tiana', 'Pope', 'tianapope7@yahoo.com', 'c8b50b24dcc3d934cb28000f77e84529189e8755893bb52f67e3c3b59af11aad8a66f40c7cc304271eede231423fc9507SktM9iB1/uA1kdRCmKq1OCj1jRhCL2WydAO67i9MgU=', 'Atlanta ', 'Georgia', '30315', '4043122186', 0, '', 'Tiana A Pope', '9f6271132148b7983bd73ffa614e02bff18c1377d933db7915ac474bbcd5cedf640670178737be664ceffbe2fda2ffe9uryhKZw/v3hXzpFC+I+I5g==', '1989-01-06', '8b22507b503f0eeeea01b51401c380b136e3be83209bd8da9a136507d6e45f690852a1b69c5f18a89af3f6c45b579439iVAXI9h9syDvqftuKOc2vw==', 'Georgia', '2019-01-07', '', '', '', '', 'Graduated', 'Attended', 11, 8, 'Transport', 1, 1, 0, '2016-06-16 21:54:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(78, 111, 40.741043, -73.639236, 'Christine', 'Thomas', 'kristine318@me.com', '7ae9722df069b7ffbd29e1158301eeae7f13dd474e5db174c69c595f5dc829c7c1eca55b618dcc610ddaa97ddab65350PbldFBK+jjdj528f7XcFlj/1LxFVbE5ba+/mtTHuwQg=', 'marietta', 'Georgia', '30030', '6788365439', 0, '', 'Christine Mckenzie Thomas', '2abd72f1b306798c263c1338a4821dcf2a4d8504cc746f2eb5172ed13093609c9454487b033422567cbcf71bd44fe963pPuGXbvgx1GLVMG+JtFK0w==', '1993-03-17', '4f1a20968777e2d0b65aceb6654ccc57beb9e25900e4731dc498f547aff8793bbbb25ed2626bbce8903d63c578a2921dT8krAiKny3H2BZvybwqaNA==', 'Georgia', '1993-03-18', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-17 07:41:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(79, 124, 33.513344, -84.220177, 'Machella', 'Anthony', 'manthony2007@yahoo.com', '7ca63857a63e062492ee71bf755a8e2fbc9b2b795764c661744b7814c1951207c0482b58e64677805c0308ad6e32719dM/SW/JjC+8Dldj3is+6AmK7Qzxw3Y7eJIIioEPatTCA=', 'Griffin ', 'Georgia', '30223', '6785884574', 0, '', 'Machella  Anthony ', '3d3cc34c65f3dfe9f4da99bde7d7660f0761af3e0d4ff2255342c569ee8239d8f1f13e1930a8259e3d2c16e2e24a92b0RW3gmiFZW2/07Xk1gDTDrQ==', '1989-07-28', 'a721ca7dd3ddcae954c610a1d75f47560bbb41685427f1517b0da0da1acbde363ae6e9a0997299dbdb322ec4dac84f36cG9wxzpOBiTYz4B1SsjGgg==', 'Georgia', '2018-07-28', '', '', '', '', 'Graduated', 'Graduated', 16, 3, 'Transport', 1, 1, 0, '2016-06-17 10:26:22', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(80, 126, 34.580261, -118.057587, 'Tarian', 'Bullock', 't.bullock@lafilm.edu', 'c0b1a27246de0e3703dad5921b0910ab38c962d477181ac5149f731b634fa5604e941ca94480d2e6054fc8ad090c3f6esNcvvNnYXJDf522kj8uXDQyW42GF3mwnnxxtu+xlA+g=', 'lancaster ', 'California', '93534', '6616747084', 0, '', 'Tarian B Bullock', '75798b4e5e39b14bb1e1c4cbf3bfb0598e1ca231c6b9fd87e2cb4ffaa23042d7017e6405af386cdb9f6fae387fcf0383CDJwnTLmjPm6FF+RpoFfOw==', '1994-08-18', '4fedf42e79b09e939e955bd11ec112a5394f8f62f7a91118fdc22cb29b836d3af498abe4b7163574812ed25e61b58902ollihoI1+KDD9fkX15gEEw==', 'California', '2019-08-18', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport', 1, 1, 0, '2016-06-17 14:13:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(81, 127, 34.106346, -118.463867, 'Aliyah', 'Burroughs', 'burroughsaliyah@yahoo.com', '2af932391a5f1b5fc717092e9b35d8c2b2986d15d09e94e5a89a5a9575a770e16af2fc3bbd63bbff8783de5cb94fac15zDwdJ85lMew6101T3DcHlhsTdErZEx+g8c6as7JWrZc=', 'sugar hill', 'Georgia', '30518', '2145859419', 0, '', 'Aliyah Nicole Burroughs', 'c32f7280088659eadde94fb8af87b04444748b8900635c73dce56684a71a9a6d5e69f8912200c4ec628bc96bacd8c24f+wKbogMkIN6djn2AMkZ9dw==', '1994-09-11', 'e104b943d6a87e95775a62eaf314fa7fe707bb40e36fc50d1665dddc58f6d3f7797571a75b294d76bde6b021d163bb68Zt7GJXO5kSqWvsdVpzJDPQ==', 'Georgia', '2018-09-11', '', '', '', '', 'Graduated', 'Attended', 4, 0, 'Transport', 1, 1, 0, '2016-06-17 17:10:33', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(82, 132, 33.966782, -118.248917, 'Jannai', 'Calderon', 'jannaicalderon@ymail.com', '7831c4db7bf2916667ee1dc7ddf2fea2c9c4371849de8e7fe4fddedaf3f1b1395ba6faad55b708620154ccd82e6437afcL3r2foAorXtfx64ka4LcDsXmmFTBMis8Y8y4BtWOs4=', 'Los Angeles', 'California', '90001', '3234121141', 0, '', '', 'a656f89c8bc99015eb5d70936c62da6118d1664b8b7894e39a9a61d73442b0f4d5a3d50c4aa55f30519ae4ac49d70685sTfU0IiTxH6Xuq0L5CVmvg==', '0000-00-00', '13dc35fb4f02b2936e0ee841846e5bbeb9102c1b4ba479af21e3cc191feabc49c14cfe2ce0fd8aadee337ee8ed7408dbOU1ybPPAqFPjkZuOBuDPpQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(83, 134, 42.515892, -71.033157, 'Stephanie', 'Breen', 'SAB934@gmail.com', 'db697f64e709105e357c4d79a1470c66b070cfa8ee6f91c5866f3825a5efc306b7e10c5d6debaa60058a62096c757271YhVn0YEEtyp3kNEqrUB+BA==', 'Salem', 'New Hampshire', '03079', '6034016617', 0, '', 'Stephanie A Breen', '80f0e4f976c91eb97f11c1a0295b7537c5b67708cd45fd5b8eb1ddcce79035e447c59786922fd309af78310efab60976obNnkcKngyusDV/Vt67KTA==', '1992-04-10', '048d4a1a4f257a9948b3e452413cc714d6e9e8fe8a6404b5926c008daf13873bc92b286726e60b16ca3e5dcc818c43d4PUmmXmGgQGhPNXNONExPYg==', 'New Hampshire', '2018-04-11', '', '', '', '', 'Attended', 'Attended', 8, 1, 'Transport', 1, 1, 0, '2016-06-17 18:42:15', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(84, 135, 42.345516, -71.088173, 'Perry ', 'Wade ', 'pwade16@gmail.com', '945f43392682533a25973d1c77728ab033f051fd59151794e454d10cbc081dd00521accaa8519a331c89a917ab8f7dddDo4cIqOOi4wv8fyF2rh7/DaG+OJinLXEes+gzEGM5xg=', 'Boston ', 'Massachusetts', '02115', '8573338308', 0, '', 'Perry  Wade', 'aa072a2ffeccdccc6028bc59438acf81dd4a05c2931ba4f0a4a709827fe015ca55d66f29dd3cd612350d314fb1e99f65CxhNUeGXuszhopkPktpS/Q==', '1989-07-05', '934e08282eded9f72a70d1ef53df36c92a53306d07b3cb6a0cc5ff17bfc860993fa4d68333978caab176452341b80609mv+lAsI08GcJHS2OHVBPnA==', 'Massachusetts', '2019-07-05', '', '', '', '', 'Graduated', 'Attended', 8, 0, 'Transport', 1, 1, 0, '2016-06-17 19:40:14', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(85, 116, 34.145626, -118.370674, 'Nicholas', 'Ruck', 'ruck.nick@gmail.com', 'c421da9c73887abc561496740bc078d208285c9181115d5959f4c49d8b8ac5bb116d4875171bdf28a6a5e21a81846cbbd9kSuhBqoJlYHlDz8f3y/in1mvP7+QJdc1k7gdmZBEc=', 'los angeles', 'California', '91602', '9197706024', 0, '', 'Nicholas Robin Ruck', 'e3cdd691d601bd7237757a21430b0f3dc2cf29e4ce939141119ace6afa22ddf477c940c2b066fc8854316f0a49f09c35QdA9NxIgHnXB+Fl+uuULqg==', '1992-04-25', '6bd3efe5755e2bd6fa42d3a1d83a3da2659a4f53e3498e70a8d4f1f23127e60202534c32493f125fa88c084ebbad1bc6RDwDHUA/XyLU47iBv/A+rA==', 'California', '2020-04-25', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport', 1, 1, 0, '2016-06-18 00:57:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(86, 136, 34.058834, -118.293434, 'Amber', 'Guidry', 'AmbercadeG@gmail.com', '270c786458f86a8a374b6e773bf8097f4493aa62a60a3a2f3b483d62ca8fae6f98a2bca623e4892ec5483bc73341234cjULxPpCzo4n/oFYGYcyKRQ9LuAr76vo3XOcLjBimA9I=', 'los angeles', 'California', '90005', '9162302551', 0, '', 'Amber Cade Guidry', '7eedbf0b567aa875352beff49397519f7afc1c7e3ef4dc5f29f6faf16b92577848771b9fbdccb5e9a77b11e6f1be73a2LfBcb2VDRxoqJfv7HZsj0w==', '1993-04-18', '1a628647beb8851552348aaec28a9ed50ecc98bf923932cb48b9537681208f256a82b943e0f611bd52735d7450da4b87Sq/dl/wuHgHOKIAdFvSl7Q==', 'California', '2021-04-19', '', '', '', '', 'Graduated', 'Attended', 5, 2, 'Transport', 1, 1, 0, '2016-06-19 10:53:56', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(87, 137, 42.292675, -71.051941, 'Yulimar', 'Andrades Cordova ', 'yuls2000@hotmail.com', '6ea6e7c323f6e558714678867369f6ccfa436da5b5a7c72a7d8e1a9cff8c93fd47895df6b6784ff70c8c676e2ad38d0fqcREL23in85TVzPJXTodfRX7de48Vq5LPDjOGxJzI2I=', 'dorchester', 'Massachusetts', '02122', '8579910489', 0, '', 'Yulimar Andrades cordova', '1f178d1a712ec5b6603d9dedf4ee44d3a875e3365c5414bf2f01241d7bbf66425efcfdba60df2350c588b109a0568a16Oow+JUGzPdUcZYlXsT294Q==', '1986-10-03', '72d34a7c74f0405ba359673f7fda19e3504daf5e1ec7bb3c003fb0df5bb8d2b9bbf7db9366727967891d76a7e0aba4c7NG4KHYWkxLHKYXIiSI+bYQ==', 'Massachusetts', '2018-10-03', '', '', '', '', 'Graduated', 'Attended', 8, 3, 'Transport , Anything else', 1, 1, 0, '2016-06-18 06:04:31', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(88, 133, 40.589638, -73.806633, 'Felicia', 'Reed', 'feliciareeed12@gmail.com', '0f8e62ebfb206e2e981475884ed431d113c5235a336085684dc8ac7c8890c625044396253cda2bc62e3d06e5a7a52065gWKVFZJA4p8m7LzyFzs/UPTMc3k4BfWXlxrdzMomm2M=', 'queens ', 'New York', '11693', '3478588329', 0, '', 'Felicia Charlotte  Reed', '639842e81b0774f50def68fa911359c536571722f402aea86d59000ab52af30edfe0d9be0c3d5e83cf656d7a4dface2cwO4p9FMoaMFKgahOJb7/aA==', '1998-04-09', 'd79ec694012d8c60a9f37988b1888d889c3d54fbce1709cb5979356023d0e30bed05b2b2ee00d19289841bc6449ca5efpQce2whc9JM0EHVzm2qXJw==', 'New York', '2019-04-09', '', '', '', '', 'Attended', 'Attended', 0, 0, 'Transport', 1, 1, 0, '2016-06-18 07:44:28', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(89, 139, 40.833416, -73.888474, 'Brittney', 'Jackson', 'b.jackson1390@icloud.com', 'e345e279f4f98eff7089a2a5b929662cff0dcf70f032faa77a36349022b4a586a6f4e094bfc0b0435e714058594e908494RULQsh64hSgrzO5wXe1ucHOlKIZ7+FJYiUgcOlXBU=', 'Bronx', 'New York', '10460', '6466205308', 0, '', 'Brittney Denise Jackson', 'fbdf1ee2fb5e74a98770e7bf0604d604ca4c3b052f29bef2a5c90f3e03cde9fc5fee0fb221726caee74fa4341991a58aZsVQM4brrF+h23bKaefjLA==', '1990-01-12', '55299bfabb6892712128f291fb1ae9a2ddab5f3427a1ffc2b4b0794b5320932b3f9a9f321cae75afb0fe987426f056e3aVYlOB+pMs5KXdLE+Evz8w==', 'New York', '1990-01-13', '', '', '', '', 'Attended', 'Attended', 10, 1, 'Transport', 1, 1, 0, '2016-06-18 11:26:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(90, 142, 34.065895, -118.408554, 'Shaina', 'Lavine', 'shainarlavine3@gmail.com', 'e8a867cc0ffcc057b61df6f3664bd9d79f183154648bdc2af3b04d76b29077dd010c4651826a72c139a53b0e4e3c82a0Rfm/Gu7msD8RD251WEJNTpxLAddTZivalRRuVNfElwI=', 'Beverly Hills', 'California', '92679', '9492915650', 0, '', 'Shaina Rachel Lavine', '1d39012ca9f6f90da5480cdd849b37b4732fa7453cc49533010477de94697c32cdc924f43f305c6e4c95a9b156ddb61aRqGPZ9CCh2W7crrb/qz1Rg==', '1995-12-23', '634aaf18f281a5c9e005fd4a2beebc2aaaa184f0ccc98ac9e19546ff429aefac827992bacb3be1cf9e1e8861b71f85ca0EtDbZVoUWdSqp4bEUfDzA==', 'California', '2017-12-23', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Transport', 1, 1, 0, '2016-06-19 22:03:20', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(91, 144, 34.063663, -118.398445, 'Laura', 'Martellino', 'lmartellino@gmail.com', '4fd466245c641d261b9afb34dc92ff6ffd3cc5aea14779f92b80f635136cd50d8aa5cfa70d317897a1c6307c65a38626f4vcoqoZJAEO3EThGJ/kizX70HvII2F3KrieUyMRRus=', 'los angeles ', 'California', '90212', '4018553322', 0, '', 'Laura Jane Martellino', 'a0533bb5dfb8dd763590dd0fe3539ba006d117d78249558f3b74ca687094196143691a4f7c60c144d73c3a99f68ef65c3WiETxBt4qjFTTKwDGJgyw==', '1988-02-26', '55911fffe62265684981f488c19aed7154dd046581654bb6c69f66bc2e4a01bc1e470b53b9c6dbe613334a1bb78a96f3CjtgybgezUO0meswbfyDww==', 'Connecticut', '2018-02-26', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Transport,Anything else', 1, 1, 0, '2016-06-19 15:19:21', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(92, 145, 40.826881, -73.130310, 'Esther', 'Lenderman', 'Estherlenderman@yahoo.com', '410c17654cad51ee0a8e3615170b97acb9d501c65b1f7ce52f12bfb33f95e99119e4da8013d8d7260c06fec8676334d6W2x8V+gwL1VKmYugRFiH7g==', 'Ronkonkoma', 'New York', '11779', '6314137352', 0, '', 'Esther Malka Lenderman', 'a19c87a2e1ac4b1e827a30f395eef1cae41f327783b6f23dec8a1204289d1893e78e1d3f93b4bddee59a6db28eccb30fmUixDXXstGnJzYgK3Itc0w==', '1992-09-11', '0ec487c0bbb2fe80c936ba609af4917d243e70bf2c9cb4216f30d9d9ef2f037e921f423393c924c72d6bc0451df06039aAK+Kcmf5yEdyfozjL2TwA==', 'New York', '2021-09-12', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport,Anything else', 1, 1, 0, '2016-06-19 16:14:24', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(93, 146, 0.000000, 0.000000, 'Pamela', 'Towner', 'cr8nheat1@yahoo.com', '5e825fdef383f09a83be1f43c67a52f502b1606f6004dbd95fe71d92ff8045f66a576104cfcb4acfbc29a3526b35decebamYJHpnHbMFIvrYE6HXUFZzFWMdzY/t80GMHNBTxLQ=', 'chino', 'California', '91708', '6613130073', 0, '', 'Pamela Lynette Towner', '47f6e5fb963453e6771c98ecda109dc96a26eb08517d6fb341fb6b22ff82029ecd191602429bf3b00ea5be13fc42d7a4yeFi5LeLAuo9VCOMLFxvQA==', '1968-02-19', '48251731751a3b2cedddaa67e1db7418ff8c98628b52b7b44a020ca5ccf3af76ed0db2418d17268173a1400f97c36d99vONSEeN5DYByIl/ZL70cUw==', 'California', '2021-02-20', '', '', '', '', 'Graduated', 'Attended', 25, 2, 'Transport', 1, 1, 0, '2016-06-19 21:07:18', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(94, 147, 40.671803, -73.906433, 'Tranise', 'West', 'slimprissi@gmail.com', 'cf82a4a8e0faefd4d4178b799aa651190e1fd8fcfdb403a47880199dc974566f05cda5bb5a831cefbe1c0e863ca6a15fo5HOg/I+cP7i0oyxMsTo47Jvwc87OP7Sj3j53TehZhI=', 'Brooklyn', 'New York', '11212', '5162326116', 0, '', 'Tranise Ratana West', 'c83323761ed337c59843ec710061f7e31e578b33d8af5205a3627344d82677a2cfd61461cb35164512bea75c092ed853f1aoiEo7a5VEGMABSvRxYQ==', '1980-03-17', 'db805606b6eba96b4f67e58f5503903cc2ae97294b8ef8fbed0295359aaf28d1f02021a3617c993228f0133048a29a8dHukPmeuM5N08xSV9EzmTcA==', 'New York', '2020-03-17', '', '', '', '', 'Graduated', 'Attended', 10, 10, 'Transport,Anything else', 1, 1, 0, '2016-06-20 09:09:21', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(95, 148, 34.141758, -118.371849, 'Tiffany', 'Glass', 'lalee2@aol.com', '270c4664bd21e8978cd9f3ce9f83f7e15f976cdd0ebb58322dcbbeaa672bd74845556f23da2a9e95ea3d19379481daa0giQ5I+7CyakwamyzJIAqRiUi/4a/G60m8C/V+lxddiE=', 'Studio City', 'California', '91604', '3107760597', 0, '', 'Tiffany Anne Glass', '9bd2b5fb224acda702bafc617adfb43c2f96673073968838f0777d5e7f99636f1662df003b75d7136c199b202e4b07ebzTRnEXiJb0G5aANdRHAcNg==', '1973-03-19', '5f8e67ad7cee02457d0b46c92696f7bb223cd868afdfaa352b96ec5b7d1a25ec5bbfce8d267eb4bf39edf75f77346d9e185fSt8uogBQT39VvwOjAQ==', 'California', '2020-03-20', '', '', '', '', 'Graduated', 'Graduated', 15, 15, 'Transport', 1, 1, 0, '2016-06-20 09:41:36', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(96, 149, 0.000000, 0.000000, 'Nicholas', 'Oliver', 'nsoliver@outlook.com', '331046b8ea95dd2294f5daf21817bc864c0dbd46103e66b58a25dd7939917efc6b000dd80629408ef6be5c93ff03b57aGiQO1nzDMJc/fW1gAKK2ohnWACZVp9As4YWB68r9VGw=', 'brooklyn', 'New York', '11236', '3472487239', 0, '', 'Nicholas Oliver', '24ef8f404cb001dce443d017dea891123a4ef8f5c7b67492581ad14293a5a05b61347ac0d22768eda774ca75b3bbf7adaW9avCWDUYx6zOjrAkfkSg==', '1994-04-12', '6454215add80e544d2b9488c1a43de5e411b7037ed23b28907ab76d94a8e80b21a7b74b10ad9a7a159232aab7086e3c3Ux8xx7liQIuHwcYYZXP+FQ==', 'Connecticut', '2020-04-12', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Transport', 1, 1, 0, '2016-06-20 11:04:45', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(97, 151, 34.105816, -118.264900, 'Carla', 'Onofri', 'carlaonofri@gmail.com', '922c03947b27a09ae79229e045fa8b7b074149c7a0810069ff724d8db7cf9eb52e42181602f8f60e79abb51312c8a6e3/o0i/gl7R+WfqXq1GgAmC2sVQETOHeHbJfCoIjGllzQ=', 'los angeles ', 'California', '90039', '2134223232', 0, '', 'Carla J Onofri', 'a3a31c87d58496438ee36e85ee9a2dc42d749063fadafdcc62b4b70044e99f542bec245db472a22703eeb48ad2599245cBRLZhkd62RzFQnypaTvlg==', '1983-03-01', 'f61edd83f92f34c9d16a00382c5bb97945e49843b2b632b96f9975472f664285a68bb7ac6d1a401cd67c5265fc1fa653CRI0SJJ4qIrBGyMLczhEpA==', 'California', '2019-03-02', '', '', '', '', 'Attended', 'Attended', 10, 8, 'Transport', 1, 1, 0, '2016-06-20 11:17:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(98, 152, 34.149090, -118.406395, 'Talia', 'Davis', 'talia.ashanti@gmail.com', 'e04d7ac0a42782693d08c89e0d6b7974807092b60e283f93ecc29d8f60deb9795256730f0b54202553df1f86391a9f43IQjyY5MU/8i6S49NME31ZeriVHO3fKWvvapI4IY0AOs=', 'studio city', 'California', '91604', '9725051301', 0, '', 'Talia Ashanti Davis', 'ba9b96c99fe8d00e9166ac8ee3e2d679958d72ccc9d9be6cdbb02141265a647e47e6b5453400a66dd5903580f362679dB57GI7uWHKkQoSFjwefYbQ==', '1991-02-11', 'ee6d006490bd62d31741ce6f4cdf53976ee6d6ea0f748209813849210bc85bd6db29b13f8e0270e10a84e67602543c23WhDYMx42wk/Dd1M71+JiOQ==', 'California', '2020-02-11', '', '', '', '', 'Graduated', 'Graduated', 7, 6, 'Transport', 1, 1, 0, '2016-06-20 12:09:15', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(99, 153, 33.837620, -84.257263, 'ShaQuisha', 'DILLARD', 'sydillard@gmail.com', '3bcd4e6eda8bb2757bfb6a02216338012741a5053f675ae7ceeca94ceaeaf889da26accf6f93ce7b0e4c37d1cf1013e6CtvZ/es7OyeewNvNXwH7YA==', 'Tucker', 'Armed Forces Europe', '30084', '6784128727', 0, '', 'ShaQuisha Yvette Dillard', 'cdc1742c4dc971ae258a10f7146a173b7c9bde58818c71a99e298dc812a8b59e9c7e2a0b27a6734f2bd93978e1f248d14BtiLLOkjAmZ/HjpCSW4GA==', '1979-06-28', '2586f78f76b2fb9007d5ec2625faa15b61402666848688c0980b4ed5c9566f62d8b8da73bb9ef67fbeb80791a9399701WnXv9nWv2qF1tSI9TiV0kA==', 'Georgia', '2020-06-28', '', '', '', '', 'Graduated', 'Attended', 10, 7, 'Anything else', 1, 1, 0, '2016-06-20 13:38:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(100, 154, 40.878647, -73.881348, 'Yasmin ', 'Salah ', 'salamconsulting7@gmail.com', '3a06bcc8454afa6ef514e39d89c8a2b5c5799b44abad2cb001afe428e4079386a052ac2b4b6f877a5b3038549d2368ecS88nhw61wgMvGEz4HwfsN5OtQSb5Q5fzvVg90YBZq8Q=', 'Yonkers ', 'New York', '10704', '2405511111', 0, '', 'Yasmin  Mohammed  Salah ', '1d2a0f671a84d337a088477d3187cb081175f11b666f9d0382ef4158fbb39695e3a1d3d51740b3675e9a74e9dc319b2cNwRT9ony9RK9spb97o0uug==', '2016-06-26', '7ce88792eb5d1b46dd02d4e17589307ca6f06f3a4b99b06b6c8d5cb235fea209b78727fc56555b991c322b94e6c1ffe9e/5816CJ+ZbHC1ryRAZl9qn+V43r79iAR64317LApy8=', 'New Jersey', '2019-10-31', '', '', '', '', 'Graduated', 'Attended', 12, 10, 'Transport', 1, 1, 0, '2016-06-26 10:27:37', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(101, 155, 40.870647, -73.858810, 'Gina', 'Ramos', 'gramos98@yahoo.com', '085dc734ca103e97e0f82b40048a6da99df825888b60da0c3feb0240fd21754634af8382c97e85866f6024856371f194MsCuZBH5viO7AthCzGy7hNOW9BkK4FXwq5j+hs+9Aso=', 'Bronx', 'New York', '10469', '3472556470', 0, '', 'Gina J Ramos', 'c4c60a2924006ab6d84a536efead30c150d210765d69800c5448afc6e6b412dc709e0d1a2acb7c4d6247896c57ff91c6aoNTvwBEWYr0QbXAwGkQWQ==', '1984-09-07', '466b798d3a55b8bc8df87c5bcdd6c37c53991072503d3416640c5676ddc61accdf12768866c75d1bd241c3a84402cd6c9h4WWTo4eA3Ck0XcYnVlEg==', 'New York', '2023-09-08', '', '', '', '', 'Graduated', 'Attended', 10, 5, 'Transport,Anything else', 1, 1, 0, '2016-06-20 21:00:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(102, 157, 40.724022, -74.042091, 'Bryan', 'Brea', 'bryan.brea11@gmail.com', '78401d6bed2ab79ffcb110e6e1c8c61b72462029073671a3c911f056c7793f605e6ca2e3c830b6ec30a4dddd80e9f863Qednl7Blgz/C+HnZLmaTkFbhd7x26sF8mqV17zI6/q4=', 'Jersey City', 'New Jersey', '07302', '3475641493', 0, '', 'Bryan Geronimo Brea', '8eaa786c41cfd2c8fd89895e1d7f46dbc40f3c37a7e813e9b79492d40b012f0e27f52e340ffdbc6c3aa8f3d4a836953aGnx0w2VwJbiax9ojx8QUZg==', '1995-09-09', 'fa56ec4614b3c3839ec24620b5f2d90acf7c48124a30f4038b51f44fe7ff1cfde0294fe50407aedb7cf3b43dc3515bdcsXZBqPjFD++VCP/cu1H/ig==', 'New York', '0000-00-00', '', '', '', '', 'Graduated', 'Attended', 7, 2, 'Anything else', 1, 1, 0, '2016-06-21 16:03:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(103, 158, 0.000000, 0.000000, 'Ellis', 'Clayton', 'ellislclaytonlll@gmail.com', 'a4307b7ab20fcadadb3bed85419814aa61726e2e6617636b93742a3575654bf0053bb20d37db64c117217fe4bcb2e47f3xtUWShZvVt6dndo2D2KWl3P5nahFt9QWarXCfTwnoY=', 'Bronx', 'New York', '10452', '3477985460', 0, '', '', '0fe82a71285eecb69f43df753be7fe1b669451866cfccaaf99aaec9566a6e15eab09399a95ad156c5c6a4412ebd15046wzHo/jeTb8ky0UutfXkeCA==', '0000-00-00', '249d1d0b06ccb46a423d524336d33d5c96419adfe7eb8970469302d12d5cb0214ab4b6e8d235f5669fe8e08b4a524dc78qIjsx00VaAd6V7DALrIag==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(104, 159, 0.000000, 0.000000, 'Qing Lei', 'Lin', 'lin.qing.624@gmail.com', 'f662d78554828f7d9e96d74b1e2775af7f25e880f5fd6166e159c0e8ad6233c724c15990e39e98f36b5fcae1c6356c26eQjRHX0R51aUsoqubhOFdg==', 'Brooklyn', 'New York', '11220', '6463713510', 0, '', '', '75b27154a26e858a6606cd8c9e03bf0dc676c68cd575f306411a99b8cd321aba90f871f1e578f3735daae380ef7b0031Xokev0UqYSX3LihC4be2ew==', '0000-00-00', '9bd9833be15580214979852c96f0820a0a8b43dbf59b3623205c9cc6e4a0c71dcd46db3376bcabcf28c867c4663256edNfOG8vks/TG4wDzrKzpL9A==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(105, 161, 0.000000, 0.000000, 'Kennedy', 'Barnett', 'kennedybarnett1@yahoo.com', '810c16f579c35ffb996fbfe4fb61be5e8317650ac593ae35416f76fc40e3f8a6cc92b2041d099342e9993dc8ed376a8dOhLWnZW+1N35J+8LSmEvRtw8Qpn0B7fg3t+uIvtBXZs=', 'los angeles ', 'California', '90018', '3238778250', 0, '', '', 'a298f586a552f0bfc593ff77de721381c63a78d297c6026687967bd19a6255e414a509c5988592c6210066716700ee23D5ZYAnTD4UVErSISDsqAYQ==', '0000-00-00', 'fefe70404c9e0d17157a4ac64517337418f6e0a7ad7122fe7c59c20b480cc0e2484d51e9555008a18f4e4890cd373bc0DZq/kH0u/p6DnBU24+j+pg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(106, 162, 0.000000, 0.000000, 'Linda', 'Caceres', 'lchcfan@yahoo.com', '7208786a2c9a805dcc3402a8c37ff6c09d3148a52791bed89616ea93dae7d509dc9613b8f67ea0d419d8ea4872feb65fvfxnIvjs/bVoOgCN+U+zEIYfVuwSTFoaAFtOQ8Bv53M=', 'South Pasadena', 'California', '91030', '8184689779', 0, '', '', '86ac0ba39f61015d5dab5876e2507afbc7b40a42d556b795c065ed38a57d1ab8b73b971d21ed1197f12c51a62ead3a29kupvuyabMKXTXvMtlYA3Pg==', '0000-00-00', 'bd69f72fd99332728f44d045d06613c31871db962597247dd80fc41f1bacc4ccaaabd5ec616835fcf39b9cacd191358dHLwIfNvdk183T7+vPFFwJw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(107, 163, 40.942726, -73.885460, 'Waulinda', 'Harris', 'waulinda@Gmail.com', '52381174afc745ca6a70160d180219129f69debb652777744496122244c8b207f8a1941c119dba416825bb9b61cf29ddtvUIROQvPm0j4dbJm1xPMuLZGx5JYfPST+HjKRNba+Y=', 'Jamaica', 'New York', '11436', '3476849032', 0, '', 'Waulinda Jolene Harris', 'c0b7ec80bc81217be5517185a1f4cc6b2be2af5569b079e579f3c794c6d6f876ef6a3a951e24f03612a9bc01e06d74c3CfhLZ5+Pf0DQ1bZHHT0nNA==', '1987-04-12', '7af4b6a6cce27eaa78b94fd1d596d4e46815b6fdc6a959a600865bc7c2c1ffa81067c5bbbfd49f1a8cff81fecdd5bea71A4s8OVu3lauoBJQZ8i+Qw==', 'New York', '2017-04-12', '', '', '', '', 'Graduated', 'Attended', 1, 1, 'Transport', 1, 1, 0, '2016-06-21 06:38:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(108, 150, 34.063538, -118.319374, 'John ', 'Nunez', 'john.e.nunez@gmail.com', '3151bdbfb8798fadad20bc80c3cd48a62c358437541497be202e65e370bf22d736b4cf5428a995b2581aac049436eb0cvk33ASKEc7cNeIpntWyBuipAtpJfIHKnZUMAphcy2cg=', 'bronx', 'New York', '10463', '3479333141', 0, '', '', '57e700df45027225a2c8bc960b55fb1ee83d0407875d08c183225f6912a378bf93773ec8efe19daa4be6ee8bbd51dff9RcDbADjFtprQk/JeiYVHyg==', '0000-00-00', '1aa146e55c777939ce03c5afc3ae13f296aa0abfde15783a78770f3ae7c4cd5545ef1d2b45589b090a300daf75c8b6b1ZFEAn30TSuDRPl+3WN96uA==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(109, 164, 34.106194, -118.463722, 'Lenicia', 'Appleton', 'leniciaappleton@yahoo.com', '81310686646a79c20ff46b39d47365b63a3a73a8b7847bea504a7dea705643193f409795fb42d204c191757fd84bd71fjjJuLlR3PHwir9CEs/3TLw==', 'mount vernon ', 'New York', '10550', '3473102305', 0, '', 'Lenicia Antoinette Appleton', '4cb841e1c5e7ab56268e7ca2c6c4f1b378b14315aed2f7dd4ed57e47e5b99f7724b5e7771c0a89c4401787d6e4d4abd5FtB5X6ewB1G40lxNLAR23A==', '1988-02-21', 'b116b6388558d4674bcda19daac942a71d774ce7c002fe9d0ff0fd54fa77732bdbbe96ba26c70441598030494268c5a21QPsv/jp23mTFuCpeXPTkg==', 'New York', '1988-02-22', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport', 1, 1, 0, '2016-06-21 10:37:53', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(110, 165, 33.809254, -84.831383, 'Melissa', 'Lehman', 'meemee920@gmail.com', 'bddcb350e25e17c26b5b4f587612e2c1198556034708c1a4fa55d57a548eaa9ac66ff156cf9c52773dec2338aaed860eiMny5lkC8j3A+Jw5eqgT5w==', 'Douglasville', 'Armed Forces Europe', '30134', '6786701717', 0, '', 'Melissa Ann Lehman', '60670e1936d063d2a7e371701a7904b262e1dba8569286412e378de7008d54e616765ff708c2b407b2adfc8fbf40780ffsiPCWZIAPhJEz6QudbC2w==', '1987-12-06', 'fb6410f551fa3b6709523ced0cc537e34f835d909f2a9b6e6193ac7d0a983a4a107d51966a5200be380b09b03ee49fefkV3pED/o38mBTFIWXGvyJA==', 'Armed Forces Europe', '2016-12-06', '', '', '', '', 'Graduated', 'Graduated', 8, 4, 'Transport , Anything else', 1, 1, 0, '2016-06-21 10:57:59', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(111, 166, 40.777176, -73.954018, 'Francesca', 'Pagano', 'fcp16@me.com', '88eac123b62198557874551e58acd553b815a89c8a606fba5a701552f24bd8ab86a5a5764a4fb49d4368eddaa402db14PfVEiCh2cdJz2X48XncpK9+nFgmf9b9445ucLRbeb/A=', 'New York', 'New York', '10028', '9178172822', 0, '', 'Francesca C Pagano', '53b468800fb485c157b89d7c26ef72357830a2c76652ca1c793c15b41a28d69f015585ee31c892637c1ff0016a44e9a0GQF9k8In1kxrbeYYLh67Kg==', '1980-01-16', '3e63e32bc06013719cedb6ad31e6d0f10432e87ac3d700f724917cafc1b13b458f10f5deff803203f77a213534a8dee08X89ZfyDCskV/WPBb7Jk0A==', 'New York', '1980-01-16', '', '', '', '', 'Graduated', 'Graduated', 15, 10, 'Transport', 1, 1, 0, '2016-06-21 10:59:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(112, 169, 0.000000, 0.000000, 'Elizabeth', 'Brown', 'fairfaxb@hotmail.com', '399b8f1f2712dc7fd6ce6295fa59e22d2fd2b5a49f10ffae0e2d737419768c90a3aff5fd4923a333bf5c9c5cab28c1bcZ6LY4aJnDSIJv69OpW5nu0Sg2RJC08EOqaMqBNwZKyc=', 'New York', 'New York', '10011', '3479223551', 0, '', 'Elizabeth Fairfax Brown', '7a7a390e15f5bf8b78f5ab92e57979f0309146b57b025732fa328a532547c4e5e7f96f8193b6248e8934bb8803006650TcShh6oLER8FJULWTsEE1w==', '1972-12-05', 'd2b6215cad81a35b940127ff9d77d69d02ffb32fde09774f5403265c35f2d5913a55fb512bfc08bbb1cf4b8a42be80deVSoCFHgTTOD6j5y0nv63zA==', 'New York', '2018-12-05', '', '', '', '', 'Graduated', 'Graduated', 20, 20, 'Transport,Anything else', 1, 1, 0, '2016-06-21 12:04:14', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(113, 170, 34.185616, -84.502052, 'Rhiannon', 'Briggs', 'rhiannonmbriggs@hotmail.com', '82ef7e66bca2519893c49826c8641582652c160be4eee37e6f1050c5c57b56071bdad089a49ca7854695c38faec7356dBEnUjJZI4UzsfcWcBryBSATxjVHfBi92xjO7NXh8orM=', 'canton ', 'Georgia', '30115', '7708625816', 0, '', '', '368ca3bfcf56cb5d375c110c46a56b3a3c7fc57922416e8dc234cfefb8fa05a126ad75f817027fb8e36ee4bafb55c58cmytPxcmTqpxyXJHAqmlEeA==', '0000-00-00', '8f2e16a2d631bcb9c118397d7d71f762291811157d5d7e43bfaf6c8e00cbf440a0ac2e4cb12eaa9adb603a1c4ee23705tZMhhda52vP25IgCIgsjpg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(114, 171, 34.106106, -118.463745, 'Brianna', 'Williams', 'b.williams850@yahoo.com', 'ca057d595639623677d281b0cc126afd2306adecbec99a98eb27b8fe390a7870967c409c21243b36424ba6a44d7a146aTgNMmezmN5joc/ONdw3DqvyC2Aj7aS+zeMmo9ejIG4M=', 'Atlanta', 'Georgia', '30310', '7137033002', 0, '', 'Brianna Marie Williams', '5b8b12f5eccbafbf07aaea1845bdc3767ceb6d44549bb1934f2749c7993d55a4e53f12c093c8b8a5a5f87d6d4037b15cK55aq32/hnRL7n3dBEGO8g==', '1992-04-16', 'ddc9e3dd83eaeb7e64b51480c9d663cbf791e7ec7b972f3f278f063d13d48aa9e0b1829868f871a77b090496e8d7f8cbIYHtM3hyrH7aFMH5lGkrqA==', 'Georgia', '2020-04-17', '', '', '', '', 'Graduated', 'Graduated', 6, 2, 'Transport', 1, 1, 0, '2016-06-21 12:45:23', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(115, 172, 33.895607, -84.596939, 'Victoria ', 'Lash', 'serendipity736@gmail.com', '3477c0dd5bf1cf0467c3ce1fd0c0b64cf27e7ce79c7557a4a7e352de9038e1807bb5b3beb3e5da37901a34ac3cde707545LQVkQGuLfyY706nRONKua2OYWmnI2LoJ60/mCapp4=', 'Marietta ', 'Armed Forces Europe', '30008', '6786877924', 0, '', 'Victoria  Kirsten  Lash', '9c04de70ee66ad9ed37dd956d7c512de140fa302280a1d0c78f38197c63d1b96685cdbd3f30e8d6108c6b0914fcbef4989ySMxlUfAL6fhQ2C8/zpA==', '1981-10-08', '5d611f0127417f40af5c598c17cb96a51be7916811da2ef6614895cbb38b4df0d3792ccb4ecf2d5a2674131c06c4c8d7OdYhESipkML+Xcfb5c94sg==', 'Armed Forces Europe', '2016-10-08', '', '', '', '', 'Graduated', 'Graduated', 15, 2, 'Transport', 1, 1, 0, '2016-06-21 13:06:03', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(116, 173, 33.540436, -84.071671, 'Ricardo', 'Willis', 'rickyw796@gmail.com', '9cdc8d88565b70cef5fb513cf04fd3354b8b6d0285e7a75cf9fed37ddf1365f8e40d3cbf7c04c34ca47c82f07b0e6cc7r9G3aJlO3CD3OIf2Hex/uQ==', 'mcdonough', 'Georgia', '30252', '7706084841', 0, '', 'Ricardo Sean Willis', 'a06a02a01e4e0e45c58722fe00004a2bb075ecb50b43e3ab4aa62ae6862cb0adedc8cf9f4d8898bd5a2fd4cf90ba7f73oH/q856PvPIH7+uW9jwbng==', '1982-12-09', '01519695f31f4fa7755106447bbccb5e4de00339f7ee7aeed66269271207e9177d10e332e77ab4da638474a09a4a7693qrS8QCE/7+Lu2NNQVOzZOA==', 'Georgia', '2018-06-08', '', '', '', '', 'Attended', 'Attended', 12, 2, 'Transport , Anything else', 1, 1, 0, '2016-06-21 13:27:14', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(117, 175, 40.630390, -74.151688, 'Kesia', 'Poole', 'kesiashani@icloud.com', '50ee41e4dbd051e4e6bc9d2da939fec91bc332fc467962756e0cfb4ed1aaa862107159ac9bc867c77aa34a1d91cd092287C2gKWHT/mC0obzPZaKqSR7Y+1dcoBGOgX52sZl1/E=', 'staten island ', 'New York', '10302', '9293400542', 0, '', '', '84017c7ec6c5e475ce8f7cbaa1399edf3b54c76589f9bdd6d0d98f9ac5deaf243d3ef151dbca5e4c2840b62934288864sgxvIzrEVVX5+U2i26Bsnw==', '0000-00-00', 'edf7b45c592a646da2abf004c0838d938f01f12515c8eaf881e3c11c5415a8f8f90a5882cfe55b0c25b7ff953c9fc9d3I6oDmlbxzYvXetHGnNUCpw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(118, 177, 39.100941, -121.630104, 'Jodi', 'John', 'jodilynn0511@gmail.com', '2890cec50f57a53b95dbc0e061552a7b1a0f600d63c58472df9cd56c4d45f65065ec553e8fcb7dd835d826163fdcd16b5xZSGoFnHjX6VP9ObzdxmLAC8oP3rpORGrrrVkdXfew=', 'Playa del Rey', 'California', '90293', '5303000763', 0, '', 'Jodi Lynn John', '70e5dc5a68fce6fb784706b844553b34a2a87d0379e2879998c2a8243afeb4c2c51d9358ba229c453cf3814078844fb0PbCy/SzYSoKDXuENgtcDWA==', '1987-12-29', 'a22324e039f4799fd08fa8e476292d1fb522ea88b2517bfdc0505856f47911287092efa6902c161ab57426514fd2afe6uo1RwFI0+WjlZVcUad43qw==', 'California', '2017-12-29', '', '', '', '', 'Graduated', 'Graduated', 10, 4, 'Transport,Anything else', 1, 1, 0, '2016-06-21 14:24:36', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(119, 178, 40.813236, -73.940292, 'Yseult', 'Polfliet', 'ypolfliet@gmail.com', '1a4e1c46130a25b8092d47eb0213422eb3d85972ecf2bafda6384e40620c7bb6f1d05dcb60c0a06de08b71567d875253xLywncU5a+P0XwbTgtv7iQ==', 'manhattan ', 'New York', '10037', '6095766606', 0, '', '', '126c4c55af42f77a9e1f91e60c58bf71809e8c33b4abeb58e3708961eba9f1367dcf9b692293fa293be0657aecd405336M1ptixUknOsou55e1LZyw==', '0000-00-00', '130046c8830e74a18477272e1c527f93a0061c0c48ad349c2d03ce5e5ea5fdc9022520ebbbfe4f57d28431161f4bb5a5Pz8NkLAQ6KByeQAZa1T2LA==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', -1),
(120, 176, 33.597252, -84.318459, 'Loleka', 'Hudson ', 'Lolekah@gmail.com', '9f974de28707a1ed2b9e1a570a0b79c6dda5061ca212db71530deb20605fb041b082972526696a2b2440ecf3aa9ec6adGsjNumT5JNQzno1PP0z3BN+laN8Ckm4Qjele8mmIfdk=', 'Jonesboro ', 'Georgia', '30238', '3364570430', 0, '', 'Loleka Arlean  Hudson', 'e557353a7f6c77a5aa3c025c37e9bccaade9163e2bc044a17c0b5b8bf40bd48b96366f495147e8f04d71ae7e0b252722X4LrwPIgSI8usm1EAvgdxQ==', '1988-12-19', '21185070dd77ce67dda94133f9798257cff8c2db8df7eb02975670f3f02b04fe7a553d9cb2f97b8f162a17ab3c3a47eezestUmexTovY7NBx6gEM8g==', 'Georgia', '2023-12-19', '', '', '', '', 'Graduated', 'Attended', 6, 3, 'Transport', 1, 1, 0, '2016-06-22 21:54:48', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(121, 174, 34.194710, -118.500305, 'Jessica', 'Caceres', 'jessmcaceres@yahoo.com', 'aa92d262b1f4813aa019e36c5f74ab8a539da25de8104335de090d253ffaa33a21cda2a86e149fded421e43c77d0804bDBZhD8tXmyrHyCLmv2eEWGbr/iZ1/3T5ggSuN5TMQBA=', 'lake balboa', 'California', '91406', '8188499593', 0, '', '', 'd8ee02c15ce7259d4fe97be71220d4bf2a44f08676527879ad46f09ae31692dea7477876221a5b3a62c9b62a5f3f4b75cy9FbP77KlyA1uXoBFpr3Q==', '0000-00-00', 'b0351335ce5f3995bf24a26e9b09b55903e35e15bb769e19149d9f98985497bd006e51c243c6689a644ad5e1417f04a8ilZxxMmbBYFb5hH/Rk2j5w==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(122, 167, 34.106194, -118.463364, 'Christian', 'Allemand', 'christianallemand91@gmail.com', '19553b4c1c4209e145f224d884f48a61ee31e34ffe74c7be7c24bf79baaff66933599b16b8b3c686a93e7ed607ec5d293tKvF54ulJ3EcBd0D4L5Tt4BtX5Zn4Kh4/1g2Ezcifk=', 'lawrenceville ', 'Georgia', '30043', '4044347941', 0, '', 'Christian Rand Allemand', '2d9641f0d5abed1efebd8c1bf5728b202e50f520dd660293ca05c08c528e7117423f2c766168ff610cbb9fb53c084beafFyTvTEQQYORlUbrEV+SdA==', '1991-10-21', '2fe2bf976b6c3ee6b6a3b0b8e2341c37c8faf583e0fab6fbef7a5e052449611dc7a174da1e963770b5e13cfda56d6321FZ7z9NuYEOQh6RDqE4uo+g==', 'Georgia', '2021-10-21', '', '', '', '', 'Graduated', 'Attended', 0, 0, 'Transport', 1, 1, 0, '2016-06-21 16:19:18', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(123, 180, 40.749535, -73.936615, 'Melanie', 'Binet', 'melalexa88@gmail.com', '2d4480e96cf8b6e5980e9d52dabf37649891e9205b9a0e065b38986f59806f184892e0b7f3d0e48d38bd2d4bb17d4e63/ak88d46Kj26sOkSfYhtkQ==', 'Forest Hills', 'New York', '11375', '5163757956', 0, '', 'Melanie A Binet', '956bd4f943d7116a18ff7796855ab8067bc3b5ed9c18d2e8175801375f9dd3afb4862f1a67d73425ef73267938c27765bqVBNTLD+/bsisZwlsuBBw==', '1988-12-28', '947a44e7a8592cc5efdb4190582d92dbb73e80895462625e457dbac69bb94267cacdc5febade9896193bb9c19704b0c0n7M97on6z2qAtjZi+q4ulg==', 'New York', '2017-12-29', '', '', '', '', 'Graduated', 'Graduated', 6, 4, 'Transport', 1, 1, 0, '2016-06-21 16:51:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(124, 181, 34.024956, -83.967476, 'Hailey', 'Brock', 'hb_080995@icloud.com', '540e7fc318b29b436491a820dbdcdc71914b0e824113fc687f8ed5b36ad0d7592bf2ddb7ce6bc4ffcebff6c9f305fb8aAhDc8mEmkjbvcBoylbzmSviRAycnZudbL1hi962cN+A=', 'Hoschton ', 'Georgia', '30548', '6784464892', 0, '', 'Hailey Diana christine Brock', '9c087d14daaed967e9574d15dd627846def2e9dbbca56b3c1d74b94ae2b253e45270499623633acff38db22efe2004a35wi//E3jPiVqqVyJwkic9g==', '1995-08-09', '6c6260e2a83a3953601c80f370c9a27a094c6b144c3fd646eb8a31a5ddda8c2ddc8a3cd66099250a03d8dc649a613479EunpV4+eCUo3BkYtPpzIQg==', 'Georgia', '2017-08-09', '', '', '', '', 'Attended', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-21 17:13:41', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(125, 182, 33.443031, -84.170013, 'Alexis', 'Hart', 'lexihart1216@gmail.com', '549c3c1cd3dc3212528d277a37fec32e673eef5eb029af802c537943748758866139aa4e8306dc4b576746ea3dd51743zEJ8vBHraVK3iUcUKgXV6jC3cp3IuhnRWkV/zfHTgN0=', 'mcdonough ', 'Georgia', '30253', '4043246252', 0, '', '', 'a474a42f10ab57dc6fcbe37b0218f4a1ec2e2f5feea60080c74272e0f022546aefa82f8d8f53b5b95fd5064002a63248141Myyk/I+jB6grdsV9OKw==', '0000-00-00', '9b2f7760dacb64dfe49fbe11c724643eedf55e164fce4ffb11774f935fd2bcd8a47827d9e362ecaee637b7d9d6c1d65aQfnuUPwMCqnN9MJPoeBjdQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(126, 185, 33.982494, -118.383827, 'Darius', 'Byrd', 'dbyrd10@hotmail.com', '489a5ef9f6cf16941a8bbf317efb3ca0760619ee114f9e06527b271ebe4ce0d222fa0c4cc5abe0791f8da8d712de55e3Gglrn2m983oWBjYo9xt+Jv5KVXMq/sWA+fiHIhT3PUA=', 'Culver City', 'California', '90230', '2533895939', 0, '', 'Darius Davon Byrd', 'b6685716dfdf68d2f9eb3a8d21765d15dc81c91b41a9440b3ac1cb723948f3eff5b2dd5d5898a656b7ef9b66bcb65564M4JN6OhuNWa2PxZZz+ta6Q==', '1994-08-18', 'a109b989b07b0324b6dc382a6ec06bf6fde92bc6425fc8bfb1933708e9f87beff3c43c0889cbc2431b922d55c237c4abBBrVJnLv+p7y4R95jwrJpw==', 'Washington', '1994-08-19', '', '', '', '', 'Graduated', 'Attended', 3, 0, 'Transport', 1, 1, 0, '2016-06-21 19:33:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(127, 188, 34.105980, -118.463867, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '50b80dea1502c5522bb264722d3162cff329ed668d24bdbba4b2f0799c991f31b4cff0f82acb15044b3987b97e999b73jacMZplzFQh3vag3cVQ26iyJSE983E5ZsW5N8DSo5nY=', 'Los Angeles ', 'California', '90077', '2038879349', 0, '', 'Kimberly Elizabeth Idoko', 'f2370cfbe243549b1f4319bbb2c392fc6b6f8b106d9789b1c2f0b280e18876b81b60ebab7078767cb02039646af0703aJg+/jesVMXfA3zGqnsnzcA==', '1983-07-28', 'f39221a053362a96344ae0f9db5f2147290d191ddf76114ee76d45a815758afcbf1dce0ee7f051f336262b30ac15ef67ZgHSrGHNhnn3U0tjGCbLSQ==', 'New York', '2021-07-28', '', '', '', '', 'Graduated', 'Graduated', 8, 0, 'Transport , Anything else', 1, 1, 0, '2016-06-21 21:32:20', 0, 7, 3, 1300, '9326', 'acct_18P1EIHM8u5dOm2Q', 'btok_8gO1cs5coTVPoR', 'ba_18P1FAHM8u5dOm2QqHHaZsmC', 0, '2016-06-28 07:53:10', 1),
(128, 189, 0.000000, 0.000000, 'Diane', 'Lester', 'dmlester21@gmail.com', '0b93eaa50766d73afaeb44cb8194aec8d5c2390edc12274c9f5c9141f1775a7f2464d2cb0e1e1cf05065eb551c1d8d024eYX3BMiqJXtCf+ZFMxfzRI3qhBimTqFhkeX5AscENU=', 'brooklyn', 'New York', '11215', '7033177869', 0, '', '', '34656f605d92ddb583e2a282ddd317c0834378920b203a760e69ac11b10b0f6207c43cde012601e38a368b6aa9752b43Cma4ocEeks7YSzjzFJoKUg==', '0000-00-00', '0cd553964a33b0d52df6f26180053fa1dd6e241a3742364204fbfd4d388492696fed14b53df337f23d2475556c2ef692Y6QwcLEkMQCMtImwYBvYGQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(129, 156, 40.708553, -73.958115, 'Equanda', 'Willis', 'quandak282@gmail.com', 'ab713b639bb85d86964f0559f3dde18abc2f7ef7face4935fd88a56347f3d40e95f9af64b963e9ab7f9efc86d58d9239QBf8Pd09zBAFBHmTAsYXxBd/xaVVFwa7wmCIgGYTMfg=', 'Brooklyn', 'New York', '11211', '3473044544', 0, '', 'Equanda Kyra Willis', '601c81f83c193fc704191a85e707f2e3095e437f944ab766049fd4e2559f9000a92281008dfe38a3727831d9d7b10f6fgbRdERy6i5KWbq4kqjZLNw==', '1978-02-28', '5d56c5d1215f82d7ec2f66edc0dd10e2b53e6ed51cf9b84c9ea6e8ac0684b808bf7755d82c14d6a75cd2aa1632f939f6aDs3HdOrn3mYeZ9ZK4PNGg==', 'New York', '2019-05-23', '', '', '', '', 'Attended', 'Graduated', 14, 9, 'Transport', 1, 1, 0, '2016-06-22 02:30:10', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(130, 5, 21.148027, 72.760735, 'Vimal', 'Gajera', 'lanetteam.vimalgajera@gmail.com', '9b0628e605a54c5a52278ca99bdbb91ae92500cffef0cde566983d4c49ee96ffbb666a6860f9b4a5a1988fdc87af00beMwKYBWPhv7DFs+FeJmLAqA==', 'Florida', 'Florida', '12369', '9998078073', 0, '', 'Vimal G Gajera', 'd04e91ab57f9221557f57ea3d6ea2e0c82c51dba716123ba9704d334b7e2541c81aea7481b6be6e1bb72b1977b2c37304G3P9lDdMJdE/vcDE/uVeQ==', '2007-06-22', '13b2734b4e67050aa248cb694d9de2a64c73354d4fe721c02a059141fd22f96f5c3922e2d162e34414eb1d4a0ed12f9bN4nJIKwy1jMqNGjzhETeGA==', 'Florida', '2016-06-22', '', '', '', '', 'Attended', 'Attended', 2, 2, 'Anything else', 1, 1, 0, '2016-06-22 03:15:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(131, 192, 0.000000, 0.000000, 'Caitlin', 'Siney', 'caitlinsiney@gmail.com', '3ee6b456f7b5f05ef411e5bd5c110fb4f16388893646dcfad73d87a47ae0414437ec7c358f5dd6bc5e830401575221c7m3hdXFw/xMI98YtUslxQH4wiPF3Y/MYzfMxi7pJIVoE=', 'Sandy Springs ', 'Georgia', '30328', '6102031445', 0, '', 'Caitlin Siney', '466caa116697e88d1283ef15cb1760b4443aaaf910fdfbe8fb8a57256c6e57629a55c8743b74307f481c6ebdee3f51e3dy7q5KVD9cnwPMfkVVvn8Q==', '1992-12-16', 'a9bf35d26700bb1ee7339eda34c049975d1d5e3ca70aeef91c9dabefd328d0bb4d96d6f2fc8397915783ce31c2520e0cQECj+b76mwZSBEIPuAikRA==', 'South Carolina', '2014-08-22', '', '', '', '', 'Graduated', 'Graduated', 6, 3, 'Transport', 1, 1, 0, '2016-06-22 08:46:34', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(132, 190, 40.752159, -73.925560, 'Elisha', 'Sostre', 'lisha1018@gmail.com', 'b874581b1d2308229479aaa7d73c1846c348f63014048a1658d78c4cdfd16d4b7515efc59f1711d851f5835ad42845aeFABgSdR4BrFKiHUwpmk3aGvTFy/iQPvyTfiAtPZmI2Q=', 'Brooklyn ', 'New York', '11236', '9293652284', 0, '', '', '93f89e308bc2a8c7f22ec67daa6f18f772340b48aa995fcf8ac2af5d26cb040b25a80adb311eceda6861487923544084nPIKaytLNkJr9vQRzn25jA==', '0000-00-00', 'a986a132fffadb9574198bef7b130075c3ae4a7f1f8ada84151d3f0d7b1567ee441691ccb4b820ec56f3c909f2c59998QdcOkn9H65hSB1QDFiB9vw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(133, 199, 33.409576, -84.404259, 'Stephanie ', 'Skinner', 'stephanie32391@gmail.com', '2778a9733021424660748f32dd8333c77b0c437d98ae671ecfcf1417d898c7a8ba59a58b7afca45ba689377fb22a0e4e/4GintG4MuzJul+nxQWZu0nulDyatKbo+oyB+KiXj6k=', 'Fayetteville', 'Georgia', '30215', '6786508848', 0, '', 'Stephanie Lynne Skinner', 'c8eb897626ef8db16cfd181e45da4a82ec42a1c7b7cf1a0ad76d358ffda46d91abbf6e75b96858c59a871ec5dfac9c10Jli4chsNVhBbwZW/dGWusw==', '1991-03-23', '3eaeaf369c9cc3c67d25007205c01ceef1b2cfb48b3887c2b9dadac2b2a7515907e56a90f686a393029290c5c8147d607uGQLYUpHPeUR2fphxfV0g==', 'Georgia', '2017-03-23', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport', 1, 1, 0, '2016-06-22 21:10:00', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0);
INSERT INTO `qProvider` (`qId`, `userId`, `currentLat`, `currentLong`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipCode`, `mobile`, `isMobileVerified`, `mobileVerificationCode`, `nameOnDL`, `socialSecurityNo`, `dateOfBirth`, `dlNo`, `dlState`, `dateOfDlExpiration`, `highSchoolName`, `highSchoolCity`, `highSchoolState`, `highSchoolYOGrad`, `hsInfo`, `collegeInfo`, `totalYearOfProfExp`, `personalAssistantExp`, `roleOfQ`, `isStateDisclouserAcknowledged`, `isBackgroundCheckAuthorized`, `isQVerified`, `registrationDate`, `isQOnline`, `registrationStepCompleted`, `TotalRequestCompleted`, `TotalPaymentReceived`, `qBankAccountNumber`, `qStripeId`, `qStripeBankTokenId`, `qStripeBankId`, `isPerformingRequest`, `LastRequestSent`, `isDeleted`) VALUES
(134, 201, 34.097843, -118.003860, 'Lola', 'Lopez', 'lola9lopez@gmail.com', '2e643dfff086c65eba267487cfb870600f574d644ff0a37c61487ab577ea50c4b7461c79ddcdc314b4e027e90a6c0c79mStW3fobjBvkVwzNiLIjQD9pQqj045NfmWyQ3uxgrc4=', 'El Monte ', 'California', '91732', '6266930169', 0, '', 'Lola Lopez', '4f876483239b9426e9d108309d4693475bf4270e8ead26f990d095f43afced47e1ad3764fef6aaeec8a93f86f00c5caayauLjMQOTZkxORBXOMxtlQ==', '1995-02-28', '1d164f256613db2363bbbb5d176ecdc91e237854da5caff02340d9181758a7679520567af14e2768b889dfcb46a73b15csBdxWd4A/WSwM35eR4tsQ==', 'California', '2017-03-01', '', '', '', '', 'Graduated', 'Attended', 3, 1, 'Transport', 1, 1, 0, '2016-06-22 22:04:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(135, 202, 32.877438, -84.320618, 'Montana', 'Pickens', 'mpickens2014@yahoo.com', '5a3ebc8d95e9a05320e7873e60073be5082b42ccd861369233eff0e9da7768520495bf2f199140e586b8a3cf135a2106+RIIqa6O1PkksebRwkx1fCgr6lPc4QEzhP/V8FV3e2M=', 'thomaston', 'Georgia', '30286', '7067410591', 0, '', '', '3597da645260fa25e1a5827a304c03fba1d17caad5ca36c7a94527450337bf03d928d3a816c9f0f83a60fb98ecf17d03yHnydxpJTm1I9U8J5SgbxA==', '0000-00-00', '2199fe3b9568f04165a31d952508673e178dbe321372f462745c66ee0890a44c2fe6c856f15dbe9a0eaa28588c071cc6CEAwvuhkBsT/Kpvlsm2iBw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(136, 203, 0.000000, 0.000000, 'Joi', 'Allen', 'joi.allen210@yahoo.com', '7fdcf8d81f27112771e241dd8fe9fc796d46cee2eb6afff60b3f15a7ee3ef3b50a479cc5bb150c853c7b90baeea5238cHggncJGjBmqn+e942f5o/5P2xMDkRa+UPUtQx/oNrvQ=', 'Lawrenceville', 'Georgia', '30044', '5743443401', 0, '', '', '4b89b2d0af49a1308c5a3344da43b03ac729fb8c6c32a29bc714672d22a0f8db840f6ea37030be499ded765343eaf0ad/Gyxcy67e3wgE5WAFVqLog==', '0000-00-00', 'dd10a02caf607928cc6bb36214f18b2525f48ff2396b00e9d58e7be76454d387de4f355f94dd2ab2100f0019a0d0e631thQPHbjx26DOD28vOFtOrQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(137, 206, 0.000000, 0.000000, 'Charity', 'Wise', 'charityiswise@gmail.com', 'a41b70dea273866a6264db0918abe2fc732d0c67e1b6b0fb7ef974f90b411746d831748abb657ec4e9d173da247857032c1ys0cvaGVsb45Dds24i3vmwtWDuowkIMX2sYDDcKg=', 'orlNdo ', 'Florida', '32839', '2026158832', 0, '', '', '75a110996f22b1cb85291dbc49135976b2848354decc16e925f14cc0eb56e96375d991000ff73d58e5227ef7050d14ee0OS6q5k0ZvOg3szOWXqyvg==', '0000-00-00', '21c7a677035713b0517c919f096c45aa8bb5e9d6be86068c33bf524c33a66097c0c4b9ea40044ca23299af9c0a72bd037oSsBWBxRj94E77rjte2kQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(138, 207, 40.808308, -73.943962, 'Leanne', 'Stella', 'lstella147@aol.com', '01aef3e025ab4fb4f1b390d0d052f281d0aa7e6effac87e24a935e9d656931c07b472fa8ee4bd6ff98fe8a3f38b79ed3kcU4TOtCwtJm15cMdNI3A1vIJ9MyaQMIbRNHDyjz+/Y=', 'New York', 'New York', '10027', '9172734405', 0, '', 'Leanne Stella', '6093d0d8b1da62293f740bbb1c33402608f5238c14fb017d736d036dc28583ccc00081dda866cb7cc65b47ece4a2c954pfYj3XJz8XjmQDXjNusOaw==', '1966-03-24', '3fea52d1a0b3e60e0e77085fd97951a7cf9c49305bea5bc2ad7ef6ed4c8b5589cc4856c5c2404f9308ab861f35f5498fWwz+NVMw1sqwH3GcunJRZA==', 'New York', '2016-08-21', '', '', '', '', 'Attended', 'Attended', 20, 2, 'Transport', 1, 1, 0, '2016-06-23 08:05:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(139, 210, 40.676178, -74.287575, 'Dailyn', 'Santana', 'santanadaii@gmail.com', 'c82d944cb6fd1a50e9520e06db243c961084e93b234963be615774fd730fb131198689ef0f89d96bef430d5d64342bf2luL/yO08O63jK/FoZeH1TDr/9leG1/ei0oLFyoUykhU=', 'kenilworth ', 'New Jersey', '07033', '9082175067', 0, '', 'Dailyn Santana', '2b0ae2c933e0edd7b88bd5bdd15bb3b28ff5754d470877a52eec5d48b264cd303b937dff5a31db3368858d6dcd4744c6kkRPmgB0p70LbORuxt8WvQ==', '1991-03-20', '9207b3eb533b52ebccdaacacdd2f1679a94d4831fbaa58d1508daed95c8047f70ce3750b36e78fdd66ef98b02c21b07dftLVT0HPW7HASCmvsrShhW8V2iWK6Lna1i73SomGgD4=', 'New Jersey', '2018-08-31', '', '', '', '', 'Graduated', 'Graduated', 9, 5, 'Transport,Anything else', 1, 1, 0, '2016-06-23 12:47:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(140, 211, 33.672062, -84.388428, 'Monique', 'Williams', 'moniqueshavon@gmail.com', '857f86b20eb6bd1dcfd1e829496a9c6814e643fd3a8a7ef5e0759389c9a778fc32bffb271e9edda53c341635f6287247kFPvsOjU2RxEveIKTXw+KbAnhdSug5rvgi/WzN/dHbE=', 'atlanta', 'Georgia', '30354', '6785232604', 0, '', 'Monique Shavon Williams', 'f1a266946e302a23aa2f8c20556d1c4c8308209e6d69bafc371a73d3c125531f7503302f42efb9e2e1758acf05ac85f44VUMRRvJTNdvsHtc/tyUIg==', '1983-01-23', '0a701c7aa82ecee381b605f52990fdde5ddfb77c4966689d09fb17c423018f041687abeb6501670f3bae397ac3e7132bY8Yg6X571VjFa6La2bhpFA==', 'Georgia', '2019-01-24', '', '', '', '', 'Graduated', 'Graduated', 12, 10, 'Transport', 1, 1, 0, '2016-06-23 13:01:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(141, 212, 33.701199, -84.259621, 'Darius', 'Taylor', 'dariustaylor16@gmail.com', '436fa771b1d2cf71d9d286368c4471ddd6463a09066df24d61be8e398e4e93ca39dd4f38141db5e7e703d588732ce5f16nBqhF0JCrn/BZK3IzMNDXXRhrtWXiy/D/875Qb6LG0=', 'decatur', 'Georgia', '30032', '6782879404', 0, '', 'Darius Rashad Taylor', 'd98b27eaabc98f68378e0d38806036100339e47f851bfbedd7393847255b9dc4844a695072e3072a1f89449e79c1fd11TjgPJxM1SWWIgVfD6c5dvg==', '1996-01-21', '9fcd9088a1b67d00d5d49dfd142084ace7bd710b2ade0fb8947f83e0a37ce16d16a810ee21b295b15c930fc7601275e1sBgNH7y9ctM89HU3OhjYhQ==', 'Georgia', '2020-01-21', '', '', '', '', 'Graduated', 'Attended', 3, 0, 'Transport', 1, 1, 0, '2016-06-23 13:11:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(142, 209, 0.000000, 0.000000, 'Elina', 'Stella', 'elinastella9@gmail.com', 'd81289210df63f802006f049b78d901ba5145a9345fe6d5b5c0888ea7cd7aff2dcb95d51355dc48dcd9327486d7010f7gE/9XmDVsj+VuEoa4GUKTI9h7Mt89jRMNOP8x7fwX2Q=', 'new york', 'New York', '10027', '9175754425', 0, '', 'Elina Stella', '83583ca1dc179329d5a6c4bbc4235bfea20f1f9216c79e6a194d228a98e22ebbbe66436c710b57123181bf1b918016d0t35vSLsHXVuKX6t2mpjEcg==', '1996-09-10', '091c0320da804da2da91b9399dd0eb10c07d2448a13262f60cb043ab5b91c13f9e5ed6b02ce34011ea6b1b9d2635c787O8hwkqjKUWSPuMRbTFY+ug==', 'New York', '1996-09-11', '', '', '', '', 'Attended', 'Attended', 4, 0, 'Transport', 1, 1, 0, '2016-06-24 16:44:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(143, 214, 33.815136, -118.195518, 'Romaldo', 'Arteaga', 'romyazteka7@gmail.com', '2ae853fea22b5ad817b3d0cec845095670d81e976fc6d08f496d0d4728a4e838bbdfde9e952c2a64a96240fa1310ddfdqiUmjsCjP365dwFoOeyTVqR5PLc2k5a6wEgE8M6L6B8=', 'long beach', 'California', '90806', '5622907557', 0, '', 'Romaldo M Arteaga', '15970ac1a0584389b12b6cf4de663badfdcd75ecf479ab130806e1729c8a399389141ebe0c5362f28040fade5727deadkg5h9dDfGk45s/UmOFl5RQ==', '1989-09-04', '2bb15eabd1e8cf0831644b1ac17ee278491e6a35d42d0a1c089200b85c98cb9021a0456f9c7f5ba5e6792bc55b55de918Cpy5MhHY/T3VnC3qXBhfQ==', 'California', '1989-09-05', '', '', '', '', 'Attended', 'Attended', 1, 0, 'Transport', 1, 1, 0, '2016-06-23 13:58:42', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(144, 215, 34.156727, -118.455536, 'Josh', 'Mann', 'jsmact@gmail.com', '83585baf78c4a24d8a881969155eaf6009e42ff7035d55d62c424da069220f72265287615a9085095b7c5886d4f4a096v84kOEIwSi3SMO0wfkRG/H1UV0LyG5SLWq9EQXCHc9U=', 'sherman oaks ', 'California', '91403', '3108509839', 0, '', 'Joshua Samuel Mann', '8b27eaef782a05c8824b6eb4f1194e4189ec4b844dd8f1a7cd79e3918afcad6674d830c5775f63f36de192ee2ae4da141H4MQNtMMv8q9DkYSx8OlA==', '1979-01-30', 'eb1365efe8e0275b610a85267de44504e9de54d78b42521f26b8c0d4740919dcdda821b6e09ed48158e6a39ded846182ZSt811608d8mfueFIJlkyg==', 'California', '2018-01-31', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport', 1, 1, 0, '2016-06-23 15:03:04', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(145, 216, 0.000000, 0.000000, 'Jai', 'Patel', 'jaipatel850@gmail.com', 'f41663394eb1a59e8419f61df8496aa911aedfc595b39bca35d563cf9695d87215ef6b8a92fe5151a73d5424ff3ab38fdKjRF9UW2ftSnQ0Fj9S1mPcAcnI3NxCP2/dMTb4eXYc=', 'Decatur', 'Georgia', '30033', '8503778952', 0, '', 'Jai Patel', '63b239f294e9c473e3bc0271dd361d11acdc59f78444ab353898302c9a7431c90210c7196bcf04213248b6fef4689837jmZYhU0LvuzZbP/HDFUUiQ==', '1991-11-14', '22f4012ea081d848f13c2943879a64151a15602bc4c3300f49893b0e297704a8926b6ed586b6227155e2771972039b41l5PxCw3ONm+82UjT/UHplg==', 'Georgia', '2023-11-14', '', '', '', '', 'Graduated', 'Graduated', 3, 0, 'Transport', 1, 1, 0, '2016-06-23 15:52:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(146, 217, 33.931328, -84.268852, 'Alisha', 'Watkins', 'alishakenshe@icloud.com', '4e1475d5cbc8185264702f28af83cbe990f2a6d30c0f65b8bab6a3df7d45f65c02a72096e31d867096c5178e94b7d028hsS3ppqJDF30sNrtOfijUiF5O8DQheWjH1VHJoIEn9k=', 'Lilburn', 'Georgia', '30047', '6789797024', 0, '', 'Alisha Watkins', '54677ad354f646f02f898ed550acbefa52c4271c7698fe6bb0cacff952fd912d948503df22a3a3121c0617621f1aaecerekp+jFQcvxsjYINsCVcBA==', '1993-08-15', '10e5c9eb6231ea78ae64aa70810fdfa88fcf201801d262193a2f3ad434f49e7b5e7f4370c0aa1dd08c3d0fc1f2763257vlv9qZFHJTBTxelNfIHfVA==', 'Georgia', '2016-08-16', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Transport,Anything else', 1, 1, 0, '2016-06-23 16:34:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(147, 219, 42.401676, -83.229889, 'Alicia', 'Hosey', 'alicia.hosey7@gmail.com', '5d8e52e82453b8c86f7217b48d06c60d7bfaa3f69fca77f381e4f573c6b74acea2ab7f69fcede8d878ed56930337dbafKhxV+JFGbDAA73QF2uenDi5v06Zu08WJWS4k0ANnCcU=', 'los angeles', 'California', '90018', '3232517866', 0, '', 'Alicia Diane Hosey', '50bf9a9c249289992b4e9c6972600774181a0a2800b95695403eb108bbc62615818916c11840a0d749640d57daeba31eqomi/8NWiYduFLk5uDwDKA==', '1980-01-19', 'dc66cc81e4da1b9ef2e58504414d910f8c84bdcb8cb30c590f9529d973a67b27c2f5350e4a952217a7b6fcf2eecfffcfM54DQAo1gpJ0JpB+270vQg==', 'California', '2021-01-20', '', '', '', '', 'Graduated', 'Graduated', 20, 15, 'Transport', 1, 1, 0, '2016-06-23 18:20:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(148, 221, 40.754398, -73.880157, 'Deshawn ', 'Millien ', 'deshawnmillien97@gmail.com', '717bc9f1bee38211be5917a2f0021905caad8bf3b551f98c367f58eba343e21d8a2d8555fe6ea441cd750f467465a4afxyx3uRYsFiJM1O+EIoGyoPHdFojfELSUJjJ+cxbw+OQ=', 'jackson heights ', 'New York', '11372', '7186631598', 0, '', '', 'eabc4009a1fb63d668bf6944b3fdd7e9e37255f735ed097fab2e2dfbbb85469746a54f155042adbd97f1ca91c0fecc867CW+XI9R8RtJW7NyTYpr0w==', '0000-00-00', '4ba164f095cf2cf78264d9d6308059058be7db575e52bad7db6be80cebfb532e9fd1ffdf4bbc2888774b97b3c7db7ae5h4z/ydlGTLg6U+oTJ1lgMw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(149, 222, 40.690674, -74.092804, 'Yasmine', 'Christian', 'y.christian312@hotmail.com', '1a20a9a34e10429a5d513b357990902cbd08a49f42e94b88923f147ff03724eef19d6c056a1763d9a0bf9da7d2372b5fYeGUn+ojAHcmtYwmLYY0/A==', 'jersey city', 'New Jersey', '07305', '2015899013', 0, '', 'Yasmine Monique Christian', '69e3a31a62f2d59b5f4f82fbeef44c9650acbf25bbc50615bbc0d491b3fc03407b7417bf85a268d4957d2299f581d1e5G7ng4niRQBZP5YCwM7iFdg==', '1991-03-11', 'a7198dffed47781e3df64043285bc96f402ad97a401cd95b81ef8f7f56aba8701928637a69a4c8d5d0408e75c5666abfsl/0AvghEt/szg+JkvRCd9iIu1NoQ+I+nnjBpzJKQfo=', 'New Jersey', '2017-10-31', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Anything else', 1, 1, 0, '2016-06-23 22:09:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(150, 223, 34.016083, -118.813049, 'Merlin', 'Vinegradova', 'merlinvinegradova@gmail.com', '4f11916d924fda029f6b31be5ef0396889023a65dab3b5ebd8423dc34120cda28c9e66928e89a64d5d3f86fd9beeb88d3G1fH2kYu9sIiaNMRSF+K7L70dw/9kqGJvSMdOVBGi4=', 'malibu', 'California', '90265', '3233339554', 0, '', 'Merlin Moss Vinegradova', '5cd741ffdceeb27f05121a47d0ded7c71dcc69238ae3ddb4ada1be70b50d1d2620c553dd8d4b4ee9ab26438bcbf0cae5ehY8pxoBAczpjC4f8QzH0A==', '1994-11-06', '03b8c35545b9eec977de27146ca116cf6b755112b00bbb0297cb8b7bc52e6d54721fe5ff639077215740fba118123ba5cto+cpjGV/ErWS526N4Xtw==', 'California', '2019-11-07', '', '', '', '', 'Graduated', 'Graduated', 3, 1, 'Transport', 1, 1, 0, '2016-06-23 22:08:10', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(151, 224, 33.447369, -84.163383, 'Cassandra', 'Ball', 'cassandrakball@yahoo.com', '48caa2847c55732481dac86a995acc9a0f0673f3f0373fcc0957e305a14e01f3a8614554d5124b121b1db61df8510b42hnRZl8sPFj/TxxJvYEGy++kewna21fq13kfpoUARAGI=', 'McDonough', 'Georgia', '30253', '4049532117', 0, '', 'Cassandra Katrina Ball', 'cc50aca7126b1487bcee194fe6900f4bd44046206e3a1c038597c1a0d4486a9485eef20ae8e78a8a9219ee58a6562c2cmTU7ccGYiDigFTliD71L6A==', '1985-02-05', '1d5539a188941aa02abf1df2e66c02e33ca0ef549e7c37c7c7841ed24eee933982540debfde2d8cd505ebb0fbc3610fa6MpG34Wexs0Lsz8KdBnc8A==', 'Georgia', '2019-02-06', '', '', '', '', 'Graduated', 'Attended', 12, 6, 'Transport', 1, 1, 0, '2016-06-24 04:00:23', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(152, 226, 41.967712, -88.203247, 'Jessica', 'Alexander', 'jeshalex23@gmail.com', '553ffa6e543346f94772859d8bc700ae32cdb011dd00a38b82e705bdbf00b416aff563d4b376de85f8e1d28d944a04e3jzxCj52mX2YLgq9Nl0p+TRMv8HIhFeIk+H6twrD8ljQ=', 'simi valley', 'California', '93063', '6304006824', 0, '', '', 'bff8c02c8eefda7a64618de177fd19efe08124334f841852b8db26db76ac9f38bd298deabe006daa582c00af4cf50a0cW5USyKS2wGZmItd1KHoqDQ==', '0000-00-00', '21cc00ba43f649abbc344e6dc2489eb35e67ba41547a5ee39f0b7d5768c7b3493af8eefac6a9bc5c7d701f7890e0e64dEjQZ99akC/LiIsCxuLXC/g==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(153, 227, 40.708912, -74.000984, 'Yamel', 'Favela', 'ya.fav@me.com', '5d27433d8cd628954be76c734ea5e4154b391a76dabe5a48e80cef9cbbba12f4b709d48e9b5beb6576c0bb814a3975321ZQ1ClwYaMV9S83CKNtR0FbObWq/F1KFLHIFq4LkMsc=', 'corona ', 'New York', '11368', '3475754836', 0, '', 'Yamel Manuela Faveladelgadillo', '3d326179ffeba0264d5a2018697ecce3f755c2e7be2a7dfb75ddb8a3ecb7eb1378056638a81f66a4b5919bddad3532115VnkW0BNus8nv5Ew2Cj6Pw==', '1994-06-05', 'eb10851e8cb042f7dbb0d5e0eb0206535d555ef267f24bc8bb06f245b35470475b1d6dc6ae1c85c185006f5d9f638320OSOxLFArdqpy3yU/UHxd2g==', 'New York', '2020-06-06', '', '', '', '', 'Graduated', 'Attended', 4, 2, 'Transport,Anything else', 1, 1, 0, '2016-06-24 13:10:20', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1),
(154, 228, 40.701675, -73.987732, 'Sarah', 'Aviles', 'sarahaviles10@yahoo.com', '1b4730db841b280b6fb578c087baefaff0e9fcae11aa07ac0717dc9c2e4325ee5d80547ce26c5de3f671951a13055f1ereAoZ85k5uCSs83s0AcmJYVtr1LKYeOQtXwJ/WtDDbc=', 'Brookyn', 'New York', '11224', '9174369769', 0, '', '', '00bc63dbc979b6bc4a1e793864d92cd25d5e695c8ed5a51155e0a743f8f6172248a93fce4cec8254ebce742f2784058448u+zWWCISZQu7gF7FYPlQ==', '0000-00-00', 'bbe6704fd99334a54e80e4b7846139f422b74980830c4a9515b298f57f9e1cee4a117eb30ad64808466ec1096a92956e0H51qM/AxVwtM0qYEBHzog==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(155, 229, 42.365627, -71.103729, 'Sarah', 'Crain', 'ms.sarahdc@gmail.com', 'd95cf9d62fa6827e530b07edeff44bca0f36f244e0b6dc4e29aba0dcfd244bf49cfa9561c233068025499b4d7f7d3cd4Mr0Hxsc12BfaInpAXL2R4l8wmnTo10JOqPb7kjCYHHE=', 'Somerville ', 'Massachusetts', '02145', '5183214881', 0, '', 'Sarah Rose Diblasicrain', '49442d97910a73f03ad3d51588d0a39fc03e790c1691115d3b7c9345fec832455abcbb5d505aaba7e3c0dc0e0d705338nMMOPviMKPSrD1NLffxhfQ==', '1988-12-17', '48bfbf874d6adcd3e9f569204cf6aae5f87b107f79bc9deef2a5f5e7faf3ad5d6f890b7934829f3def4519700858c524M13r+WAnITumd8fyeVrHXw==', 'Massachusetts', '2019-12-18', '', '', '', '', 'Graduated', 'Graduated', 3, 0, 'Transport', 1, 1, 0, '2016-06-24 14:07:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(156, 225, 34.023811, -84.043373, 'Olajauwon ', 'Andrews', 'olajauwon27@gmail.com', '35408cca41b791159b09929b6f5bab7483576af3aaf37440e2786f764ffd5a9465d8fafb63960daecf4b5d6d09e04438qGHGD7j+Zru1zPR/WKDjYIzfMLxcZ+HYbLyKEagMVW8=', 'Snellville', 'Georgia', '30078', '2162174450', 0, '', '', 'c56b378a5f0eb9e62c9febed5a94413bef4f8ce2ac693c4bd5c81bb56bcb0a6e233c2d2305985e74ebd2a045da8415a3EbRKDrq/D9yYAHvr3+dGfw==', '0000-00-00', '509accb61cf8979297c8e96e2fa5482c18153472f01a83af3b13f1b5c513d517d88048ba62658c6e53a038a5633b8b762ozF6mYW3zsL9068yNUSLQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(157, 230, 34.010071, -118.438721, 'Paulo R', 'Abesamis', 'pau.is.fit5@gmail.com', '9b202f4d8d5beb4734059b995b84422d0bd6af92e5a2d55777d5940023f331db4c40e82cbffb15e74d999768e006cb11mhzhNKHxtdHLBs4OW/qRnaa9qwoG49o8070OtDl8UuE=', 'inglewood', 'California', '90302', '8186755243', 0, '', 'Pauloroman Roa Abesamis', 'c006f855a64afc3ad91af1b10b8dce2598dee3609ba6482fe399d692f0c442ffb068f917e870bea9a74ec190eb8e499e1OirlL3jNKretY3eifKojA==', '1985-05-11', '6fc2f862f225066e547a8eb7a4ed67b100caba5754f0d281000202f506cccd1bbee2fe21efee210b04703e113e5feb6dk9bG1YWg0Z7/b8EaL+RKcw==', 'California', '2021-05-11', '', '', '', '', 'Attended', 'Attended', 3, 3, 'Transport', 1, 1, 0, '2016-06-24 21:02:09', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(158, 232, 33.514214, -84.362617, 'Ericka', 'Andrews', 'ericka_martin91@outlook.com', '3f46342e665b37f8e5c2d5f41d979466d7a34d1f1848b4b127ef1432882c735f0f7e6776c27bf947276b9676b9bd221alQtbYtHA83dXx27j1HBpxwOjCySJyCGG7obE6vpnv88=', 'Snellville', 'Georgia', '30078', '6789000701', 0, '', 'Ericka Shanell Andrews', '6de637e5cd503aedc1cf7151fd48b85c1b423b9354572907fc043751a939fc4450cfb51894b32fbe3a7ab6c9e4180283VBg/mgdOUyjL8jCU6Y8LtA==', '1991-12-25', '759b4853e0435c36f27a130d8c9f646dc7dc76d944d1f40624a1c4ad896f960eacf00fc5447140f9705eb38043a18a72qZF0x4+5hLDQQohMzXeJcA==', 'Georgia', '2019-12-26', '', '', '', '', 'Graduated', 'Attended', 3, 3, 'Transport', 1, 1, 0, '2016-06-26 10:50:05', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(159, 235, 34.103451, -118.302261, 'Candace', 'Carter', 'candycolette@gmail.com', 'f426ae24bc3430d5745b4334f9202813eaef73bb6258677cf03f603c40903dba00f459b03df3fa12d4379b897c03bc38FBlG5HP6NsQU6JqIA+H0EpI4dpeL+igfFisdB4bmXh8=', 'los angeles', 'California', '90027', '8187383337', 0, '', 'Candace Carter', '1a60528b6f7a78b68cd43e7a015e11401b65cb0e1438817c77c69b8c9555205b146ff845e59aeb7545e22931a8516a8aXgza7Bm2DS7+RTHUxzFV1w==', '1980-07-08', 'f27ef0f60b55bb3dd46adbfa909451c159adb219e927211d4057fc67e563d0ed6b0bad20cc61ad7a3db3f08aaeb93ba1N4ip4uV1ITFNtFImMVhIvw==', 'California', '2019-07-09', '', '', '', '', 'Attended', 'Attended', 14, 14, 'Transport', 1, 1, 0, '2016-06-26 19:58:30', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(160, 236, 34.106140, -118.463898, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '22696761f0df6fba8b324703b9acdf00ea39adbdf800187d51ecd2d7765a404d68e8032bc1f929fc0d13d77a10a670adfJuLfJQmTLFgL50Neo3ccyXqweZX1XaxZpMtcQdES8E=', 'los angeles', 'California', '90077', '8184658228', 0, '', 'Kimberly Odigie', '3ee1e3a4e866e351428ab4664c031e22cb13f24b830c03abceeb9ffd7c187a6a0eff6817f106380e5c66dd2f23e6e975B2dAMKdMfY/iRwaJe7y+1g==', '1987-07-27', 'cd6c15a67b7fcee355d7290b6f2ea021069f6cb9dcf7ac7e7c57bb9433fb37ed70dc5d86ec2b460f89eb7c082d6a824b0xI+9KxRVzxx7myUGA+6Vw==', 'Delaware', '2020-07-28', '', '', '', '', 'Graduated', 'Graduated', 2, 0, 'Transport,Anything else', 1, 1, 0, '2016-06-26 22:56:21', 0, 7, 1, 0, '1273', 'acct_18R4brJdEvzd2B0W', 'btok_8iw78X07ZxxCsz', 'ba_18RUFAJdEvzd2B0WhrdPHvp6', 0, '2016-06-28 17:02:13', 1),
(161, 237, 33.760777, -84.333336, 'Michael', 'Galloway', 'buckcitynow@gmail.com', 'c8cb25ab11963db53750398ab8321da5bdce0505d1f28793af7f1ffd418e3ea93e328b3376bee3160f8e1ff7573277a3VvNJulVRc5V1FFuIsV6/wmQPgdRlGmb3BqbUUXiXBs8=', 'stockbridge', 'Georgia', '30281', '8044055055', 0, '', 'Michael James Galloway', 'e3d45e38fe44cd1dfe578b054e0d3aa0c100fe0b480c709e318f971a25801cc0365a9074ef22a3299d4f4673aa88258fMtQHpltOWSi2D3Xqt0+EMw==', '1986-05-09', '7c020e2492bdbde9d18413afacffe340a1e71cdf29ac6558df2000caa72b5626aedb86ce2b2beddca3a318dbfbaefd63e6QKXyO5h3neoZS/caSj+Q==', 'Georgia', '2017-05-10', '', '', '', '', 'Graduated', 'Attended', 12, 5, 'Transport', 1, 1, 0, '2016-06-27 08:56:46', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(162, 238, 40.649364, -73.958435, 'Antonett', 'Young', 'ayoung81@aol.com', 'ec1483cc0208c7f96bf6be175b2755c56f2090226cbf22b7912a63a8f181fe8248f9c512bc5aa33f17ae33604a1d109aS5gfjD1FE1sLns7f8t/jQUq+izbfP1W1sCXX0UhxhZ8=', 'Brooklyn', 'New York', '11226', '3478161779', 0, '', 'Antonett A Young', 'a0d71c278be45c65b6db5755cb5d1f364a7fd4b3985c2bcebe917833ff3e3a271b0a1f489e20ee45e66a2172e4a23a4dweHfR7Vy5MKjPojsjjsx3g==', '1981-03-12', '0812fc03cec68eeaf796fd91e1f1aa25a51caa7f7798edd14accf9b3966bb628dc42ed54be01bcc72ed85a44e1424b3cNE2Dxu2sQCdkO8TDXHJ0bw==', 'New York', '2018-03-12', '', '', '', '', 'Graduated', 'Attended', 10, 1, 'Transport', 1, 1, 0, '2016-06-27 11:01:17', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(163, 234, 33.576809, -84.501366, 'Tanika', 'Kennedy', 'tanikakennedy@yahoo.com', '978c0c6e614aae04a7a4974dd31707f1771072a68c0fdc7e2fe1a6200de533ca8bff31c9a4ef80236b3e18172c622800crZQKjofKyb2rbajbUXsw5dEqshAzSsHXegaGVhf8l4=', 'college park', 'Georgia', '30349', '6787990823', 0, '', 'Tanika Lasha Kennedy', '4def01e33ed2aca83c440747d72510f2162ed429721cb5dd0a140dca3a47290b28d014324bf5e30698b48d357180d337weEem5Kt2aCsBY+jhN+ZTA==', '1993-02-20', 'c0e5b6887d28f8c7865c52a3b9e2d3a76931ba0896a79c83d750b42ab09cd0260456396316363f0ec7d70fb130a55407PVPkFDidZL0CgcRdvFS95A==', 'Georgia', '2017-02-21', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport', 1, 1, 0, '2016-06-27 11:09:08', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(164, 239, 29.522718, -98.501717, 'Felix', 'Odigie', 'felix@myqapp.com', 'e0cca3c57835a3f0fb05005abdcba689d8c93f76e131a666bf2de310a62df2f1f80542b59e51c0e4add1fa3e85fae06b/TrtNjxwyomRPNXhQbJi2+cx6jirK7dRBLYpliYMv5s=', 'los angeles', 'California', '90077', '6173881912', 0, '', 'Felix Im Odigie', 'b8bab7a590231cd80dfa2cc81dea7837704ebaa15e0d8f4f40fa1436f8db210adcac64a23a08f7a165fa9c344e2817b9zCBm0ITEo8QqDfdUZ2xChg==', '1976-09-30', '0e536ff99412aee8e15ea9da68b8eadaf90621d0349e0dde5b8569eb2bb4184d84cb219c0374a6a5093a9eb363f1e2c4oaXFpElpN/h0ChEE8rDDzA==', 'California', '2022-10-02', '', '', '', '', 'Graduated', 'Graduated', 8, 9, 'Transport,Anything else', 1, 1, 1, '2016-06-27 22:23:28', 0, 7, 2, 0, '9326', 'acct_18RDZwJk4TAQKJ7C', 'btok_8iysZWzZUYmShK', 'ba_18RWuLJk4TAQKJ7CFaGrUxJj', 0, '2016-07-07 01:55:01', 0),
(165, 241, 28.308712, -81.360764, 'Jessenia', 'Carrasquillo', 'jcarrasquillo90@icloud.com', 'f4ce719eb34288d6080cafb3b768b6207f797894ca5bbe3796088c5390b4edcd9b29e83097b1298eb112468797be76e8M91qRUCzIi6NeJUSTvZTCbHecP3hrrSAtoadxq249JU=', 'sandy springs ', 'Georgia', '30328', '4049914198', 0, '', 'Jessenia Amada Carrasquillo', '941e2d8845a5b90f26b0824a94ccef22e19dbed93dbaf4d2a44550a20d435f223d1b561ab55908dab8d97c66f92ae0a2yjH/dV+KWVHajQPCZvAagA==', '1990-09-22', '437df6916a2f56e262e535eb4cf9c5f4e6dc823b6796c419812f9c8d1b7af389d459050fd433e43989a5eb4c3e691c11Yuxi8p3foPgTMnBYtupXlQ==', 'Georgia', '2019-09-23', '', '', '', '', 'Graduated', 'Attended', 5, 3, 'Transport', 1, 1, 0, '2016-06-28 01:41:02', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(166, 242, 40.907738, -111.872368, 'Barbara', 'Horsley', 'barbiebabe115@gmail.com', '77999902fe0ba91e7bac172dd6cd397773a4372980fbe9871ee47560a989b97296c6a195bd62f69482a9c3d6aa7d994cDv/EgRxTlAs6kJcRgOVhv2p0ZIGOMKCacoM5jwDUIbs=', 'centerville', 'Utah', '84014', '8018886538', 0, '', 'Barbara Lee Horsley', '2ea94166eacf74aff06da0d6a3b79f532ba8777206c5cb68d010c18cd561bc1fe3bbb35fcefd14548e211873ed25c58fTF79UQRyWGbddxa9/wiodA==', '1997-01-07', 'f0c0ac0288b3aa22d799e2b16fd269031cd19aca6499ebd72f96ac0278c135174039fb51fb4098b65d15892cc63f63d5Oh8xRwihdzah22QWDjcSWg==', 'Utah', '2018-01-07', '', '', '', '', 'Attended', 'Attended', 6, 4, 'Transport , Anything else', 1, 1, 0, '2016-07-01 03:01:15', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(167, 245, 34.106251, -118.463783, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '3f31f5e5e7d7649580a43dcb21cd6d1a52aa0e10120e82c526c4b535c36613709054024494ef9154a261165f6773193eduGo0N7yTVD9AgK8olkl/ar6mWqZ5d1nZU+HpvJeRJQ=', 'los angeles', 'California', '90077', '2038879349', 0, '', 'Kimberly Elizabeth Idoko', 'f1952fed8e599827269e00235db391b4520e5d4303334323a52a58369941394040eb45a72b008ceec586050f80692c7cuSRqUUNSXThN6HL6FFrszA==', '1983-07-27', 'ad54e8c5f6cc31a848632b38056ef2149e6b9d972a023565b9fa5e2fc0148fe55d59b188211df3a32077186db0675fd3qJNkxEO2yOXQdDHRMfQbMQ==', 'New York', '2022-07-28', '', '', '', '', 'Graduated', 'Graduated', 12, 0, 'Transport,Anything else', 1, 1, 1, '2016-06-28 20:02:38', 0, 7, 15, 6432, '9326', 'acct_18RX6ZH40Jarjfbo', 'btok_8iz6gB98jWqLru', 'ba_18RX8OH40JarjfbodX2t0zQ3', 0, '2016-07-07 05:34:30', -1),
(168, 248, 33.650951, -84.451218, 'Kamilah', 'Carter', 'kcarter25@yahoo.com', '8b96fb2cbc496e523e1ddc4a663fd7fff0f8c13be5c069682988d237a8a64cb77317c7355cfe304c5dd62e1f3323b53byc0gl5mt4Yrh/r2o+IQIj5o1T83eVQzcmhj6wdSI6qo=', 'East Point', 'Georgia', '30344', '6783589025', 0, '', 'Kamilah Janelle Carter', 'bbc40abe49ccb63a42ece16978faef53146c512c026a438e80e20d3a32d52bcab0c3d066a81090d9d3792cfb9c3a1f56HFwU+cPs34oaBQ1lW0b/yQ==', '1980-01-09', 'b5113ceaffa394a82086b542e70dba518b34dbbd534ab9481b75cecc2e0fa77e60b335ebb0d1b9e7cce9c0ff83ef980eqwCrRUPnupqmKTtXYQC1Bg==', 'Georgia', '2019-01-09', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport , Anything else', 1, 1, 0, '2016-06-30 09:45:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(169, 251, 33.227955, -84.266403, 'Ashley', 'Anthony', 'ashleynnanthony@gmail.com', '5393a3fd823a7b9f5e77b8bdb7ce086809eed79d15804b9d9b45f90ca137021c4ecd7c627ded9084eaf8da163d61ccffavDyNs1xFheBtJVaXTMB3Q==', 'Griffin', 'Georgia', '30224', '7703046301', 0, '', 'Ashley Nicole Anthony', '4691daa6265cf775142c673d0e1e39d49d4739eee3335fcf9267cab01493c882e7460e458f9f9dde38572c0ed867414f/oZZWbieqd9VyP3PFhR8aw==', '1983-11-10', '9ba594adf31adb81b421f738126923aefcf91c74cf3e164cb5222339d34dcda1a42c0503909ffc2ede86919211686c24m91/j1BX2Xy1BA2VJpOTrA==', 'Georgia', '2016-11-10', '', '', '', '', 'Graduated', 'Graduated', 14, 9, 'Transport,Anything else', 1, 1, 0, '2016-06-30 11:16:41', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(170, 252, 40.740707, -74.184555, 'Ashley', ' Bennia', 'ashley.bennia@gmail.com', '20840ab10fc49702ac8b410ddad059c1db333a46888bfa2847c38a753f8b3a2886e6c72db25c0452ef792e225be06aecNqLQ3n3+QAOZM4XeAb+lvIe5Ip96WZyanBwVuhQTYNk=', 'Sandy Springs ', 'Georgia', '30350', '9737276699', 0, '', '', '1f06a14af30e301386291edd4313758a39ea17a9bbd9961946111a4bbf24641e4c66f00189ced98615b24e3b5d32ca22OVpzaV3q9Vf6UFxKoPEerw==', '0000-00-00', 'd5880e01ccf69da561c56fd4cca55a139d8a692698d02255be530729950b0ab594f88ceeaa44f72eb7b4a3f1349e80f20EgN3dBVq0ro1nZsAebfjw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(171, 253, 34.105965, -118.463722, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2a4c554f7d37358c8572ba50239c0914cdab3701b0711de77bce12c86cecd2fa153f27ea8b30167fe659f0f801359e34R3ouYBE6mSkLVPQoKCp3SpzSxuyHtNx3YNo6HVWawJY=', 'Los Angeles', 'California', '90077', '2038879349', 0, '', 'Kimberly Elizabeth Idoko', 'e6a3c0196e24275efc280d82af40f5babe2e8c8844127244785b9371bc5f3b2db2c442d64a8dd23610381c6aba43d8dfEICww+7xZFeHAzoyuXMHLQ==', '1983-07-27', '85673fdeee254133b89be13a6899147ff8ec505823904949958e7fdec0add314783bb2a76e2c21ee1c710af47e8eaa88UGKHtH0LOOZWThgW+HRpqw==', 'California', '2022-07-28', '', '', '', '', 'Graduated', 'Graduated', 15, 0, 'Transport,Anything else', 1, 1, 1, '2016-07-02 02:47:02', 0, 7, 8, 12170, '1273', 'acct_18Sj6cEJ5ByhSLhE', 'btok_8kDaE5JuV7vwtn', 'ba_18Sj9ZEJ5ByhSLhE63Uqz0H9', 0, '2016-07-06 19:03:20', 0),
(172, 256, 33.920895, -84.561516, 'Taja', 'Jackson', 'hill_taja@yahoo.com', '5459f7d0d236119c995830a18458d0ebf9542c3b9127fd38e777171004a6ff8955f1cec06143e86335cd00f94025bd4fwOHGLN/0HGnEtqYMyHd62L9c2CEnzA0od/uQ8DPDats=', 'marietta ', 'Georgia', '30008', '4192604385', 0, '', 'Taja M  Hill Jackson ', '2a56d0ff75a023a637444f4151d9061c099d0081706d90ad4c1eb0eda7bedd2843b9a250662c2d2500b9a69edb09304fPJUY6s9/P8yHpnRMxxCb/g==', '1994-06-11', '0b618e48182c0de3bb2190113d738de5bf54203c4f5e90b50e0c813ffd77adfb29320f0320640c7bcc61259ec1ac8c68Uqj6ZCMRHGIvWB/GvYHnlQ==', 'Georgia', '2024-06-11', '', '', '', '', 'Attended', 'Attended', 4, 4, 'Transport , Anything else', 1, 1, 0, '2016-07-03 20:12:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(173, 257, 33.776676, -84.301117, 'Jamal', 'Jones', 'jamal.and.jones@gmail.com', 'ff5a3672c2fd5fda3d42c6cfa81d2b3066411566ac1abc164f41283f249550bcbe469a78145a9970867c3111a92ce6b58qpLHIfZtOZervB7DXH241WSS6I7KeOjC4/WX6MffH8=', 'Decatur', 'Georgia', '30030', '6099297013', 0, '', '', '16e0f84d1ec59dff6e300cc159ddba641f221af607fa395e6daa452b3018b13e1b80c3f2c1d53991fe94274415b0ed55/nM/pY6Npa65rTkjgRv9+Q==', '0000-00-00', '382dca915957545085a30ab5be161910547e8acd7bdf3d18ed2a60e9635ac166947b15ef2589064613927a1d20e1903fQGs94rO6SF5rEH4YFcaezA==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(174, 258, 40.612209, -73.945305, 'Jake', 'Montagnino', 'jmonte98@gmail.com', '0512cd56c717b9fdd3d12c2a876dbbfce317aac5372eb150e55ef0025f23f4bccdf7af98a55581850e13821d643f297ew1D4gizzkAjMs+zLYMEJ3Q==', 'Brooklyn', 'New York', '11229', '3478160721', 0, '', 'Jake Lawrence Montagnino', '7337e8697e509e7b3551efe355619aad9378b5dc2903168d97dccb3e18b66892d792486375f4665da63b4c912fb3e9b5RFTNXH+J/GJkemE0MV7Tyw==', '1998-01-22', '44c3140ef81c8326a75679912625b19bdc7a62ca788bb1648a54fee85f10325327d8d0220b288cb3adb931be94c5df67/HqDKABfGcgEf6yKQRI7gQ==', 'New York', '1998-01-22', '', '', '', '', 'Graduated', 'Attended', 3, 5, 'Transport,Anything else', 1, 1, 0, '2016-07-03 22:27:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(175, 259, 40.870617, -73.858742, 'Gina', 'Ramos', 'gramos98@yahoo.com', '84ecb84f30f6e71ddcc415412c0c1d26dacc5e86b48a2814eb55b72f75ce05191543385dadc0c8b3d5b21068c3b9e801DeDlt2qfxPdtHBrKnBnOgI9algtyzovq13Xj1f6omNU=', 'Bronx ', 'New York', '10469', '3472556470', 0, '', 'Gina J Ramos', '0fc8313127acae07435f1256229db93569b5d5f7048fe108709eb2ae937bebcda41e18b3b1cc11574e213b436c2df469X/HB1xE9pKNAO/zdSnrRhQ==', '1984-09-07', '1d9ec0054db2cdbeed6497542bb673720df7ea86a4e5b77e33d21bd51209902e0b786ea3ea19b74e33be0380acf4b8c9iHk0AvNJDAjLmiwLaQtFcA==', 'New York', '2023-09-08', '', '', '', '', 'Graduated', 'Attended', 10, 7, 'Transport,Anything else', 1, 1, 0, '2016-07-03 23:21:33', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(176, 260, 35.453621, -80.848442, 'Michele', 'Sawka', 'michelesawka@gmail.com', 'dcf2680c44f9193d5a496b46874e94ebc9f06e7f413b3e4b852a8d81c7fcaaac00d1cba5be3d745aeee17658173d0502o/YI7u1oJNBpXQQjFxWV3yb0WuknpVb/5xtPXv8Q2E0=', 'Atlanta', 'Georgia', '30329', '4128979809', 0, '', 'Michele Lynn Sawka', 'dd52f99813381864921ef07a14d6d0ebd72fe79f861c39eb074763b25718d51221467f3570f20abce6a1b808f00d3aa1lJK6dOiRQTvk8Th9eyZM4A==', '1975-09-25', '3ec2494a51d8359e44517ba78dc0f54076b56b12250ac1d560fbf18728ccb9c6a46dfec46f718a968add9fe7aa711abdm64GFWseq3UeemWjBsEeCg==', 'Georgia', '2020-09-26', '', '', '', '', 'Attended', 'Attended', 10, 5, 'Transport,Anything else', 1, 1, 0, '2016-07-04 00:39:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(177, 261, 33.789444, -84.689316, 'Cecily ', 'White', 'cecilylong19@gmail.com', 'dfba074114d49b11acf067cc7dfe1c7cb9ec90568451585f47e8637768547a53bbda25b28a98629a8521f7c7faf409bcpwyvqzdpW6hpvAjB8wB5tAvXbBIGTVniLz/2MTebDA4=', 'Douglasville ', 'Georgia', '30134', '6788306836', 0, '', 'Cecily Francesca LongWhite ', 'd313ec9a7e036772974404cefd25034db6cf0650339dc24a9db5d172825e72de07e50d0d8a504aaf2470f1fd8b726424BH4S7LMQDr6BoKSYfmRN6A==', '1977-09-26', '6dfa35de9b12b72aaa851bbba31d53015d214fa7b51aa76bc4903c2a4787a908e1bb67ca0c090e9c20aef75f3f12715feoQ3nV+ERbRUTnkaLJSqTw==', 'Georgia', '2018-09-26', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport , Anything else', 1, 1, 0, '2016-07-04 01:32:55', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(178, 231, 33.536110, -84.048462, 'Alyxandra', 'Pinkston', 'alyxandra.pinkston@gmail.com', '00b2fb8b3ae2d82ce0a44c20e7c0d05067536ab3cdfd5a84ce3bfaaca92769d44f5842c08766456337e431e6bedd1bdeiAnuSol4O6cdgX56urAi4q/KTwBFnrzd9cJfqCIh9CA=', 'Conyers', 'Georgia', '30094', '6782944973', 0, '', 'Alyxandra Marie Pinkston', '6c0f39f0e942c8e06cbaa9e070a19804d0a44289d8359b9cd7cd4fb974e76890f0e1c95daef732782bd3d767773c16ecM+HtJM+gf1FD2mxaklMzZQ==', '1992-10-26', '53c414481ae1f5c19a64805e21bfdd1f7db2f1c212241e92f93d9f7b402df7e0f35301fa26d4d166d3e818e697265313/AV4yMqrWqRCThzwfRs4RA==', 'Georgia', '2020-10-26', '', '', '', '', 'Graduated', 'Graduated', 2, 6, 'Transport , Anything else', 1, 1, 0, '2016-07-04 11:22:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(179, 262, 0.000000, 0.000000, 'Taycia', 'Orr', 'taycia675@gmail.com', '66cd46d9a16078152bc9502087b4e691125fe0023304eee1fb34c10d742e95f3c56d19148bdc2e22e61ca20188d4b62ceJHkP29i8VbgnOOZzjBFcSvGIw7KBpjPMSGXR/A3zGo=', 'brooklyn ', 'New York', '11206', '7187089275', 0, '', '', '6ecd83dc9b74f93f678ed5ad9abd4931d8adb21c67196fa8b18c6e0f0ada8a9e0371d9e1d35cd49064d53d5dd28060a90Bdg/r6/MDj8pPjqIZQFRg==', '0000-00-00', 'e01c17445dec2039c38643045e03dd518cc9f235354838eb08becf8d86c6e9d37650d04997d5b219b95a850849f76b47gp0jXahiTixdLGLjJdCZ2A==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(180, 265, 34.075768, -117.879509, 'Wesley', 'Reeves', 'Wesrvs25@yahoo.com', '66736bed163f8e6331376bee81171e5ec511f530f067bce0e9867100985f13cf2e3fb8f433a30f0ae0c1ba75bf7be707CiPYg93zCtF2aXxWULhBpuMkpZVy5PoW9S/TyYLv/Q0=', 'Covina', 'California', '91723', '6268064841', 0, '', 'Wesley Nakata Reeves', '508a9bf02b6666bcc330ad8533f9a4c3ac2e701857c6043ceece1aa763b2a724dcf6aa71a51b1d874b98d76bd2526fba8SOmukbKZ25k/WwEsXKS9Q==', '1990-03-22', '8a0d605065a0f8ec3ab28aef4baf76381cbf74e11fd166238ede5d451f3e6de40696a20e28dfacd54c733af60e0e41e9KJU2iH/0fajov0HothLNDg==', 'California', '2017-03-22', '', '', '', '', 'Graduated', 'Graduated', 8, 0, 'Transport , Anything else', 1, 1, 0, '2016-07-04 16:59:07', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(181, 266, 44.748878, -93.218567, 'Dan', 'Walters', 'danwalters6@gmail.com', 'fcbeed0c36f59866885eccc737a6ed129b1b2f0f3399ded94649778d00f60fc87a07a17ca73e735f2136c12974249a87lmgkhFpzabak3DuGVPwl7Jou579UF2uDcH5i8/oGLyg=', 'apple valley', 'Minnesota', '55124', '6513685913', 0, '', '', '7d1a8c485994abc080dffbb50dc62fe7ac24e676cb0989643246c35737618788e49f1c8ca6d87f32491e52c4d6bd1119j7GzGodlchElC9YylgTb8g==', '0000-00-00', '9b465da085eba67f738ffd91fa7f9f27f0920609135b654fe96bff9db923f4bc7ae258ce8ca93e4d6522c73a4b76efdc8IPK6FEroaw1ljGkfSdIyQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(182, 267, 40.676857, -73.780006, 'Adrienne', 'Moore', 'Admoore23@aol.com', '0a7aab5a0009290972737c7bfbe8b5fff77cf4f96a34f326365a055b15580d23cf137f86c142f11c5ac9ca36c99dc771gfpXSflmRgpJHpjeepUlqynv5Z6QQeYYRwVlEB5JkNU=', 'Jamaica', 'New York', '11434', '9175098032', 0, '', '', 'd8105c16dda5af564424b0a3f1f6c5a7bb1fb18ef3ac76ee36e37f6bfbe0e59e9f57ce8198c27479d9390aa3071016ffUoto1iAYzDzSzfgxrHEMBA==', '0000-00-00', '9c9fe8ac8fc7f2b41b9e94144d2f7dcecca201eb198f5d74a2e8edc99646db739df1db9be7b82f0fec4b3b66b038a406e3jKYkCeMt6jLUgPpuhJWA==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(183, 268, 33.670513, -84.370186, 'Avery', 'Calhoun', 'averycalhoun62@gmail.com', 'f31608c2ce9867b1a5a1af03a02a344d220fd8e620cfa3b2c7c84788c5a9abacb95e34157ee3467950b9f626d914e3d1/rBq+JUrmydcwoFPX4NYeeIv/iUCqWn6EPpJ6QxSVzw=', 'atlanta', 'Georgia', '30354', '4706850090', 0, '', 'Avery Deshon Calhoun', '48dda8052845ccef1c0389b5f93f3ce094faa2b7044141701bb604071726d53ee87f5b1e1ae1ff70e5a829e44f5fc9b8UEAwPj6CywU2THGmJXg6Ww==', '1996-07-29', '79e1831fa30af374c7a2ad7a79c6cc861fe87483b6b78362debf5438ebe0a2ea0b78cb8cd90d5e92e890d286768c770aiN1ievf0xQQcLiA1wV2SdA==', 'Georgia', '2018-07-30', '', '', '', '', 'Attended', 'Attended', 3, 3, 'Anything else', 1, 1, 0, '2016-07-04 15:54:05', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(184, 269, 42.372738, -87.869438, 'Jordan', 'Welder', 'jordanwelder09@gmail.com', 'd247c89ac9c5e0bd8a799e918edf74fe665a449dfb0343e7b9296d103cfe49453664814c5b4cdb9a0be7840ddbee37271iv8UYRMlKhlcBazwlrY9oNuHdI33Kdcn/RSQGYOZng=', 'Waukegan', 'Illinois', '60085', '5159713593', 0, '', 'Jordan Welder', '736679dfc6ffab373175f7efa4a84d5d31a0cca8caf707ba7c51f737042a778d9a8cb2f400802d90c75a95b71d1ce4eeydC+FVW/iwMFfEvnqZXMQA==', '1990-08-31', '0bf56303c13f075b17fec7e4fc980259806ee4f68c629bde3950d5af96654081008fe113d6a44519403e5310c5ce89d7XzDvT9y+flOnKLFRJSNxgg==', 'Iowa', '2018-08-31', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Anything else', 1, 1, 0, '2016-07-04 16:18:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(185, 271, 33.765968, -84.768478, 'Crystal', 'Perkins', 'crystalcperkins@icloud.com', '54ffc3741a1e12d303e3e847509769b2a8f18a6d8357c05e6a2fc0f8db3056bd4d48a84d154c480e77c205de7d82b2a5yyiroMYjz7mrwy9zK2aR1ICE8USvLXQb8fJ60AVEMx4=', 'Douglasville', 'Georgia', '30134', '6785279905', 0, '', 'Crystal Cherise Perkins', '7713cd479eb28641b625ce96857c90a570b594ab95ea69d35a8ed510700121d1f98e7b7dc492eb5995d8fd0eb741527c+F6+pRkJYvt2bu3upBK/aw==', '1991-09-26', '781dd2d6b8662eb30e1551f9642675460893f73b1eb2bc6b7ec586ed1cdf15fe83ee632256b3892dffcb6591fca07a98DMVlxkLue/5YW8PVfx6IYQ==', 'Georgia', '1991-09-27', '', '', '', '', 'Graduated', 'Attended', 8, 4, 'Transport,Anything else', 1, 1, 0, '2016-07-04 19:05:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(186, 272, 40.648502, -75.012558, 'Gilda', 'Palacios', 'gildapalacios18@gmail.com', 'f1fd103d14cf0a0682a888a45e1ec88b16fafe0181ea0f867299cd8e9a95777dd9e0f5f134dd701dd89a94a36fb4cf55w/aFNsfxP+stiDZApkhNhlvNr3+Oq4+O0JeY1/7bEs4=', 'Jamaica', 'New York', '11433', '9294423124', 0, '', '', '45285ac45086497966ce8996250a0efcda92fd692dca6f261da599cbbd45e5fa263c9d4a6dc4d2744e84296dbe7200f7dnpv38y6Majg5LgEprn9OA==', '0000-00-00', 'fe91aed9f17112573208121afd817b9d5250ca534ece6a1362675b7154ad54eb8526c88949549ffd83fb1071714b168dcUHcESjEDjsFRn4z/zFLlA==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(187, 273, 0.000000, 0.000000, 'Nykiah', 'Morgan', 'nikkim2@msn.com', '832f9ba4fbd2e1d0ff8eb47f7549c3f3f2ac711da914a5e329b30eb71dda9e3a5f1b1b28919af855b56e2538bfd63fa8x9rf5xR0i+65wmQv+1JRpj94xvd9THyu3Ld9v7GV9kA=', 'westbury', 'New York', '11590', '5168526639', 0, '', 'Nykiah Morgan', '7b28c5123bd51d10e03eea72cfd8f274f948b3e10d9a43f4d7532c6153cfc7e1a175e2284c580250b54653283f29eaeaiYrUu8L11aknxQHXhNBbnQ==', '1976-11-14', 'e3a0e38bfbd3c13aa634a822c20f675dd556570ec68cfe25513b62f598fa7fe6f7b6129a984626cbce03c840ae7a510c4QEAtkD5fX9Wbwwmnb0z2g==', 'New York', '2020-11-15', '', '', '', '', 'Graduated', 'Graduated', 13, 13, 'Transport,Anything else', 1, 1, 0, '2016-07-05 05:06:06', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(188, 275, 33.590199, -84.491798, 'Michelle ', 'Mosley', 'chelle_4334@yahoo.com', '006462372828455801633fdb6a372a9a2275ae6cec231a9822db4293964a6590a77f8576e749e16782bc51af2bcf8189I95PwxosrLQuSToF+0M9vYUKLjukzC4zbNmV4ZdoPk8=', 'Atlanta ', 'Georgia', '30349', '4049096627', 0, '', '', 'eeeee29998350d98b0f061af612c350c1eac7c91b177c6de1c5a16f563553be012fc31b61a77570e2a1dde2d4797eb71DHmSVO4Ig0CqoTsKxQ5h4Q==', '0000-00-00', '6666929fe0d6b9cac1fb83697c7e3e4a01c69087dc8e3b39e115e94fde6895117e8a482ebb3e1bd9fdf45d71315225a0DZFuLD8jDRc1zdbYaGAtZw==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(189, 276, 40.706715, -73.909668, 'Jeszenia', 'Jimenez', 'jvjimenez76@yahoo.com', 'fd133c555a73638d03e0401c6f12c0fd472b3701ccb1e739766dcdbd268964fd7a6040b7272ee67d6fcf5b3f38d3c581H/IsUYucig/rKVLu5R2lQ8ruQc3gptFds7c1VA+OM5A=', 'Flushing', 'New York', '11385', '9177956847', 0, '', 'Jeszenia V Jimenez', 'c6eeaf728d7d00fe53b2f7f82985d2bc59b30ec5ecb0bfc7ea389ae383bd6398ec52779ffba67020200c633b089d8e31HN+Bs4KtP8ZUCv6BiDGcIw==', '1976-07-20', 'b7357542db51b6355fe04aef94bd88c87ecb6355e208b54b5092f1b69301cdfadf5dc549dee4a7a20d896277d73854050kz04X717cEx424TLALM9w==', 'New York', '2017-07-20', '', '', '', '', 'Graduated', 'Graduated', 19, 5, 'Transport , Anything else', 1, 1, 0, '2016-07-05 16:30:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(190, 277, 40.711098, -73.963943, 'Janiella', 'Franklyn', 'janiellafranklyn11@newdesignhigh.com', '6f0c301aa8aac763e9456cd78a090832cf7c853a8315c0e5f9e4dacd98a04b24e9b3e55e047f52f6c5e4395d2a3d3a988l7YokE59kRT5PjPV/TYMIxrf2jZ94SvSFpP6TLPF6k=', 'brooklyn', 'New York', '11212', '3478560739', 0, '', '', 'beff55f94c363c46564081d1b45753099c5a7fcde091810db84858695cc56ce3adb830dcdb24da76cef564d86e45ec3abRxNeXq/S4vGonMl4qHtXw==', '0000-00-00', '4b25701613104cab76669754fa285413fae4fb5ae7377100620f13c70d0362d329af9c41b2f1c1acaa5223c4ec7c60cehsR3byJxs538X72OB/6KmQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(191, 281, 34.233917, -118.565132, 'Ashlyn', 'Nichols', 'ashlyn.nichols@icloud.com', '1656c33a231388b846cf0e52104617200694a469717068d9dba6ce275d4e4cebcfa7a833fc5843a3559c1a8587899725RUiao6KRztqVRqC3FKNYMzvsdzHjNvpvkVB52i447cA=', 'Glendale', 'California', '91204', '13103497018', 0, '', 'Ashlyn Christina Nichols', '299f6a1cc75724b7cc9ee419b892a654157b82b10d18fb9dbe0df68b4efcaf423e580c648fd4b831c7279928a1ccbbf81E0O+pTkkgAb5faBSXAugQ==', '1993-05-22', '85a3fd87d39453bd58639427ce286e36de646855c28ded9264144909e775210f040554b1463714acdf9c2e598aa887f2ItfDwHVOussJ1wFtOBNmLA==', 'California', '2019-05-23', '', '', '', '', 'Graduated', 'Graduated', 4, 2, 'Transport,Anything else', 1, 1, 0, '2016-07-05 12:14:49', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(192, 283, 33.343716, -84.201904, 'Shernette', 'Hyatt', 'shernettehyatt@gmail.com', 'ae4377c4a967e1486a89fb545b8ac096329b4210341e4571731163e73c0a719980dcc4bf4ddddb62267b89ff2f014588f5Lce6cOyufCU0njs0ZSjfeV8wL971iX5N44BrENUeI=', 'locust grove ', 'Connecticut', '30248', '5163680282', 0, '', 'Shernette Reneta Hyatt', '326c71b587db72bb2f3ab5f844be1dbab30347d03f932a74667faf643c62b70bbcc9f4d6a9a4b9a2e46ba7c9f037f867cAHUf1Hb0LFu1FTlc0e5pg==', '1982-02-01', '11751d0fe401b98c3fa5885a158621cbd3f5531539ed0a64757705099155d87b62b3affef2ffa847d9365845b5399020ou/JxmOcHjE7hHY9IMjavg==', 'Georgia', '2023-02-02', '', '', '', '', 'Attended', 'Attended', 5, 1, 'Transport,Anything else', 1, 1, 0, '2016-07-05 14:36:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(193, 285, 40.715099, -74.006721, 'Michelle', 'Mayer', 'mellymay643@gmail.com', 'fe93a2dddae02452186f1379a1f6442ec30b6ba07f3e30ce8a4e5869a072e16e233a49099e6c2b01aa75189c4bd3c984hyYeXF4xIjQbGUb3d/ky7Q==', 'brooklyn', 'New York', '11228', '9175334203', 0, '', 'Michelle Bernadette Mayer', '3f42edb989774ac3b06cf9647c0f2e6102e9f064e7aad849814606b0cbfc9ee9ca1f300f6ae65a4f22bd01e5eb14fab9eScIKbkdhv50LYRmlyedKw==', '1994-09-05', '7e5f39dfc795cfd4595719a27a5206bf720e2001fe9ab3152786f9e2f975499b47bb96777755207bb76c8d41cb718e4d1h/aQ8vcH18lDKLBtvchbg==', 'New York', '1994-09-06', '', '', '', '', 'Graduated', 'Graduated', 5, 5, 'Anything else', 1, 1, 0, '2016-07-05 14:20:21', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(194, 284, 34.079906, -84.314163, 'Matthew', 'Mcdearmont', 'mmcdearmont@gmail.com', '61f46b34790d1cafcfa451da2240f06133624917ad976a99f4b68f8a8eca1fb14037e0d8c4214aa7111722e953e8973bQHGvazCFCSwobfuRxMZdHJLC7fi08ZAQHbJplpGQmOY=', 'Alpharetta', 'Georgia', '30004', '7706807774', 0, '', 'Matthew Bradly Mcdearmont', 'a6ae0ad2627732ded836aeb8965007cdce68daf3fd93190d25b220e77a1d80430a98bb4d31b0517eef82ac91e90d4f5861l7SToMTeTcv4dBrfbB2w==', '1964-01-14', '1ed956329a3779ae3b7e1b68869a24e3e8c92ca21afc9681574a6494c09fcb9c89defe47693ff0eb5d1353cd9b1ef117yrk7L/Fa+9wkcW6vmLQ8Hw==', 'Georgia', '2018-01-15', '', '', '', '', 'Graduated', 'Graduated', 30, 2, 'Transport,Anything else', 1, 1, 0, '2016-07-05 14:31:55', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(195, 286, 34.178314, -118.361771, 'Adam', 'Silverstrim ', 'ajsilverstrim@gmail.com', '9b857ad70ee09946c9b730ea9f8a9d7a1b44096e4872a80b475aa0cc1a142d70438bdd80eab398b87657d5d26380d877NsIPVoOvOHn8lksoE2AjC60Obn7Wm7HrgKX4E5N49f0=', 'North Hollywood ', 'California', '91601', '6178187846', 0, '', 'Adam Jacob Silverstrim ', '6d2fd94df6c55bace2b5388f8af7d7582aa094cab7097f35eafe187f9796991f80db2d7513c82d7fc2530e13a59670abK53r9+1wy56WOjfp7UQDZQ==', '1996-09-23', '723d5f915e78e75396ee458bd2ef41bf439a041bf95bbf142c77faa9fe1252f40f598eaa3edc8258e4e9788b703b5eb3t5OUQHZhguu2g+qFDGzl6A==', 'California', '2017-09-23', '', '', '', '', 'Graduated', 'Graduated', 2, 1, 'Transport , Anything else', 1, 1, 0, '2016-07-05 14:49:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(196, 292, 33.527081, -84.373238, 'Teresa', 'Brown', 'tree866@gmail.com', '76019ab3cf01169278d73605b3a0929775e2195a486ecdb17eec1f2ed8e89810adcfad090acb0d22e56d2ef87e957d2dvAZFNp+SNmtJ28qGXTasWeeCMla/QQ+9z44c06lGc9U=', 'Jonesboro', 'Georgia', '30238', '4049529687', 0, '', 'Teresa Melonie Brown', 'a20046b8d6c23d813cc19d325c62d93e3879af69abf2bf0a169b49040c44bcba44c3952b3d2485216e34ed3ba4416613ey2ESC6PiGlr9ZF8XA2sJQ==', '1975-02-15', '737a26585de904fc53e79b3f8edae2809bcf57c146e2562304067fe6e4037283716067527e79b711eeb2afec0bb32801dtmxWNoXg27Tii2mETmbMw==', 'Georgia', '2020-02-16', '', '', '', '', 'Graduated', 'Graduated', 21, 15, 'Transport', 1, 1, 0, '2016-07-05 18:59:25', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(197, 293, 33.888073, -84.564499, 'Parasia', 'Cook', 'parasiac@gmail.com', 'd2a70e2cc6c00ecbfaddd09974b1623f4dbee87fea52ac49e03fef8207cd88ea738bf1b1304e8af5e1e5d8544d2646d4o3nLaO3A9tt6ySmgrrbR9zxDjPHkAauaBQsEsMUOh1Y=', 'marietta', 'Georgia', '30060', '6784994324', 0, '', 'Paresia Chevell Cook', 'd78283092e109e1ff5ab746efe4a289cd8cad7b4b251241aef2ecc0747b9ff812ff3523a7d85a0e4c84ade5ad112ee71V9lPgs0Z3LiJVx4JQbgZdg==', '1981-08-04', '46ba7643b9d17cb74fbd3ec32f58ca1dd6cf25aea4cce14f71ceaeecd84fb3e229c1a185705c8792674a35931216ca4895789lG4f3+gYenXV+WtYw==', 'Georgia', '2020-08-04', '', '', '', '', 'Attended', 'Attended', 10, 10, 'Transport , Anything else', 1, 1, 0, '2016-07-05 19:04:39', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(198, 294, 40.666626, -73.864685, 'Brincisky', 'Quinonez', 'brincisky@gmail.com', 'b8f42b90d597683d590c6a23f42243e00eb2ef305a4243af4c01d17cef93a185e5bf73e219144d9073524625a3ab946alRt+7h19RVM2Zn1b5Li92t8q9VFsftNyGH8DaqBiO8Q=', 'brooklyn', 'New York', '11208', '3476846243', 0, '', '', 'f36b7ed58a6e22ee4131eee1fc7acd87e6a444a2328d41b6d03ab0dc3ae775e64fdb0f184b76795b35bcc566df206c08YvEXTwVPXSdK+fp2GuAvDw==', '0000-00-00', 'c3214c0586f96f82d7c77ce949d674dd0fc1127cecb5e4012a7db1e75e615dd722b95a67c03478f0cd09639b8ec877ae38hjttIAN3sJBkxrkEN5pQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(199, 298, 40.721775, -73.838715, 'Jessica', 'Braunstein', 'jsbraunstein1@gmail.com', '11d385e5e3789ab7a67b8a9c19acd1584840b09efd81638bed42c95c63ae1d86011c26988fe392890761dda67526c4edeKVtYenu4s3IBaRgi2nfwUFXx7afkiCWATBcgVcbsys=', 'Forest Hills', 'New York', '11375', '5163828705', 0, '', 'Jessica Eve Braunstein', '8c25196a82c83dd3805ad723b97cb8cb7f301db4eeed0a6cc7b06bcf3f53508d3d83a634bebc3aeed5b8e8ecee648871fKWEYTRU5mDZ90xikpWNBw==', '1990-09-29', '2ee5c0486c89e11d17534209e79ee968a23b102195c5c580dd3936983a93b945f0347f35ec80a2a9a80262435acbb59abe6UIQ1H0cfDoLrLhrBZ4g==', 'New York', '2019-09-29', '', '', '', '', 'Graduated', 'Graduated', 4, 4, 'Transport,Anything else', 1, 1, 0, '2016-07-06 14:00:32', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 1);
INSERT INTO `qProvider` (`qId`, `userId`, `currentLat`, `currentLong`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipCode`, `mobile`, `isMobileVerified`, `mobileVerificationCode`, `nameOnDL`, `socialSecurityNo`, `dateOfBirth`, `dlNo`, `dlState`, `dateOfDlExpiration`, `highSchoolName`, `highSchoolCity`, `highSchoolState`, `highSchoolYOGrad`, `hsInfo`, `collegeInfo`, `totalYearOfProfExp`, `personalAssistantExp`, `roleOfQ`, `isStateDisclouserAcknowledged`, `isBackgroundCheckAuthorized`, `isQVerified`, `registrationDate`, `isQOnline`, `registrationStepCompleted`, `TotalRequestCompleted`, `TotalPaymentReceived`, `qBankAccountNumber`, `qStripeId`, `qStripeBankTokenId`, `qStripeBankId`, `isPerformingRequest`, `LastRequestSent`, `isDeleted`) VALUES
(200, 299, 34.157585, -118.376129, 'Rebecca', 'Clouse', 'beccaclouse@gmail.com', '9c2fa3b3e141ae751df79df462670a9da5ee44992b31a430921e9b8177b342cd2dc5e6d1470d9b96f91aeaf1d1d1ea63k88G/eutR+Jckud/ipK7pj2UOJBeaJFhzisBORvcBn4=', 'West Toluca Lake', 'California', '91602', '9166072043', 0, '', 'Rebecca Clouse', '08b2c89a96a613587f17f9372715eeb9009621e38080cbf4e1dfb81df25dc457b956e93bed69c24fdc58915acc5332de4GU3nVOTmQkiEktcAw3OXg==', '1990-02-12', '5ce8472d948264ecec8e6bd6b3347d2f6d5f9be9fb76430a37d3fe77878cc6852dc32d4c7ae748fead123ccc394ab4f873ZVCQsr0Mr307WPeNCkhA==', 'California', '2020-02-13', '', '', '', '', 'Graduated', 'Graduated', 4, 3, 'Transport,Anything else', 1, 1, 0, '2016-07-06 04:29:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(201, 300, 32.369133, -84.964363, 'Tyneshia', 'Pitts', 'tyandnas@gmail.com', '551f2ed1862d52517be80915b0e27ff630b7a02f10412f9cc88f821892871529692d3d432cc13ed1f596c63ab42af761EWMEiI7Lvgxg2+namkus6g==', 'Atlanta', 'Georgia', '30331', '7064617790', 0, '', 'Tyneshia Rene Pitts', 'c2dbf567576fb6a870846f065e64709da94e900455a490bac178e607bde1fbe37ec3b943a4846dde16ad0bea365c5f5cSpXPC/XVGCV3IHU/mJcPvA==', '1983-02-24', '86b3d5d75a58e0c890859828eea843f39a007409572dc1aea82e0492f53d3516da07557510c1f0614297fc6ed09bf876pS9ztwe4+ODgmnJ2Tcm9ew==', 'Georgia', '2023-02-24', '', '', '', '', 'Graduated', 'Attended', 15, 10, 'Transport , Anything else', 1, 1, 0, '2016-07-06 04:45:52', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(202, 301, 40.856991, -73.899651, 'Ashley', 'Amarante', 'ashleya0730@gmail.com', '8aea53ab8b25cc0f6c8a3cf2801c89ae3e8397fe34fccfb6c77f19561ce756d0485c2640c95a0ab9da9561b7477fd63fT9smesMOWDIXgWMxX2LkvlS3hIuol4F6QnaBFPIHunI=', 'bronx', 'New York', '10457', '3475069691', 0, '', '', '40dbe8a77a9eb25ef8ce3ea7e91f8525951a7516200453fd6efdbf5c759ee64ed71855ab05ad12acd51ef33af57325ab6+irroT1DCDFUdReMdhGHA==', '0000-00-00', 'd4b3af6f4edaf91929253273d9ae004353257a3468a952dd9d63f6afa493cc5522becfdc0f1b352c1b8c18e1caacd6efPdDsVaR6N6nv18dpnQIvRQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(203, 304, 33.892307, -84.481636, 'Arian', 'Sanders', 'asanders5138@gmail.com', 'd6ce5d18b5271660e7be3dca07ed431ce8ee2920c398b1fe26f262e11d9b9c9779b150946d8d78107ae231208aac03ffTC9TROjtFzx/m6rK3U21LymgjnriNE/HHae5Nf8XCTc=', 'Smyrna', 'Georgia', '30080', '9122282051', 0, '', 'Arian Claudette Sanders', '877c655e2447e3cb0a9ec3d838f18d8e5c9166d548d70cd12f91022a85cbf91329b3893d3b8ec7bed76d1c7f99f39428B6KQ2bTuT54DuCkGQZ333w==', '1989-03-18', 'df287836ffc40839c2c8c80001299ded10ddbf90a38fdf67985f589ce3a9fbc600bbd27c1364046d7185c8cfef65908bng7ByXnWhXFuzAyDLWQ1fg==', 'Georgia', '2020-03-19', '', '', '', '', 'Graduated', 'Graduated', 4, 0, 'Transport,Anything else', 1, 1, 0, '2016-07-06 13:22:11', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(204, 307, 34.060181, -118.415672, 'Jacqueline', 'Diaz', 'diaz.jackie78@gmail.com', '4ff4f5c337e0da23c16d9a140110216b64be5debe80a16f089fc2edf6d11cd3f98a95ca040c310679a10b40f8e85ee8ar5wgt1Fs72BsrPUrmvJoD+DfyKbatmYMhfVdUzteXjo=', 'Los Angeles', 'California', '90065', '6193095286', 0, '', 'Jacqueline Diaz', 'fe9ab98bb5f17b1bd3ad8a6f1e166614576b9f242ec2b796cdedd031989e614870cae76927ecfe909139c698688b0c0eJhDZwGycxbBToWtJ1c/v3Q==', '1978-01-11', '3d3e625fba07e1cd808aaf102e99fa92448f5ee54b7f460ebdcbd073d94c30bba1445c126eac624b2c084cb06d839073k+zzP+SVpF8vXzDd1ryq9g==', 'California', '2018-01-12', '', '', '', '', 'Attended', 'Attended', 15, 10, 'Transport,Anything else', 1, 1, 0, '2016-07-06 14:59:02', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(205, 311, 40.658699, -73.878662, 'Alex', 'Junior', 'alexbadine1@yahoo.com', 'b20ce2c6fc5dc6a1a4daae531554089054024155c0879520284907c69ef910be6bf1c03df6da22f6f5c7998cfe87064bW++quiedsJcqc1DSslvgQXwIZfZHV/Mt1IMKiNFMKwQ=', 'brooklyn', 'New York', '11207', '3477755975', 0, '', 'Alex Trevon Badine', '85a35446c8a9f79ed39e2da0c8065d6c61beb5d7a227178df991a8b21b082449c5c8803b31d0b6e8f0e111ac58a65a80Yb9JesXrazjlvTLM6QdkBA==', '1997-06-30', '7368b97bce8792b4182f10f1bd5d6e993ce471484c5c9772e467a2f187f634ed877a1efdf72f4032e87d72ae06799b32nfpjXKiaP6lRB+SasnXunQ==', 'New York', '1997-07-01', '', '', '', '', 'Graduated', 'Attended', 0, 1, 'Transport', 1, 1, 0, '2016-07-06 19:04:43', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(206, 310, 40.879875, -73.898109, 'Janel', 'Wallace', 'jjwallac@aggies.ncat.edu', '8183b7bc8b22cbdd2caf238ffc120d3b2cdb7f5ca8afbf3cc560847163048d9ccaf6b08d557395284463e12455805a67aH6al2NHiMBJMSPBIbMz3JusU12b6qgct8Aywtmfbhk=', 'Bronx', 'New York', '10463', '9803228502', 0, '', 'Janel Jessica Wallace', 'c18d5ca50bceae4b5fac9812ad8163e68d3862ef269c9397827299c9679b0384e13e12a8f0402a97c5cae45ec9a5ea92DGmzpmfh4E79OqWriEloJg==', '1991-12-31', '429c6caef54bb2f324efb0047784491cfe0f6502cbbc522632d21f950d0ec5eb30c4224d849734b1466667c04202e6453pVOIfx2qTiTXuUHWdwVOw==', 'North Carolina', '2019-12-31', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 0, '2016-07-06 19:14:26', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(207, 314, 35.233551, -89.980629, 'Ibinka', 'Stone', 'fullfigureblackbarbie@gmail.com', '2e616a52cf01c22d139855fdd952597884f09919a3aaa0ec6a7d11181408f612c030721187c483db54e87b0107f17392vWJYX5X7bEhwc4gewXw0HOuE0+27Dl1Dj004KGx3EnE=', 'Memphis', 'Tennessee', '38127', '9013149946', 0, '', 'Ibinka Sade Neilly', '20961cbd568a13e837a54f329fbe83ebf5b482ef2121b2a59947861fb09913645a18038ebd767d31fb29d4c13343c68cuwPs3Q6bCSaF9vMWjjzT8w==', '1986-05-05', 'da0870cbfbbd38d3cd3ac5fd132440ceb70d33505cd3d34b5c915479ff5c1c1ecb0196e31044518d16f00310ae8e74c277iliWOlQuUPxcGqYcxSOA==', 'Tennessee', '2021-05-05', '', '', '', '', 'Graduated', 'Graduated', 10, 4, 'Transport , Anything else', 1, 1, 0, '2016-07-06 21:35:58', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(208, 318, 0.000000, 0.000000, 'Nina', 'Blake', 'ninasimone.mb@gmail.com', '7665f0828a5e974d27c233bce9043d759059e5f512c3ad5383f3885a44d7336658c5becea9d42b2aea27dd43f8dc12a2TD/zpFHnX4GshWqMz+fRYVsXBYe8qZZlX4OfhNYTxHo=', 'mount vernon', 'New York', '10552', '9145229912', 0, '', 'Ninasimone May Blake', '77817f4e2e2ccad98a2d8ca75485e31d465d2ee097ac6771953cd5b63aff2dbcbd0bdc5213b52e86fa54f92e2831b816qQCBIpKlT7aWY9XL+IQJcQ==', '1994-03-17', '02d5607f202045361b679267510e3765d2a7d7b8a1910d270673af7e89dd5ad6bed51b8f3613ca0f6e4adedbcaa1d8efVzJjh/L+YfYxlaQX9U81/A==', 'New York', '2023-03-18', '', '', '', '', 'Graduated', 'Attended', 7, 10, 'Transport,Anything else', 1, 1, 0, '2016-07-07 06:52:28', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(209, 320, 40.809921, -73.943420, 'Meaghan', 'Mcleod', 'meaghan.mcleod@yahoo.com', '4a362e1698f425a485dbf0192f77446d25fbb7051985eeafd252e56332229630e7c73a33fab174de7d9ac041b7e05147J3IWxs9XLrQ/YdyKGql+FM6xoQARdi9+oY/5GvaTyKc=', 'NY', 'New York', '10027', '9144717382', 0, '', '', '3079c2853903b39cc9b3543cc0c022535ddb9f4b3ac997bfbb962e09426f7198992c44cb11331373dbb6fcf923439299S+UBQV6Ackzb47NUxqEpeQ==', '0000-00-00', '2e911c4c13482896bfd326aa0344a93dd4e0d599258d4cf01029c9d73e16d9aa6e93e8a5ab4e3b58e74d668a6d3ff8d4s3qRMQ12Kg3uN0jFVo5FXg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(210, 321, 40.944855, -73.894066, 'Jassiah', 'Mcnulty', 'jassiah96@gmail.com', '39cdf1d1f6c7d884d1dfee4862f3b8ea635bcb7453a3c5d1ee4a6e7a22bb148d3adc125740aeefa79d848d1c954bdbedh+U6bgYLPegCC68vneVeraJYTIIs6F6BPt6uegA2Pj4=', 'yonkers ', 'New York', '10701', '9147519937', 0, '', '', '3cd3588b8833a778f4a2a3371937b6a2b3e8eabc973736af59e359b7eafd2b2aa6a1cf31af9fce435b440ea0ba1f1888FL0NNsVC2QNRkn4MX7fhOQ==', '0000-00-00', 'd73fc5e50855320fedc09d4f87c21e6a070f470e1f6ea51bbe43f6d2287ac01d7ede4b749b776240e3132caa4ea3146eEHA+Nn368jLjdLfyiY5tYg==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(211, 322, 34.270233, -118.678009, 'Liqun', 'Cai', 'cailiqun123@gmail.com', '1790591320f34bf517d5f1adc200011ecd59c64239a42fd772645888d458493d96f30af9eaeb8c78897573632463ed08/q6FGg4zdBv2h+1MJ0YXhiQ16a8hInSGg/MR4jStSqA=', 'Simi Valley', 'California', '93063', '8053589458', 0, '', 'Liqun Cai', '9da8c1e282cdb5b223873d7f78077c5b8aefaf633f46ed4d60dd255e8588ed057c92fdb108649328aa9f555dc82974658InKznZP/jBMMDqxYgaP1g==', '1990-05-27', '1453fdccfa080ca0dca7500162f1ebc40eb40b6697aed310849c388ede9e06ec47347387bb984f7f345d2ec969cae660GmXzxCAi6d96rdy4WstdHw==', 'California', '1990-05-28', '', '', '', '', 'Graduated', 'Graduated', 3, 3, 'Transport,Anything else', 1, 1, 0, '2016-07-07 12:44:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(212, 323, 40.695885, -73.944695, 'Priya', 'Bond', 'bondpriyabond@gmail.com', '0a8d2f9cb701a0405fdf52b974caa351a2e4e241f8606562a55b4727e2cdd73ea8b1819edc6c6047570e564ff6e55913JebvyN5wuMvWAI/xuvOzxmWBM6PnVHI8dfiblIbx4nE=', 'Brooklyn', 'New York', '11206', '8157157079', 0, '', '', '1dacc4b80ded027fcff6ba0e4e3d5428da4ee7b4c5dd903c6bc6f6e89f85debee2e4badf822ae7a633b3260d08b3d21dxE0i3jLduuQN45GCq/amHQ==', '0000-00-00', 'ce0224e643af07634e1d30c9d6adc0209507c8dd871711faabca33bd04578a07a557a3a3960b220c297af080031acb54XOFg+Ken9yMRaO50iZbG7g==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(213, 288, 0.000000, 0.000000, 'Kirstin', 'Smith', 'kirstinsmith1420@gmail.com', 'c5760d5fb1709102f40265ab955980ee3711d9464029141db918d95952cc644133568ce231666d734c21f2b6778583d4i3tTYKvJX3ZGC3L8jdxLIfX2RkrDdptMcdpXqu+2Tok=', 'venice', 'California', '90291', '3105910707', 0, '', '', '2a0c4382c021e4209fa83cbd10910f37b9f3a1833cf6964e75bc3fd73782d462553d7cfdf231f3353bf99ba159c6352cETzuy/GOanRBCUhwe1baUw==', '0000-00-00', 'a39302a3c02dd9169a5c3b71a560c290eef04f0fbdc4d23151534c636e2454c4d3b7e92e197f1aa98ddb40b60e82eed3gmLGvrMlED7EXnwlM4ATgQ==', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(214, 325, 40.736671, -73.991142, 'Brittany', 'Louis', 'louisbrit1990@gmail.com', '0561b4d581a65a2e96a87dd6daba51a5bf33573ff7c94ec6ab0c23ed2e14e33370013c3930c6372f2655a108c2bf96e3qbWieujpnamu4biOtzwWI/HzVdonQOSdvNn3CRpceVc=', 'north bergen', 'New Jersey', '07047', '7329771177', 0, '', 'Brittany Ashley Louis', '443b05ff618e2d2c21f100767b443b08d9257e8e70d164dab2b41d356509e49527942b1ac63de3baf3c1a7ea02889c6fvyvdg1BqIRRlY7NKtVNF9g==', '1990-02-05', 'fbe2f6d7bebd1c18d468326e3878549af2abdd816d300a3b04a6e0e17c2856442ea981272771ed833cf94d16981d2f98SgdMgHjDakYip2e6l0GfP1oav2jkuh7uVKZZbs5vGeU=', 'New Jersey', '2015-03-09', '', '', '', '', 'Graduated', 'Graduated', 3, 2, 'Transport,Anything else', 1, 1, 0, '2016-07-07 17:25:38', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(215, 326, 34.134895, -118.489510, 'Phil', 'Zaikovatyy ', 'pzaikovatyy@yahoo.com', 'd1f5eaaf0f3f1a403a6a148647247181ad6fe692c03502437b09664b2207c95dd516531f69a0b089b0bdd41c9f10b59da37x84J4Hwxj4yVcv1qFKZHZYexNWydxFGIBfY7LA58=', 'sherman oaks ', 'California', '91403', '8186212531', 0, '', 'Fedor Zaikovatyy', '87975fe8a328d6dfaa9fd78271b3ac6a075e9ddea6be289283c5856200eb3343d46a9ef9f362584d95ed944ddf1d9e86z5jEXHLKVXP3pvNoARNyEQ==', '1981-04-28', '27d1b71f01850c84355d5f12f3af5c4daf2a17e67025d3d2cfebba63a6c80343eb34fab355c1382db8126fa3dd585be98wnCJbxrd/tKTjsbwXgchQ==', 'California', '2020-04-28', '', '', '', '', 'Graduated', 'Graduated', 12, 12, 'Anything else', 1, 1, 0, '2016-07-07 17:31:01', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(216, 327, 0.000000, 0.000000, 'Shuneka', 'Andrews', 'shuneka.andrews@gmail.com', 'fbbdcf3c883219daf7f6847fb6c928d5b29effc537fe4e46410704cc53d7a25b5599bbee01732954c0e37d77eda58861yA+cx/3Js1/xH70Sj7xUE7YN8tm5HCCl8t4Flgdxjos=', 'Atlanta ', 'Georgia', '30314', '4045429503', 0, '', 'Shuneka Nicholoe Andrews', 'f0d9c416af591bfdc803bd7fbbaabf4cb98492ed6a10d0ef2ff33fe38034fac50d239c067a046c19f3d77b3a71e4bb62S3Izer5X3XWet3+r2rQCbw==', '1988-11-06', 'e0b7f3c9e7fca4b6f23af53107654e1af8c78e18161156cfa44fa2f3a9d5ce3109c792f50295d3fee57fd7736aef2abdltrlHNL0GcP9emnmzwQUyQ==', 'Georgia', '2020-11-07', '', '', '', '', 'Attended', 'Attended', 8, 4, 'Transport,Anything else', 1, 1, 0, '2016-07-07 20:59:12', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(224, 342, 21.170240, 72.831062, 'ishani', 'shah', 'lanetteam.ishani1@gmail.com', '1e895f5469aac51eb588221a7ee99675882190a7e035606479b5497bcbfa441fcee137773a573eac42d5415cf7ce1ed84HEGUzjHGxtsJvswQNvc4g==', 'surat', 'gujarat', '396445', '1234567808', 0, '', 'ishani jayesh shah', '538421fe4e27ad6eff3452f596e6da3803c04cbe73633c9445c5a19cdee2ba0ec9d4228823de9cce680a79f9d9146030U0uExFGIvIJGw8sg4FP7nA==', '1995-07-14', '3e82bb51772a002d2fcd85af1c4de9e58e3485df04022d9feadfc01c121a7e791f75409137ee608c6a4b6f325bc2a131ByQ4qBzPN+BoAWFzOY/NGg==', 'Gujrat', '2032-01-30', '', '', '', '', 'Gattu school', 'Attended', 0, 0, 'Anything else,Transport', 1, 1, 0, '2016-07-13 17:02:50', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0),
(225, 345, 65.966698, -18.533300, 'Yamini', 'Tailor', 'lanetteam.yamini@gmail.com', '608ecdec867b5e97bcc24bc78ac1b126e1ebb4fcc206390ae717bb2dd6fb03fab00d24d4ae843628539730e431708833kf9oW8Nz5CP9GEWDJ/KVIHqbuxpSfad3T4eg90yk2F4=', 'florida', 'Florida', '32140', '7845123960', 0, '', 'Yamini S Tailor', 'ae339ee0dbe316e07200c8cd9ca0f0d06d5c826dae4e2e48b5682cdd48c360c082e3039f2cbf82cf961ac9fca11d16b2HaJubiY76fHsNdatKOUvQw==', '2016-07-13', '535fab3097af16253213c0f247077e9f445c25c03373e1baa37f26da1e58a4b109522f7b55db998c47cd2784889b2432JoALc4/RUuFzgBY7G2wg6A==', 'Florida', '2020-12-13', '', '', '', '', 'Graduated', 'Graduated', 1, 1, 'Transport , Anything else', 1, 1, 0, '2016-07-13 17:52:35', 0, 7, 0, 0, '', '', '', '', 0, '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qRequest`
--

CREATE TABLE IF NOT EXISTS `qRequest` (
`qRequestId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `currentLat` float(9,6) NOT NULL,
  `currentLong` float(9,6) NOT NULL,
  `isTransport` tinyint(4) NOT NULL COMMENT '1 = Transport request 0 =any thing else request',
  `requestVerb` varchar(50) NOT NULL,
  `requestNoun` varchar(50) NOT NULL,
  `qRequiredTime_Hr` varchar(25) NOT NULL,
  `qRequiredPayment` varchar(255) NOT NULL,
  `numberOfStops` int(11) NOT NULL,
  `isRequiredNow` tinyint(4) NOT NULL DEFAULT '0',
  `qRequiredDate` date NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `requestStatus` int(11) NOT NULL COMMENT '1 = submitted, 2 = accepted, 3 = completed',
  `fine` int(11) NOT NULL,
  `cancelDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=400 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qRequest`
--

INSERT INTO `qRequest` (`qRequestId`, `userId`, `currentLat`, `currentLong`, `isTransport`, `requestVerb`, `requestNoun`, `qRequiredTime_Hr`, `qRequiredPayment`, `numberOfStops`, `isRequiredNow`, `qRequiredDate`, `createdDate`, `requestStatus`, `fine`, `cancelDate`) VALUES
(1, 2, 21.147299, 72.760063, 1, 'Transport', 'Uvucj', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-13 12:16:39', 4, 5, '2016-05-13 12:18:16'),
(2, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:19:53', 4, 0, '2016-05-13 12:20:16'),
(3, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:20:19', 4, 0, '2016-05-13 12:20:32'),
(4, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:20:53', 4, 0, '2016-05-13 12:21:00'),
(5, 1, 21.147301, 72.760056, 0, 'Hybyb', 'Bubuvy', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 12:28:00', 3, 0, '0000-00-00 00:00:00'),
(6, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:43:22', 4, 0, '2016-05-13 12:43:37'),
(7, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:43:47', 4, 0, '2016-05-13 12:43:51'),
(8, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 0, '2016-05-14', '2016-05-13 12:44:10', 4, 0, '2016-05-13 12:44:19'),
(9, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:44:39', 3, 0, '0000-00-00 00:00:00'),
(10, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:46:51', 3, 0, '0000-00-00 00:00:00'),
(11, 1, 21.147522, 72.759933, 0, 'Juvu', 'Bgf', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 12:48:32', 3, 0, '0000-00-00 00:00:00'),
(12, 1, 21.147562, 72.760086, 0, 'Juvu', 'Bgf', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 13:01:03', 3, 0, '0000-00-00 00:00:00'),
(13, 5, 21.147984, 72.760773, 0, 'Dghdbd', 'Hrhdd', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-13 13:24:43', 4, 0, '2016-05-13 13:24:47'),
(14, 5, 21.148182, 72.760818, 0, 'Rhrhhr', 'Bhfhf', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-13 13:25:04', 4, 0, '2016-05-13 13:25:57'),
(15, 5, 21.148485, 72.760918, 0, 'Gdgdb', 'Vfbf', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-13 13:26:15', 3, 0, '0000-00-00 00:00:00'),
(16, 5, 21.147966, 72.760735, 0, 'Kyjt', 'Fbfb', '2-3hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 13:31:54', 3, 0, '0000-00-00 00:00:00'),
(17, 7, 34.106121, -118.463852, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-15 00:26:29', -1, 0, '0000-00-00 00:00:00'),
(18, 7, 34.106197, -118.463829, 0, 'Find', 'Fun', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:53:19', 3, 0, '0000-00-00 00:00:00'),
(19, 7, 34.106197, -118.463837, 0, 'Find', 'Fun', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:57:03', 4, 5, '2016-05-15 00:58:00'),
(20, 7, 34.106197, -118.463837, 0, 'Get', 'Help', '> 3 hrs', '>$300', 0, 0, '2016-05-14', '2016-05-15 00:58:35', -1, 0, '0000-00-00 00:00:00'),
(21, 7, 34.106197, -118.463837, 0, 'Get', 'Food', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:59:07', 4, 0, '2016-05-15 00:59:52'),
(22, 7, 34.106197, -118.463837, 0, 'Get', 'Food', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:59:56', 4, 0, '2016-05-15 01:00:16'),
(23, 6, 34.106140, -118.463760, 0, 'Find', 'Flights', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-15 02:58:27', 4, 0, '2016-05-15 02:59:04'),
(24, 6, 34.106110, -118.463882, 1, 'Transport', 'Food', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-05-15 03:02:17', 4, 0, '2016-05-15 03:03:00'),
(25, 8, 21.148430, 72.760971, 1, 'Transport', 'Computer', '2-3hrs', '$20-100', 2, 0, '0000-00-00', '2016-05-17 11:01:33', -1, 0, '0000-00-00 00:00:00'),
(26, 8, 21.148384, 72.760956, 0, 'Arrange', 'Party', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-17 11:02:37', -1, 0, '0000-00-00 00:00:00'),
(27, 12, 19.387451, -99.209839, 1, 'Transport', 'Plumber', '<1hr', '<$20', 2, 0, '0000-00-00', '2016-05-25 19:05:26', 4, 0, '2016-05-25 19:06:29'),
(28, 1, 34.148685, -118.435608, 1, 'Transport', 'Tequila', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-28 18:10:50', 4, 0, '2016-05-31 07:35:37'),
(29, 14, 0.000000, 0.000000, 1, 'Transport', 'Food', '1-2 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-30 01:57:47', -1, 0, '0000-00-00 00:00:00'),
(30, 14, 0.000000, 0.000000, 0, 'Find', 'Plumbers', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 02:00:31', -1, 0, '0000-00-00 00:00:00'),
(31, 14, 0.000000, 0.000000, 0, 'Find', 'Plumbers', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 02:03:49', 4, 0, '2016-05-30 02:03:59'),
(32, 14, 34.106117, -118.463974, 0, 'Find', 'Flights', '1-2hrs', '$20-100', 0, 0, '2016-05-30', '2016-05-30 03:08:04', -1, 0, '0000-00-00 00:00:00'),
(33, 7, 34.106125, -118.463860, 0, 'Find', 'Plumber', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 21:20:33', 4, 0, '2016-05-30 21:20:48'),
(34, 7, 34.106255, -118.463974, 0, 'Find', 'Plumber', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 21:23:07', 3, 0, '0000-00-00 00:00:00'),
(35, 7, 34.106094, -118.463821, 1, 'Transport', 'Groceries', '< 1 hr', '$20-$100', 2, 0, '0000-00-00', '2016-05-30 21:33:03', 4, 5, '2016-05-30 21:36:46'),
(36, 7, 34.106102, -118.463638, 1, 'Transport', 'Dog', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-30 21:38:55', 4, 5, '2016-05-30 21:40:21'),
(37, 7, 34.106033, -118.463875, 1, 'Transport', 'Eggs', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-30 21:53:21', 3, 0, '0000-00-00 00:00:00'),
(38, 7, 34.106163, -118.463821, 1, 'Transport', 'Fun', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-31 04:36:40', -1, 0, '0000-00-00 00:00:00'),
(39, 1, 21.147598, 72.760063, 0, 'Chjj', 'Kvjc', '2-3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-05-31 09:03:12', 4, 5, '2016-05-31 09:04:21'),
(40, 1, 21.147446, 72.760017, 1, 'Transport', 'Uffufh', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-31 09:06:32', 4, 0, '2016-05-31 09:18:05'),
(41, 1, 21.147488, 72.760048, 1, 'Transport', 'Gigiguc', '2-3 hrs', '$100-$300', 3, 0, '0000-00-00', '2016-05-31 09:19:12', 4, 5, '2016-05-31 09:20:21'),
(42, 2, 21.154499, 72.765198, 1, 'Transport', 'Sdfd', '1-2 hrs', '<$20', 3, 0, '0000-00-00', '2016-05-31 09:26:24', 3, 0, '0000-00-00 00:00:00'),
(43, 2, 21.154499, 72.765198, 1, 'Transport', 'Dxsvfds', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 09:31:53', -1, 0, '0000-00-00 00:00:00'),
(44, 2, 21.154499, 72.765198, 1, 'Transport', 'Dxsvfds', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 09:32:36', -1, 0, '0000-00-00 00:00:00'),
(45, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfd', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 09:35:16', -1, 0, '0000-00-00 00:00:00'),
(46, 2, 21.154499, 72.765198, 1, 'Transport', 'Dfg', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 09:37:14', 4, 0, '2016-05-31 09:37:27'),
(47, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfds', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-31 09:40:23', 4, 0, '2016-05-31 09:40:33'),
(48, 1, 21.147596, 72.760071, 0, 'Jviv', 'Jjvu', '2-3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-05-31 11:18:05', 4, 5, '2016-05-31 11:46:18'),
(49, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfsd', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 11:39:50', 4, 5, '2016-05-31 11:40:48'),
(50, 5, 21.146152, 72.760559, 0, 'Arrange', 'Tickets', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-31 12:07:13', 4, 0, '2016-05-31 12:07:24'),
(51, 2, 21.150225, 72.768677, 1, 'Transport', 'Bchc', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 12:08:35', 2, 0, '0000-00-00 00:00:00'),
(52, 5, 21.146152, 72.760559, 0, 'Arrange', 'Ticket', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-31 12:11:17', 4, 5, '2016-05-31 12:11:59'),
(53, 5, 21.146152, 72.760559, 1, 'Transport', 'Goods', '1-2hrs', '$100-300', 2, 0, '0000-00-00', '2016-05-31 12:36:10', 3, 0, '0000-00-00 00:00:00'),
(54, 5, 21.148094, 72.765564, 0, 'Arrange', 'Pizza', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:34:02', 3, 0, '0000-00-00 00:00:00'),
(55, 5, 21.148094, 72.765564, 0, 'Arrange', 'Painter', '2-3hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:40:05', 3, 0, '0000-00-00 00:00:00'),
(56, 5, 21.148094, 72.765564, 0, 'Arrange', 'Teacher', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:44:02', 3, 0, '0000-00-00 00:00:00'),
(57, 22, 31.894056, -106.576904, 1, 'Transport', 'Me', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-02 23:08:05', -1, 0, '0000-00-00 00:00:00'),
(58, 22, 31.912148, -106.573784, 0, 'Fix', 'Kitchen', '> 3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-06-03 04:19:36', -1, 0, '0000-00-00 00:00:00'),
(59, 18, 34.106068, -118.463791, 1, 'Transport', 'Drycleaning', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-04 22:11:48', 4, 0, '2016-06-04 22:12:23'),
(60, 18, 34.106083, -118.463760, 1, 'Transport', 'Drycleaning', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-04 22:29:57', 4, 0, '2016-06-04 22:33:18'),
(61, 18, 34.106098, -118.463776, 1, 'Transport', 'Drycleaning', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-04 22:33:20', 4, 0, '2016-06-04 22:34:21'),
(62, 7, 34.106220, -118.463791, 1, 'Transport', 'Documents', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-06 04:17:34', 4, 0, '2016-06-06 04:17:52'),
(63, 7, 34.106171, -118.463921, 1, 'Transport', 'Documents', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-06 20:26:35', 3, 0, '0000-00-00 00:00:00'),
(64, 22, 31.826063, -106.523560, 1, 'Transport', 'Carry', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-08 01:45:19', -1, 0, '0000-00-00 00:00:00'),
(65, 22, 31.826086, -106.523552, 1, 'Transport', 'Carry', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-08 01:45:30', -1, 0, '0000-00-00 00:00:00'),
(66, 33, 31.912201, -106.573891, 0, 'Find', 'Plummer', '2-3 hrs', '$100-$300', 0, 0, '2016-06-09', '2016-06-10 22:14:45', 3, 0, '0000-00-00 00:00:00'),
(67, 77, 41.672836, -71.163734, 0, 'Arrange', 'Drycleaning', '< 1 hr', '<$20', 0, 0, '2016-08-13', '2016-06-14 22:30:21', 4, 0, '2016-06-14 22:30:31'),
(68, 117, 34.106148, -118.463852, 0, 'Find', 'Flights', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-16 19:54:05', 4, 0, '2016-06-16 19:54:11'),
(69, 67, 31.912218, -106.573799, 1, 'Transport', 'Flights', '1-2 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-06-17 17:09:30', -1, 0, '0000-00-00 00:00:00'),
(70, 67, 31.912411, -106.600494, 0, 'Looking', 'Landscaper', '> 3 hrs', '>$300', 0, 1, '0000-00-00', '2016-06-17 18:46:17', -1, 0, '0000-00-00 00:00:00'),
(71, 67, 31.912556, -106.600319, 0, 'Find', 'Plumer', '> 3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-06-17 18:48:09', 3, 0, '0000-00-00 00:00:00'),
(72, 67, 31.912571, -106.600243, 0, 'Looking', 'Carperter', '> 3 hrs', '>$300', 0, 1, '0000-00-00', '2016-06-17 19:22:19', 3, 0, '0000-00-00 00:00:00'),
(73, 16, 34.153973, -118.451866, 1, 'Transport', 'Groceries', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-17 22:58:47', 4, 0, '2016-06-17 23:25:01'),
(74, 16, 34.153519, -118.451584, 1, 'Transport', 'Groceries', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-17 23:25:09', 2, 0, '0000-00-00 00:00:00'),
(75, 16, 34.151833, -118.453743, 1, 'Transport', 'Dog', '1-2 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-06-17 23:30:00', 4, 0, '2016-06-17 23:48:26'),
(76, 7, 34.106098, -118.463982, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-18 15:29:40', 4, 0, '2016-06-18 15:33:41'),
(77, 7, 34.106125, -118.463829, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-18 15:33:43', 4, 0, '2016-06-18 15:33:47'),
(78, 7, 34.106087, -118.463890, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-18 15:34:05', 4, 0, '2016-06-18 15:34:26'),
(79, 5, 0.000000, 0.000000, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 09:32:54', -1, 0, '0000-00-00 00:00:00'),
(80, 5, 0.000000, 0.000000, 0, 'doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 09:42:51', -1, 0, '0000-00-00 00:00:00'),
(81, 5, 37.332333, -122.031219, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:15:58', -1, 0, '0000-00-00 00:00:00'),
(82, 5, 37.332333, -122.031219, 0, 'Dotcor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:32:43', -1, 0, '0000-00-00 00:00:00'),
(83, 5, 37.332333, -122.031219, 0, 'Hi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:43:25', -1, 0, '0000-00-00 00:00:00'),
(84, 5, 37.332333, -122.031219, 0, 'Hi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 11:44:41', -1, 0, '0000-00-00 00:00:00'),
(85, 5, 37.332333, -122.031219, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:28:20', -1, 0, '0000-00-00 00:00:00'),
(86, 5, 0.000000, 0.000000, 0, 'Hi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:29:33', -1, 0, '0000-00-00 00:00:00'),
(87, 5, 19.017614, 72.856163, 0, 'Doctor', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:36:12', -1, 0, '0000-00-00 00:00:00'),
(88, 5, 21.150000, 72.760002, 0, 'Help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 12:44:47', -1, 0, '0000-00-00 00:00:00'),
(89, 5, 21.150000, 72.760002, 0, 'undefined', 'Here', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:17:30', -1, 0, '0000-00-00 00:00:00'),
(90, 5, 21.150000, 72.760002, 0, 'undefined', 'Need', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:24:24', -1, 0, '0000-00-00 00:00:00'),
(91, 5, 21.150000, 72.760002, 0, 'undefined', 'Hiiii', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:24:48', -1, 0, '0000-00-00 00:00:00'),
(92, 5, 21.150000, 72.760002, 0, 'undefined', 'Going', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-20 13:36:07', -1, 0, '0000-00-00 00:00:00'),
(93, 5, 21.150000, 72.760002, 0, 'undefined', 'Hhhhoiii', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:04:16', -1, 0, '0000-00-00 00:00:00'),
(94, 67, 37.332279, -122.035782, 0, 'Help Me Fix A Flat Tire', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:41:25', 3, 0, '0000-00-00 00:00:00'),
(95, 5, 21.150000, 72.760002, 0, 'undefined', 'Hey guys', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:58:13', -1, 0, '0000-00-00 00:00:00'),
(96, 5, 21.150000, 72.760002, 0, 'undefined', 'Hey guys', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 06:59:39', 3, 0, '0000-00-00 00:00:00'),
(97, 5, 21.150000, 72.760002, 0, 'undefined', 'Hello', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:00:15', 3, 0, '0000-00-00 00:00:00'),
(98, 5, 21.150000, 72.760002, 0, 'undefined', 'Find a plumber', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:03:27', -1, 0, '0000-00-00 00:00:00'),
(99, 5, 21.150000, 72.760002, 0, 'undefined', 'Find a plumber', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:05:45', 4, 0, '2016-06-21 07:06:58'),
(100, 5, 21.150000, 72.760002, 0, 'undefined', 'Hope', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:07:20', -1, 0, '0000-00-00 00:00:00'),
(101, 5, 21.150000, 72.760002, 0, 'undefined', 'Lanet', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:10:37', 4, 0, '2016-06-21 07:10:57'),
(102, 5, 21.150000, 72.760002, 0, 'undefined', 'Lanetteam', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:11:24', -1, 0, '0000-00-00 00:00:00'),
(103, 67, 37.330433, -122.030090, 0, 'Help Me Clean The Garage, Backyard ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:15:56', -1, 0, '0000-00-00 00:00:00'),
(104, 5, 21.150000, 72.760002, 0, 'undefined', 'Let', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:18:14', -1, 0, '0000-00-00 00:00:00'),
(105, 5, 21.150000, 72.760002, 0, 'undefined', 'Yyy', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:19:28', 4, 0, '2016-06-21 07:19:56'),
(106, 5, 21.150000, 72.760002, 0, 'undefined', 'Pppp', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:20:14', 4, 0, '2016-06-21 07:21:31'),
(107, 5, 21.150000, 72.760002, 0, 'undefined', 'For Old', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 07:25:18', 3, 0, '0000-00-00 00:00:00'),
(108, 5, 21.150000, 72.760002, 0, 'Hello', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:26:10', 4, 0, '2016-06-21 10:26:23'),
(109, 5, 21.150000, 72.760002, 0, 'Heyyy', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:26:37', -1, 0, '0000-00-00 00:00:00'),
(110, 5, 21.150000, 72.760002, 0, 'Hhiiii', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:54:40', 4, 0, '2016-06-21 10:55:08'),
(111, 5, 21.150000, 72.760002, 0, 'Tdyducjvj', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:55:47', 3, 0, '0000-00-00 00:00:00'),
(112, 5, 21.150000, 72.760002, 0, 'Dydhfjc', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:56:13', 4, 0, '2016-06-21 10:56:32'),
(113, 5, 21.150000, 72.760002, 0, 'Gxhdkfcj', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:56:43', 4, 0, '2016-06-21 10:57:29'),
(114, 5, 21.150000, 72.760002, 0, 'Hhhhhh', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 10:58:04', -1, 0, '0000-00-00 00:00:00'),
(115, 5, 21.150000, 72.760002, 0, 'hey hii ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 12:02:52', -1, 0, '0000-00-00 00:00:00'),
(116, 5, 21.150000, 72.760002, 0, 'Happy', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 12:03:25', -1, 0, '0000-00-00 00:00:00'),
(117, 5, 21.150000, 72.760002, 0, 'happpp hi mfjfjc gzgxhxjxjcjcjcjcjc', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-21 12:06:34', -1, 0, '0000-00-00 00:00:00'),
(118, 188, 34.106216, -118.463898, 0, 'Find', 'Horses', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 02:44:46', 4, 0, '2016-06-22 02:45:08'),
(119, 188, 34.106155, -118.463913, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 0, '2016-06-22', '2016-06-22 02:48:47', 4, 0, '2016-06-22 02:49:04'),
(120, 188, 34.106155, -118.463913, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 0, '2016-06-22', '2016-06-22 02:49:07', 4, 0, '2016-06-22 02:49:21'),
(121, 17, 34.106152, -118.463829, 0, 'Help', 'Me', '<1hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 03:04:17', 4, 0, '2016-06-22 03:04:36'),
(122, 188, 34.106140, -118.463814, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 03:05:10', 4, 0, '2016-06-22 03:05:24'),
(123, 17, 34.106155, -118.463829, 1, 'Transport', 'Fun', '<1hr', '<$20', 2, 0, '0000-00-00', '2016-06-22 03:06:12', 3, 0, '0000-00-00 00:00:00'),
(124, 188, 34.106140, -118.463867, 1, 'Transport', 'Gum', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-22 06:47:54', 4, 5, '2016-06-22 06:50:14'),
(125, 188, 34.106148, -118.463852, 0, 'Hit', 'Home', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-22 06:50:50', 4, 0, '2016-06-22 06:50:58'),
(126, 188, 34.106136, -118.463783, 0, 'Try', 'Harder', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-23 00:57:48', 3, 0, '0000-00-00 00:00:00'),
(127, 188, 34.106167, -118.463989, 0, 'Get', 'Ready', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-23 01:11:37', 3, 0, '0000-00-00 00:00:00'),
(128, 5, 21.150000, 72.760002, 0, 'High', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-23 11:15:03', 4, 0, '2016-06-23 11:15:08'),
(129, 5, 21.150000, 72.760002, 0, 'Not really ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-23 11:15:54', 4, 0, '2016-06-23 11:16:18'),
(130, 205, 31.912302, -106.573540, 1, 'Transport', 'Flights', '1-2hrs', '$100-300', 2, 0, '0000-00-00', '2016-06-23 21:00:31', 4, 0, '2016-06-23 21:01:31'),
(131, 205, 31.912308, -106.573372, 1, 'Transport', 'Flights', '2-3hrs', '>$300', 2, 0, '0000-00-00', '2016-06-23 22:02:37', 4, 0, '2016-06-23 22:02:55'),
(132, 205, 31.912209, -106.573853, 1, 'Transport', 'Friend', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-06-23 22:04:36', 4, 0, '2016-06-23 22:09:07'),
(133, 205, 31.912184, -106.573868, 1, 'Transport', 'Groceries', '2-3hrs', '>$300', 2, 0, '0000-00-00', '2016-06-23 22:10:26', 4, 5, '2016-06-23 22:12:02'),
(134, 205, 31.912308, -106.573372, 1, 'Transport', 'Fligth', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-06-24 09:57:51', 4, 5, '2016-06-24 18:15:12'),
(135, 5, 21.150000, 72.760002, 0, 'help me to fix flat tire', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 12:35:21', -1, 0, '0000-00-00 00:00:00'),
(136, 5, 21.150000, 72.760002, 0, 'find plumber', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 12:50:36', -1, 0, '0000-00-00 00:00:00'),
(137, 5, 21.150000, 72.760002, 0, 'Happy to help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 12:53:26', -1, 0, '0000-00-00 00:00:00'),
(138, 205, 31.910000, -106.570000, 0, 'Help with pergola', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:42:11', 4, 0, '2016-06-24 18:42:27'),
(139, 205, 31.910000, -106.570000, 0, 'Help with deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:43:16', 4, 0, '2016-06-24 18:43:49'),
(140, 205, 31.910000, -106.570000, 0, 'Help with wood deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:44:10', 4, 0, '2016-06-24 18:44:39'),
(141, 205, 31.910000, -106.570000, 0, 'Help getting to party', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 18:45:05', 4, 5, '2016-06-24 20:18:04'),
(142, 205, 31.910000, -106.570000, 0, 'Get to school', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 19:51:50', 4, 0, '2016-06-24 19:52:13'),
(143, 205, 31.910000, -106.570000, 0, 'Get to work', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 19:52:36', 4, 0, '2016-06-24 19:58:23'),
(144, 205, 31.910000, -106.570000, 0, 'Help build deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-24 20:18:44', 3, 0, '0000-00-00 00:00:00'),
(145, 5, 21.150000, 72.760002, 0, 'find taxi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-25 11:04:02', -1, 0, '0000-00-00 00:00:00'),
(146, 236, 34.106281, -118.463890, 0, 'Find', 'Hats', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-27 03:51:19', 4, 0, '2016-06-27 03:57:17'),
(147, 5, 21.150000, 72.760002, 0, 'find cab ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 05:38:23', -1, 0, '0000-00-00 00:00:00'),
(148, 5, 21.150000, 72.760002, 0, 'arrange party', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 06:26:39', 3, 0, '0000-00-00 00:00:00'),
(149, 67, 31.912085, -106.573799, 0, 'Hejdjjd', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 18:59:33', 4, 0, '2016-06-27 19:00:58'),
(150, 67, 31.912115, -106.573769, 0, 'Hdidjdj jdjjd', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:04:50', 4, 0, '2016-06-27 19:04:53'),
(151, 67, 31.912123, -106.573807, 0, 'Help with dog', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:13:27', 4, 0, '2016-06-27 19:13:41'),
(152, 67, 31.912098, -106.573792, 0, 'Help with deck', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:15:25', -1, 0, '0000-00-00 00:00:00'),
(153, 67, 31.912157, -106.573807, 0, 'Help with door', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:17:34', 4, 0, '2016-06-27 19:17:37'),
(154, 67, 31.912167, -106.573906, 0, 'Help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:22:11', -1, 0, '0000-00-00 00:00:00'),
(155, 67, 31.912167, -106.573875, 0, 'Help', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 19:24:11', 4, 0, '2016-06-27 19:24:22'),
(156, 67, 31.912142, -106.573761, 0, 'Please fix my car', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 23:55:07', 4, 0, '2016-06-27 23:55:11'),
(157, 67, 31.912125, -106.573753, 0, 'Please fix my car', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-27 23:57:34', 4, 0, '2016-06-27 23:57:37'),
(158, 188, 34.106197, -118.463943, 0, 'find a plumber', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 00:36:41', 4, 0, '2016-06-28 01:28:45'),
(159, 188, 34.106197, -118.463943, 0, 'find a plumber ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 00:37:11', 4, 0, '2016-06-28 00:37:14'),
(160, 16, 29.521984, -98.502228, 0, 'Create a vacation plan', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 00:58:34', 3, 0, '0000-00-00 00:00:00'),
(161, 67, 31.912212, -106.573784, 0, 'Help cooking pizza', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 01:19:44', 3, 0, '0000-00-00 00:00:00'),
(162, 188, 34.106152, -118.464043, 0, 'find a plumber ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 01:25:11', 3, 0, '0000-00-00 00:00:00'),
(163, 5, 21.150000, 72.760002, 0, 'Find people', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 06:58:54', 4, 0, '2016-06-28 07:07:46'),
(164, 5, 21.148062, 72.760750, 0, 'Find', 'Cab', '2-3hrs', '$20-100', 0, 1, '0000-00-00', '2016-06-28 07:04:48', 4, 0, '2016-06-28 07:04:59'),
(165, 5, 21.150000, 72.760002, 0, 'Find cab', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 07:08:47', -1, 0, '0000-00-00 00:00:00'),
(166, 5, 21.150000, 72.760002, 0, 'Arrange childcare', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:15:47', 3, 0, '0000-00-00 00:00:00'),
(167, 5, 21.150000, 72.760002, 0, 'Arrange auto', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:29:43', -1, 0, '0000-00-00 00:00:00'),
(168, 5, 21.150000, 72.760002, 0, 'Help to fix problems', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:41:22', -1, 0, '0000-00-00 00:00:00'),
(169, 5, 21.150000, 72.760002, 0, 'Find taxi', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:44:53', -1, 0, '0000-00-00 00:00:00'),
(170, 5, 21.150000, 72.760002, 0, 'Help me', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 08:49:36', -1, 0, '0000-00-00 00:00:00'),
(171, 5, 21.150000, 72.760002, 0, 'Hi there', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 09:00:36', -1, 0, '0000-00-00 00:00:00'),
(172, 5, 37.332333, -122.031219, 0, 'Help me to fix problem', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 09:26:45', 4, 0, '2016-06-28 09:26:58'),
(173, 5, 37.332333, -122.031219, 0, 'Truthful', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 09:36:35', -1, 0, '0000-00-00 00:00:00'),
(174, 5, 0.000000, 0.000000, 0, 'Find can', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 10:35:43', -1, 0, '0000-00-00 00:00:00'),
(175, 5, 21.150000, 72.760002, 0, 'Hey', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 11:26:53', -1, 0, '0000-00-00 00:00:00'),
(176, 5, 21.150000, 72.760002, 0, 'Testing', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 11:31:44', 4, 0, '2016-06-28 11:47:29'),
(177, 5, 21.150000, 72.760002, 0, 'Test', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 11:33:58', 4, 0, '2016-06-28 11:34:06'),
(178, 5, 21.150000, 72.760002, 0, 'Hello testing', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:37:07', 4, 0, '2016-06-28 12:40:00'),
(179, 5, 21.150000, 72.760002, 0, 'Testing', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:40:41', 4, 0, '2016-06-28 12:41:17'),
(180, 5, 21.150000, 72.760002, 0, 'Dhh', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:43:45', 4, 0, '2016-06-28 12:44:53'),
(181, 5, 21.150000, 72.760002, 0, 'Dfduxhjjjjj', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:46:07', 4, 0, '2016-06-28 12:46:36'),
(182, 5, 21.150000, 72.760002, 0, 'Hdjdjdjd', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:46:56', 4, 0, '2016-06-28 12:47:25'),
(183, 5, 21.150000, 72.760002, 0, 'JJjJjdJjdjJjdJj ', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:49:44', 3, 0, '0000-00-00 00:00:00'),
(184, 5, 21.150000, 72.760002, 0, 'Yfghhhhhhhh', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:51:52', 4, 0, '2016-06-28 12:52:27'),
(185, 5, 21.150000, 72.760002, 0, 'Hope', 'undefined', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 12:52:52', 3, 0, '0000-00-00 00:00:00'),
(186, 1, 21.150000, 72.760002, 0, 'Tgggh', '', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 16:47:34', 3, 0, '0000-00-00 00:00:00'),
(187, 1, 21.150000, 72.760002, 0, 'Yxiviboboo', '', 'undefined', 'undefined', 0, 1, '0000-00-00', '2016-06-28 16:57:05', 2, 0, '0000-00-00 00:00:00'),
(188, 1, 21.150000, 72.760002, 0, 'Hopw a doc', '', '', '', 0, 1, '0000-00-00', '2016-06-28 17:14:55', 4, 0, '2016-06-28 17:15:17'),
(189, 239, 29.522346, -98.501892, 0, 'Find', 'Flight', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-28 22:02:12', 3, 0, '0000-00-00 00:00:00'),
(190, 245, 34.106133, -118.463753, 0, 'Find', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:44:53', 4, 0, '2016-06-29 00:44:56'),
(191, 245, 34.106155, -118.463776, 0, 'Create', 'List', '1-2 hrs', '<$20', 0, 0, '2016-06-29', '2016-06-29 00:46:57', 4, 0, '2016-06-29 00:53:22'),
(192, 245, 34.106163, -118.463799, 0, 'Find', 'Flights', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:56:42', 4, 0, '2016-06-29 01:16:48'),
(193, 245, 34.106167, -118.463799, 0, 'Find', 'Flights', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:58:13', 4, 5, '2016-06-29 00:58:42'),
(194, 245, 34.106167, -118.463799, 0, 'Create', 'List', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-29 00:59:11', 4, 0, '2016-06-29 01:00:14'),
(195, 245, 34.106167, -118.463799, 0, 'Create', 'List', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-29 01:00:15', 4, 0, '2016-06-29 01:00:48'),
(196, 18, 34.106197, -118.463531, 1, 'Transport', 'Dog', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 01:06:42', 4, 0, '2016-06-29 01:07:17'),
(197, 18, 34.106144, -118.463554, 0, 'Create', 'List', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 01:08:19', 3, 0, '0000-00-00 00:00:00'),
(198, 245, 34.106178, -118.463867, 1, 'Transport', 'Fun', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-06-29 02:00:19', 3, 0, '0000-00-00 00:00:00'),
(199, 17, 34.106121, -118.463928, 0, 'Find', 'Developer', '<1hr', '$20-100', 0, 1, '0000-00-00', '2016-06-29 02:08:32', 3, 0, '0000-00-00 00:00:00'),
(200, 18, 34.106026, -118.463959, 1, 'Transport', 'Dog', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 02:21:49', 3, 0, '0000-00-00 00:00:00'),
(201, 239, 29.526861, -98.470398, 1, 'Transport', 'Food', '<1hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 02:28:55', 4, 0, '2016-06-29 02:29:50'),
(202, 239, 29.526884, -98.470459, 0, 'Find', 'Flights', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-29 02:30:47', 3, 0, '0000-00-00 00:00:00'),
(203, 5, 65.970001, -18.530001, 0, 'hiii', '', '', '', 0, 1, '0000-00-00', '2016-06-29 05:56:44', -1, 0, '0000-00-00 00:00:00'),
(204, 5, 21.150000, 72.760002, 0, 'Happy ', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:31:10', 4, 0, '2016-06-29 06:31:23'),
(205, 5, 21.150000, 72.760002, 0, 'Happy', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:31:38', 4, 0, '2016-06-29 06:35:46'),
(206, 1, 21.150000, 72.760002, 0, 'Hello', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:33:53', -1, 0, '0000-00-00 00:00:00'),
(207, 5, 21.150000, 72.760002, 0, 'heyhelloinheyhelloin', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:34:16', 4, 0, '2016-06-29 06:35:36'),
(208, 5, 21.150000, 72.760002, 0, 'hello ', '', '', '', 0, 1, '0000-00-00', '2016-06-29 06:36:57', 3, 0, '0000-00-00 00:00:00'),
(209, 5, 21.150000, 72.760002, 0, 'testing request', '', '', '', 0, 1, '0000-00-00', '2016-06-29 07:04:56', 3, 0, '0000-00-00 00:00:00'),
(210, 67, 37.331760, -122.030663, 1, 'Bring Doritos', 'Bring Doritos', '0', '0', 2, 0, '0000-00-00', '2016-06-29 09:52:28', 4, 0, '2016-06-29 09:52:48'),
(211, 5, 21.150000, 72.760002, 0, 'request testing', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:12:30', 3, 0, '0000-00-00 00:00:00'),
(212, 5, 21.150000, 72.760002, 0, 'find place', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:18:49', 3, 0, '0000-00-00 00:00:00'),
(213, 5, 21.150000, 72.760002, 0, 'hello', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:22:45', 3, 0, '0000-00-00 00:00:00'),
(214, 5, 21.150000, 72.760002, 0, 'Happy birthday', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:27:51', 4, 0, '2016-06-29 10:33:45'),
(215, 67, 37.324623, -122.019936, 0, 'Help with Home work', '', '', '', 0, 1, '0000-00-00', '2016-06-29 10:33:09', 4, 0, '2016-06-29 10:33:11'),
(216, 5, 21.150000, 72.760002, 0, 'Find cab', '', '', '', 0, 1, '0000-00-00', '2016-06-29 12:23:55', -1, 0, '0000-00-00 00:00:00'),
(217, 5, 21.150000, 72.760002, 0, 'fjdjxjffk', '', '', '', 0, 1, '0000-00-00', '2016-06-29 12:49:23', 3, 0, '0000-00-00 00:00:00'),
(218, 18, 34.106209, -118.463837, 0, 'Find', 'Flights', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:11:51', 3, 0, '0000-00-00 00:00:00'),
(219, 18, 34.106186, -118.463905, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:19:42', 4, 0, '2016-06-29 14:20:02'),
(220, 18, 34.106186, -118.463905, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:20:04', 4, 0, '2016-06-29 14:20:11'),
(221, 18, 34.106178, -118.463913, 1, 'Transport', 'Hat', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 14:22:56', 3, 0, '0000-00-00 00:00:00'),
(222, 18, 34.106113, -118.463898, 1, 'Transport', 'Hat', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 14:31:30', 3, 0, '0000-00-00 00:00:00'),
(223, 245, 34.106106, -118.463928, 0, 'Find', 'Sanity', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-06-29 14:46:48', 3, 0, '0000-00-00 00:00:00'),
(224, 17, 34.106178, -118.463860, 0, 'Get', 'Help', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-06-29 14:49:04', 3, 0, '0000-00-00 00:00:00'),
(225, 18, 34.106148, -118.463882, 1, 'Transport', 'Hat', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-29 15:21:17', 2, 0, '0000-00-00 00:00:00'),
(226, 245, 34.106144, -118.463966, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-06-29 18:28:47', 4, 0, '2016-06-29 18:29:13'),
(227, 245, 34.106144, -118.463966, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-06-29 18:29:28', 4, 0, '2016-06-29 18:29:45'),
(228, 5, 0.000000, 0.000000, 0, 'Gthgtjygj', '', '', '', 0, 1, '0000-00-00', '2016-06-30 04:50:25', -1, 0, '0000-00-00 00:00:00'),
(229, 5, 0.000000, 0.000000, 0, 'H', '', '', '', 0, 1, '0000-00-00', '2016-06-30 05:01:24', -1, 0, '0000-00-00 00:00:00'),
(230, 5, 0.000000, 0.000000, 0, 'Y', '', '', '', 0, 1, '0000-00-00', '2016-06-30 05:23:22', -1, 0, '0000-00-00 00:00:00'),
(231, 5, 21.147984, 72.760704, 0, 'Find', 'Cab', '1-2hrs', '<$20', 0, 1, '0000-00-00', '2016-06-30 05:50:17', -1, 0, '0000-00-00 00:00:00'),
(232, 5, 21.147991, 72.760681, 0, 'Arrange', 'Party', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-06-30 05:56:52', 3, 0, '0000-00-00 00:00:00'),
(233, 5, 65.966698, -18.533300, 1, 'Transport', 'Goods', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-06-30 06:05:48', -1, 0, '0000-00-00 00:00:00'),
(234, 5, 21.150000, 72.760002, 0, 'Hello', '', '', '', 0, 1, '0000-00-00', '2016-06-30 10:17:48', -1, 0, '0000-00-00 00:00:00'),
(235, 4, 21.150000, 72.760002, 0, 'Testing', '', '', '', 0, 1, '0000-00-00', '2016-06-30 10:43:37', -1, 0, '0000-00-00 00:00:00'),
(236, 245, 34.106167, -118.463829, 0, 'Gg', 'Cf', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-30 12:09:36', 3, 0, '0000-00-00 00:00:00'),
(237, 18, 34.106144, -118.463928, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-30 19:13:39', 3, 0, '0000-00-00 00:00:00'),
(238, 18, 34.106182, -118.463852, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-06-30 19:28:11', 3, 0, '0000-00-00 00:00:00'),
(239, 239, 34.165142, -118.449242, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-06-30 23:57:49', 3, 0, '0000-00-00 00:00:00'),
(240, 239, 34.106155, -118.463821, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-01 00:35:58', 3, 0, '0000-00-00 00:00:00'),
(241, 4, 37.332333, -122.031219, 0, 'Hook', '', '', '', 0, 1, '0000-00-00', '2016-07-01 07:25:35', -1, 0, '0000-00-00 00:00:00'),
(242, 5, 21.150000, 72.760002, 0, 'Transport food', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:45:29', 4, 0, '2016-07-01 13:46:48'),
(243, 5, 65.970001, -18.530001, 0, 'Chvjh', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:45:57', 4, 0, '2016-07-01 13:46:56'),
(244, 5, 21.150000, 72.760002, 0, 'Hello', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:48:03', 4, 0, '2016-07-01 13:52:39'),
(245, 5, 65.970001, -18.530001, 0, 'hjhgj', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:49:24', 4, 0, '2016-07-01 13:52:21'),
(246, 5, 21.150000, 72.760002, 0, 'Hi', '', '', '', 0, 1, '0000-00-00', '2016-07-01 13:51:56', 4, 0, '2016-07-01 13:52:01'),
(247, 18, 34.106129, -118.463837, 1, 'Transport', 'Aiden', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-07-02 01:07:03', 4, 0, '2016-07-02 01:36:07'),
(248, 18, 34.106293, -118.463936, 1, 'Transport', 'Aiden', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-07-02 01:36:10', 2, 0, '0000-00-00 00:00:00'),
(249, 5, 21.150000, 72.760002, 0, 'Arrangefood', '', '', '', 0, 1, '0000-00-00', '2016-07-02 06:05:21', -1, 0, '0000-00-00 00:00:00'),
(250, 5, 21.150000, 72.760002, 0, 'Hii', '', '', '', 0, 1, '0000-00-00', '2016-07-02 06:06:28', 4, 0, '2016-07-02 06:07:09'),
(251, 239, 34.106117, -118.463844, 0, 'Find', 'Floghgt', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 06:23:55', 3, 0, '0000-00-00 00:00:00'),
(252, 239, 34.106205, -118.463806, 0, 'Find', 'Floghgt', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 06:28:27', -1, 0, '0000-00-00 00:00:00'),
(253, 239, 34.106236, -118.463821, 0, 'Find a flight', '', '', '', 0, 1, '0000-00-00', '2016-07-02 06:29:15', 3, 0, '0000-00-00 00:00:00'),
(254, 239, 34.106232, -118.463898, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 07:01:06', 3, 0, '0000-00-00 00:00:00'),
(255, 239, 34.106228, -118.463791, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 07:45:34', 4, 0, '2016-07-02 08:10:05'),
(256, 239, 34.106243, -118.463837, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 08:11:07', 4, 0, '2016-07-02 08:11:52'),
(257, 239, 34.106243, -118.463837, 0, 'Find', 'Flights', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-07-02 08:11:55', -1, 0, '0000-00-00 00:00:00'),
(258, 239, 34.106243, -118.463837, 0, 'Hh', 'Fg', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-02 08:12:22', 3, 0, '0000-00-00 00:00:00'),
(259, 4, 65.970001, -18.530001, 0, 'helppp', '', '', '', 0, 1, '0000-00-00', '2016-07-02 10:48:24', 4, 0, '2016-07-02 10:48:27'),
(260, 18, 34.106262, -118.463882, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:24:03', 4, 5, '2016-07-04 05:26:05'),
(261, 18, 34.106232, -118.463829, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:27:17', 4, 5, '2016-07-04 05:27:31'),
(262, 18, 34.106205, -118.463814, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:32:14', 4, 0, '2016-07-04 05:32:33'),
(263, 18, 34.106216, -118.463829, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:32:40', 4, 0, '2016-07-04 05:33:06'),
(264, 18, 34.106224, -118.463867, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:33:25', 3, 0, '0000-00-00 00:00:00'),
(265, 18, 34.106190, -118.463837, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 05:40:17', 4, 5, '2016-07-04 05:40:23'),
(266, 5, 0.000000, 0.000000, 0, 'Rare', '', '', '', 0, 1, '0000-00-00', '2016-07-04 13:00:59', -1, 0, '0000-00-00 00:00:00'),
(267, 4, 65.970001, -18.530001, 1, 'GFHGF', '', '', '', 2, 0, '0000-00-00', '2016-07-04 13:35:22', -1, 0, '0000-00-00 00:00:00'),
(268, 18, 34.106121, -118.463669, 0, 'Get', 'My', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 20:15:00', 3, 0, '0000-00-00 00:00:00'),
(269, 18, 34.106171, -118.463783, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:22:57', 3, 0, '0000-00-00 00:00:00'),
(270, 18, 34.106102, -118.463844, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:24:35', 4, 5, '2016-07-04 23:24:47'),
(271, 18, 34.106102, -118.463844, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:24:59', 4, 0, '2016-07-04 23:25:21'),
(272, 18, 34.106098, -118.463860, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:25:36', 3, 0, '0000-00-00 00:00:00'),
(273, 18, 34.106033, -118.463844, 0, 'Get', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:59:40', 4, 0, '2016-07-04 23:59:50'),
(274, 18, 34.106033, -118.463844, 0, 'Get', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-04 23:59:56', 4, 0, '2016-07-05 00:00:06'),
(275, 18, 34.106087, -118.463814, 0, 'Get', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:00:22', 4, 0, '2016-07-05 00:00:27'),
(276, 18, 34.106110, -118.463814, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:00:46', 4, 0, '2016-07-05 00:01:48'),
(277, 18, 34.106113, -118.463821, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:01:50', 4, 0, '2016-07-05 00:01:53'),
(278, 18, 34.106113, -118.463821, 0, 'Get', 'Help', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:03:03', 4, 0, '2016-07-05 00:03:08'),
(279, 18, 34.106113, -118.463821, 0, 'Help', 'Ne', '< 1 hr', '$20-$100', 0, 1, '0000-00-00', '2016-07-05 00:03:39', 4, 0, '2016-07-05 00:14:09'),
(280, 18, 34.106251, -118.464149, 0, 'Help', 'Ne', '< 1 hr', '$20-$100', 0, 1, '0000-00-00', '2016-07-05 00:14:11', 3, 0, '0000-00-00 00:00:00'),
(281, 18, 34.106010, -118.463623, 0, 'Help', 'Me', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-07-05 00:51:57', 3, 0, '0000-00-00 00:00:00'),
(282, 5, 21.150000, 72.760002, 1, 'Transport goods', '', '', '', 2, 0, '0000-00-00', '2016-07-05 04:31:22', -1, 0, '0000-00-00 00:00:00'),
(283, 5, 21.150000, 72.760002, 0, 'Help to find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-05 04:36:13', 4, 0, '2016-07-05 04:36:53'),
(284, 5, 21.150000, 72.760002, 0, 'Find food', '', '', '', 0, 1, '0000-00-00', '2016-07-05 04:41:17', -1, 0, '0000-00-00 00:00:00'),
(285, 4, 21.150000, 72.760002, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 04:48:37', 4, 0, '2016-07-05 04:48:53'),
(286, 5, 21.150000, 72.760002, 1, 'Hey', '', '', '', 2, 0, '0000-00-00', '2016-07-05 05:51:54', -1, 0, '0000-00-00 00:00:00'),
(287, 5, 21.150000, 72.760002, 1, 'Hope', '', '', '', 2, 0, '0000-00-00', '2016-07-05 06:05:31', -1, 0, '0000-00-00 00:00:00'),
(288, 5, 21.150000, 72.760002, 1, 'Here', '', '', '', 2, 0, '0000-00-00', '2016-07-05 06:10:24', -1, 0, '0000-00-00 00:00:00'),
(289, 205, 31.912151, -106.573875, 0, 'Help now', '', '', '', 0, 1, '0000-00-00', '2016-07-05 06:27:54', 3, 0, '0000-00-00 00:00:00'),
(290, 4, 21.150000, 72.760002, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 06:41:16', -1, 0, '0000-00-00 00:00:00'),
(291, 4, 21.150000, 72.760002, 1, 'Hello', '', '', '', 2, 0, '0000-00-00', '2016-07-05 07:00:14', -1, 0, '0000-00-00 00:00:00'),
(292, 4, 21.150000, 72.760002, 0, 'Hey', '', '', '', 0, 1, '0000-00-00', '2016-07-05 07:08:40', -1, 0, '0000-00-00 00:00:00'),
(293, 205, 31.912054, -106.573868, 0, 'Help with dog', '', '', '', 0, 1, '0000-00-00', '2016-07-05 07:34:25', 3, 0, '0000-00-00 00:00:00'),
(294, 205, 31.912136, -106.573853, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 07:58:50', 3, 0, '0000-00-00 00:00:00'),
(295, 205, 31.912098, -106.573837, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:07:23', 3, 0, '0000-00-00 00:00:00'),
(296, 205, 31.912125, -106.573807, 0, 'Help with door', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:13:50', 3, 0, '0000-00-00 00:00:00'),
(297, 205, 31.912079, -106.573883, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:17:24', 4, 0, '2016-07-05 08:17:35'),
(298, 205, 31.912067, -106.573822, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:17:42', -1, 0, '0000-00-00 00:00:00'),
(299, 205, 31.912067, -106.573830, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:17:56', -1, 0, '0000-00-00 00:00:00'),
(300, 205, 31.912107, -106.573822, 0, ' Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:18:21', 3, 0, '0000-00-00 00:00:00'),
(301, 205, 31.912113, -106.573792, 0, 'Help with pool', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:22:35', -1, 0, '0000-00-00 00:00:00'),
(302, 205, 31.912157, -106.573792, 0, 'Help with kids', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:23:50', 3, 0, '0000-00-00 00:00:00'),
(303, 205, 31.912090, -106.573853, 0, 'Help with grass', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:25:40', 3, 0, '0000-00-00 00:00:00'),
(304, 205, 31.912083, -106.573807, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:27:11', -1, 0, '0000-00-00 00:00:00'),
(305, 205, 31.912083, -106.573807, 0, 'Need help with game', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:27:46', -1, 0, '0000-00-00 00:00:00'),
(306, 205, 31.912088, -106.573830, 0, 'Help with fridge', '', '', '', 0, 1, '0000-00-00', '2016-07-05 08:28:18', 3, 0, '0000-00-00 00:00:00'),
(307, 4, 21.170000, 72.830002, 1, 'help', '', '', '', 2, 0, '0000-00-00', '2016-07-05 09:16:22', -1, 0, '0000-00-00 00:00:00'),
(308, 4, 21.170000, 72.830002, 1, 'find plumber', '', '', '', 2, 0, '0000-00-00', '2016-07-05 09:24:28', -1, 0, '0000-00-00 00:00:00'),
(309, 4, 21.170000, 72.830002, 0, 'find cab', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:26:32', -1, 0, '0000-00-00 00:00:00'),
(310, 4, 21.170000, 72.830002, 0, 'arrange party', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:29:46', -1, 0, '0000-00-00 00:00:00'),
(311, 4, 21.170000, 72.830002, 0, 'arrange partyyy', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:33:36', -1, 0, '0000-00-00 00:00:00'),
(312, 4, 21.170000, 72.830002, 0, 'hjhhg', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:36:39', 4, 0, '2016-07-05 09:37:44'),
(313, 4, 21.170000, 72.830002, 0, 'hello', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:40:09', -1, 0, '0000-00-00 00:00:00'),
(314, 4, 21.170000, 72.830002, 0, 'find auto', '', '', '', 0, 1, '0000-00-00', '2016-07-05 09:42:35', -1, 0, '0000-00-00 00:00:00'),
(315, 4, 21.170000, 72.830002, 0, 'gbfch', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:01:13', -1, 0, '0000-00-00 00:00:00'),
(316, 4, 21.150000, 72.760002, 0, 'Helps', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:10:46', -1, 0, '0000-00-00 00:00:00'),
(317, 4, 21.150000, 72.760002, 1, 'Transport luggage', '', '', '', 2, 0, '0000-00-00', '2016-07-05 11:18:37', -1, 0, '0000-00-00 00:00:00'),
(318, 4, 21.150000, 72.760002, 0, 'Find maid', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:20:44', -1, 0, '0000-00-00 00:00:00'),
(319, 4, 21.150000, 72.760002, 1, 'Transport funds', '', '', '', 2, 0, '0000-00-00', '2016-07-05 11:32:00', -1, 0, '0000-00-00 00:00:00'),
(320, 4, 21.150000, 72.760002, 0, 'Help to find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:40:54', -1, 0, '0000-00-00 00:00:00'),
(321, 4, 21.150000, 72.760002, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:49:20', -1, 0, '0000-00-00 00:00:00'),
(322, 4, 21.150000, 72.760002, 0, 'Help to fix flat tire', '', '', '', 0, 1, '0000-00-00', '2016-07-05 11:59:30', -1, 0, '0000-00-00 00:00:00'),
(323, 4, 21.150000, 72.760002, 1, 'Help', '', '', '', 2, 0, '0000-00-00', '2016-07-05 12:23:59', -1, 0, '0000-00-00 00:00:00'),
(324, 17, 34.110001, -118.459999, 0, 'Create a vacation itinerary', '', '', '', 0, 1, '0000-00-00', '2016-07-05 15:12:20', 4, 0, '2016-07-05 15:12:49'),
(325, 17, 34.110001, -118.459999, 1, 'Pick up drycleaning', '', '', '', 2, 0, '0000-00-00', '2016-07-05 15:14:38', 4, 0, '2016-07-05 15:14:53'),
(326, 17, 34.110001, -118.459999, 0, 'Create itinerary', '', '', '', 0, 1, '0000-00-00', '2016-07-05 15:20:37', 4, 0, '2016-07-05 15:20:45'),
(327, 17, 34.110001, -118.459999, 0, 'Create itinerary', '', '', '', 0, 1, '0000-00-00', '2016-07-05 15:21:03', 4, 0, '2016-07-05 15:21:13'),
(328, 18, 34.106117, -118.463791, 0, 'Find a good  hearing aid', '', '', '', 0, 1, '0000-00-00', '2016-07-05 18:49:39', 4, 5, '2016-07-05 18:51:15'),
(329, 239, 29.522690, -98.501701, 0, 'Find ginger drink recipe', '', '', '', 0, 1, '0000-00-00', '2016-07-05 18:53:37', 4, 0, '2016-07-05 18:56:44'),
(330, 18, 34.106113, -118.463806, 0, 'Find a dentist ', '', '', '', 0, 1, '0000-00-00', '2016-07-05 18:54:39', 4, 5, '2016-07-05 18:57:07'),
(331, 253, 34.106255, -118.463959, 0, 'find a plumber ', '', '', '', 0, 1, '0000-00-00', '2016-07-05 19:12:07', 4, 0, '2016-07-05 19:12:09'),
(332, 17, 34.110001, -118.459999, 1, 'Pick up drycleaning', '', '', '', 2, 0, '0000-00-00', '2016-07-05 20:36:13', 4, 5, '2016-07-05 20:36:54'),
(333, 17, 34.110001, -118.459999, 1, 'Drop off drycleaning ', '', '', '', 2, 0, '0000-00-00', '2016-07-05 20:41:17', 4, 5, '2016-07-05 20:45:54'),
(334, 253, 34.106197, -118.463943, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:52:40', 4, 0, '2016-07-05 20:53:03'),
(335, 253, 34.106201, -118.463951, 0, 'fix my app', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:53:15', 4, 0, '2016-07-05 20:53:26'),
(336, 253, 34.106201, -118.463951, 0, 'get help ', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:54:27', 4, 0, '2016-07-05 20:54:38'),
(337, 253, 34.106201, -118.463951, 0, 'get help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:55:21', 4, 0, '2016-07-05 20:55:47'),
(338, 17, 34.110001, -118.459999, 0, 'Fix my app', '', '', '', 0, 1, '0000-00-00', '2016-07-05 20:56:21', -1, 0, '0000-00-00 00:00:00'),
(339, 205, 31.912165, -106.573853, 0, 'Help with guitar', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:51:38', -1, 0, '0000-00-00 00:00:00'),
(340, 205, 31.912159, -106.573883, 0, 'Doritos party', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:53:11', 4, 5, '2016-07-05 22:53:38'),
(341, 205, 31.912218, -106.573875, 0, 'Help with pc issue', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:54:09', 4, 5, '2016-07-05 22:52:24');
INSERT INTO `qRequest` (`qRequestId`, `userId`, `currentLat`, `currentLong`, `isTransport`, `requestVerb`, `requestNoun`, `qRequiredTime_Hr`, `qRequiredPayment`, `numberOfStops`, `isRequiredNow`, `qRequiredDate`, `createdDate`, `requestStatus`, `fine`, `cancelDate`) VALUES
(342, 253, 34.106468, -118.463844, 0, 'get help', '', '', '', 0, 1, '0000-00-00', '2016-07-05 21:55:25', 4, 5, '2016-07-05 22:56:05'),
(343, 205, 0.000000, 0.000000, 0, 'Help with garage', '', '', '', 0, 1, '0000-00-00', '2016-07-05 22:54:13', 4, 0, '2016-07-05 22:54:38'),
(344, 205, 31.912127, -106.573807, 0, 'Help with backyard', '', '', '', 0, 1, '0000-00-00', '2016-07-05 22:58:27', 2, 0, '0000-00-00 00:00:00'),
(345, 205, 31.912136, -106.573814, 0, 'Help with car', '', '', '', 0, 1, '0000-00-00', '2016-07-05 22:58:54', -1, 0, '0000-00-00 00:00:00'),
(346, 4, 65.970001, -18.530001, 0, 'hgfhgf', '', '', '', 0, 1, '0000-00-00', '2016-07-06 04:27:05', -1, 0, '0000-00-00 00:00:00'),
(347, 4, 65.970001, -18.530001, 1, 'helloo', '', '', '', 2, 0, '0000-00-00', '2016-07-06 05:00:33', -1, 0, '0000-00-00 00:00:00'),
(348, 205, 31.912058, -106.573761, 0, 'Help with homework', '', '', '', 0, 1, '0000-00-00', '2016-07-06 05:18:09', -1, 0, '0000-00-00 00:00:00'),
(349, 205, 31.912064, -106.573784, 0, 'Help w dishes', '', '', '', 0, 1, '0000-00-00', '2016-07-06 05:19:26', -1, 0, '0000-00-00 00:00:00'),
(350, 5, 19.017614, 72.856163, 0, 'Knoll', '', '', '', 0, 1, '0000-00-00', '2016-07-06 06:25:44', -1, 0, '0000-00-00 00:00:00'),
(351, 205, 31.912041, -106.573730, 0, 'Help with rv', '', '', '', 0, 1, '0000-00-00', '2016-07-06 06:26:45', -1, 0, '0000-00-00 00:00:00'),
(352, 5, 19.017614, 72.856163, 0, 'Jeff', '', '', '', 0, 1, '0000-00-00', '2016-07-06 06:39:49', -1, 0, '0000-00-00 00:00:00'),
(353, 205, 31.912121, -106.573753, 0, 'Help cleaning', '', '', '', 0, 1, '0000-00-00', '2016-07-06 07:42:54', -1, 0, '0000-00-00 00:00:00'),
(354, 5, 65.970001, -18.530001, 0, 'ngff', '', '', '', 0, 1, '0000-00-00', '2016-07-06 08:04:25', 4, 0, '2016-07-06 08:49:16'),
(355, 205, 31.912100, -106.573700, 0, 'Help with storage', '', '', '', 0, 1, '0000-00-00', '2016-07-06 08:44:57', -1, 0, '0000-00-00 00:00:00'),
(356, 5, 65.970001, -18.530001, 0, 'gfhgf', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:12:48', 4, 0, '2016-07-06 09:12:59'),
(357, 5, 21.150000, 72.760002, 0, 'Help to find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:32:09', 4, 0, '2016-07-06 09:33:29'),
(358, 205, 31.912102, -106.573776, 0, 'Need help', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:52:40', -1, 0, '0000-00-00 00:00:00'),
(359, 5, 21.150000, 72.760002, 0, 'Test request', '', '', '', 0, 1, '0000-00-00', '2016-07-06 09:54:52', 4, 0, '2016-07-06 09:55:20'),
(360, 5, 21.150000, 72.760002, 0, 'Find plumber', '', '', '', 0, 1, '0000-00-00', '2016-07-06 10:02:46', 4, 0, '2016-07-06 10:35:48'),
(361, 5, 65.970001, -18.530001, 0, 'help', '', '', '', 0, 1, '0000-00-00', '2016-07-06 10:41:44', 4, 0, '2016-07-06 14:57:43'),
(362, 4, 21.150000, 72.760002, 1, 'Pick up goods ', '', '', '', 2, 0, '0000-00-00', '2016-07-06 10:49:44', 4, 0, '2016-07-06 11:02:36'),
(363, 4, 21.150000, 72.760002, 0, 'Yrehfdfsyausry', '', '', '', 0, 1, '0000-00-00', '2016-07-06 11:03:53', 4, 0, '2016-07-06 11:04:17'),
(364, 4, 21.150000, 72.760002, 0, 'Find food', '', '', '', 0, 1, '0000-00-00', '2016-07-06 11:09:44', -1, 0, '0000-00-00 00:00:00'),
(365, 5, 21.150000, 72.760002, 1, 'pick up goods', '', '', '', 2, 0, '0000-00-00', '2016-07-06 12:40:54', 4, 0, '2016-07-06 12:46:11'),
(366, 18, 34.106197, -118.463783, 0, 'Find', 'Doctor', '< 1 hr', '<$20', 0, 0, '2016-07-05', '2016-07-07 00:02:43', 4, 5, '2016-07-07 00:03:39'),
(367, 205, 31.912149, -106.573845, 0, 'Fix garage', '', '', '', 0, 1, '0000-00-00', '2016-07-07 02:49:36', -1, 0, '0000-00-00 00:00:00'),
(368, 5, 21.150000, 72.760002, 1, 'Pick up toothbrush', '', '', '', 2, 0, '0000-00-00', '2016-07-07 04:31:12', 2, 0, '0000-00-00 00:00:00'),
(369, 205, 31.912062, -106.573898, 0, 'Please help with pool', '', '', '', 0, 1, '0000-00-00', '2016-07-07 04:47:41', -1, 0, '0000-00-00 00:00:00'),
(370, 5, 21.150000, 72.760002, 0, 'Find food', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:31:17', 2, 0, '0000-00-00 00:00:00'),
(371, 5, 21.150000, 72.760002, 0, 'Find goods', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:44:52', 2, 0, '0000-00-00 00:00:00'),
(372, 205, 31.912117, -106.573837, 0, 'Test', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:51:44', -1, 0, '0000-00-00 00:00:00'),
(373, 5, 21.150000, 72.760002, 0, 'Hello testing', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:55:45', 2, 0, '0000-00-00 00:00:00'),
(374, 5, 21.150000, 72.760002, 0, 'Fguub', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:56:57', 2, 0, '0000-00-00 00:00:00'),
(375, 5, 21.150000, 72.760002, 0, 'Tnjk', '', '', '', 0, 1, '0000-00-00', '2016-07-07 05:58:05', 2, 0, '0000-00-00 00:00:00'),
(376, 5, 21.150000, 72.760002, 0, 'Test', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:18:06', 2, 0, '0000-00-00 00:00:00'),
(377, 5, 21.150000, 72.760002, 0, 'Testing', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:20:06', 2, 0, '0000-00-00 00:00:00'),
(378, 5, 21.150000, 72.760002, 0, 'Hey', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:25:53', 2, 0, '0000-00-00 00:00:00'),
(379, 5, 21.150000, 72.760002, 0, 'Arrange cab', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:27:24', 2, 0, '0000-00-00 00:00:00'),
(380, 5, 21.150000, 72.760002, 0, 'Bdbnjgng', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:37:06', 4, 0, '2016-07-07 06:41:03'),
(381, 205, 31.912111, -106.573830, 0, 'Help with homework', '', '', '', 0, 1, '0000-00-00', '2016-07-07 06:55:01', -1, 0, '0000-00-00 00:00:00'),
(382, 205, 31.912100, -106.573746, 0, 'Help cleaning oven', '', '', '', 0, 1, '0000-00-00', '2016-07-07 08:02:47', -1, 0, '0000-00-00 00:00:00'),
(383, 4, 65.970001, -18.530001, 0, 'help', '', '', '', 0, 1, '0000-00-00', '2016-07-07 09:49:37', 4, 0, '2016-07-07 10:45:12'),
(384, 5, 21.150000, 72.760002, 0, 'Hello hii', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:26:18', 4, 0, '2016-07-07 10:35:46'),
(385, 5, 21.150000, 72.760002, 0, 'Hi', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:29:02', 2, 0, '0000-00-00 00:00:00'),
(386, 5, 21.150000, 72.760002, 0, 'Find cab', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:32:25', 2, 0, '0000-00-00 00:00:00'),
(387, 5, 21.150000, 72.760002, 0, 'Testing req', '', '', '', 0, 1, '0000-00-00', '2016-07-07 10:34:25', 2, 0, '0000-00-00 00:00:00'),
(388, 4, 65.970001, -18.530001, 1, 'pic up dress drop at home', '', '', '', 2, 0, '0000-00-00', '2016-07-07 10:44:43', -1, 0, '0000-00-00 00:00:00'),
(389, 5, 21.150000, 72.760002, 0, 'Find more', '', '', '', 0, 1, '0000-00-00', '2016-07-07 11:24:01', 2, 0, '0000-00-00 00:00:00'),
(390, 5, 21.150000, 72.760002, 1, 'Drop everything', '', '', '', 2, 0, '0000-00-00', '2016-07-07 11:25:08', 2, 0, '0000-00-00 00:00:00'),
(391, 5, 21.150000, 72.760002, 0, 'Find auto', '', '', '', 0, 1, '0000-00-00', '2016-07-07 11:43:41', 2, 0, '0000-00-00 00:00:00'),
(392, 5, 21.150000, 72.760002, 0, 'Dnfamstkts', '', '', '', 0, 1, '0000-00-00', '2016-07-07 11:47:27', 2, 0, '0000-00-00 00:00:00'),
(393, 205, 37.332333, -122.031219, 0, 'Help with home improve', '', '', '', 0, 1, '0000-00-00', '2016-07-07 20:38:24', -1, 0, '0000-00-00 00:00:00'),
(394, 205, 37.332333, -122.031219, 0, 'Help dog', '', '', '', 0, 1, '0000-00-00', '2016-07-07 21:42:08', -1, 0, '0000-00-00 00:00:00'),
(395, 205, 37.332333, -122.031219, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-07 22:46:14', -1, 0, '0000-00-00 00:00:00'),
(396, 205, 37.332333, -122.031219, 0, 'Help Now', '', '', '', 0, 1, '0000-00-00', '2016-07-08 01:26:24', -1, 0, '0000-00-00 00:00:00'),
(397, 205, 37.332333, -122.031219, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-08 03:39:06', -1, 0, '0000-00-00 00:00:00'),
(398, 205, 37.332333, -122.031219, 0, 'Help with dishes', '', '', '', 0, 1, '0000-00-00', '2016-07-08 06:47:08', 4, 0, '2016-07-08 07:29:10'),
(399, 205, 37.332333, -122.031219, 0, 'Help', '', '', '', 0, 1, '0000-00-00', '2016-07-08 07:42:27', 4, 0, '2016-07-08 07:42:47');

-- --------------------------------------------------------

--
-- Table structure for table `qRequestAccept`
--

CREATE TABLE IF NOT EXISTS `qRequestAccept` (
`requestAcceptId` bigint(20) NOT NULL,
  `qId` bigint(20) NOT NULL,
  `qRequestId` bigint(20) NOT NULL,
  `acceptDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isConfirmedByQ` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 = not completed, 1 = completed, 2 = canceled',
  `isPaymentDone` tinyint(4) NOT NULL DEFAULT '0',
  `requestCompletionDateTime` datetime NOT NULL,
  `receiptTotalBill` float NOT NULL,
  `mapURL` varchar(255) NOT NULL,
  `milesTransported` varchar(100) NOT NULL,
  `paymentDoneDateTime` datetime NOT NULL,
  `paymentDoneByRequestor` float NOT NULL,
  `paymentReceivedByQ` float NOT NULL,
  `requestAmt` float(9,2) NOT NULL,
  `serviceFeeToQ` float(9,2) NOT NULL,
  `serviceFeeToUser` float(9,2) NOT NULL,
  `speedRating` int(11) NOT NULL,
  `qualityRating` int(11) NOT NULL,
  `feedback` varchar(255) NOT NULL DEFAULT ' ',
  `ratingDate` datetime NOT NULL,
  `isReviewed` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qRequestAccept`
--

INSERT INTO `qRequestAccept` (`requestAcceptId`, `qId`, `qRequestId`, `acceptDate`, `isConfirmedByQ`, `isPaymentDone`, `requestCompletionDateTime`, `receiptTotalBill`, `mapURL`, `milesTransported`, `paymentDoneDateTime`, `paymentDoneByRequestor`, `paymentReceivedByQ`, `requestAmt`, `serviceFeeToQ`, `serviceFeeToUser`, `speedRating`, `qualityRating`, `feedback`, `ratingDate`, `isReviewed`) VALUES
(1, 1, 1, '2016-05-13 12:17:01', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(2, 2, 5, '2016-05-13 12:28:11', 1, 1, '2016-05-13 07:28:59', 0, '', '', '2016-05-13 07:28:59', 71.48, 65.2, 0.00, 0.00, 0.00, 5, 5, 'Hchchnchxhxjuucjdhxhxhcudjfydjucudcjxhcjxgxhgx xx', '2016-05-13 07:29:24', 1),
(3, 1, 9, '2016-05-13 12:44:54', 1, 1, '2016-05-13 07:45:37', 0, '', '', '2016-05-13 07:45:37', 19.68, 15.2, 0.00, 0.00, 0.00, 5, 5, 'ubtbt g gb', '2016-05-13 07:46:14', 1),
(4, 1, 10, '2016-05-13 12:47:29', 1, 1, '2016-05-13 07:47:53', 0, '', '', '2016-05-13 07:47:53', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(5, 2, 11, '2016-05-13 12:48:38', 1, 1, '2016-05-13 07:51:25', 0, '', '', '2016-05-13 07:51:25', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(6, 2, 12, '2016-05-13 13:01:13', 1, 1, '2016-05-13 08:03:03', 0, '', '', '2016-05-13 08:03:03', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(7, 3, 15, '2016-05-13 13:26:26', 1, 1, '2016-05-13 08:27:07', 0, '', '', '2016-05-13 08:27:07', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(8, 3, 16, '2016-05-13 13:32:02', 1, 1, '2016-05-13 08:32:07', 0, '', '', '2016-05-13 08:32:07', 19.68, 15.2, 0.00, 0.00, 0.00, 1, 2, '', '2016-05-13 08:32:13', 1),
(9, 1, 18, '2016-05-15 00:53:23', 1, 1, '2016-05-14 19:55:03', 0, '', '', '2016-05-14 19:55:03', 19.68, 15.2, 0.00, 0.00, 0.00, 1, 1, '', '2016-05-14 19:55:16', 1),
(10, 1, 19, '2016-05-15 00:57:14', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(11, 10, 34, '2016-05-30 21:23:46', 1, 1, '2016-05-30 16:27:32', 0, '', '', '2016-05-30 16:27:32', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(12, 10, 35, '2016-05-30 21:33:36', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(13, 10, 36, '2016-05-30 21:39:26', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(14, 10, 37, '2016-05-30 21:53:32', 1, 1, '2016-05-30 17:01:38', 0, '', '0.09', '2016-05-30 17:01:38', 52.66, 47.63, 0.00, 0.00, 0.00, 1, 1, 'great!', '2016-05-30 17:01:53', 1),
(15, 2, 39, '2016-05-31 09:03:18', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(16, 2, 41, '2016-05-31 09:19:26', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(17, 1, 42, '2016-05-31 09:26:47', 1, 1, '2016-05-31 05:38:03', 0, '', '0.031412', '2016-05-31 05:38:03', 144.01, 135.8, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(18, 2, 48, '2016-05-31 11:18:12', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(19, 1, 49, '2016-05-31 11:40:08', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(20, 1, 51, '2016-05-31 12:08:44', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(21, 3, 52, '2016-05-31 12:11:25', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(22, 3, 53, '2016-05-31 12:36:23', 1, 1, '2016-06-01 00:27:24', 0, '', '0.41', '2016-06-01 00:27:24', 58.1, 52.86, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(23, 3, 54, '2016-06-01 05:34:11', 1, 1, '2016-06-01 00:36:29', 0, '', '', '2016-06-01 00:36:29', 20.72, 16.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(24, 3, 55, '2016-06-01 05:40:13', 1, 1, '2016-06-01 00:41:10', 0, '', '', '2016-06-01 00:41:10', 20.72, 16.2, 0.00, 0.00, 0.00, 4, 4, '', '2016-06-01 00:41:24', 1),
(25, 3, 56, '2016-06-01 05:44:12', 1, 1, '2016-06-01 00:45:00', 0, '', '', '2016-06-01 00:45:00', 20.72, 16.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(26, 9, 63, '2016-06-06 20:27:22', 1, 1, '2016-06-06 16:30:54', 0, '', '29.96', '2016-06-06 16:30:54', 22.78, 17.59, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-06 16:31:23', 1),
(27, 4, 66, '2016-06-10 22:14:50', 1, 1, '2016-06-10 17:16:15', 0, '', '', '2016-06-10 17:16:15', 45.87, 40.48, 0.00, 0.00, 0.00, 1, 1, 'Great service ! I recomend this q!', '2016-06-10 17:16:50', 1),
(28, 4, 71, '2016-06-17 18:48:40', 1, 1, '2016-06-17 13:49:18', 0, '', '', '2016-06-17 13:49:18', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(29, 4, 72, '2016-06-17 19:22:26', 1, 1, '2016-06-17 14:23:30', 0, '', '', '2016-06-17 14:23:30', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(30, 9, 74, '2016-06-17 23:27:20', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(31, 4, 94, '2016-06-21 06:41:46', 1, 1, '2016-06-21 01:42:14', 0, '', '', '2016-06-21 01:42:14', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(32, 3, 96, '2016-06-21 07:01:16', 1, 1, '2016-06-29 02:03:21', 0, '', '', '2016-06-29 02:03:21', 3630.51, 2871.69, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(33, 4, 107, '2016-06-21 08:03:32', 1, 1, '2016-06-21 03:03:38', 0, '', '', '2016-06-21 03:03:38', 19.68, 15.2, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(34, 3, 111, '2016-06-21 10:55:55', 1, 1, '2016-07-01 08:54:33', 0, '', '', '2016-07-01 08:54:34', 4593.33, 3633.19, 4374.60, 874.92, 218.73, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(35, 127, 123, '2016-06-22 03:06:16', 1, 1, '2016-06-21 22:08:25', 0, '', '0.000000', '2016-06-21 22:08:25', 16.78, 13, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(36, 10, 124, '2016-06-22 06:48:01', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(37, 9, 126, '2016-06-23 00:58:01', 1, 1, '2016-06-22 19:58:58', 0, '', '', '2016-06-22 19:58:59', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-22 19:59:07', 1),
(38, 9, 127, '2016-06-23 01:11:41', 1, 1, '2016-06-22 20:12:04', 0, '', '', '2016-06-22 20:12:05', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'swell\n', '2016-06-22 20:12:54', 1),
(39, 39, 133, '2016-06-23 22:10:53', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(40, 39, 134, '2016-06-24 09:57:55', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(41, 39, 141, '2016-06-24 18:45:13', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(42, 39, 144, '2016-06-24 20:18:51', 1, 1, '2016-06-24 15:24:32', 0, '', '', '2016-06-24 15:24:32', 40.95, 36.69, 0.00, 0.00, 0.00, 1, 1, 'great job!!!!\n', '2016-06-24 15:25:24', 1),
(43, 3, 148, '2016-06-27 06:27:05', 1, 1, '2016-06-27 01:30:04', 0, '', '', '2016-06-27 01:30:04', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(44, 127, 160, '2016-06-28 00:59:19', 1, 1, '2016-06-27 19:59:56', 0, '', '', '2016-06-27 19:59:56', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(45, 127, 161, '2016-06-28 01:19:56', 1, 1, '2016-06-27 20:20:05', 0, '', '', '2016-06-27 20:20:05', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(46, 39, 162, '2016-06-28 01:25:30', 1, 1, '2016-06-27 20:26:04', 0, '', '', '2016-06-27 20:26:05', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-27 20:26:09', 1),
(47, 3, 166, '2016-06-28 08:15:59', 1, 1, '2016-07-01 08:26:09', 0, '', '', '2016-07-01 08:26:10', 1459.56, 1154.67, 1390.06, 278.01, 69.50, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(48, 3, 183, '2016-06-28 12:49:55', 1, 1, '2016-06-28 07:50:51', 0, '', '', '2016-06-28 07:50:52', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'ggf\n', '2016-06-28 07:51:18', 1),
(49, 3, 185, '2016-06-28 12:53:20', 1, 1, '2016-07-01 08:33:58', 0, '', '', '2016-07-01 08:33:59', 1374.66, 1087.53, 1309.20, 261.84, 65.46, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(50, 3, 186, '2016-06-28 16:47:45', 1, 1, '2016-06-28 11:48:33', 0, '', '', '2016-06-28 11:48:34', 544.95, 531.3, 0.00, 0.00, 0.00, 1, 1, 'hjfhnhgg', '2016-06-28 11:50:00', 1),
(51, 3, 187, '2016-06-28 16:57:14', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId187.png', '', '2016-07-07 05:07:12', 3957.44, 3015.19, 3768.99, 753.80, 188.45, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(52, 160, 189, '2016-06-28 22:02:18', 1, 1, '2016-06-28 17:03:13', 0, '', '', '2016-06-28 17:03:13', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(53, 164, 193, '2016-06-29 00:58:17', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(54, 164, 197, '2016-06-29 01:08:26', 1, 1, '2016-06-28 20:09:48', 0, '', '', '2016-06-28 20:09:49', 26.77, 22.77, 0.00, 0.00, 0.00, 1, 1, 'Great job', '2016-06-28 20:09:58', 1),
(55, 9, 198, '2016-06-29 02:00:29', 1, 1, '2016-06-28 21:01:13', 0, '', '0.00', '2016-06-28 21:01:13', 16.8, 13.59, 0.00, 0.00, 0.00, 5, 5, 'great', '2016-06-28 21:01:35', 1),
(56, 167, 199, '2016-06-29 02:09:02', 1, 1, '2016-06-28 21:10:05', 0, '', '', '2016-06-28 21:10:06', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-28 21:10:14', 1),
(57, 167, 200, '2016-06-29 02:21:54', 1, 1, '2016-06-28 21:22:18', 0, '', '', '2016-06-28 21:22:19', 16.8, 13.59, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-28 21:22:24', 1),
(58, 167, 202, '2016-06-29 02:31:22', 1, 1, '2016-06-28 21:31:37', 0, '', '', '2016-06-28 21:31:37', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'Good work\n', '2016-06-28 21:34:01', 1),
(59, 3, 208, '2016-06-29 06:37:14', 1, 1, '2016-06-29 01:39:19', 0, '', '', '2016-06-29 01:39:20', 19.95, 16.08, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(60, 3, 209, '2016-06-29 07:05:11', 1, 1, '2016-06-29 02:05:35', 0, '', '', '2016-06-29 02:05:35', 19.95, 16.08, 0.00, 0.00, 0.00, 2, 2, '', '2016-06-29 02:05:53', 1),
(61, 3, 211, '2016-06-29 10:13:23', 1, 1, '2016-06-29 05:14:43', 0, '', '', '2016-06-29 05:14:44', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, 'good service', '2016-06-29 05:15:06', 1),
(62, 3, 212, '2016-06-29 10:19:04', 1, 1, '2016-06-29 05:19:25', 0, '', '', '2016-06-29 05:19:25', 19.95, 16.08, 0.00, 0.00, 0.00, 1, 1, '', '2016-06-29 05:19:40', 1),
(63, 3, 213, '2016-06-29 10:23:03', 1, 1, '2016-06-29 05:23:13', 0, '', '', '2016-06-29 05:23:14', 19.95, 16.08, 0.00, 0.00, 0.00, 4, 4, '', '2016-06-29 05:23:23', 1),
(64, 3, 217, '2016-06-29 12:49:54', 1, 1, '2016-06-29 08:14:31', 0, '', '', '2016-06-29 08:14:32', 649.95, 634.35, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(65, 167, 218, '2016-06-29 14:11:54', 1, 1, '2016-06-29 09:13:19', 0, '', '', '2016-06-29 09:13:20', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-29 09:13:26', 1),
(66, 167, 221, '2016-06-29 14:23:00', 1, 1, '2016-06-29 09:24:16', 0, '', '', '2016-06-29 09:24:17', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-29 09:24:21', 1),
(67, 167, 222, '2016-06-29 14:31:33', 1, 1, '2016-06-29 09:31:49', 0, '', '', '2016-06-29 09:31:50', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-29 09:31:53', 1),
(68, 9, 223, '2016-06-29 14:46:59', 1, 1, '2016-06-29 09:47:22', 0, '', '', '2016-06-29 09:47:23', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-29 09:47:31', 1),
(69, 167, 224, '2016-06-29 14:49:12', 1, 1, '2016-06-29 09:49:18', 0, '', '', '2016-06-29 09:49:18', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-29 09:49:25', 1),
(70, 167, 225, '2016-06-29 15:21:20', 1, 1, '2016-06-29 10:21:28', 0, '', '', '2016-06-29 10:21:29', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-29 10:21:32', 1),
(71, 9, 225, '2016-06-29 15:24:55', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(72, 3, 232, '2016-06-30 05:57:12', 1, 1, '2016-06-30 00:57:36', 0, '', '', '2016-06-30 00:57:37', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-30 00:57:46', 1),
(73, 164, 236, '2016-06-30 12:09:38', 1, 1, '2016-06-30 07:10:22', 0, '', '', '2016-06-30 07:10:23', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-06-30 07:10:29', 1),
(74, 167, 237, '2016-06-30 19:13:42', 1, 1, '2016-06-30 14:14:26', 0, '', '', '2016-06-30 14:14:27', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-30 14:28:00', 1),
(75, 167, 238, '2016-06-30 19:28:13', 1, 1, '2016-06-30 14:28:20', 0, '', '', '2016-06-30 14:28:21', 16.8, 13.59, 16.00, 3.20, 0.80, 1, 1, '', '2016-06-30 14:28:25', 1),
(76, 167, 239, '2016-06-30 23:57:56', 1, 1, '2016-06-30 18:58:08', 0, '', '', '2016-06-30 18:58:09', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, 'Good', '2016-06-30 18:58:27', 1),
(77, 167, 240, '2016-07-01 00:36:02', 1, 1, '2016-06-30 19:36:07', 0, '', '', '2016-06-30 19:36:08', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, 'Ok', '2016-06-30 19:36:16', 1),
(78, 167, 248, '2016-07-02 01:36:12', 0, 0, '0000-00-00 00:00:00', 0, '', '0.045466', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 1, 1, '', '2016-07-01 20:39:07', 1),
(79, 167, 251, '2016-07-02 06:24:24', 1, 1, '2016-07-02 01:24:30', 0, '', '', '2016-07-02 01:24:30', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 2, '', '2016-07-02 01:24:50', 1),
(80, 167, 253, '2016-07-02 06:29:40', 1, 1, '2016-07-02 01:29:44', 0, '', '', '2016-07-02 01:29:45', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-02 01:30:42', 1),
(81, 167, 254, '2016-07-02 07:01:08', 1, 1, '2016-07-02 02:01:11', 0, '', '', '2016-07-02 02:01:12', 19.95, 16.08, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-02 02:01:22', 1),
(82, 171, 258, '2016-07-02 08:13:30', 1, 1, '2016-07-02 03:13:34', 0, '', '', '2016-07-02 03:13:35', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(83, 171, 260, '2016-07-04 05:24:05', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 1, 1, '', '2016-07-04 00:24:54', 1),
(84, 171, 261, '2016-07-04 05:27:19', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 1, 1, '', '2016-07-04 00:27:27', 1),
(85, 171, 264, '2016-07-04 05:33:27', 1, 1, '2016-07-04 00:34:25', 0, '', '', '2016-07-04 00:34:26', 20.05, 15.3, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 00:34:30', 1),
(86, 171, 265, '2016-07-04 05:40:20', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(87, 171, 268, '2016-07-04 20:15:01', 1, 1, '2016-07-04 15:15:10', 0, '', '', '2016-07-04 15:15:12', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 15:15:18', 1),
(88, 171, 269, '2016-07-04 23:22:58', 1, 1, '2016-07-04 18:24:06', 0, '', '', '2016-07-04 18:24:07', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 18:24:11', 1),
(89, 171, 270, '2016-07-04 23:24:36', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(90, 171, 272, '2016-07-04 23:25:38', 1, 1, '2016-07-04 18:25:45', 0, '', '', '2016-07-04 18:25:46', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 18:25:50', 1),
(91, 171, 280, '2016-07-05 00:14:16', 1, 1, '2016-07-04 19:14:23', 0, '', '', '2016-07-04 19:14:24', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 19:14:30', 1),
(92, 171, 281, '2016-07-05 00:51:59', 1, 1, '2016-07-04 19:52:05', 0, '', '', '2016-07-04 19:52:06', 19.95, 15.2, 19.00, 3.80, 0.95, 1, 1, '', '2016-07-04 19:52:12', 1),
(93, 39, 289, '2016-07-05 06:27:59', 1, 0, '2016-07-05 02:25:46', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(94, 39, 293, '2016-07-05 07:34:28', 1, 1, '2016-07-05 02:57:06', 0, '', '', '2016-07-05 02:57:07', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(95, 39, 294, '2016-07-05 07:58:52', 1, 1, '2016-07-05 03:00:06', 0, '', '', '2016-07-05 03:00:08', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(96, 39, 295, '2016-07-05 08:07:28', 1, 1, '2016-07-05 03:08:11', 0, '', '', '2016-07-05 03:08:12', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(97, 39, 296, '2016-07-05 08:13:53', 1, 1, '2016-07-05 03:14:05', 0, '', '', '2016-07-05 03:14:06', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(98, 39, 300, '2016-07-05 08:19:19', 1, 1, '2016-07-05 03:19:30', 0, '', '', '2016-07-05 03:19:31', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(99, 39, 302, '2016-07-05 08:23:53', 1, 1, '2016-07-05 03:23:59', 0, '', '', '2016-07-05 03:24:01', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(100, 39, 303, '2016-07-05 08:25:42', 1, 1, '2016-07-05 03:25:48', 0, '', '', '2016-07-05 03:25:49', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(101, 39, 306, '2016-07-05 08:28:22', 1, 1, '2016-07-05 03:28:36', 0, '', '', '2016-07-05 03:28:37', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(102, 164, 328, '2016-07-05 18:50:31', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(103, 164, 330, '2016-07-05 18:55:23', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(104, 171, 332, '2016-07-05 20:36:16', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(105, 171, 333, '2016-07-05 20:41:20', 2, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId333.png', '', '2016-07-05 15:44:50', 19.95, 15.2, 19.00, 3.80, 0.95, 4, 4, 'excellent job', '2016-07-05 15:44:29', 1),
(106, 39, 340, '2016-07-05 21:53:14', 2, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId340.png', '', '2016-07-05 16:53:23', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(107, 171, 341, '2016-07-05 21:54:11', 2, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId341.png', '', '2016-07-05 16:54:17', 19.95, 15.2, 19.00, 3.80, 0.95, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(108, 39, 342, '2016-07-05 21:55:27', 2, 0, '0000-00-00 00:00:00', 0, 'requestMapURLId342.png', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 4, 9, '', '2016-07-05 16:55:45', 1),
(109, 39, 344, '2016-07-05 22:58:34', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(110, 171, 366, '2016-07-07 00:03:28', 2, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(111, 3, 368, '2016-07-07 04:31:38', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId368.png', '', '2016-07-06 23:34:10', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(112, 3, 370, '2016-07-07 05:31:26', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId370.png', '', '2016-07-07 06:52:07', 124.12, 94.57, 118.21, 23.64, 5.91, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(113, 3, 371, '2016-07-07 05:45:01', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId371.png', '', '2016-07-07 01:00:48', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(114, 3, 375, '2016-07-07 06:01:10', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId375.png', '', '2016-07-07 01:15:33', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(115, 3, 374, '2016-07-07 06:01:29', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId374.png', '', '2016-07-07 05:28:21', 88.27, 67.25, 84.06, 16.81, 4.20, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(116, 3, 373, '2016-07-07 06:01:39', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId373.png', '', '2016-07-07 05:30:16', 88.82, 67.67, 84.59, 16.92, 4.23, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(117, 3, 376, '2016-07-07 06:20:30', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId376.png', '', '2016-07-07 07:37:56', 123.09, 93.78, 117.23, 23.45, 5.86, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(118, 3, 377, '2016-07-07 06:20:44', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId377.png', '', '2016-07-07 01:28:48', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(119, 3, 379, '2016-07-07 06:29:19', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(120, 3, 378, '2016-07-07 06:37:40', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(121, 3, 387, '2016-07-07 11:20:56', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(122, 3, 386, '2016-07-07 11:21:55', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(123, 3, 385, '2016-07-07 11:22:41', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(124, 3, 392, '2016-07-07 11:57:29', 0, 0, '0000-00-00 00:00:00', 0, '', '', '0000-00-00 00:00:00', 0, 0, 0.00, 0.00, 0.00, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(125, 3, 391, '2016-07-07 11:57:56', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId391.png', '', '2016-07-07 07:22:05', 23.1, 17.6, 22.00, 4.40, 1.10, 4, 4, '', '2016-07-07 07:23:28', 1),
(126, 3, 389, '2016-07-07 11:58:16', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId389.png', '', '2016-07-07 07:06:52', 23.1, 17.6, 22.00, 4.40, 1.10, 4, 4, '', '2016-07-07 07:04:26', 1),
(127, 3, 390, '2016-07-07 11:59:10', 0, 1, '0000-00-00 00:00:00', 0, 'requestMapURLId390.png', '', '2016-07-07 07:01:30', 23.1, 17.6, 22.00, 4.40, 1.10, 0, 0, ' ', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qRequestBillImages`
--

CREATE TABLE IF NOT EXISTS `qRequestBillImages` (
`billImageId` bigint(20) NOT NULL,
  `qRequestId` bigint(20) NOT NULL,
  `billImage` varchar(2000) NOT NULL,
  `billAmount` float(9,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `qRequestBillImages`
--

INSERT INTO `qRequestBillImages` (`billImageId`, `qRequestId`, `billImage`, `billAmount`) VALUES
(1, 5, '1463142535884.jpg', 50.00),
(2, 34, '1464643622979.jpg', 0.00),
(3, 37, '1464645517373.jpg', 12.00),
(4, 37, '1464645606745.jpg', 11.32),
(5, 37, '1464645680349.jpg', 11.49),
(6, 42, '1464691071662.jpg', 123.00),
(7, 53, '1464758834752.jpg', 40.00),
(8, 54, '1464759379159.jpg', 1.00),
(9, 55, '1464759645136.jpg', 1.00),
(10, 56, '1464759875619.jpg', 1.00),
(11, 66, '1465596930613.jpg', 25.28),
(12, 71, '1466189347923.jpg', 0.00),
(13, 94, '1466491328262.jpg', 0.00),
(14, 123, '1466564884546.jpg', 0.20),
(15, 144, '1466799856077.jpg', 20.00),
(16, 186, '1467132500013.jpg', 500.00),
(17, 197, '1467162580044.jpg', 6.50),
(18, 217, '1467204633087.jpeg', 600.00),
(19, 248, '1467423531994.jpg', 0.10),
(20, 260, '1467609864749.jpg', 0.00),
(21, 264, '1467610462694.jpg', 0.10),
(22, 289, '1467700165882.jpg', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `reportIssue`
--

CREATE TABLE IF NOT EXISTS `reportIssue` (
  `issueDetail` varchar(255) NOT NULL,
  `userId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reportIssue`
--

INSERT INTO `reportIssue` (`issueDetail`, `userId`) VALUES
('Fix bugs  please ', 12),
('i''m having trouble logging in ', 7),
('Trying to become a Q. Recieved an error message that I needed to contact admin.\n\nThanks you', 48),
('test', 7),
('my account is not verified ', 99),
('Hello, it says my accoint is not verified. Please help to ensure account is verified ', 152),
('hii I couldn''t  register my DOB.\nit doesn''t go back. ', 154),
('Hi i received message stating that my Q is not verified.', 211),
('hi I tried to register but former some reason it didn''t work. it''s contact  administration. ', 154),
('also I couldn''t write my DOB. \n01/31/1980.\n', 154),
('How do I get my account verfied?', 224);

-- --------------------------------------------------------

--
-- Table structure for table `requestSentToQ`
--

CREATE TABLE IF NOT EXISTS `requestSentToQ` (
`notificationId` bigint(20) NOT NULL,
  `qRequestId` bigint(20) NOT NULL,
  `qId` bigint(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=947 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requestSentToQ`
--

INSERT INTO `requestSentToQ` (`notificationId`, `qRequestId`, `qId`) VALUES
(1, 68, 8),
(2, 68, 3),
(3, 70, 8),
(4, 70, 3),
(5, 70, 4),
(6, 71, 4),
(7, 71, 8),
(8, 71, 3),
(9, 72, 4),
(10, 72, 8),
(11, 72, 3),
(12, 73, 4),
(13, 73, 8),
(14, 73, 9),
(15, 74, 4),
(16, 74, 8),
(17, 74, 9),
(18, 75, 4),
(19, 75, 8),
(20, 76, 8),
(21, 76, 10),
(22, 77, 8),
(23, 77, 10),
(24, 79, 3),
(25, 79, 4),
(26, 79, 8),
(27, 80, 3),
(28, 80, 4),
(29, 80, 8),
(30, 81, 4),
(31, 81, 8),
(32, 81, 3),
(33, 82, 4),
(34, 82, 8),
(35, 82, 3),
(36, 83, 4),
(37, 83, 8),
(38, 83, 3),
(39, 84, 4),
(40, 84, 8),
(41, 84, 3),
(42, 85, 4),
(43, 85, 8),
(44, 86, 4),
(45, 86, 8),
(46, 87, 4),
(47, 87, 8),
(48, 88, 4),
(49, 88, 8),
(50, 89, 4),
(51, 89, 8),
(52, 90, 4),
(53, 90, 8),
(54, 91, 4),
(55, 91, 8),
(56, 92, 4),
(57, 92, 8),
(58, 93, 4),
(59, 93, 8),
(60, 94, 4),
(61, 94, 8),
(62, 95, 8),
(63, 93, 3),
(64, 95, 3),
(65, 96, 8),
(66, 96, 3),
(67, 97, 3),
(68, 97, 8),
(69, 98, 8),
(70, 99, 8),
(71, 100, 8),
(72, 101, 8),
(73, 102, 8),
(74, 103, 8),
(75, 104, 8),
(76, 105, 8),
(77, 106, 8),
(78, 107, 8),
(79, 98, 4),
(80, 100, 4),
(81, 102, 4),
(82, 103, 4),
(83, 104, 4),
(84, 107, 4),
(85, 100, 3),
(86, 102, 3),
(87, 103, 3),
(88, 104, 3),
(89, 108, 3),
(90, 108, 8),
(91, 109, 3),
(92, 109, 8),
(93, 110, 3),
(94, 110, 8),
(95, 111, 3),
(96, 112, 8),
(97, 114, 8),
(98, 115, 8),
(99, 116, 8),
(100, 117, 8),
(101, 118, 4),
(102, 118, 8),
(103, 119, 4),
(104, 119, 8),
(105, 121, 4),
(106, 121, 8),
(107, 122, 4),
(108, 122, 8),
(109, 123, 127),
(110, 175, 4),
(111, 175, 8),
(112, 175, 39),
(113, 175, 127),
(114, 176, 4),
(115, 176, 8),
(116, 176, 39),
(117, 176, 127),
(118, 178, 4),
(119, 178, 8),
(120, 178, 39),
(121, 178, 127),
(122, 179, 4),
(123, 179, 8),
(124, 179, 39),
(125, 179, 127),
(126, 181, 3),
(127, 181, 4),
(128, 181, 8),
(129, 181, 39),
(130, 181, 127),
(131, 182, 3),
(132, 182, 4),
(133, 182, 8),
(134, 182, 39),
(135, 182, 127),
(136, 183, 3),
(137, 183, 4),
(138, 183, 8),
(139, 183, 39),
(140, 183, 127),
(141, 184, 3),
(142, 184, 4),
(143, 184, 8),
(144, 184, 39),
(145, 184, 127),
(146, 185, 3),
(147, 185, 4),
(148, 185, 8),
(149, 185, 39),
(150, 185, 127),
(151, 186, 3),
(152, 186, 4),
(153, 186, 8),
(154, 186, 39),
(155, 187, 3),
(156, 187, 4),
(157, 187, 8),
(158, 187, 39),
(159, 188, 4),
(160, 188, 8),
(161, 188, 39),
(162, 189, 4),
(163, 189, 8),
(164, 189, 39),
(165, 189, 160),
(166, 190, 4),
(167, 190, 8),
(168, 190, 39),
(169, 191, 4),
(170, 191, 8),
(171, 191, 39),
(172, 191, 3),
(173, 192, 4),
(174, 192, 8),
(175, 192, 39),
(176, 192, 164),
(177, 192, 3),
(178, 193, 4),
(179, 193, 8),
(180, 193, 39),
(181, 193, 164),
(182, 194, 3),
(183, 194, 4),
(184, 194, 8),
(185, 194, 39),
(186, 194, 164),
(187, 195, 3),
(188, 195, 4),
(189, 195, 8),
(190, 195, 39),
(191, 195, 164),
(192, 196, 4),
(193, 196, 8),
(194, 196, 167),
(195, 197, 4),
(196, 197, 8),
(197, 197, 39),
(198, 197, 164),
(199, 197, 167),
(200, 197, 3),
(201, 198, 4),
(202, 198, 8),
(203, 198, 9),
(204, 199, 4),
(205, 199, 8),
(206, 199, 39),
(207, 199, 164),
(208, 199, 3),
(209, 199, 167),
(210, 200, 4),
(211, 200, 8),
(212, 200, 167),
(213, 202, 4),
(214, 202, 8),
(215, 202, 39),
(216, 202, 167),
(217, 202, 3),
(218, 203, 4),
(219, 203, 8),
(220, 203, 39),
(221, 203, 164),
(222, 204, 4),
(223, 204, 8),
(224, 204, 39),
(225, 204, 164),
(226, 204, 3),
(227, 205, 4),
(228, 205, 8),
(229, 205, 39),
(230, 205, 164),
(231, 206, 4),
(232, 206, 8),
(233, 206, 39),
(234, 206, 164),
(235, 207, 4),
(236, 207, 8),
(237, 207, 39),
(238, 207, 164),
(239, 205, 3),
(240, 206, 3),
(241, 207, 3),
(242, 208, 3),
(243, 208, 4),
(244, 208, 8),
(245, 208, 39),
(246, 208, 164),
(247, 209, 3),
(248, 209, 4),
(249, 209, 8),
(250, 209, 39),
(251, 209, 164),
(252, 211, 4),
(253, 211, 8),
(254, 211, 39),
(255, 211, 164),
(256, 211, 3),
(257, 212, 3),
(258, 212, 4),
(259, 212, 8),
(260, 212, 39),
(261, 212, 164),
(262, 213, 3),
(263, 213, 4),
(264, 213, 8),
(265, 213, 39),
(266, 213, 164),
(267, 214, 3),
(268, 214, 4),
(269, 214, 8),
(270, 214, 39),
(271, 214, 164),
(272, 215, 4),
(273, 215, 8),
(274, 215, 164),
(275, 215, 3),
(276, 216, 4),
(277, 216, 8),
(278, 216, 39),
(279, 216, 164),
(280, 216, 3),
(281, 217, 3),
(282, 217, 4),
(283, 217, 8),
(284, 217, 39),
(285, 217, 164),
(286, 218, 4),
(287, 218, 8),
(288, 218, 39),
(289, 218, 164),
(290, 218, 167),
(291, 219, 4),
(292, 219, 8),
(293, 219, 39),
(294, 219, 164),
(295, 219, 167),
(296, 219, 3),
(297, 221, 4),
(298, 221, 8),
(299, 221, 164),
(300, 221, 167),
(301, 222, 4),
(302, 222, 8),
(303, 222, 164),
(304, 222, 167),
(305, 223, 4),
(306, 223, 8),
(307, 223, 9),
(308, 223, 39),
(309, 223, 164),
(310, 223, 3),
(311, 224, 4),
(312, 224, 8),
(313, 224, 39),
(314, 224, 164),
(315, 224, 167),
(316, 224, 3),
(317, 225, 4),
(318, 225, 8),
(319, 225, 9),
(320, 225, 164),
(321, 225, 167),
(322, 226, 4),
(323, 226, 8),
(324, 226, 39),
(325, 226, 3),
(326, 228, 3),
(327, 228, 4),
(328, 228, 8),
(329, 228, 39),
(330, 229, 3),
(331, 229, 4),
(332, 229, 8),
(333, 229, 39),
(334, 230, 3),
(335, 230, 4),
(336, 230, 8),
(337, 230, 39),
(338, 231, 3),
(339, 231, 4),
(340, 231, 8),
(341, 231, 39),
(342, 232, 3),
(343, 232, 4),
(344, 232, 8),
(345, 232, 39),
(346, 234, 4),
(347, 234, 8),
(348, 234, 39),
(349, 235, 4),
(350, 235, 8),
(351, 235, 39),
(352, 236, 4),
(353, 236, 8),
(354, 236, 39),
(355, 236, 164),
(356, 237, 4),
(357, 237, 8),
(358, 237, 164),
(359, 237, 167),
(360, 238, 4),
(361, 238, 8),
(362, 238, 164),
(363, 238, 167),
(364, 239, 4),
(365, 239, 8),
(366, 239, 39),
(367, 239, 167),
(368, 240, 4),
(369, 240, 8),
(370, 240, 39),
(371, 240, 167),
(372, 241, 4),
(373, 241, 8),
(374, 241, 39),
(375, 241, 164),
(376, 241, 167),
(377, 242, 4),
(378, 242, 8),
(379, 242, 39),
(380, 242, 164),
(381, 242, 167),
(382, 243, 4),
(383, 243, 8),
(384, 243, 39),
(385, 243, 164),
(386, 243, 167),
(387, 244, 4),
(388, 244, 8),
(389, 244, 39),
(390, 244, 164),
(391, 244, 167),
(392, 245, 4),
(393, 245, 8),
(394, 245, 39),
(395, 245, 164),
(396, 245, 167),
(397, 246, 4),
(398, 246, 8),
(399, 246, 39),
(400, 246, 164),
(401, 246, 167),
(402, 247, 4),
(403, 247, 8),
(404, 247, 164),
(405, 247, 167),
(406, 248, 4),
(407, 248, 8),
(408, 248, 164),
(409, 248, 167),
(410, 249, 4),
(411, 249, 8),
(412, 249, 39),
(413, 249, 164),
(414, 250, 4),
(415, 250, 8),
(416, 250, 39),
(417, 250, 164),
(418, 249, 167),
(419, 251, 4),
(420, 251, 8),
(421, 251, 39),
(422, 251, 167),
(423, 252, 4),
(424, 252, 8),
(425, 252, 39),
(426, 252, 167),
(427, 253, 4),
(428, 253, 8),
(429, 253, 39),
(430, 253, 167),
(431, 254, 4),
(432, 254, 8),
(433, 254, 39),
(434, 254, 167),
(435, 255, 4),
(436, 255, 8),
(437, 255, 39),
(438, 255, 167),
(439, 256, 4),
(440, 256, 8),
(441, 256, 39),
(442, 256, 167),
(443, 256, 171),
(444, 257, 4),
(445, 257, 8),
(446, 257, 39),
(447, 257, 167),
(448, 257, 171),
(449, 258, 4),
(450, 258, 8),
(451, 258, 39),
(452, 258, 167),
(453, 258, 171),
(454, 260, 4),
(455, 260, 8),
(456, 260, 39),
(457, 260, 164),
(458, 260, 167),
(459, 260, 171),
(460, 261, 4),
(461, 261, 8),
(462, 261, 39),
(463, 261, 164),
(464, 261, 167),
(465, 261, 171),
(466, 262, 4),
(467, 262, 8),
(468, 262, 39),
(469, 262, 164),
(470, 262, 167),
(471, 262, 171),
(472, 264, 4),
(473, 264, 8),
(474, 264, 39),
(475, 264, 164),
(476, 264, 167),
(477, 264, 171),
(478, 265, 4),
(479, 265, 8),
(480, 265, 39),
(481, 265, 167),
(482, 265, 171),
(483, 266, 4),
(484, 266, 8),
(485, 266, 39),
(486, 266, 167),
(487, 266, 171),
(488, 268, 4),
(489, 268, 8),
(490, 268, 39),
(491, 268, 167),
(492, 268, 171),
(493, 269, 4),
(494, 269, 8),
(495, 269, 39),
(496, 269, 167),
(497, 269, 171),
(498, 270, 4),
(499, 270, 8),
(500, 270, 39),
(501, 270, 167),
(502, 270, 171),
(503, 272, 4),
(504, 272, 8),
(505, 272, 39),
(506, 272, 167),
(507, 272, 171),
(508, 278, 4),
(509, 278, 8),
(510, 278, 39),
(511, 278, 167),
(512, 278, 171),
(513, 279, 4),
(514, 279, 8),
(515, 279, 39),
(516, 279, 167),
(517, 279, 171),
(518, 280, 4),
(519, 280, 8),
(520, 280, 39),
(521, 280, 167),
(522, 280, 171),
(523, 281, 4),
(524, 281, 8),
(525, 281, 39),
(526, 281, 167),
(527, 281, 171),
(528, 283, 4),
(529, 283, 8),
(530, 283, 39),
(531, 283, 167),
(532, 283, 171),
(533, 284, 4),
(534, 284, 8),
(535, 284, 39),
(536, 284, 167),
(537, 284, 171),
(538, 285, 4),
(539, 285, 8),
(540, 285, 39),
(541, 285, 167),
(542, 285, 171),
(543, 289, 4),
(544, 289, 8),
(545, 289, 39),
(546, 289, 167),
(547, 289, 171),
(548, 290, 4),
(549, 290, 8),
(550, 290, 39),
(551, 290, 167),
(552, 290, 171),
(553, 292, 4),
(554, 292, 8),
(555, 292, 39),
(556, 292, 167),
(557, 293, 4),
(558, 293, 8),
(559, 293, 39),
(560, 293, 167),
(561, 294, 4),
(562, 294, 8),
(563, 294, 39),
(564, 294, 167),
(565, 295, 4),
(566, 295, 8),
(567, 295, 39),
(568, 295, 167),
(569, 296, 4),
(570, 296, 8),
(571, 296, 39),
(572, 296, 167),
(573, 297, 4),
(574, 297, 8),
(575, 297, 39),
(576, 297, 167),
(577, 298, 4),
(578, 298, 8),
(579, 298, 167),
(580, 299, 4),
(581, 299, 8),
(582, 299, 167),
(583, 300, 4),
(584, 300, 8),
(585, 300, 167),
(586, 298, 39),
(587, 299, 39),
(588, 300, 39),
(589, 301, 4),
(590, 301, 8),
(591, 301, 39),
(592, 301, 167),
(593, 302, 4),
(594, 302, 8),
(595, 302, 39),
(596, 302, 167),
(597, 303, 4),
(598, 303, 8),
(599, 303, 39),
(600, 303, 167),
(601, 304, 4),
(602, 304, 8),
(603, 304, 39),
(604, 304, 167),
(605, 306, 4),
(606, 306, 8),
(607, 306, 39),
(608, 306, 167),
(609, 305, 4),
(610, 305, 8),
(611, 305, 39),
(612, 305, 167),
(613, 309, 4),
(614, 309, 8),
(615, 309, 39),
(616, 309, 167),
(617, 310, 4),
(618, 310, 8),
(619, 310, 39),
(620, 310, 167),
(621, 311, 4),
(622, 311, 8),
(623, 311, 39),
(624, 311, 167),
(625, 312, 4),
(626, 312, 8),
(627, 312, 39),
(628, 312, 167),
(629, 313, 4),
(630, 313, 8),
(631, 313, 39),
(632, 313, 167),
(633, 314, 4),
(634, 314, 8),
(635, 314, 39),
(636, 314, 167),
(637, 315, 4),
(638, 315, 8),
(639, 315, 39),
(640, 315, 167),
(641, 316, 4),
(642, 316, 8),
(643, 316, 39),
(644, 316, 167),
(645, 318, 4),
(646, 318, 8),
(647, 318, 39),
(648, 318, 167),
(649, 320, 4),
(650, 320, 8),
(651, 320, 39),
(652, 320, 167),
(653, 321, 4),
(654, 321, 8),
(655, 321, 39),
(656, 321, 167),
(657, 322, 4),
(658, 322, 8),
(659, 322, 39),
(660, 322, 167),
(661, 324, 4),
(662, 324, 8),
(663, 324, 39),
(664, 324, 167),
(665, 324, 171),
(666, 325, 4),
(667, 325, 8),
(668, 325, 167),
(669, 325, 171),
(670, 326, 4),
(671, 326, 8),
(672, 326, 39),
(673, 326, 167),
(674, 328, 4),
(675, 328, 8),
(676, 328, 39),
(677, 328, 167),
(678, 328, 164),
(679, 328, 171),
(680, 329, 4),
(681, 329, 8),
(682, 329, 39),
(683, 329, 167),
(684, 329, 171),
(685, 330, 4),
(686, 330, 8),
(687, 330, 39),
(688, 330, 164),
(689, 330, 167),
(690, 331, 4),
(691, 331, 8),
(692, 331, 39),
(693, 331, 164),
(694, 331, 167),
(695, 332, 4),
(696, 332, 8),
(697, 332, 167),
(698, 332, 171),
(699, 333, 4),
(700, 333, 8),
(701, 333, 167),
(702, 333, 171),
(703, 334, 4),
(704, 334, 8),
(705, 334, 39),
(706, 334, 164),
(707, 334, 167),
(708, 336, 4),
(709, 336, 8),
(710, 336, 39),
(711, 336, 164),
(712, 336, 167),
(713, 337, 4),
(714, 337, 8),
(715, 337, 39),
(716, 337, 164),
(717, 337, 167),
(718, 338, 171),
(719, 338, 4),
(720, 338, 8),
(721, 338, 39),
(722, 338, 164),
(723, 338, 167),
(724, 339, 4),
(725, 339, 8),
(726, 339, 39),
(727, 339, 164),
(728, 339, 167),
(729, 340, 4),
(730, 340, 8),
(731, 340, 39),
(732, 340, 164),
(733, 340, 167),
(734, 341, 171),
(735, 339, 171),
(736, 342, 4),
(737, 342, 8),
(738, 342, 39),
(739, 342, 164),
(740, 342, 167),
(741, 343, 4),
(742, 343, 8),
(743, 343, 39),
(744, 343, 164),
(745, 343, 167),
(746, 344, 4),
(747, 344, 8),
(748, 344, 39),
(749, 344, 164),
(750, 344, 167),
(751, 345, 4),
(752, 345, 8),
(753, 345, 164),
(754, 345, 167),
(755, 346, 4),
(756, 346, 8),
(757, 346, 164),
(758, 346, 167),
(759, 348, 4),
(760, 348, 8),
(761, 348, 164),
(762, 348, 167),
(763, 349, 4),
(764, 349, 8),
(765, 349, 164),
(766, 349, 167),
(767, 350, 4),
(768, 350, 8),
(769, 350, 164),
(770, 350, 167),
(771, 351, 4),
(772, 351, 8),
(773, 351, 164),
(774, 351, 167),
(775, 352, 4),
(776, 352, 8),
(777, 352, 164),
(778, 352, 167),
(779, 353, 4),
(780, 353, 8),
(781, 353, 164),
(782, 353, 167),
(783, 354, 4),
(784, 354, 8),
(785, 354, 164),
(786, 354, 167),
(787, 355, 4),
(788, 355, 8),
(789, 355, 164),
(790, 355, 167),
(791, 356, 4),
(792, 356, 8),
(793, 356, 164),
(794, 356, 167),
(795, 357, 4),
(796, 357, 8),
(797, 357, 164),
(798, 357, 167),
(799, 358, 4),
(800, 358, 8),
(801, 358, 164),
(802, 358, 167),
(803, 359, 4),
(804, 359, 8),
(805, 359, 164),
(806, 359, 167),
(807, 360, 4),
(808, 360, 8),
(809, 360, 164),
(810, 360, 167),
(811, 361, 4),
(812, 361, 8),
(813, 361, 164),
(814, 361, 167),
(815, 363, 4),
(816, 363, 8),
(817, 363, 164),
(818, 363, 167),
(819, 364, 4),
(820, 364, 8),
(821, 364, 164),
(822, 364, 167),
(823, 366, 4),
(824, 366, 8),
(825, 366, 164),
(826, 366, 167),
(827, 366, 171),
(828, 367, 4),
(829, 367, 8),
(830, 367, 164),
(831, 367, 167),
(832, 368, 3),
(833, 369, 4),
(834, 369, 8),
(835, 369, 39),
(836, 369, 164),
(837, 369, 167),
(838, 369, 3),
(839, 370, 3),
(840, 370, 4),
(841, 370, 8),
(842, 370, 39),
(843, 370, 164),
(844, 370, 167),
(845, 371, 3),
(846, 371, 4),
(847, 371, 8),
(848, 371, 39),
(849, 371, 164),
(850, 371, 167),
(851, 372, 4),
(852, 372, 8),
(853, 372, 39),
(854, 372, 164),
(855, 372, 167),
(856, 373, 4),
(857, 373, 8),
(858, 373, 39),
(859, 373, 164),
(860, 373, 167),
(861, 374, 4),
(862, 374, 8),
(863, 374, 39),
(864, 374, 164),
(865, 374, 167),
(866, 375, 4),
(867, 375, 8),
(868, 375, 39),
(869, 375, 164),
(870, 375, 167),
(871, 372, 3),
(872, 373, 3),
(873, 374, 3),
(874, 375, 3),
(875, 376, 3),
(876, 376, 4),
(877, 376, 8),
(878, 376, 39),
(879, 376, 164),
(880, 376, 167),
(881, 377, 3),
(882, 377, 4),
(883, 377, 8),
(884, 377, 39),
(885, 377, 164),
(886, 377, 167),
(887, 378, 4),
(888, 378, 8),
(889, 378, 39),
(890, 378, 164),
(891, 378, 167),
(892, 379, 4),
(893, 379, 8),
(894, 379, 39),
(895, 379, 164),
(896, 379, 167),
(897, 378, 3),
(898, 379, 3),
(899, 380, 4),
(900, 380, 8),
(901, 380, 39),
(902, 380, 164),
(903, 380, 167),
(904, 381, 4),
(905, 381, 8),
(906, 381, 39),
(907, 381, 164),
(908, 381, 167),
(909, 382, 4),
(910, 382, 8),
(911, 382, 39),
(912, 382, 167),
(913, 383, 4),
(914, 383, 8),
(915, 383, 39),
(916, 383, 167),
(917, 384, 4),
(918, 384, 8),
(919, 384, 39),
(920, 384, 167),
(921, 385, 4),
(922, 385, 8),
(923, 385, 39),
(924, 385, 167),
(925, 386, 4),
(926, 386, 8),
(927, 386, 39),
(928, 386, 167),
(929, 387, 4),
(930, 387, 8),
(931, 387, 39),
(932, 387, 167),
(933, 385, 3),
(934, 386, 3),
(935, 387, 3),
(936, 389, 3),
(937, 390, 3),
(938, 391, 3),
(939, 392, 3),
(940, 393, 3),
(941, 394, 3),
(942, 395, 3),
(943, 396, 3),
(944, 397, 3),
(945, 398, 3),
(946, 399, 3);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
`state_id` int(11) NOT NULL,
  `state_name` varchar(50) NOT NULL,
  `state_ab` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`, `state_ab`) VALUES
(3, 'Alaska', 'AK'),
(4, 'Alabama', 'AL'),
(6, 'Arkansas', 'AR'),
(8, 'Arizona', 'AZ'),
(9, 'California', 'CA'),
(10, 'Colorado', 'CO'),
(11, 'Connecticut', 'CT'),
(12, 'District of Columbia', 'DC'),
(13, 'Delaware', 'DE'),
(14, 'Florida', 'FL'),
(16, 'Georgia', 'GA'),
(18, 'Hawaii', 'HI'),
(19, 'Iowa', 'IA'),
(20, 'Idaho', 'ID'),
(21, 'Illinois', 'IL'),
(22, 'Indiana', 'IN'),
(23, 'Kansas', 'KS'),
(24, 'Kentucky', 'KY'),
(25, 'Louisiana', 'LA'),
(26, 'Massachusetts', 'MA'),
(27, 'Maryland', 'MD'),
(28, 'Maine', 'ME'),
(30, 'Michigan', 'MI'),
(31, 'Minnesota', 'MN'),
(32, 'Missouri', 'MO'),
(34, 'Mississippi', 'MS'),
(35, 'Montana', 'MT'),
(36, 'North Carolina', 'NC'),
(37, 'North Dakota', 'ND'),
(38, 'Nebraska', 'NE'),
(39, 'New Hampshire', 'NH'),
(40, 'New Jersey', 'NJ'),
(41, 'New Mexico', 'NM'),
(42, 'Nevada', 'NV'),
(43, 'New York', 'NY'),
(44, 'Ohio', 'OH'),
(45, 'Oklahoma', 'OK'),
(46, 'Oregon', 'OR'),
(47, 'Pennsylvania', 'PA'),
(48, 'Puerto Rico', 'PR'),
(50, 'Rhode Island', 'RI'),
(51, 'South Carolina', 'SC'),
(52, 'South Dakota', 'SD'),
(53, 'Tennessee', 'TN'),
(54, 'Texas', 'TX'),
(56, 'Utah', 'UT'),
(57, 'Virginia', 'VA'),
(59, 'Vermont', 'VT'),
(60, 'Washington', 'WA'),
(61, 'Wisconsin', 'WI'),
(62, 'West Virginia', 'WV'),
(63, 'Wyoming', 'WY');

-- --------------------------------------------------------

--
-- Table structure for table `stopDetail`
--

CREATE TABLE IF NOT EXISTS `stopDetail` (
  `stopDetailId` bigint(20) NOT NULL,
  `qRequestId` varchar(255) NOT NULL,
  `stopLat` float(9,6) NOT NULL,
  `stopLong` float(9,6) NOT NULL,
  `address` varchar(255) NOT NULL,
  `isQReachedAtStop` tinyint(4) NOT NULL,
  `reachedAtTime` datetime NOT NULL,
  `distanceTravelled` float(9,2) NOT NULL,
  `timeTakenForTravel` float(9,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stopDetail`
--

INSERT INTO `stopDetail` (`stopDetailId`, `qRequestId`, `stopLat`, `stopLong`, `address`, `isQReachedAtStop`, `reachedAtTime`, `distanceTravelled`, `timeTakenForTravel`) VALUES
(1, '1', 21.146875, 72.759598, 'Luxuria Business Hub, Beside Dumas Resort, Dumas Rd, Vesu, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '123', 34.106163, -118.463692, '1954-1980 Roscomare Rd 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '124', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '130', 31.805334, -106.382439, 'El Paso International Airport 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '131', 31.805334, -106.382439, 'El Paso International Airport 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '132', 31.912289, -106.573288, '7640 Crest Creek Ln 7640 Crest Creek Ln, Canutillo, TX 79835, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '133', 31.836048, -106.565727, 'Walmart Supercenter 7555 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '134', 31.805334, -106.382439, 'El Paso International Airport 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '17', 34.152893, -118.448975, 'Domino''s Pizza, 4467 Van Nuys Blvd, Sherman Oaks, CA 91403, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '196', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '198', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '200', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '201', 29.531197, -98.468346, 'San Antonio International Airport 9800 Airport Blvd, San Antonio, TX 78216, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '210', 31.829082, -106.447067, '5631 Dyer St, El Paso, TX 79904, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '221', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '222', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '225', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '233', 21.204893, 72.840843, 'Surat Railway Station Station Road, Suryapur Gate, Varachha, Railway Station Area, Varachha, Surat, Gujarat 395003, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '237', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '238', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '24', 34.105061, -118.463203, 'Haines Obtains Ltd 1924 Roscomare Rd, Los Angeles, CA 90077, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '247', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '248', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '25', 21.150036, 72.761703, '(21.1500353, 72.7617048) ', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '267', 21.170240, 72.831062, 'shop,7 ,krishna com,modi mohollo a,k,road surat, Laxmi Nagar, Udhna, Surat, Gujarat 395008, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '27', 19.386772, -99.210098, 'Cto de la Unidad 33 Cto de la Unidad 33, Sta Fé IMSS, 01170 Ciudad de México, D.F., México', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '28', 34.152534, -118.453819, 'CVS Pharmacy, 14735 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '282', 21.146473, 72.759399, '18/2, Dumas Road, Rundh, Rundh, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '286', 21.147245, 72.762794, 'Near VR mall opp Vastu Luxuria, Udhana-Magdalla Rd, Piplod, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '287', 21.150949, 72.760376, 'Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '288', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '29', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '291', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '307', 21.167906, 72.834969, 'Samithi English & Gujarati Medium School S Zone Rd, Opp. Akshar Kunj Apartment, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '308', 21.168407, 72.834763, 'Shiv Shakti Apartment S Zone Rd, Samity School, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '317', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '319', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '323', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '325', 34.156895, -118.490967, 'Hilltop Cleaners 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '332', 34.156895, -118.490967, 'Hilltop Cleaners 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '333', 34.106117, -118.463875, '2001 Roscomare Rd 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '347', 65.967606, -18.530159, 'Dalvík Vegamót Cottages??????????? Dalvik, Iceland', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '35', 34.153294, -118.456673, 'Pavilions, 14845 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '36', 34.106052, -118.463676, '1954-1980 Roscomare Rd, 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '362', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '365', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '368', 21.148632, 72.760437, 'Audi Surat Plot No. 43, Moje Rundh, Near Rundhnath Mahadev Mandir, Surat Dumas Road, Choryasi, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '37', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '38', 34.106125, -118.463692, '1954-1980 Roscomare Rd, 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '388', 21.145103, 72.757027, 'VR Surat Dumas Road, Magdalla, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '390', 21.148567, 72.760490, 'Raj Palace Dumas Rd, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '40', 21.147446, 72.759575, 'Vastu Luxuria | Surat, Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '41', 21.147026, 72.759743, 'ASK-EHS Engineering & Consultants Pvt. Ltd., 214 to 217 | Luxuria Business Hub | Besides Dumas Resort | Dumas Road, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '42', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '43', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '44', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '45', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '46', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '47', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '49', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '51', 21.150087, 72.768715, 'Raghuvir Party Plot, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '53', 21.146473, 72.759399, 'Dumas Resorts Pvt Ltd 18/2, Dumas Road, Rundh, Rundh, New Magdalla, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '57', 31.760315, -106.488647, 'Coffee Box, 401 N Mesa St, El Paso, TX 79901, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '59', 34.157021, -118.490662, 'Hilltop Cleaners, 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '60', 34.157021, -118.490662, 'Hilltop Cleaners, 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '61', 34.157021, -118.490662, 'Hilltop Cleaners, 16422 Ventura Blvd, Encino, CA 91436, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '62', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '63', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '64', 31.825670, -106.523575, 'Cafe Grille, 5860 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '65', 31.825670, -106.523575, 'Cafe Grille, 5860 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '69', 31.760881, -106.488350, 'Downtown El Paso, 201 E Main St #107, El Paso, TX 79901, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '73', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '74', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '75', 34.151253, -118.454292, '14724 Ventura Blvd, 14724 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '76', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '77', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '78', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '1', 21.153954, 72.763397, 'Nidhi impotrade pvt ltd, New Magdalla, Surat, Gujarat, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '123', 34.106163, -118.463692, '1954-1980 Roscomare Rd 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '124', 34.107975, -118.463478, '2003 Roscomare Rd, 2003 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '130', 31.752808, -106.488701, 'Downtown Transit Ctr Bay #P United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '131', 31.760881, -106.488350, 'Downtown El Paso 201 E Main St #107, El Paso, TX 79901, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '132', 31.912127, -106.573792, '7637 Crest Creek Ln 7637 Crest Creek Ln, Canutillo, TX 79835, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '133', 31.834141, -106.560448, '200 Desert Pass St 200 Desert Pass St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '134', 31.841196, -106.591515, 'El Paso Country Club 5000 Country Club Pl, El Paso, TX 79922, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '17', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '196', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '198', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '200', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '201', 29.522495, -98.502075, '613 NW Loop 410 613 NW Loop 410, San Antonio, TX 78216, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '210', 31.834141, -106.560448, '200 Desert Pass St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '221', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '222', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '225', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '233', 21.145103, 72.757027, 'VR Surat Dumas Road, Magdalla, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '237', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '238', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '24', 34.106400, -118.465675, 'Brentwood Express 1978 Linda Flora Dr, Los Angeles, CA 90077, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '247', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '248', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '25', 21.147640, 72.765335, '(21.1476404, 72.7653356) ', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '267', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '27', 19.388283, -99.210121, 'Cto de la Unidad 5 Cto de la Unidad 5, Maria G. de García Ruiz, 01160 Ciudad de México, D.F., México', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '28', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '282', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '286', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '287', 0.000000, 0.000000, 'undefined', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '288', 21.149733, 72.759399, 'P R Khatiwala Vidya Sankul Subhash Nagar, New Magdalla, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '29', 34.151253, -118.454292, '14724 Ventura Blvd, 14724 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '291', 21.147245, 72.762794, 'HEERA MOTI Wedding Lawn Near VR mall opp Vastu Luxuria, Udhana-Magdalla Rd, Piplod, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '307', 21.168367, 72.835182, 'S E M High School Behind Postal Society,Udhna Gam, Gayatri Society - 2, Gayatri Society, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '308', 21.168459, 72.834564, 'Ramji Nagar Souh Zone Road, Near Samithi School, Udhana Village, Udhna, Surat, Gujarat 394210, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '317', 21.150949, 72.760376, 'C K Pithawala College Dumas Road Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '319', 21.150949, 72.760376, 'C K Pithawala College Dumas Road Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '323', 21.150415, 72.758652, 'S.B.R. Maheswari VidyaPeeth School Behind Rundnath Temple,, Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '325', 34.106117, -118.463875, '2001 Roscomare Rd 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '332', 34.106117, -118.463875, '2001 Roscomare Rd 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '333', 34.106159, -118.463524, '2002 Roscomare Rd 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '347', 65.967621, -18.532349, 'Fosshotel Dalvik Dalvik, Iceland', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '35', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '36', 34.161167, -118.510155, 'Bubbles Pet Spa Encino, 17301 Ventura Blvd, Encino, CA 91316, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '362', 21.147179, 72.759789, 'La Net Team Software Solutions Pvt. LTD. 405/406 Luxuria Business Hub, Near VR mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '365', 21.147026, 72.759743, 'ASK-EHS Engineering & Consultants Pvt. Ltd. 214 to 217 | Luxuria Business Hub | Besides Dumas Resort | Dumas Road, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '368', 21.148567, 72.760490, 'Raj Palace Dumas Rd, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '37', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '38', 34.106400, -118.465675, 'Brentwood Express, 1978 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '388', 21.147446, 72.759575, 'Vastu Luxuria | Surat Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '390', 21.147543, 72.759384, 'Garvi Films 611, Luxuria Business Hub, Beside Dumas Resort, Dumas Road, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '40', 21.151699, 72.762497, 'Empire Chevrolet, Plot No. 3, Dumas Road, Near Rangoli Hotel, Rundh, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '41', 21.147179, 72.759789, 'La Net Team Software Solutions Pvt. LTD., 405/406 Luxuria Business Hub, Near VR mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '42', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '43', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '44', 21.154350, 72.764778, 'Blaster Family Spot, Mall Gaurav Path,, Dumas Rd, Central Revenue Colony, Athwa, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '45', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '46', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '47', 21.154457, 72.764816, 'Gili, Mahrana Pratap Marg, Athwalines, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '49', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '51', 21.149622, 72.767448, 'DMD Party Plot, Piplod, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '53', 21.148399, 72.765404, 'Safal Square,UM Rd,Vesu Udhana-Magdalla Rd, Vesu, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '57', 31.895943, -106.575722, 'BizLink Technology, 1790 Commerce Park Dr, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '59', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '60', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '61', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '62', 33.985039, -118.390709, '6167 Bristol Pkwy, 6167 Bristol Pkwy, Culver City, CA 90230, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '63', 33.985039, -118.390709, '6167 Bristol Pkwy, 6167 Bristol Pkwy, Culver City, CA 90230, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '64', 31.833464, -106.536072, 'Julian''s Doggie Daycare & Boarding, 6330 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '65', 31.833464, -106.536072, 'Julian''s Doggie Daycare & Boarding, 6330 N Mesa St, El Paso, TX 79912, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '69', 31.805334, -106.382439, 'El Paso International Airport, 6701 Convair Rd, El Paso, TX 79925, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '73', 34.151821, -118.454262, '14742 Ventura Blvd, 14742 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '74', 34.151821, -118.454262, '14742 Ventura Blvd, 14742 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '75', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '76', 34.106876, -118.466980, 'Puerta Grande Productions, 2007 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '77', 34.106876, -118.466980, 'Puerta Grande Productions, 2007 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '78', 34.106876, -118.466980, 'Puerta Grande Productions, 2007 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '1', 21.136570, 72.751862, 'Players Sports & Cafe, Cityplus Multiplex Front Parking Lot, Surat Dumas Road, Near Opp L & T Colony, Magdalla Port Road, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '40', 21.141336, 72.754982, 'Mataji hardware, Gail Colony, Vesu, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '41', 21.147442, 72.759575, 'Om Meditronics Pvt. Ltd., 506, Vastu Luxuria, Near Dumas Resort, Near VR Mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '42', 21.154417, 72.764633, 'Central Mall, Opp. Valentine Multiplex, Surat - Dumas Road, Athwa, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '47', 21.154417, 72.764633, 'Central Mall, Opp. Valentine Multiplex, Surat - Dumas Road, Athwa, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`userId` bigint(20) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isEmailVerified` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=verified 0 = not verified ',
  `passcode` int(11) NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userProfile` varchar(255) NOT NULL,
  `deviceToken` varchar(255) NOT NULL,
  `deviceType` int(11) NOT NULL COMMENT '1 = android 0= IOS',
  `forgotRandom` int(11) NOT NULL,
  `userType` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 for user and 1 for admin',
  `changedEmail` varchar(255) NOT NULL,
  `changedMobile` varchar(255) NOT NULL,
  `isMobileverified` tinyint(4) NOT NULL,
  `mobilePasscode` int(11) NOT NULL,
  `isDeleted` int(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=346 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userId`, `firstName`, `lastName`, `email`, `mobile`, `password`, `isEmailVerified`, `passcode`, `createdDate`, `userProfile`, `deviceToken`, `deviceType`, `forgotRandom`, `userType`, `changedEmail`, `changedMobile`, `isMobileverified`, `mobilePasscode`, `isDeleted`) VALUES
(1, 'Tilak', 'Jethva', 'lanetteam.tilak@gmail.com', '9537624401', '28d8c1f075b6ccb6b8d6a530e7886bad', 1, 223440, '2016-05-13 11:42:23', '1463140084582.jpg', 'fs-T7YFmZM4:APA91bG_xQU4224jLDFTS-nJTox3Oi5UXYv3lpS4aBDwqWUSNP-DntzBThMy0SKNLnKq8jDmlqvsS8ZztNQQ0teaNIoQKuo-XyIQQEYj3aXILznVRi4CyHV1da49C0e2Q1yNfZe66kJ1', 1, 0, 0, '', '', 1, 366021, 0),
(2, 'Riken', 'Doshi', 'lanetteam.riken@gmail.com', '9913060874', '61c895e51d8b83de169b8f9a3fd45f82', 1, 396276, '2016-05-13 11:53:51', '1463140878975.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 641974, 0),
(3, 'Admin', 'Admin', 'admin@qapp.com', '', 'e6e061838856bf47e1de730719fb2609', 1, 223440, '2016-05-13 11:42:23', '1463140084582.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 1, '', '', 1, 311586, 0),
(4, 'Tapan', 'Gohil', 'lanetteam.tapan@gmail.com', '9898304401', '61c895e51d8b83de169b8f9a3fd45f82', 1, 994616, '2016-05-13 12:25:18', '1464696868232.jpg', 'dZXD52Bfj-Q:APA91bF1WOpY4FDP1N3PfBA8DhwVzV0gO0v38OjKh7005unvS5U7NL1G0QqwRtTp67y3gFFnQ6ge22wHo2IamJeMh64N1EmeeWpIQ0PbgtVITLyQfV0wT7UA-2rjB2CDK_FFdLJuvaiO', 1, 0, 0, '', '', 1, 707978, 0),
(5, 'Vimal', 'Gajera', 'lanetteam.vimalgajera@gmail.com', '9998078073', '61c895e51d8b83de169b8f9a3fd45f82', 1, 837844, '2016-05-13 12:51:50', '1466852327484.jpg', 'dZXD52Bfj-Q:APA91bF1WOpY4FDP1N3PfBA8DhwVzV0gO0v38OjKh7005unvS5U7NL1G0QqwRtTp67y3gFFnQ6ge22wHo2IamJeMh64N1EmeeWpIQ0PbgtVITLyQfV0wT7UA-2rjB2CDK_FFdLJuvaiO', 1, 0, 0, '', '', 1, 792848, 0),
(6, 'Felix', 'Odigie', 'felix@valdecapital.com', '6173881912', '8834751a888422b1835fe516cc2dbce8', 1, 102349, '2016-05-14 15:10:18', 'user-profile.png', 'fztKILuB0Ks:APA91bEBYSJKnMapew_-T6uMNykmI35xXgnbmpzKry_4imGjY3ArGqphXkKtC-d31BHWFAYZw8FIr3aWFUpnBHkWM82LTHKCH7Tpes3Alx_t6xfg8a7k2lgjjMBiGGXs_97UbBeKudEp', 1, 0, 0, '', '', 1, 699296, -1),
(7, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '8184658228', 'df574db6ddf358c9cf111b82c56a56fe', 1, 437133, '2016-05-15 00:24:24', '1464634891868.jpg', '3accd036208c70ed66fa1b5cc862b6e5edd62dcb86070da0ee2701168eabae56', 0, 753044, 0, 'kimberly.odigie@myqapp.com', '', 1, 149125, -1),
(9, 'Test', 'User', 'test@gmail.com', '9998078073', '10b8e822d03fb4fd946188e852a4c3e2', 0, 114006, '2016-05-18 11:27:39', 'user-profile.png', 'fy4rcoxZiP4:APA91bHAc0J3_EVO6etx6UhMEkfWfYKRvZFctodFGYy66WDTt4iFcLyGTjmz2v8Y_taT5Uy97G-v8SHhz8klr2UtVOM1zjZKpHkHAR-3BR8Uzabi2JltsfsSRQxDNyK0fSFkyVjkzOOW', 1, 0, 0, '', '', 0, 416426, -1),
(10, 'Demo', 'User', 'demo@qapp.com', '9998887770', '4ab4d4df1d2ea10d1f4d7a76d9a7a41f', 1, 636797, '2016-05-18 11:29:35', 'user-profile.png', 'b8bdd16a19a78c5e6a33d98958ea8bc94ef5249eaaa47761e8fbcdf553957e2d', 0, 0, 0, '', '', 1, 289355, -1),
(11, 'Fly', 'Flyerson', 'flyflyerson@gmail.com', '4088214398', 'f0b407b11a62acbfaa65400ce3310f04', 1, 997161, '2016-05-19 19:04:39', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 514664, 0),
(12, 'Cristian ', 'Try', 'lokinenuco@gmail.com', '9153556813', '84ec225c4e3396260a3a06449bec5405', 1, 338221, '2016-05-23 21:24:12', 'user-profile.png', 'fdlsbwWEYBs:APA91bFS1umeDo6B7VAXleg3DbP5HYBqLm9o0OBeDA82U345nqnHXRWM4FEan4wd79JznzyDoVUBOmneMtrilUQxkX2EfzoCgBSpuXNy7otUANObo7rv5omSNdV_Kgw1GIh9SDDNI1MJ', 1, 0, 0, 'criptoc@hotmail.com ', '', 1, 588823, 0),
(13, 'Deric', 'Mccloud', 'dericrmccloud@gmail.com', '13342210826', '71242207e00e31f69fc6ef71052e2ede', 1, 102562, '2016-05-28 03:18:13', 'user-profile.png', 'f3eekuv74bs:APA91bHmR7_02FB-a07Cmn7en996QJ3wbEXCSm3uK2UmjgPjVoDuxtU2Nw_img8xN2qC6mv1Y371L7VZ8MjTOXTNB79YojItmxtimkBXFWOguyl8lumXp6cYU5EhAtb5tFQCspuEFLDq', 1, 0, 0, '', '', 1, 115515, 0),
(14, 'Felix', 'Odigie', 'felix@myqapp.com', '6173881912', '2de5be3cf1cef0ad7d054ae0d231ce41', 0, 797199, '2016-05-29 04:04:39', '1464628686642.jpg', 'fztKILuB0Ks:APA91bEBYSJKnMapew_-T6uMNykmI35xXgnbmpzKry_4imGjY3ArGqphXkKtC-d31BHWFAYZw8FIr3aWFUpnBHkWM82LTHKCH7Tpes3Alx_t6xfg8a7k2lgjjMBiGGXs_97UbBeKudEp', 1, 0, 0, 'felix.odigie@gmail.com', '', 1, 845208, -1),
(15, 'Angela', 'Ciochetti', 'am.ciochetti@gmail.com', '8604178983', 'bf4cf71040f42715c4c709ba64a44ecb', 1, 353389, '2016-05-30 14:26:17', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 647736, 0),
(16, 'Felix', 'Odigie', 'felix.odigie@gmail.com', '6173881912', '2de5be3cf1cef0ad7d054ae0d231ce41', 1, 301756, '2016-05-30 17:25:01', '1466054826108.jpg', 'b9820a03e650f7b08fbc56c9acb075875cdf36e087e4fe9e6af0b8fb3031300f', 0, 0, 0, '', '', 1, 745696, 0),
(17, 'Kevin', 'Robinson', 'thomas77607@aol.com', '8185197366', '0dd4a23afa7412066c8e0b7eb1c375fe', 1, 239592, '2016-05-30 17:36:06', 'user-profile.png', 'dHmsoDeFcyY:APA91bGZ8nEHs69wfL2G82eMTXKPw8A_TpFmVG48ePVz6bCdlT6D1b-4fuVlwBboyB7fxpQq24_VcAzGQLm7NtDSQZ94WkejK1BEzXJuYLd6iJgY0e97LdCAfukev_GYibPrOfdJsmty', 1, 0, 0, '', '', 1, 571912, 0),
(18, 'Paulette', 'Simone', 'rapturre@gmail.com', '8189179171', '7c1b4ccf86e08fc7dcd7ea0662595362', 1, 187942, '2016-05-30 17:43:45', '1465077736480.jpg', '9efa2a9d2f0d61893b01b6eb83b1292100f88b23113adf2e27859ae24b1d5812', 0, 0, 0, '', '', 1, 812346, 0),
(22, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '9154746047', 'a2ffd2108b4d9153290c6a9dd3d53780', 1, 677408, '2016-06-01 16:08:36', 'user-profile.png', '6e68823f06cad38eefd7519db4f414eedfb7874b3218560aa67b056dcc0760af', 0, 998005, 0, '', '', 1, 475552, -1),
(23, 'Shivani', 'Chauhan', 'ldeveloperl1985@gmail.com', '9974072410', '12b0b8b5cbc7e56c5983bd0cf0434058', 0, 710662, '2016-06-03 11:24:21', 'user-profile.png', '1b3dace55fc1988720eeffd8ee0a58e0b1e608e6969fac9b565443e09bf6eaf8', 0, 0, 0, '', '', 0, 972593, 0),
(24, 'Derrick', 'Smith', 'iderricksmithjr@gmail.com', '2096403224', '577116b5bb1aa7e23b3ca8bda593a8be', 0, 779906, '2016-06-06 18:51:26', 'user-profile.png', '3a56cee42b656de01c2d2f612eb86726076c44d124ae9c0c4bf2a92075934019', 0, 0, 0, '', '', 0, 720221, 0),
(25, 'Ivan', 'Cerezo', 'ivan.cerezo28@gmail.com', '3234701069', 'f77cb029b236fa2d548e85629fbb1365', 1, 908984, '2016-06-06 22:45:40', 'user-profile.png', 'fmTcfX4p38A:APA91bHAqeAgy_jQ0carHqZFJTojt19GkIT8FtfqK5gYvYXV2c-gFg844rI3YdQj8qStdmWwbr75UsinDlv0y7G3wgly0AUGa__aTy6RkYj1ZvmQYq8zKY9brLXtXu_usm_sGhxMxU-0', 1, 0, 0, '', '', 1, 525646, 0),
(26, 'Erin', 'Wilber', 'forever4learning@yahoo.com', '3235433435', 'bf4dfad9e07bc1f5b3403dd737fb9f4a', 1, 135672, '2016-06-07 23:06:07', 'user-profile.png', '6e3714dee7436b73a992624638096d2e76899acb527cf01f6cd4c26695e490d8', 0, 0, 0, '', '', 1, 801138, 0),
(27, 'Rubot', 'H', 'vauxxer@gmail.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 1, 541412, '2016-06-07 23:39:38', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 901327, -1),
(28, 'Sajid', 'Ansari', 'sajidansari0605@gmail.com', '7069995161', '043ec7cfd1171ca3db4d38aeacd6212c', 1, 989434, '2016-06-08 10:51:42', 'user-profile.png', 'e2-XkYWhsZ8:APA91bFMBUNVWBL_H9iIHUKkqzsOWwwY8ZO9JKgep3_Dbc56SCQZUEB-NkkrGB-OGWCoSlb43I6v8DFqExCvM_SBWyuIHHtSTbDhWy8GsR6ODcHHBXd2qBTD8vjR6TNmGoT3Iresvzub', 1, 0, 0, '', '', 0, 514731, -1),
(29, 'Jessica', 'Walton', 'jesssicaalexine@gmail.com', '4705648397', '902160a36094e7cf3ff754d9f148993b', 0, 694235, '2016-06-08 16:46:53', '1465404688893.jpg', '068264385dde1b5cfdc37827e1e5b68930db08a3cdeb9a578f6bcb9771ab4d5a', 0, 0, 0, '', '', 0, 903714, 0),
(30, 'Kristeen', 'Washington', 'kristeen.washington@gmail.com', '7078535100', '9ebad9205830ba554757e715ca94c788', 1, 114397, '2016-06-08 19:43:51', 'user-profile.png', '1a80e15c979bfc2a7c6a99e4a19762777f75d5774f4679fd7c150910c4c05b24', 0, 0, 0, '', '', 1, 994338, 0),
(31, 'Fanny', 'Lin', 'fannylinnn@gmail.com', '19178856565', '08bfcdcd64bdb4f99e7657c85ca96e9e', 0, 976998, '2016-06-08 19:51:04', 'user-profile.png', '47a55523b1fa27b79be020e036189db4758e7fd26e7fadeb11179872da6642db', 0, 0, 0, '', '', 0, 564688, 0),
(32, 'Kimberly', 'Odigai', 'kimberly.odiag@gmail.com', '2038849349', '1bfa5ad9b6df629b5115bf6a50693960', 0, 594534, '2016-06-08 20:21:12', 'user-profile.png', 'dgV3ek707-0:APA91bHrlZ3M4TFBzUuE1dYd0uiEpw25iW69sEOKr43yBdcjsS_Y8FmhKVJpmfg7FrLPZ0qtvzt4umqkBDbidI7NuvZg0GLSGRipeDyGvU9nvwLwgE_CzlNAcST3K7LVhgSQhrAnWUJo', 1, 0, 0, '', '', 0, 454969, -1),
(33, 'Ruben', 'Dev', 'ruben.h.dev@gmail.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 1, 246191, '2016-06-08 20:30:42', 'user-profile.png', '6e68823f06cad38eefd7519db4f414eedfb7874b3218560aa67b056dcc0760af', 0, 0, 0, '', '', 1, 822700, -1),
(34, 'Ruben', 'Tester', 'ruben.h.hpe@gmail.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 0, 485203, '2016-06-08 20:44:15', 'user-profile.png', '777949bc8e6a3de0ebc2ecd368f03654a716957dc8e31f37223101d40a12a000', 0, 0, 0, '', '', 0, 923696, 0),
(35, 'Rub', 'Hern', 'jrhernandez2@miners.utep.edu', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 1, 485162, '2016-06-08 20:49:13', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 579924, -1),
(36, 'Judi', 'Figueroa', 'figueroaissa@yahoo.com', '3868820792', 'd701c916fa2cbb96dd4205fb804cd501', 1, 819861, '2016-06-08 21:49:50', 'user-profile.png', 'e7bc6UWjsVQ:APA91bFEM_yqaEPNjFiVaErESyt_QGelx6GmYifX3w0pUB5Yk7bILCy7VBn_5URsfHJDxSuKVQtu4M1284DnZBeuYw8jTmHuMX8u4rh_rXPjB8APsEbFutFMpnjyxbmKqZH9vkDuy14b', 1, 0, 0, '', '', 1, 267066, 0),
(37, 'Rachel', 'Fulgencio', 'rfulgencio@outlook.com', '6175050713', 'e969c2fd37eb593150db6e34c723a99b', 1, 783091, '2016-06-08 23:30:25', '1465827013992.jpg', '1c6c6082dc79280a588ec392761168e1f1d079779a013c1584bd31e026fb8b7c', 0, 0, 0, '', '', 1, 389678, 0),
(38, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '8184658228', 'df574db6ddf358c9cf111b82c56a56fe', 1, 989849, '2016-06-09 04:32:55', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 417914, 0, '', '', 1, 891993, -1),
(39, 'Tapan', 'Gohil', 'tapanmyid@gmail.com', '9998078073', '61c895e51d8b83de169b8f9a3fd45f82', 0, 366440, '2016-06-09 07:01:21', 'user-profile.png', 'cLAqmD11_1A:APA91bFYcBqB6f3zD6Zox1FJHF5vIALaiYrzqkV9TKMAJ3EAylf1ysSz8NtGJJvptEImlxHwuIRzITCX5jOUR5K2f4w1GLuUF6mUwhazSBuWG5bjan0cqs-CLNH4xiKB26W_B27tvi_u', 1, 0, 0, '', '', 0, 720472, 0),
(40, 'Abc', 'Test', 'abc@gmail.com', '99998880', '61c895e51d8b83de169b8f9a3fd45f82', 0, 946520, '2016-06-09 07:28:11', 'user-profile.png', 'e2-XkYWhsZ8:APA91bFMBUNVWBL_H9iIHUKkqzsOWwwY8ZO9JKgep3_Dbc56SCQZUEB-NkkrGB-OGWCoSlb43I6v8DFqExCvM_SBWyuIHHtSTbDhWy8GsR6ODcHHBXd2qBTD8vjR6TNmGoT3Iresvzub', 1, 0, 0, '', '', 0, 685449, -1),
(41, 'New', 'User', 'testuserandroid@gmail.com', '1234567890', '61c895e51d8b83de169b8f9a3fd45f82', 0, 748176, '2016-06-09 07:58:57', 'user-profile.png', 'e2-XkYWhsZ8:APA91bFMBUNVWBL_H9iIHUKkqzsOWwwY8ZO9JKgep3_Dbc56SCQZUEB-NkkrGB-OGWCoSlb43I6v8DFqExCvM_SBWyuIHHtSTbDhWy8GsR6ODcHHBXd2qBTD8vjR6TNmGoT3Iresvzub', 1, 0, 0, '', '', 0, 367523, 0),
(42, 'Tyneshia', 'Stephenson', 'tyneshiastephenson@gmail.com', '6176026526', 'e2740ad0c1decfd8c1dbea501d9d56de', 0, 710398, '2016-06-09 18:20:58', 'user-profile.png', '36b6942d397995c0372bb396a88e6fd0de0874078179cb2a7bbfa142bee39b4c', 0, 0, 0, '', '', 0, 261336, 0),
(43, 'Foluke', 'Arogundade', 'folukearogundade@yahoo.com', '6785239128', 'aeb49d49c5cf884696609500463b90cd', 0, 685164, '2016-06-09 18:43:16', 'user-profile.png', 'e8995593849189b5b90f3a1d26c8f015b535ce9ddf1379d75cdfdb9e8a2a625f', 0, 851506, 0, '', '', 0, 383337, 0),
(44, 'Vanessa', 'Jean Louis', 'vanessa19jl91@gmail.com', '6174129581', 'bfaccb780c5f1a2da59b82228233b9b7', 1, 337429, '2016-06-09 19:51:41', '1465502403381.jpg', 'elvxbc5czYU:APA91bGY0BzzzsUQ-0WYM7C5FNwxe76TTZbwTI8uV7vefAMa5fbczpsFZyZUkaDaOwn8dqkxpHxkpe4bnTmGAr3P-5RLhBsTFsWUjjalGx-9BP7aJLma3NSwqEBr6Td2RLvGyOndLy5K', 1, 0, 0, '', '', 1, 989323, 0),
(45, 'Kiron', 'Harper', 'KOHARPER92@gmail.com', '9543973616', '99534a548a518de27789aa76c7154e9a', 0, 505602, '2016-06-09 21:55:44', 'user-profile.png', 'c7f435bde1b6b3226929d3cfb3710caa3fa3516be88a7b2997bc7b6c7edcc84b', 0, 0, 0, '', '', 0, 734969, 0),
(46, 'Ruben', 'Her', 'je@gh.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 0, 903193, '2016-06-09 22:58:23', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 147204, -1),
(47, 'Kimberly', 'Idoko', 'kimberly@myqapp.com', '2038879349', 'df574db6ddf358c9cf111b82c56a56fe', 0, 536322, '2016-06-09 23:27:11', 'user-profile.png', 'ddcb406d04bd741fe9c172726aa1fd3408a5cd334190679bee8fb5f9e02496a2', 0, 0, 0, '', '', 0, 778186, -1),
(48, 'Katie', 'Toups', 'katietoups@gmail.com', '9177537604', 'c58c38cec979cf154411aca32051c382', 1, 863104, '2016-06-09 23:46:08', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 877637, 0),
(49, 'Phoeniix', 'James', 'phoeniix.james@gmail.com', '8189833739', '147a7ff017b2cc99d5452779a4caf92b', 1, 294061, '2016-06-10 03:05:16', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 222978, 0),
(50, 'Sophia', 'Nairima', 'nairimah@yahoo.com', '8183107143', '3c0afaec28c52b65f4844d89f36cc2d2', 1, 423946, '2016-06-10 03:06:35', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 765545, 0),
(51, 'Kimberly', 'Idoko', 'dr.idoko@primeneurology.com', '8184658228', 'df574db6ddf358c9cf111b82c56a56fe', 1, 565046, '2016-06-10 03:14:33', 'user-profile.png', 'ddcb406d04bd741fe9c172726aa1fd3408a5cd334190679bee8fb5f9e02496a2', 0, 0, 0, '', '', 1, 498259, -1),
(52, 'Kimberly', 'Odigie', 'kimberly@theqnowapp.com', '8184658228', 'df574db6ddf358c9cf111b82c56a56fe', 0, 865675, '2016-06-10 16:25:36', 'user-profile.png', 'ddcb406d04bd741fe9c172726aa1fd3408a5cd334190679bee8fb5f9e02496a2', 0, 0, 0, '', '', 0, 479003, -1),
(53, 'Jesse', 'Ferguson', 'j.ferguson1@lafilm.edu', '4236939242', 'a6d70938c97dc5078eb1715131c9892e', 0, 208829, '2016-06-10 17:14:34', 'user-profile.png', '1e04f5bfc7e30fc6e595cc616a797b3e5f6eb99310123ebfad26acdbadd95e18', 0, 0, 0, '', '', 0, 958115, 0),
(54, 'Vanice', 'Simpson', 's.vanice@ymail.com', '9548026914', '6bcd40286f36ca2f3dec0f261f4c8ab0', 1, 514076, '2016-06-10 18:09:14', 'user-profile.png', '6214b866cb5dabe41b414773a0370a94040487e2a778d0376fa1cdb9107d7b15', 0, 0, 0, '', '', 1, 132591, -1),
(55, 'Fati', 'Haruna', 'haruna.fati@gmail.com', '6463398454', '300947e2ffefaa83b2ff025feb68df14', 1, 572351, '2016-06-10 18:58:40', 'user-profile.png', '37fa6451be0a0de75e9a4d436fd938bff44d7d70150fa41278cbfe5fda0f0e7d', 0, 0, 0, '', '', 1, 107011, 0),
(56, 'Richard', 'Sherlock', 'richard77sherlock@gmail.com', '9092243168', '8b781641182c542e13793733e12fa677', 1, 840069, '2016-06-10 19:22:14', '1465587120048.jpg', 'f4da13e64da29be65701bffd7577759927bf046788a880cfc9414548392ba17b', 0, 0, 0, '', '', 1, 957850, 0),
(57, 'Kiah', 'Cronin', 'kiah.cronin@yahoo.com', '8145746755', '2ebe7d23474c57e1f62e1bb1c4030f86', 1, 882093, '2016-06-10 22:49:51', 'user-profile.png', 'e36457f1dc302dbee7a220b330c14e36813e529bff87f74dd0056699466c5597', 0, 0, 0, '', '', 1, 613925, 0),
(58, 'Kimberly', 'Odigie', 'kimberly@continuitycall.com', '2038879349', 'df574db6ddf358c9cf111b82c56a56fe', 0, 423927, '2016-06-10 23:36:32', 'user-profile.png', 'a27039c201ba41689160df3f81892591469a8f0f48e3f880cd6931922bc9bef9', 0, 0, 0, '', '', 0, 849587, -1),
(59, 'Raven', 'David', 'rdavid_18@yahoo.com', '9293925629', 'de4ef36ad2de26f23427affad0d2ed90', 0, 348516, '2016-06-11 00:26:25', '1465605149786.jpg', 'ae7372609ca7a147c1d2e9c936bde454ae8c399c10e99202e3b5c473887c3de6', 0, 0, 0, '', '', 0, 164889, 0),
(60, 'Martine', 'Koenigsberger', 'mpk6@caa.columbia.edu', '9174464792', 'edb32c16730802c053f72d0b48e0e575', 0, 739671, '2016-06-13 06:04:13', 'user-profile.png', '40ceac9f5b30c770f2b97b637a2db3660bb95e3391ff89a6862c900e40cbc06f', 0, 0, 0, '', '', 0, 668506, 0),
(61, 'Salim', 'Diakite', 'sdiakite16@yahoo.com', '3478216504', 'fb18409be66887653e44706b72229b7b', 0, 475995, '2016-06-13 08:20:35', 'user-profile.png', 'b51c8380fa3621acbe193159e31239149f4991c32e25c05d268debdbb8ab1e51', 0, 0, 0, '', '', 0, 412681, 0),
(62, 'Theresa', 'Avila', 'tmavila2@gmail.com', '9174002843', 'a15e0c734973d4a6b70e200bba806a4b', 1, 899834, '2016-06-13 14:55:25', 'user-profile.png', 'bcd66382622b174ececeb0d594d9d4c5bec2d53ba9788c8e084f7b5a47969bb7', 0, 0, 0, '', '', 1, 605221, 0),
(63, 'Denise', 'Decicco', 'denisedec424@gmail.com', '5082467666', 'f78a88b1be0efca17ef0b6c7ee6bfa21', 0, 674114, '2016-06-13 15:18:32', 'user-profile.png', 'bb6fdfa602c61ba2cbf6a5e45b3c4b915ebf20d5e68d7058c572f8267700696a', 0, 0, 0, '', '', 0, 754473, 0),
(64, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', '7817312269', '1eb3ee08f69eff7609a2512c498c170e', 0, 799503, '2016-06-13 15:27:27', 'user-profile.png', '38df8b5f43f8c4e36913c9f5b729b7e7dad86865252519588c4f5c3f1bc85aed', 0, 0, 0, '', '', 0, 188912, -1),
(65, 'Natasha', 'Diaz', 'natashadiaz41@gmail.com', '7817312269', '1eb3ee08f69eff7609a2512c498c170e', 1, 908422, '2016-06-13 16:15:42', 'user-profile.png', '219eccfe5224305858d751b3510e48c82d2198baf4fe14cb52d39988dc57be95', 0, 0, 0, '', '', 1, 127768, 0),
(66, 'Rebekah', 'Pelzel', 'rebekahpelzel@gmail.com', '5756404303', '0dd085c3d6d2797864081381ba0df5a8', 1, 899057, '2016-06-13 18:09:23', 'user-profile.png', '7d205fca05dd1dfd2da57a057fd1f13f932bf62b8247acca34fcf9bf9d41c032', 0, 0, 0, '', '', 1, 659117, 0),
(67, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 1, 403991, '2016-06-13 20:45:44', 'user-profile.png', '741b9bc3cedad0bdda701e75108da16836d703a088236957b4db726401dd0342', 0, 998005, 0, '', '', 1, 591663, 0),
(68, 'Seth', 'Sharbono', 'sethsharb@gmail.com', '3202491523', 'dcdb42a18544b8e94a9754f7c43a8a97', 0, 645129, '2016-06-13 21:39:01', 'user-profile.png', '6f0ec751b8c1711b3be6c3f0147a652952d3d4d863226dcb767d7a45da0667b2', 0, 0, 0, '', '', 1, 578998, 0),
(69, 'Nerishka', 'Jeanty', 'Nerishkaj@icloud.com', '3474099134', '14c7d413104b7ed291afd48aac4cd87f', 0, 899428, '2016-06-13 23:14:49', 'user-profile.png', 'd4eac9134e7fd956cebf61ec9128b98a5ed3e776a687ae8c0bda3cb6c6033cca', 0, 0, 0, '', '', 0, 120896, 0),
(70, 'Bianca', 'Latham', 'balatham@ymail.com', '3107437584', '2a8c79ac28f7779dfc272001c2ad6e24', 1, 248444, '2016-06-14 00:51:56', '1465866875786.jpg', 'cheVh3kFDM4:APA91bEh5_eqPiLC9t_gRcdXqAPnml9RTGcWyGoJTXRnHqSqexjmegALrzEimIMLQ0qcoKvlCHZ9XXo98EiLHbif5w8Z70KP_6GvAwT-G9vyDg_oJGc3jorTwHkJtIPqTIGvudQPTLW_', 1, 0, 0, '', '', 1, 110086, 0),
(71, 'Richard', 'Ramirez', 'richardramirez5@hotmail.com', '3476912171', '5817e25cef053c4a752ec149b127cb98', 0, 118584, '2016-06-14 01:53:09', 'user-profile.png', 'a715329bb0f654afe211311cb1394fe40021a74323a7a1c25f1cdc7856971842', 0, 0, 0, '', '', 0, 412778, 0),
(72, 'Ruben', 'Hernandez', 'vauxxer@gamil.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 0, 377676, '2016-06-14 06:36:53', 'user-profile.png', '6e68823f06cad38eefd7519db4f414eedfb7874b3218560aa67b056dcc0760af', 0, 0, 0, '', '', 0, 360714, -1),
(73, 'Ruben', 'Hernandez', 'ruben.h.dev@gmail.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 1, 421330, '2016-06-14 06:40:40', 'user-profile.png', 'daUSFGJi9Ro:APA91bHvePrtSlairXbhHL8pJYF7IDo8xNCKgYoU6gxLlB7kX0tvmVnkEWo8DZtByYngfl66cDvzjS1JbOQLnRkRuU269I6o5-F6hTzpARwrv7BzE-9UawDJ5CzR1QqFse4opfe4037Q', 1, 0, 0, '', '', 1, 442633, 0),
(74, 'Michelle', 'Barrionuevomazzini', 'mbmazzini@me.com', '4157061677', 'fa0ba0e4620942de0efcd83f6109841f', 0, 202230, '2016-06-14 07:44:20', '1465890378013.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 329477, 0),
(76, 'Tori', 'Uvaas', 'toriuvaas@gmail.com', '5624479004', '612c93f4daa36aff8882614783ffadaa', 0, 200299, '2016-06-14 16:08:10', 'user-profile.png', '423d6156777fd54ab871881f606a4b105b1993cbd3c283fee468db051b65bb1f', 0, 0, 0, '', '', 0, 357014, 0),
(77, 'Alexandra', 'Arruda', 'alexarrruda@gmail.com', '7742949489', '108ecdedcfb2d62f58a39f14f0511f50', 0, 399568, '2016-06-14 17:04:35', 'user-profile.png', 'de74bb0c693c0c0602dd37ff0d9632a5f1a66b683c4f80704bc6951a2ce6c35a', 0, 0, 0, '', '', 0, 255557, 0),
(78, 'Courtney', 'Siwek', 'csiwek13@gmail.com', '4196109863', '4474b0ae07af672d6476fa0c503d617c', 1, 593365, '2016-06-14 17:13:16', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 674641, 0),
(79, 'Ruben', 'H', 'jrhernandez@gami.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 0, 575991, '2016-06-14 18:13:54', 'user-profile.png', 'daUSFGJi9Ro:APA91bHvePrtSlairXbhHL8pJYF7IDo8xNCKgYoU6gxLlB7kX0tvmVnkEWo8DZtByYngfl66cDvzjS1JbOQLnRkRuU269I6o5-F6hTzpARwrv7BzE-9UawDJ5CzR1QqFse4opfe4037Q', 1, 0, 0, '', '', 0, 851384, -1),
(80, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '8184658228', 'df574db6ddf358c9cf111b82c56a56fe', 1, 716816, '2016-06-14 18:16:18', 'user-profile.png', 'a27039c201ba41689160df3f81892591469a8f0f48e3f880cd6931922bc9bef9', 0, 417914, 0, '', '', 1, 650657, -1),
(81, 'Ruebn', 'H', 'jejd@hdjd.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 0, 741461, '2016-06-14 18:16:40', 'user-profile.png', 'daUSFGJi9Ro:APA91bHvePrtSlairXbhHL8pJYF7IDo8xNCKgYoU6gxLlB7kX0tvmVnkEWo8DZtByYngfl66cDvzjS1JbOQLnRkRuU269I6o5-F6hTzpARwrv7BzE-9UawDJ5CzR1QqFse4opfe4037Q', 1, 0, 0, '', '', 0, 311713, 0),
(82, 'Deandra', 'Egusquiza', 'deandraelise@yahoo.com', '9085149546', 'a30c0e8fa3f8130c1792387f97a61a07', 0, 594810, '2016-06-14 18:22:40', '1465929016928.jpg', 'a5b5d7a6200cb8ae7027b4e017875dba5278fb4e23136f13d382f51fb14631e8', 0, 0, 0, '', '', 0, 766012, 0),
(83, 'Aliza', 'Greenstein', 'lizadancesandswims@gmail.com', '5085051534', '2869a8b24f59d98ebadd9df290b20562', 0, 866202, '2016-06-14 23:09:57', 'user-profile.png', 'f24d54f28821e8d638a9a91e602e8b2d48df56a5b42a9918e250277a4bf6570a', 0, 0, 0, '', '', 0, 522440, -1),
(84, 'Helena', 'Cohen', 'helenacohee@gmail.com', '3235612620', '30014720704fbddd1d11ad7465932c8f', 0, 649295, '2016-06-14 23:10:10', 'user-profile.png', 'd31f5ac4cb318c0ce4d88af7caec8f7771d4d9ff7570b9e18c09cd5799826622', 0, 0, 0, '', '', 0, 116551, 0),
(85, 'Imani Shadae', 'James', 'imanis.ajames@gmail.com', '7189159713', '56c671163266c39f69714ef319ca58cc', 1, 212322, '2016-06-14 23:21:21', 'user-profile.png', 'dLPeDk8i5m0:APA91bEWhqFg5G0ebnZHrftsQO2Wtuefoh7CqGLdibwLlsDvT1YQwbK5g63NsI_Q4xu-xooCgUFSV85_IZYBrRvCD2-wHz-8tp26MPrpCsZ0EbzKr4NP-2I6rE9ujVDtx_oU7QWY9giB', 1, 0, 0, '', '', 1, 933789, 0),
(86, 'Lissette', 'Gomez', 'lisyvictoria@hotmail.com', '5083950641', '029bbc93dd22d4d26c9fdcb5f69d95ad', 1, 514387, '2016-06-14 23:57:20', 'user-profile.png', 'd45OfxmErRM:APA91bG4IHHPxEfNpblByXDxHE6gflpDw-V0Qzopp6qKTe0tB_cKW5OZZJLkoTfEkF_MXN_Fxe33a4gYEFNYb6cbrri-GiphJhagxjvtyS4SE0xD1l1Bf5zVbqHklvunomfAWiBPLd0V', 1, 0, 0, '', '', 1, 367522, 0),
(87, 'Michele', 'Brown', 'm_brown18@yahoo.com', '7604152638', '672fe4d8712e12ff4e945d27ba915d97', 0, 725998, '2016-06-15 00:01:46', '1465949035235.jpg', '5a8a57dd7e04fb300c44184acd4453a364bf140e7582c92e664f87934efe1d12', 0, 0, 0, '', '', 1, 141642, 0),
(88, 'Andrew', 'Neal', 'andrewxxneal@gmail.com', '7146252326', 'ca9b1c2f1e17e7c3e1626d38f635547a', 0, 162031, '2016-06-15 03:01:13', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 434312, 0),
(89, 'Drayton ', 'Hiers', 'drayton.a.hiers@gmail.com', '9172028396', '1297520bc0f5c7f47130298fdce52f7d', 1, 782845, '2016-06-15 03:02:18', 'user-profile.png', 'cuKCzlwEmjs:APA91bF_E9sr10L2J3zjcX6JAlERAwfKa_Ayx3zreilnGnyLTjW50owrdbiTo_TTYxiRedm3rEAwHLB6AtTgCb2sCpRARILASJ5gSUfcPSjL4mnBoZtSLxD2rz0mA51FXTqWvFO5pyPH', 1, 0, 0, '', '', 1, 747969, 0),
(90, 'Chantell', 'Lawson', 'chantellandreina@yahoo.com', '6786126696', '33b85a74340722914e97e61f3d78e1ac', 0, 370915, '2016-06-15 06:16:35', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 733604, 0),
(91, 'Shermayne', 'Butts', 'sheabee09@gmail.com', '9312167534', '4d7636f9072b1e2aa1dbed5103a97858', 0, 642331, '2016-06-15 07:56:10', '1465977659701.jpg', 'cf66facf9cb9033c7db14e3a5105eaf82fbcf68958836b133b2ab2c7f5a05e1c', 0, 0, 0, '', '', 0, 955522, 0),
(92, 'Kyandra', 'Richardson', 'kyandra919@gmail.com', '3475819741', 'c3026f34d4bd3da4531dc36a277b0d6c', 0, 930832, '2016-06-15 10:33:47', 'user-profile.png', '88972ef77353f415759245d0ae0e2cc17c2b7bbd3fd3c820ab1e1df3c1e598d6', 0, 0, 0, '', '', 0, 654873, 0),
(93, 'Zelmia', 'Harvey', 'kimera.draven@gmail.com', '7815100227', '2215874af59047ca5d4648d25923863d', 0, 497746, '2016-06-15 12:57:36', '1465998689387.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 632369, 0),
(94, 'Jasmin', 'Rodriguez', 'jasminvrodriguez@outlook.com', '3472170160', 'd5dba5830e0f61acf8df491e84cc7bfd', 1, 670284, '2016-06-15 16:29:12', 'user-profile.png', '658088d2864e421e7b23aaea239d0056dea589d1c05ed0784cda336839ffae1c', 0, 0, 0, '', '', 1, 295883, 0),
(95, 'Ashley', 'Dibson', 'ashley.62497@gmail.com', '9178612391', '959840d40fea2340e08c2b9bbc556ccf', 0, 346094, '2016-06-15 16:56:52', 'user-profile.png', '20bfe0ec59f63abd8890b138a4dc10bc780d859de8eef52165a54429b4ac6d99', 0, 0, 0, '', '', 0, 512185, 0),
(96, 'Jonathan', 'Shelton', 'jshelton85@gmail.com', '2132801920', 'f4e87f33c4a1c79483d112be63d96210', 1, 622349, '2016-06-15 16:59:57', '1466010599418.jpg', 'e3fP94IFjbA:APA91bHbymGwc5-SZuUGCLsDKF-JQyshMEkoj3ORoT_ab8zFSUJ5sFvGvnSTJQLTLPwqeJly5f0QIEhyxiIfkDmnM6fEEZNeBDLz86CAk0_oDZ0c7gJfIZ_SsRdFPWXToYNMTtU5tG1c', 1, 0, 0, '', '', 1, 862862, 0),
(97, 'Kary', 'Hudson', 'Karyh92@gmail.com', '9177547685', '50ebf6ec410cabeea15254e719482dbf', 1, 402785, '2016-06-15 21:15:56', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 831471, 0),
(98, 'Catherine', 'Pena', 'cpena100@gmail.com', '9176560076', '85ca9188d3115ea79dae4eebad5e7b93', 1, 298398, '2016-06-16 00:12:22', 'user-profile.png', '19e79c597c98598b216bb9263af2c6a2c29fda90b1247297a4dd2bcc75dfece0', 0, 0, 0, '', '', 1, 787770, 0),
(99, 'Lisa', 'Willis', 'michell_willis64@yahoo.com', '4242326790', 'eedccd4fa5a1f61f3b5dc2e3c1a595db', 1, 747778, '2016-06-16 00:43:49', 'user-profile.png', 'cItFUqgbvVY:APA91bE1qg_Hysr_imMSd2_udFL0ReHQycb76hqcp3t_mBKaHN17y52k-qXBbKmpICznHYmDUFPDERsy8p6xx2Xs5bi_IklfWEpihDQoxcWVd4mRMdyJRFvs4e3gpMse7Y6d89ejrO0R', 1, 0, 0, '', '', 1, 593369, 0),
(100, 'Jeff', 'Lazelle', 'jefflazelle@gmail.com', '3235921641', '2c34354f3de608cad1fd31eb55fad18c', 1, 474501, '2016-06-16 00:51:25', 'user-profile.png', 'fzHRxMxrflA:APA91bH47cDWxOCBv57uTEBGMx4EJmDpbNUnLQhyTFv3o_eJifuTVgRj9uD7ygb_JbhapqKknoV-eM69ubxigvYRE45GmbjkScVD6VInpW7koQdSJ_eexXwbeuTlu-zFB0vBnzwNpXDu', 1, 0, 0, '', '', 1, 847890, 0),
(101, 'Melissa', 'DeJesus', 'sweetie081402@gmail.com', '6464108525', '5d83ec28bce158cbb2aec3bf987019a4', 1, 366418, '2016-06-16 02:14:43', 'user-profile.png', 'fciH0X1JY2I:APA91bEAd5Ry3Kh-acrDxtWrdnomsNXMV5ew0AFWbuLW6NBmrl_pDxxhbCHVeBnT0vKZBvaTPtVUwOU_ln3e9NTlbtsn755Hffr83f8mF1h2jgGZNTlUvtGvMrgKiTcju2bHrSBg6bKE', 1, 0, 0, '', '', 1, 552595, 0),
(102, 'Paulina', 'Tamayo', 'paulinaadrian917@yahoo.com', '5624517983', '9cf9a96aac2c4035816e31a9a949e315', 1, 413182, '2016-06-16 02:26:56', 'user-profile.png', '67e6fab9d4a3f4fdb988deddd4aae842d9431dfd310a277bd9332167f49bfb5d', 0, 0, 0, '', '', 1, 807112, 0),
(103, 'Nicholas', 'Kasule', 'kasule23n@gmail.com', '4242139725', '9db69595743687bc30931f65b76435a2', 1, 105996, '2016-06-16 03:47:07', '1466050052377.jpg', '0cfb56603c4bf2b95f3c9b898cd08551b30faa79880e1ee8d1226bcb4827f27f', 0, 0, 0, '', '', 1, 992338, 0),
(104, 'Maria', 'Caraballo', 'aradia097@gmail.com', '3475206899', '82334576c009c3d4769c5b1fc08f168e', 1, 799226, '2016-06-16 07:38:10', 'user-profile.png', 'cFJo7jJLoXo:APA91bFrroBhHbVFjsTrSjCsso-vFfLxPRCaqBHGrCryBOc2OoKIoDjoFcrbiwm1bid6lAzYFdKAYyVj2K4Ig3pVOcw2ooO8LhAhebZ_7YKpt7mDVXQUrwTH00Lzb7N6Dwk3zEVfQ-0o', 1, 0, 0, '', '', 1, 217686, 0),
(105, 'Bijal', 'Tailor', 'lanetteam.bijal@gmail.com', '9876543210', '61c895e51d8b83de169b8f9a3fd45f82', 1, 451271, '2016-06-16 08:10:20', 'user-profile.png', 'dg2_OGyDN-E:APA91bGsoxfXIvo7GsA--l1OI7waFfKI61WgTO0ccKT7v3q6za0qqy-o4Kj6STSvjIXGTp-dQiRGeRp544AYTKJWbeIgP3Vx0nSg_G8kMxLyWWrdx0k6b9lJbAiR7SZezndcc67c9O27', 1, 0, 0, '', '', 0, 131146, 0),
(106, 'Tyechia', 'Spann', 'tyspann82@yahoo.com', '4042002525', '33f45ff606db3afc98a7d4db1b9012db', 1, 413927, '2016-06-16 08:23:32', 'user-profile.png', 'eJdrDqzVits:APA91bHN8lHVxcWQ6rsHu2dxEpNTch-1dXNiTbNx361ebxR5yRANCC60HHAYVfip0p6Qc1jGA4oLk18XBTdbw5vSywEYqHxAdVFDGrivhpHu8ZIQ_h6hAal_FSiIc__D4llURPwmuQFx', 1, 0, 0, '', '', 1, 590487, -1),
(107, 'Nathan', 'Fisher', 'nateafisher@gmail.com', '3236202111', '5f8392d1d4986e13d63aea687c3344e0', 1, 897436, '2016-06-16 10:08:04', 'user-profile.png', '05bca0668cf31b3ede799d05f455113775eccfba6ca8dc1535fa4346b98ba6a9', 0, 0, 0, '', '', 1, 247367, 0),
(108, 'Victoria', 'Graham', 'jvgraham2014@gmail.com', '6787554500', '0c40dd232bf84c26a909cbafa99093ab', 1, 588010, '2016-06-16 12:20:34', 'user-profile.png', 'dv9vUbADXSs:APA91bEcv3e2RM-Qr4xe8BC4kK0v034-_lMNqLWlBQdvFr4j30GVdDiyuEwPzxEpvkyRE3GLMCMnGQgti5Im6i44lThFBEQaOdcu4ByTS7BHhuNgPs8dWBu1Gjbrts85vY7QeDaC8FmB', 1, 0, 0, '', '', 1, 804396, 0),
(109, 'Ciera', 'Crossling', 'cieracrossling@gmail.com', '4437864318', '7f092f9a4c504952e8cce629491577d0', 1, 369708, '2016-06-16 14:46:20', 'user-profile.png', 'ab315eadc1344f51035a2df368c3d0fd3ec103643ffb1f703142b27ecc0f91ab', 0, 0, 0, '', '', 1, 267118, 0),
(110, 'Whitney', 'Pensinger', 'whitneypensinger@gmail.com', '6179453117', '00c4503d23f42188f0779b9a00727194', 1, 469182, '2016-06-16 15:09:53', 'user-profile.png', 'cEkgXidSD1M:APA91bGhBeKqziiNpC6oxH4KVw9k8t5wZ0kVbLqIt37r61a7Tz7uB4ugZqSoK_ZBSNTffKrkQ1VNk3YM37n3GdRIT8XMkrLA7GJwyaZA2Oil-JOClWwi-YH0CeM094HDl0RsY0WITrQD', 1, 0, 0, '', '', 1, 217161, 0),
(111, 'Christine', 'Thomas', 'kristine318@me.com', '6788365439', '05f9e93d3ab52cefc4c249d2ac349d30', 1, 962558, '2016-06-16 15:39:27', '1466166985020.jpg', '9d3028d055c217c3cceed1f98efd273dbfa56e48435eeb4c5fca71cd9aa598ed', 0, 0, 0, '', '', 1, 335103, 0),
(112, 'Ruben', 'Hernandez', 'jdjsjs@jdjdjd.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 0, 750945, '2016-06-16 17:17:25', 'user-profile.png', 'cSZsKQSWeQU:APA91bGSCLckozHn1eEb2LT1GJgKb5QAs82VUb4bJddy9w1Xo6q0UxqaF5x4DVKTQtN_xL8e-enoRK7M7p3KgAQqzZse_zJM14enxNNA9rQaNNkJQz5XWVKSwHUq91I_NyEgURKcHxKn', 1, 0, 0, '', '', 0, 663582, -1),
(113, 'Felix', 'Odigie', 'felix.o@valdecapital.com', '6173881912', 'ab8cd70aa61a3292c17d3dbd587605a5', 0, 474870, '2016-06-16 17:33:35', 'user-profile.png', 'eFqeOR5Ps9Q:APA91bGyVI2HdUQY4ePRiAC6Xe3uM3loHxxGUCtNAp89dyEO1MvT5fc6TsFeb_DuI56-wwr6rP7IBq0jKbziVK1VL0luWYTLUEn4yrHkrRmknHNmctwMdpC6zticfbzVuqNqtGFineS3', 1, 0, 0, '', '', 0, 607623, -1),
(114, 'Test', 'Test', 'hdjsj@jdjd.com', '9154746047', '2cc47d174ce530d57e48f9578bb53323', 0, 495759, '2016-06-16 17:52:26', 'user-profile.png', 'djfkMDAJCp8:APA91bHcmsdR575xAp0FFat-96sewUNdZPTt2VsnIVBwxRWboSilj7Ulsl2_YY0cPQ2n57Q8CEMvjpGnVEaf0vjn8hBl-chmbzf-f9aM-YJmpWbWd2IPvyq1YMWkUAXtjJZwBuCPEsFa', 1, 0, 0, '', '', 0, 594686, 0),
(115, 'Zeinab', 'Golbaz', 'asal.golbaz@gmail.com', '8187939840', '104897046a5b9e0cb945e8dfcfff6495', 1, 458787, '2016-06-16 19:37:03', 'user-profile.png', '265c03667211ee3c03279089bb64a4189d23c9e38578be6e66fdee302f4331e4', 0, 0, 0, '', '', 1, 655757, 0),
(116, 'Nicholas', 'Ruck', 'ruck.nick@gmail.com', '9197706024', 'd436d92d567755d65fb38903e3085f05', 1, 162004, '2016-06-16 19:38:00', 'user-profile.png', 'c--H4akpy8M:APA91bEoJOSWoG8YC3CR-uyXD6ikf1Ix-vALCvdsO8pLKbYFIBGqiE4QjE7GsdzNr5SQbRg7m0BIGmJ3Y5Rgwl2II2LrYlt5E-i626lpQxfM0SijNkhxz_Hr49C5tVPZHu-7ojBfocPx', 1, 0, 0, '', '', 1, 465941, 0),
(117, 'Felix', 'Odigie ', 'felix@myqapp.com', '2104644634', '2de5be3cf1cef0ad7d054ae0d231ce41', 1, 267543, '2016-06-16 19:45:51', 'user-profile.png', 'fIOm6x6c0rk:APA91bEmCj_LCfjKT_kr-C-Gpb_hueLaoVt5H0ZC-jPdMQUyrU_44do_x7JJ2Kgfxtu5m96hVhOzpnuf5JSSR83TP-Ts0hdyCcc301jwP2L9ZuSo2-xcQQue2Z5sDBcPI1EpSWSHrmP2', 1, 0, 0, '', '', 1, 106793, -1),
(118, 'Camille', 'Norwood', 'kidcami@yahoo.com', '5102133564', '050a7a63ec51ca2ba96c0414a6de14b5', 0, 568502, '2016-06-16 20:54:25', 'user-profile.png', '0ae317fb28fead3b29973e9d9d4affe36e0b4634d05432a43fc1a8c0b1e8c378', 0, 0, 0, '', '', 0, 808835, 0),
(119, 'Daniela', 'Lopez', 'danielaylopez02@gmail.com', '8185682927', 'd7dc72b22f5febb2d3c52462160f4c4e', 1, 649657, '2016-06-17 00:56:50', 'user-profile.png', 'd1H3w8fvjB0:APA91bGT8Ph8Dp_ih1eQhKXoSEE53uZXnELPVppbXQpMYSlZhneGuGJgeKTjZha19wMS6x2mg0fLzz_9OECwIGHa8-L71-gBgtIy1wQWJqoEvDpzGqtGQQ0aH9i1UxMUiDplLsEQtaSE', 1, 0, 0, '', '', 1, 555661, 0),
(120, 'Shaharazaad', 'Carter', 'shaharazaadc92@gmail.com', '3238843496', '88d013130d431020d9f1aaa2add33cef', 1, 420921, '2016-06-17 01:08:20', '1466125890884.jpg', '3549fc4b58efdae34d7c6084cf45d26d0e7eeb8e938f2c589f5911f38c041ae7', 0, 0, 0, '', '', 1, 689044, 0),
(121, 'Thomas', 'Avilla ', 'thomasavilla@gmail.com', '6463728159', 'fa97071bc38a66dcacf768e4990c159a', 1, 379181, '2016-06-17 01:17:33', 'user-profile.png', 'fnFIi-AZchk:APA91bH4Q9QZguNMxTdmZRjR6l00Bwj4Twbohm4s64aCkeVQmNHrbM-SuGbzFR8fJwpejiYkAHmHhKC4k8t6rUFawhxL9fwYEluDyYWxR94lEM3cyGE_8y_0ivMt9X39gTt0l8uB9z10', 1, 0, 0, '', '', 1, 226086, 0),
(122, 'Maritza', 'Dominguez', 'dmaritza721@gmail.com', '2014668111', '167656ff89eff8629433346710905a6d', 1, 394992, '2016-06-17 02:14:46', 'user-profile.png', 'fHnEnL3SIPw:APA91bEHriQtP9ntNiEvTeKXuK-nhUMM62WLjgJ-enHWH9SnkQ_T7V_lZZ48wC6icHGONdi8_9HcBwQ2WAne7sGF8xYgfwVoEpGp-hlDIotYpcL7Fpz7_-nGgx944kEGGq1DVGzqwaKR', 1, 0, 0, '', '', 1, 803759, 0),
(123, 'Tiana', 'Pope', 'tianapope7@yahoo.com', '4043122186', 'c58c29b2c29bc7c93c7301b7afe8a016', 1, 309868, '2016-06-17 02:37:15', '1466131840008.jpg', '2ff631c775ae09a51e5caddd1ebc20b94ad5e5a154ead78ba8363b6aadfa0f8e', 0, 0, 0, '', '', 1, 310539, 0),
(124, 'Machella', 'Anthony', 'manthony2007@yahoo.com', '6785884574', '4df1db320b19ca93a2f7fabce478a682', 1, 216226, '2016-06-17 14:33:32', '1466878671314.jpg', 'feocJDEXqXU:APA91bHsPI3f9LRJnxGijQrGA8VAsMtlnR6zbKJOEaIU_B0I5NzLYqKZNJelc_cKp_DW65DRfaSpajWgTfnMpZn6hPGaYw-EWQm1NvPr0yMdtw3cdIAcnFHG6d8aW5oeW-_bnTglY9GV', 1, 0, 0, '', '', 1, 584122, 0),
(125, 'Dawn', 'Davis', 'ddlonglegs@me.com', '3104889677', '1c386879d8ec9854c89aa7a7c7473893', 1, 513692, '2016-06-17 17:49:26', '1466186043837.jpg', 'd9uSkrhAzDQ:APA91bHXS9nm6Cm8egliJwum-LTYWq8b5cdWOon5yTBpJ0PVSjmQaga4toX9pXHZC33SFDWGBhsCrM8O0jzJy7vpEJPn0LchTqup7ObkqLZ-PNkBsSagGafj05rVcurrgWOoU9yYc6-M', 1, 0, 0, '', '', 1, 414365, 0),
(126, 'Tarian', 'Bullock', 't.bullock@lafilm.edu', '6616747084', '283078bed58a41ccf791d6f6e3d3871d', 1, 824521, '2016-06-17 19:04:31', 'user-profile.png', 'f_7hcmvCfiM:APA91bEBTcG-owoNRmLHp-MzsmrpK3t5t_4pryAtLT8-c5Yka9zhQeoVVmIOqqAIBUs4U7V4gWfuTyGDVir76hJNJW6V3An5pAgJCnlqx_yNlCXKFotzjFbzU0Rsx2BjjyKmTw8kIjO5', 1, 0, 0, '', '', 1, 556949, 0),
(127, 'Aliyah', 'Burroughs', 'burroughsaliyah@yahoo.com', '2145859419', 'f2a1ee1093774c6c80cf92698ceef955', 1, 846955, '2016-06-17 22:05:14', 'user-profile.png', '624bfd74864a7425041e4ee325f78cb477c5da7c5b45e4b40eafe3d94ac79d00', 0, 0, 0, '', '', 1, 899760, 0),
(128, 'Conzady ', 'Sullivan ', 'conzadys@yahoo.com', '4047480362', 'b137e186fc3ac21deb867c1836e297e9', 1, 925320, '2016-06-17 23:07:18', 'user-profile.png', 'dOwSMUAhNPM:APA91bG05fzQhzDjwb6u-wWV8XBZNQjXXj6-2HDeVo4e9jm4BRlPpO-oC98A-0xREHV4pFXDbEoeJyytso1rfnWqsIejWl_AVmTVlLIVYuklqBENzWpRb1ZEb1jXwU3EzwIa0O4fWPuT', 1, 0, 0, '', '', 1, 116854, 0),
(129, 'Chaquita', 'Bascom', 'chaquita0102@icloud.com', '7815106952', 'da66b9383fbc0118778f35a43623ba55', 1, 718227, '2016-06-17 23:16:23', 'user-profile.png', '12f7d8cf59be5f929c4e893301308f815ee0954db3e68efbe0da209e65b621f2', 0, 0, 0, '', '', 1, 173934, 0),
(130, 'Jonathan', 'Karp', 'jonkarp01@gmail.com', '5169022916', '4b7117a452833619e63db37cc2888055', 1, 820762, '2016-06-17 23:17:04', 'user-profile.png', 'e0003da719b9a1645e508d773f050f0ff1064a239d421331bfe8af9dc0696eaa', 0, 0, 0, '', '', 1, 210743, 0),
(131, 'Ruben', 'He', 'jrhernandez@gma.com', '9154746047', '81bb9a700ffd6e27384355587433683f', 0, 135177, '2016-06-17 23:27:05', 'user-profile.png', '741b9bc3cedad0bdda701e75108da16836d703a088236957b4db726401dd0342', 0, 0, 0, '', '', 0, 333627, 0),
(132, 'Jannai', 'Calderon', 'jannaicalderon@ymail.com', '3234121141', 'c5c057be0aa36f94dcc05a20d0cd4198', 1, 424126, '2016-06-17 23:30:31', 'user-profile.png', 'f2V35x6_HpU:APA91bEKO2yqfXxvMIBfbeyuO46AQrgSkqkvQ5kTXmOqJnEWO6xOBMt8Xb8HoaLxW60Z0QPfogvuv9P9tNvcwHjqhZvkKm9rChsWMcQ0qQOWutWMPwXOor9M7v4vNKxrX_Yiz6nhI5rR', 1, 0, 0, '', '', 1, 992479, 0),
(133, 'Felicia', 'Reed', 'feliciareeed12@gmail.com', '3478588329', 'ec9d4f74d1cca7dc99ce06a28b303e53', 1, 744704, '2016-06-17 23:30:59', 'user-profile.png', 'fKRu9_Y7O7I:APA91bEgq40phqyU4NcN-3aI7xopnVTBHWsS--neKnTNfG_8AuiBxBOn39JB4RfrkpskCIPKETDmOhDnXYGtkDTdrMwjlE97ms3Rcpqh_NJsXrfJ2kgfW5e9suj0htz5QKwcAlPZUIH5', 1, 0, 0, '', '', 1, 229769, 0),
(134, 'Stephanie', 'Breen', 'SAB934@gmail.com', '6034016617', '6789ab6017c33c957785944d3fdc30ca', 1, 667519, '2016-06-17 23:35:58', '1466206760190.jpg', 'b3f1dda0187485bd25a5e72c7d5ea831cafc7bc2d107994c8aaa6421877f57ac', 0, 0, 0, '', '', 1, 105307, 0),
(135, 'Perry ', 'Wade ', 'pwade16@gmail.com', '8573338308', '49ac41911413ba4c7bcda84094f10fbd', 1, 986801, '2016-06-18 00:31:32', 'user-profile.png', 'fAcAphk4yCg:APA91bEgbb3sOKlsZb7VIxej4Osd7-ZRH-8LSVDtsy9WBL-mlTR0-do2mPzzvpJD4QEFpftEUx71p059wY_AvKNpqW3LFNogTt4rKQdaTb2x-mzVRaFLrgGQD1h6qvMEqKl6yipD1Wmi', 1, 0, 0, '', '', 1, 807301, 0),
(136, 'Amber', 'Guidry', 'AmbercadeG@gmail.com', '9162302551', '7a0251fec3c2f116c3736f7d64f83917', 1, 914452, '2016-06-18 06:30:18', 'user-profile.png', 'fc410a5b62d228f3f0ef2f9749e2433bcba437e4608b821a2fb0a5e32b6019cb', 0, 0, 0, '', '', 1, 772367, 0),
(137, 'Yulimar', 'Andrade cordova', 'yuls2000@hotmail.com', '8579910489', '33744ada78fbfba52bd9e58eccdbe477', 1, 886687, '2016-06-18 10:58:29', 'user-profile.png', 'eVaEZCCf05I:APA91bEuUIh-JYP3VSmX0a37ReZuPkyAwD99NbD9he6vK9SMkIW9XOTSccgKmez-kuKVErF69TRBFPBR9kHm2UjLdhnnERiYC3QceNbAEjYUix8diqAeZ_zEzt_4iWgOsZTk4tGgauUE', 1, 0, 0, '', '', 1, 377462, 0),
(138, 'Lee', 'Bash', 'shopeditplus@gmail.com', '6464949412', '020d986c5299a705aa39f22dccaf98f3', 1, 823957, '2016-06-18 15:21:09', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 586726, 0),
(139, 'Brittney', 'Jackson', 'b.jackson1390@icloud.com', '6466205308', 'a99beeb0a5d0237133ace3ba64903f75', 1, 545282, '2016-06-18 16:22:44', 'user-profile.png', '9f6af74ccb4b7fb712460595229874504b2ce96bb0f15b8c61ec3957ba50871f', 0, 0, 0, '', '', 1, 106115, 0),
(140, 'Jamie ', 'Gonzales ', 'jammiller16@yahoo.com', '2135704712', '969ee15d4cf62a4db0a5e86c2a4217b1', 1, 819430, '2016-06-19 03:49:07', 'user-profile.png', 'fSLjx3GXizw:APA91bGlGEljEGcqdR3I8YM8o1I2OQwhn1RqKWFXjfxzeC1ZwN6B3deppJsZg2UjRSsyYfZEA6N4DX3tTnS1_uYFLUUzauk5C1g9T50vgwIOKy7lI8hQrwIGNPJq1Z4aYg83VARbhwH1', 1, 0, 0, '', '', 1, 251278, 0),
(141, 'Shaina', 'Lavind', 'shainarlavone3@gmail.com', '9492915650', '1dd13e9059babdcf09676fe79902b740', 0, 470371, '2016-06-19 03:53:31', 'user-profile.png', '5116125df6341934873b621c86761db5a5f7f7c0fb3e2e2468270a64454d925c', 0, 0, 0, '', '', 0, 332524, 0),
(142, 'Shaina', 'Lavind', 'shainarlavine3@gmail.com', '9492915650', '1dd13e9059babdcf09676fe79902b740', 1, 574469, '2016-06-19 03:55:01', 'user-profile.png', '5116125df6341934873b621c86761db5a5f7f7c0fb3e2e2468270a64454d925c', 0, 0, 0, '', '', 1, 590604, 0),
(143, 'Arielle', 'Harness', 'aharness@iastate.edu', '7124902165', '6f7d306d5e9366296bb017a7abcb0db4', 1, 497085, '2016-06-19 14:27:21', 'user-profile.png', 'euRz11aHaGs:APA91bHGQR0cqolajcDkXRXt9KsM99MmA7k9q0AOWBVL3IL5gcepTV4LBkB9BLcUUu_XOKp0XCMmcSoGDmuEUTj9bZhkd2TKYvw7seMD--nupFVYAvSKsiiUW0rJYxY7utNCEs3wkRFC', 1, 0, 0, '', '', 0, 889804, 0),
(144, 'Laura', 'Martellino', 'lmartellino@gmail.com', '4018553322', 'e08180163b4a1f17b012b6b267dd3f0d', 1, 757099, '2016-06-19 20:07:03', 'user-profile.png', 'dadc642d584dc8513c0c404a16629c94acd46fb9cfbb05f08ff2b12a5dfc216b', 0, 0, 0, '', '', 1, 894565, 0),
(145, 'Esther', 'Lenderman', 'Estherlenderman@yahoo.com', '6314137352', '2b2809462198c8243ba46f23964cd3f9', 1, 466305, '2016-06-19 21:07:29', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 800217, 0),
(146, 'Pamela', 'Towner', 'cr8nheat1@yahoo.com', '6613130073', '14fe4a40cdde2c516605e32c410e96b9', 1, 840960, '2016-06-20 01:53:41', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 216352, 0),
(147, 'Tranise', 'West', 'slimprissi@gmail.com', '5162326116', '6c25159f3b4097bff6da2a51b9ff5b3c', 1, 188386, '2016-06-20 14:03:09', 'user-profile.png', 'e2d7862610929ed92c368e90e2313e6e6d2a9a508c73b688ac4d8218db847891', 0, 0, 0, '', '', 1, 659309, 0),
(148, 'Tiffany', 'Glass', 'lalee2@aol.com', '3107760597', '85dac9ec9ea27284f95fcb711b195679', 1, 395416, '2016-06-20 14:33:01', 'user-profile.png', '00222514e241a8607a572c86e33ebdc0b956b9302ab328305215ca8c93365f2d', 0, 0, 0, '', '', 1, 233033, 0),
(149, 'Nicholas', 'Oliver', 'nsoliver@outlook.com', '3472487239', 'c7c66a9fb8db125e67ba6a882186357d', 1, 251517, '2016-06-20 15:58:59', 'user-profile.png', '313dd764858dff70c200430c3804a5f54240601c4cfb5771cd84f63f95a0e263', 0, 0, 0, '', '', 1, 504901, 0),
(150, 'John ', 'Nunez', 'john.e.nunez@gmail.com', '3479333141', '4e4c949640b98dc9f12a6291248c0aca', 1, 292020, '2016-06-20 15:59:26', 'user-profile.png', 'f8gePpFlFik:APA91bH0rjo1Lb77vpNOIo5-Ay5xO-72u9papyPTxGrwk-x7M7LEm4YYyXsL8kZZY_vOdis7ekqWpv-YgsKASEFMK14hfy9gFYy0WbobwUL7WFYYFuUimCAKREFA3FYZ_s08cXllFnMF', 1, 0, 0, '', '', 1, 675042, 0),
(151, 'Carla', 'Onofri', 'carlaonofri@gmail.com', '2134223232', '65999c23aef20ca1b887b825fb4b7d81', 1, 984811, '2016-06-20 16:11:30', 'user-profile.png', '8e00910d02bf13a49855249a9cc4f4763fbf7b436e2ae0cbe34051141b28edad', 0, 0, 0, '', '', 1, 771205, 0),
(152, 'Talia', 'Davis', 'talia.ashanti@gmail.com', '9725051301', '2a3714e393c1549c276eccfe8b734a2b', 1, 438959, '2016-06-20 17:03:14', '1466442684794.jpg', '9f23195088c4b75835d752cf04477cdf40c5c68228d4db3f9e32129c3c315634', 0, 0, 0, '', '', 1, 281524, 0),
(153, 'ShaQuisha', 'DILLARD', 'sydillard@gmail.com', '6784128727', 'a204dd56b08f6ca4da7dba5fea5b49f5', 1, 641441, '2016-06-20 18:30:24', 'user-profile.png', 'drcuynZMLnA:APA91bF9kgEXz2JJHYPoeRYgDO0nxXDw7lVMwMg4a3JpHYHVZrlVDxVr7bruHn_29egb_Wk67v71mslKcHic1DD0m9_WtgkgH5iCR8DqGZRZiUda1di5RYBG6l7HiSIAlKgaB8pMOwvL', 1, 0, 0, '', '', 1, 705107, 0),
(154, 'Yasmin ', 'Salah ', 'salamconsulting7@gmail.com', '2405511111', 'bd00e695bed32d320449a13644ba1e69', 1, 882469, '2016-06-20 21:03:30', '1466456934587.jpg', 'fyvUQs0mL4E:APA91bErt2DCaOzpvY0GhCj8qWoJvI_pgMolkKP_70en52H8U3_ib8Yzh0vjsmVqVQJYiw1mv_uLF__atU7MeevlkVsXjIVfCKDABvJouVsyFiJjGuQDLTQpuGZIfRIJlsl3qtkI5z78', 1, 0, 0, '', '', 1, 177105, 0),
(155, 'Gina', 'Ramos', 'gramos98@yahoo.com', '3472556470', 'ed96a0035004529f335aabf8032ce982', 1, 700754, '2016-06-21 01:56:03', '1467325710119.jpg', 'db3b68742e289a6c9d07a7a1a05d4d34aafe4a914871e18576cf12fdb34c17b9', 0, 0, 0, '', '', 1, 482137, -1),
(156, 'Equanda', 'Willis', 'quandak282@gmail.com', '3473044544', 'a3f749fe377c93511cc423ddbb7bd916', 1, 151592, '2016-06-21 04:57:55', '1466485329207.jpg', 'c_j_AqeGrUE:APA91bH7oe_choHTQF9IYYQRWG5KfFg96x9XQMqnIv_CWMSDgLhiosnpTDpYfS0B2efrh69KqYtzKIAJvEBfE_hI9f0qEM5PDQWA3J7uxc6F3UgcdSEbZ7LhI53pDws0yoEkyJlsT4Mf', 1, 0, 0, '', '', 1, 274350, 0),
(157, 'Bryan', 'Brea', 'bryan.brea11@gmail.com', '3475641493', 'ad7809af4331a98dac9401a71da3614b', 1, 335973, '2016-06-21 05:19:21', 'user-profile.png', 'df152b828c8700aa6aeffc45bd2898304a47f86a39ba42f81dfb0a7a1407f948', 0, 0, 0, '', '', 1, 597475, 0),
(158, 'Ellis', 'Clayton', 'ellislclaytonlll@gmail.com', '3477985460', '77b97895d44ff83157513367b54beee7', 1, 212681, '2016-06-21 05:26:37', 'user-profile.png', '8b90b1a79ccb4400e727f5ed386e9dc1da7c1e759089768d16dd3de246cf6bda', 0, 0, 0, '', '', 1, 400155, 0),
(159, 'Queenie', 'Lin', 'lin.qing.624@gmail.com', '6463713510', '06ccf10828d2f318c405301de464b308', 1, 948550, '2016-06-21 05:38:12', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 460679, 0),
(160, 'Julio', 'Zavala', 'zavala.julio125@gmail.com', '4243942798', '4b972fd061fbb786d147327a6c0de620', 1, 199499, '2016-06-21 05:48:48', 'user-profile.png', 'c78c27d9bee2d9d94454acf5adf603411ed93b788c48abc6c6a107f12bbd6d81', 0, 0, 0, '', '', 1, 992460, 0),
(161, 'Kennedy', 'Barnett', 'kennedybarnett1@yahoo.com', '3238778250', '2c6ce33a697aa1bbbf495cb215182681', 1, 674398, '2016-06-21 06:28:48', 'user-profile.png', 'ac32432888969db0ea36e78f888dea151d2564978a5e43382f6c321270abb1ef', 0, 0, 0, '', '', 1, 316516, 0),
(162, 'Linda', 'Caceres', 'lchcfan@yahoo.com', '8184689779', '049d38e93396ce46b0509bc5b84ef4d7', 1, 886893, '2016-06-21 07:00:56', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 126831, 0),
(163, 'Waulinda', 'Harris', 'waulinda@Gmail.com', '3476849032', 'd50bf1d1534491baebd71bc9d86aedfd', 1, 197569, '2016-06-21 11:27:23', 'user-profile.png', 'fdhWodZTkTs:APA91bFMG3j9nR_7GFfi8EIT_zr2sF7M7FouzDculdERO9hJoipmi4l7fMlCx5fuWZw3IJ-pkkbFFkSLVW-HfzTt_m9bW5sn5jMhYS5PYQ2lpt8CCHsK9JffVIgBzxOuJnyxn_A8Bjoj', 1, 0, 0, '', '', 1, 294435, 0),
(164, 'Lenicia', 'Appleton', 'leniciaappleton@yahoo.com', '3473102305', 'afaee93112166fce4ee1d338c17561ac', 1, 580376, '2016-06-21 15:30:59', 'user-profile.png', '00c48cbfca7eb2ac0f77e224b95ea5814ea35c31041f26b31e75f3806f6fa09d', 0, 0, 0, '', '', 1, 761585, 0),
(165, 'Melissa', 'Lehman', 'meemee920@gmail.com', '6786701717', '3704933a06a171e41d11f0e2afe9354b', 1, 832365, '2016-06-21 15:49:04', 'user-profile.png', 'fuQIVxN0moI:APA91bFJH7sRCrZ8v245nmFGgSaF1xsGwt6boJUqxYSs8Zkl2gVGB285ave0voyMBH-SxUVL6pk9ey7a12LCGOgSWcsfcI6lhMm33kmSEsrBdAalDtFYXff_LQgm5FBP-B4Ofn1AaZcL', 1, 0, 0, '', '', 1, 714989, 0),
(166, 'Francesca', 'Pagano', 'fcp16@me.com', '9178172822', 'd182694aab92785e5ce871ee6f354030', 1, 882242, '2016-06-21 15:52:05', '1467312283812.jpg', '43aee4f851dc85648b497190a8fb0691d2214f63d3a51a34958b08e10dd902d4', 0, 0, 0, '', '', 1, 843843, 0),
(167, 'Christian', 'Allemand', 'christianallemand91@gmail.com', '4044347941', '02d84881b2252e44e8446cc0c954f1af', 1, 820824, '2016-06-21 16:07:49', 'user-profile.png', 'dc_bsahuPgs:APA91bHgf6j7OfhWf3QaPvPa6YmmtuBhazI6kh2sj-xDvcNK9HNFUI9YBIVYbmkYkpKtS1ihhLld2ynun6CfAUu7fOchAOr7ZFykInwXJ3dFj907W86YieT6SqyB1edKrEfDuhyzecgr', 1, 0, 0, '', '', 1, 458797, 0),
(168, 'Cindy', 'Murphy', 'dcset2024@gmail.com', '6785889848', '171f23ba1eb03a5a29f52b7357f1205d', 1, 432521, '2016-06-21 16:43:01', 'user-profile.png', 'fbe14bd30eb7b6b400b85687131ff15136e3318d8a74b54ff136b81823953a64', 0, 0, 0, '', '', 1, 192997, 0),
(169, 'Elizabeth', 'Brown', 'fairfaxb@hotmail.com', '3479223551', '61344dfa2bbb55b899ad679020237974', 1, 209869, '2016-06-21 16:54:56', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 274596, -1),
(170, 'Rhiannon', 'Briggs', 'rhiannonmbriggs@hotmail.com', '7708625816', '7d5c5fc50ec7e3c89a05d07ddf045062', 1, 317555, '2016-06-21 17:22:01', 'user-profile.png', '0f6f8bb9ca7eb83756a2f16f0905d99c2ce90a320dfc798dcd3a60f61f8a8945', 0, 0, 0, '', '', 1, 812698, 0),
(171, 'Brianna', 'Williams', 'b.williams850@yahoo.com', '7137033002', 'f03426ebd94666f3846349eba1f7fe19', 1, 206558, '2016-06-21 17:41:01', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 917858, 0),
(172, 'Victoria ', 'Lash', 'serendipity736@gmail.com', '6786877924', 'e433d3b0bdedd60c41d7c5e9a04240b3', 1, 475361, '2016-06-21 17:56:50', '1466532125497.jpg', 'cdtnp2A_Ueo:APA91bFsEsr0HjN03VbUBSwDHHnUPjMw024dNPGmu0e5AYW8t6yULGqaoFzc_OAhC5A0__K8Wr2BZtU4kDuKmuUooeRZ7g4Rh00X8KSKgB4PrjEOScz9Vy7w5vMnofc2Thpe-JvGqEf5', 1, 0, 0, '', '', 1, 708478, 0),
(173, 'Ricardo', 'Willis', 'rickyw796@gmail.com', '7706084841', 'f51d0f310e062b0673b83394ec807f95', 1, 418520, '2016-06-21 18:16:34', 'user-profile.png', 'e_45fu6FSq4:APA91bHgc51gncn_o3A09gA3h8IrbjF9cJf5b0L8aNm3the5yZn8gFw1arZsbGXTmeN5riZIAfPwtbF2R53TWE1N49Fyhy4Su0jd4rQJlWQNd07L9Tolc2PVcvXYrxf2L4hooQGqdfgA', 1, 0, 0, '', '', 1, 802780, 0),
(174, 'Jessica', 'Caceres', 'jessmcaceres@yahoo.com', '8188499593', '9d515b8fcb89c4c1dd063f16cca730cd', 1, 891977, '2016-06-21 18:31:19', 'user-profile.png', 'dRSUUML4LSI:APA91bEvq51ulG5EhWXNKWdvfPbRg9V75kbP5Ncl93ZeFZpS6mWinHIoHuh3d1fi-ayRTGOYEUheaYjYI3A9FgwgnO7Knbce3qTVHOQFdjOsKZ2tDlKXnJRajTeq134uXOshfI1nnS-_', 1, 0, 0, '', '', 1, 751793, 0),
(175, 'Kesia', 'Poole', 'kesiashani@icloud.com', '9293400542', '64e044d738324166128be12c50683aa1', 1, 315474, '2016-06-21 18:54:30', 'user-profile.png', '48266696dfaeda4354de7ca272d7a357b4986ef60b852e8d115bbc02dca5ea72', 0, 0, 0, '', '', 1, 239162, 0),
(176, 'Loleka', 'Hudson ', 'Lolekah@gmail.com', '3364570430', 'bcc069a4cfa0fa1dc7875aa9c46990d2', 1, 521142, '2016-06-21 19:07:42', 'user-profile.png', 'f2K46wERFlw:APA91bG7ouk7qJ9e-qtjMul7BtDFH10K8UYo-Krp4XA7RrwoftIpwbltPPP2DGiWDWB2ffQW1xs_4g8aXC9a8RdRjXc4tKEC75UlRwYmtpK34Ew_JBzxzb-Gqfj4dHDD9X2c5Akj-Fu2', 1, 0, 0, '', '', 1, 963572, 0),
(177, 'Jodi', 'John', 'jodilynn0511@gmail.com', '5303000763', 'bf99d3255ae1967ce9c98e6d03b4bd30', 1, 265338, '2016-06-21 19:09:16', 'user-profile.png', '492ce51658373d6c9d956aefeccd3caabe4d91ae22b4ab2de6e6bd7b0eedd834', 0, 0, 0, '', '', 1, 517704, 0),
(178, 'Yseult', 'Polfliet', 'ypolfliet@gmail.com', '6095766606', '167f487efadd3114b5bb959915bdbf36', 1, 404190, '2016-06-21 20:06:11', 'user-profile.png', '91d9a7eb23421e8183838bcf0531c57cda65ff5e1095a1aaa0d18448b1fa9154', 0, 0, 0, '', '', 1, 749166, -1),
(179, 'Luisa', 'Gonzalez', 'lgmusic24@gmail.com', '9203092712', 'c37eeab47f8bfe56b326529ad5918af4', 1, 137455, '2016-06-21 20:38:34', 'user-profile.png', '4acb07ca5c3de2a80af9e3032e591cca3cfe1dc9241432d4f72fcb49adfc2858', 0, 0, 0, '', '', 1, 659119, 0);
INSERT INTO `user` (`userId`, `firstName`, `lastName`, `email`, `mobile`, `password`, `isEmailVerified`, `passcode`, `createdDate`, `userProfile`, `deviceToken`, `deviceType`, `forgotRandom`, `userType`, `changedEmail`, `changedMobile`, `isMobileverified`, `mobilePasscode`, `isDeleted`) VALUES
(180, 'Melanie', 'Binet', 'melalexa88@gmail.com', '5163757956', 'a834b76f5b4e7520ffd1dff08ea8b311', 1, 948024, '2016-06-21 21:27:50', '1467313903822.jpg', 'f9b1e9fd7a3c413760a9492641260e270480c110cda60c4eb6eb22d9c69273f7', 0, 0, 0, '', '', 1, 244005, 0),
(181, 'Hailey', 'Brock', 'hb_080995@icloud.com', '6784464892', 'cdb29e82b74a0f32bbed4283269f5834', 1, 783571, '2016-06-21 21:34:56', 'user-profile.png', 'dc_bsahuPgs:APA91bHgf6j7OfhWf3QaPvPa6YmmtuBhazI6kh2sj-xDvcNK9HNFUI9YBIVYbmkYkpKtS1ihhLld2ynun6CfAUu7fOchAOr7ZFykInwXJ3dFj907W86YieT6SqyB1edKrEfDuhyzecgr', 1, 0, 0, '', '', 1, 940514, 0),
(182, 'Alexis', 'Hart', 'lexihart1216@gmail.com', '4043246252', 'd660c816b89e345e63faf2faf6414903', 1, 539090, '2016-06-21 22:06:50', 'user-profile.png', 'dZ6sfzO1mvA:APA91bHZOVbvPAn-wX9cqL2Xe82FvyI61ADOmq5TV7JpXPCYlWIOQZRnAq8bvs_fYCrk5Z_Q4GkCLKOaSCrn-OFU3uQGS07FfQ7umQwEesY4VK5uOP5MmHjr0Fr7080_Us9FsjNm4Wbh', 1, 0, 0, '', '', 1, 396508, 0),
(183, 'Eileen', 'Pena', 'penaeileen27@gmail.com', '3478321895', 'cd62b2ca411159e097281dd58903e7ad', 1, 120366, '2016-06-21 23:31:27', 'user-profile.png', '874a8353647bb5c36da0bf790d7ec26335804d759f179c76327a7bad98a60e06', 0, 0, 0, '', '', 1, 312613, 0),
(184, 'Altovice', 'Williams', 'altovicewilliams3@gmail.com', '3164694030', '2b4be963cc6be85692c5d6e3718c6ecd', 1, 210982, '2016-06-21 23:31:46', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 547638, 0),
(185, 'Darius', 'Byrd', 'dbyrd10@hotmail.com', '2533895939', '677724caae517a161cb369b5dea7266c', 1, 778975, '2016-06-22 00:30:50', 'user-profile.png', '2f6cf461ad983473347c3e195f89279dfcc28315695b5f028daab53109966968', 0, 0, 0, '', '', 1, 698143, 0),
(186, 'Vanessa', 'Mark', 'vanessajacquelyn@gmail.com', '7818126330', '1e7d371c6919cc00ba563f9441bd6069', 1, 937735, '2016-06-22 01:15:39', 'user-profile.png', 'cufjSp8AD4k:APA91bG3mjZ2lSzbCN-gSgB79c609Jvof4UqwS_Lm1N1PP4O5_HjQorRPinAo-fhWHpCV8EifhpDhcHV_bt7ayhBD_9Ynx6bEns1QqZaKmcgA44Bq9YS5FXcNEJLwL4i-0RpW0smnfnL', 1, 0, 0, '', '', 1, 104219, 0),
(187, 'Cheyenne', 'Motayne', 'cheyennemotayne@gmail.com', '3476610801', 'bad97182a9fd53c4a57634e1d0ff9c17', 1, 292758, '2016-06-22 01:41:32', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 270242, 0),
(188, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2038879349', 'df574db6ddf358c9cf111b82c56a56fe', 1, 334453, '2016-06-22 02:26:15', '1466563539803.jpg', '3accd036208c70ed66fa1b5cc862b6e5edd62dcb86070da0ee2701168eabae56', 0, 753044, 0, '', '', 1, 847287, -1),
(189, 'Diane', 'Lester', 'dmlester21@gmail.com', '7033177869', 'f5af544b038c3551254600e42738a2b8', 1, 605043, '2016-06-22 03:15:24', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 907417, 0),
(190, 'Elisha', 'Sostre', 'lisha1018@gmail.com', '9293652284', '2df227b7394f1f03cb5efb649c9e7cfb', 1, 647366, '2016-06-22 03:21:49', 'user-profile.png', 'fFx4O_wb5kA:APA91bHlAo_18uX48DOdqXxqfWBnVBKfbxQO2dAPm1hv7669sDWtZj_aJvlm-DNetoEK3foqD1YINW-1kDZxEeNG3Dlcch9PP2Q6nuVxXSChxWYaLwM3S6GwhAfjNVNMz6_1_ccoClCg', 1, 0, 0, '', '', 1, 488826, 0),
(191, 'Patricia', 'Sapp', 'tatersapp@gmail.com', '9044381521', 'e55485ff9bccd2c7d2ff37b01beff8f7', 1, 141423, '2016-06-22 13:08:37', 'user-profile.png', 'cda8cGmp1yg:APA91bHBvzeDzI59ITzZ9_G2Ih9hkdru0dvuSSRjJWzv6kUHFMr33HOsoHF_cBHgfrbFqBCAbgT-v0vovOw2jxuqGQ_iISMjGciPI6OFpD1T-OK96YPXNFR__dLhgpfmIZPbVt2aByoc', 1, 0, 0, '', '', 1, 569825, 0),
(192, 'Caitlin', 'Siney', 'caitlinsiney@gmail.com', '6102031445', '8045f3dcc94d4770220a8d62b6cc444e', 1, 244480, '2016-06-22 13:41:52', 'user-profile.png', '037cb2b0b503b361f3ca2b4a5df5e33613ac37eddb68c29c9c580360cbe3ae44', 0, 0, 0, '', '', 1, 141907, 0),
(193, 'Christopher ', 'Garlin', 'clgarlin2006@gmail.com', '4047044737', 'fe7bd671b1645a7e5c7dc8fa87389b5d', 1, 750722, '2016-06-22 15:45:43', 'user-profile.png', 'fpN6ZAPLfzc:APA91bG7RV7sxZtkWmBSo-LoQG_Qe6e6GCQGMbyC4Y82qxhg9nJQ6aUWKfL6nksLMwkfh4U3a2bWrTGaXB_vpteBKFUFawLb5FG8WNbxixHbfvF1n0UDKv1vXKGBocqv6KwQ9aemgcE6', 1, 0, 0, '', '', 1, 749034, 0),
(194, 'Genesis', 'Munoz', 'gnssmz@gmail.com', '9298881148', '655a7a61b3cb43460a4ed457c8d71b88', 1, 555010, '2016-06-22 16:12:31', 'user-profile.png', 'c316eaaa4aa5eca763d10bac4c8886868b6fc2e414be0cf424f4d6f0c15f4a55', 0, 0, 0, '', '', 1, 160371, 0),
(195, 'Curry', 'Winkfield', 'currywinkfield@yahoo.com', '3472445083', '2811a15f17572fdab1ad232f812476d5', 1, 307854, '2016-06-22 17:42:47', 'user-profile.png', '837bf2c1b3b24c9d2561621cbaa95860ddbd719673609c68ebfa6ab0c361c923', 0, 0, 0, '', '', 1, 416939, 0),
(196, 'Tanner', 'Lewis', 'tannerlewis99@gmail.com', '4239337281', 'aaf9909bd1049871d6e0c5301d2b54bc', 1, 685871, '2016-06-23 00:40:45', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 0, 309627, 0),
(197, 'Morgan', 'Lucas', 'morg.lucas96@gmail.com', '6784384363', '21fdf9e341f16524ba113b49d47a54f4', 1, 943790, '2016-06-23 01:13:35', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 934151, 0),
(198, 'Daisha', 'Price', 'daishaprice23@gmail.com', '6787781757', '333af1b5ed22e23a0528e8d148ad7a18', 1, 673155, '2016-06-23 01:49:35', 'user-profile.png', '3eb1b9fe9a23b9036d2105aaeadc3156fd987acd62e4bcc9e2c578d738468d89', 0, 0, 0, '', '', 1, 964913, 0),
(199, 'Stephanie ', 'Skinner', 'stephanie32391@gmail.com', '6786508848', '846169b1788faf6b0eb745d179dd18cf', 1, 352787, '2016-06-23 02:00:50', '1466647932522.jpg', 'fWkb0vMzewM:APA91bFE9O4kymMu9P0ZJFHJyybbq79FCpPySnRfROJ7P95138otGBy_pawMPztCZaLBjtgStYw6k_TcCyh7WUzpfFqcUeQcCRwnNN5ry1yu_c5gqdQiZCiflEF3SYdsKHrZreOaQax5', 1, 0, 0, '', '', 1, 757880, 0),
(200, 'Erick', 'Torres', 't.erick94@yahoo.com', '8189164353', '3b93cdd7c642ec32cf8a61f409ee6134', 1, 630927, '2016-06-23 02:46:41', 'user-profile.png', '0608db7cc971b086a4e5d494310cd663d85a828d59c309fa97ffcc1cdce376f3', 0, 0, 0, '', '', 1, 307636, 0),
(201, 'Lola', 'Lopez', 'lola9lopez@gmail.com', '6266930169', 'f9766f87c10ef30b7464887f59889177', 1, 691825, '2016-06-23 02:59:38', 'user-profile.png', '0bb69dc0ded3eadbe7b47bb069ae5fce7e9c62ded681def7a7a9322b27f90737', 0, 0, 0, '', '', 1, 391535, 0),
(202, 'Montana', 'Pickens', 'mpickens2014@yahoo.com', '7067410591', '31b5201589453c3ee9ba30dd3900a15a', 1, 834279, '2016-06-23 03:01:14', 'user-profile.png', 'd8aa425c0700cb906e0ca7d09cd4781880c82aaaa67b8045730814355ae3bffd', 0, 0, 0, '', '', 1, 216224, 0),
(203, 'Joi', 'Allen', 'joi.allen210@yahoo.com', '5743443401', 'c020c9079a6a000e8b66ec45e0fc2257', 1, 411062, '2016-06-23 03:08:52', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 817058, 0),
(204, 'Omer', 'Choudhry ', 'Omerchoudhr@gmail.com', '6017507351', 'e3ed4bd8115256e9a6013c23aae92393', 1, 431106, '2016-06-23 03:35:33', 'user-profile.png', 'da2Hzhv-lIA:APA91bGjgFO0zu3C4x_N0PPGu-WC1ifCllO9vgzJ7NtgnHlK9baz0EOKGVgy_IEYChu6aaT-TaoZy0pMu8cEI4vHQYWs5t-uGLr19AGCd5x8ezrHbGqrFFjNSE8nC0zipUodq_cyjpfh', 1, 0, 0, '', '', 0, 921209, 0),
(205, 'Jose', 'Hernandez', 'vauxxer@gmail.com', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 1, 264533, '2016-06-23 04:30:04', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 448777, 0),
(206, 'Charity', 'Wise', 'charityiswise@gmail.com', '2026158832', '87f90f2ab5a96656895c7412ec49afd7', 1, 935962, '2016-06-23 04:58:38', 'user-profile.png', '02adfc0f4f5bb1c80bd7f64d7a871b0b4292a4eeb62054d0480f72712437cbe6', 0, 0, 0, '', '', 1, 250154, 0),
(207, 'Leanne', 'Stella', 'lstella147@aol.com', '9172734405', '08a0bd27509bfc483287184770ae2387', 1, 911192, '2016-06-23 12:58:53', 'user-profile.png', 'f3b0100512650e4fe8aa4276ace10834d7a598a23fcfc439fb6a8e806240fad6', 0, 0, 0, '', '', 1, 632131, 0),
(208, 'Ryan', 'Williams', 'weryanwilliams@hotmail.com', '6465459236', 'c69f6a91f61ec01626232b50fb6a28a2', 0, 393843, '2016-06-23 16:15:13', 'user-profile.png', 'fn4VgLOssGw:APA91bHUy9C2cq2VGvFuZvJrSCfZjSJMAxrrlnyYZz4MpLD4F5Lu8h1XrQKsy7bzndgR78WNgSW8Qm97uzbKS77D-NLUfgnq6mioOWZgA9Pu4pWBtp2KN-43ZCJtrtNuQcGU8_QZ73Dq', 1, 0, 0, '', '', 0, 676664, 0),
(209, 'Elina', 'Stella', 'elinastella9@gmail.com', '9175754425', 'eb0e0630b5fcb584db31c7e38ec7dcd8', 1, 709077, '2016-06-23 16:52:56', 'user-profile.png', '9b2d101f235f70277de99e9d7c9b09d463239c7e0da55e1538650dacaafce878', 0, 0, 0, '', '', 1, 809877, 0),
(210, 'Dailyn', 'Santana', 'santanadaii@gmail.com', '9082175067', 'c686e9da5e5142eb68ca0383e3b430a7', 1, 717930, '2016-06-23 17:38:52', 'user-profile.png', '5b8d8d56c5efb7a165eaaa85985feda50566cc48b2dbe94fdead7a855dd9002e', 0, 0, 0, '', '', 1, 998546, 0),
(211, 'Monique', 'Williams', 'moniqueshavon@gmail.com', '6785232604', 'b8dcee723ed521e737d4c6cecf814f1f', 1, 511824, '2016-06-23 17:52:59', '1466705542507.jpg', 'c3d3ae13b5e5bc73acf0c8ae693a3f069be59227cb1f8630dfa184042164568e', 0, 0, 0, '', '', 1, 950501, 0),
(212, 'Darius', 'Taylor', 'dariustaylor16@gmail.com', '6782879404', '4585deb6278d04c81cf5f4e1b95d43a8', 1, 352906, '2016-06-23 18:04:05', 'user-profile.png', '55634236f43d4814dbe707d4d4ff5a093b2b6d3b76e6cd6beccdd8cb707cdeb4', 0, 0, 0, '', '', 1, 915083, 0),
(213, 'Jacquelin', 'Jenkins', 'jacquelin.jenkins@outlook.com', '6306774269', 'e3dcea43a71cd6a4f6f079ff7ab2548f', 1, 255818, '2016-06-23 18:35:34', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 895926, -1),
(214, 'Romaldo', 'Arteaga', 'romyazteka7@gmail.com', '5622907557', '4975967334887db00d3f1dd53b1ae93c', 1, 564149, '2016-06-23 18:42:41', 'user-profile.png', '6a60165918079364fa6ee1da5c3cef1473fef77f6c2a759d489aff562a099421', 0, 0, 0, '', '', 1, 302594, 0),
(215, 'Josh', 'Mann', 'jsmact@gmail.com', '3108509839', '046ce0c1cfef68b8e92c74b60450f0f3', 1, 577884, '2016-06-23 19:58:12', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 843000, 0),
(216, 'Jai', 'Patel', 'jaipatel850@gmail.com', '8503778952', '68894817ee1e9296ca9e62af0b15ac94', 1, 820420, '2016-06-23 20:47:47', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 165884, 0),
(217, 'Alisha', 'Watkins', 'alishakenshe@icloud.com', '6789797024', '274f8e5069baaa2d4306bf912318c2cc', 1, 866646, '2016-06-23 21:30:15', 'user-profile.png', '7ec65e7d8401a031ca242915395b45933f939f1ecaab6b50faea141f5b860e12', 0, 0, 0, '', '', 1, 535259, 0),
(218, 'Sarah', 'Nee', 'nee.sarah.88@gmail.com', '4079231221', '911bd35313e1ac2f47d9ac0786381c10', 1, 505357, '2016-06-23 22:01:03', 'user-profile.png', 'fCQkpFwRtOM:APA91bFb-ts8nz8jChFNBRtlBGPntQDH6j4stNuRHqglvrPnbyg6FTeVj9AFvera4d0tMj1IJfQtbVNMlDcNvIleGceROK03-K0vc9UzGIVviocYfoWzutu1Hgf8sELMyXoasskDaBS0', 1, 0, 0, '', '', 1, 786810, 0),
(219, 'Alicia', 'Hosey', 'alicia.hosey7@gmail.com', '3232517866', '7545c74f0c6a18979dfdcadaabffb879', 1, 872088, '2016-06-23 23:08:24', 'user-profile.png', '3034c812cf7a1c2951612358b4d9fe56f0eb55548888702bc56626b62a508b6c', 0, 0, 0, '', '', 1, 466921, 0),
(220, 'Zarina', 'Jaeger', 'zarinajaeger@yahoo.com', '9258764947', '4754add010a7ddc8804ee0b9982c9b33', 1, 666248, '2016-06-23 23:09:29', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 319193, 0),
(221, 'Deshawn ', 'Millien ', 'deshawnmillien97@gmail.com', '7186631598', '9beed2d600322ce8370deecc548f34b4', 1, 302708, '2016-06-24 00:13:32', 'user-profile.png', 'dkmnQv0RslM:APA91bEWuOc9I3coH38ZxZXaiaZxrV3x_X-0ATf6DfEvgNsmVW_LhXRchHGbRNXrG66_XoDwa3Ijpy-N7o_wAXncrk-oh7Qd6LnBy-SzfuSM4jBbO1N7Qrgiw7p8MdOWTM2rGUcF0ind', 1, 0, 0, '', '', 1, 521898, 0),
(222, 'Yasmine', 'Christian', 'y.christian312@hotmail.com', '2015899013', 'fc23275b9913ed2648f81dada0bf16fe', 1, 694565, '2016-06-24 03:01:58', 'user-profile.png', '9cc215a79229560e152a8cb982f2b3f1d5480dccaa9cd5bd6aea66c6d6badf84', 0, 0, 0, '', '', 1, 978747, 0),
(223, 'Merlin', 'Vinegradova', 'merlinvinegradova@gmail.com', '3233339554', '3ccf9b7ccba7c82b950f5db565d5e1f8', 1, 993881, '2016-06-24 03:04:49', '1467306226586.jpg', '91c34d708f4fafe49d87dee3870f43729b245b27924851d6db7c390c5ec13eea', 0, 0, 0, '', '', 1, 516725, 0),
(224, 'Cassandra', 'Ball', 'cassandrakball@yahoo.com', '4049532117', 'c85fd358d91934d8bbe9546ba0fedbe2', 1, 723292, '2016-06-24 08:54:57', '1467612515165.jpg', '4b9bfed602c1d742b35c64825f142c95a7403755ef4aadccabdd93ef51cdf94a', 0, 0, 0, '', '', 1, 764605, 0),
(225, 'Olajauwon ', 'Andrews', 'olajauwon27@gmail.com', '2162174450', 'a09f2a5efaa308ac67d8f7bf14470e6a', 1, 769163, '2016-06-24 16:52:25', 'user-profile.png', 'ed-hneREOWo:APA91bHMmjup-EiCnCsa9Qn7krpRPjW5W8ai-9W0-5tK7n0MKsQv4X8toy3GKur7lU26FKttu5ViSM6ffNObsJUrmV76nx8kpgfBXhAqEkERl6Mzst3KIGoalR4_RmwQYrmNtN98LoCH', 1, 0, 0, '', '', 1, 744875, 0),
(226, 'Jessica', 'Alexander', 'jeshalex23@gmail.com', '6304006824', '70bb9b9c0930ee278e8e9093d6710b99', 1, 443349, '2016-06-24 17:28:06', 'user-profile.png', '5d238ae9184ee06eabc556fce6f6e7b009c251f6b01dc3782eedf17565e056ab', 0, 0, 0, '', '', 1, 814065, 0),
(227, 'Yamel', 'Favela', 'ya.fav@me.com', '3475754836', 'c507f690596173c2c9f69a05531c3110', 1, 936166, '2016-06-24 18:07:04', '1466791875274.jpg', 'c6b42e60599393cbf9e66b2df937471b68237af6349f8ea6d9e1b8127035f89a', 0, 0, 0, '', '', 1, 616873, 0),
(228, 'Sarah', 'Aviles', 'sarahaviles10@yahoo.com', '9174369769', 'e1bb30350b4c1b1f8b145bd589d04568', 1, 159944, '2016-06-24 18:13:07', 'user-profile.png', 'f99bbe42be707806cb7477f229110f3fbd0a4386a357b1f6d5078e5e9cf2b2cf', 0, 0, 0, '', '', 1, 130287, 0),
(229, 'Sarah', 'Crain', 'ms.sarahdc@gmail.com', '5183214881', 'b09a8a0821f83fb71f9c7d91db2ca591', 1, 763862, '2016-06-24 18:56:23', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 298889, 0),
(230, 'Paulo R', 'Abesamis', 'pau.is.fit5@gmail.com', '8186755243', '3031edcbec408ff727ed5964fb92f918', 1, 575852, '2016-06-25 01:59:13', 'user-profile.png', 'dRG3OKLe-qY:APA91bFvyWHIN2U5P_bIeXeA2MOtS85xJel5mb-e6K7IQpnoa8A7HT_HbO7AcyD2IJdXqzsQAeYQPNX8iZmVeYvMBNRU8M4VjjF4IYwvoPhClX4_7NABL6tOKxqxxHUYiy0b6e-OSK4N', 1, 0, 0, '', '', 1, 502328, 0),
(231, 'Alyxandra', 'Pinkston', 'alyxandra.pinkston@gmail.com', '6782944973', '33eaf54676d798fe543c5f4723f10c1b', 1, 927633, '2016-06-25 19:31:11', 'user-profile.png', 'fzT2IkmrQe4:APA91bEkTccVPSFW5mSgvLiyi841paC9PYFEIbgmqKDqHTs9B5v1xXpveOdUiLZRg_TtCNMfu1FexvU63L4X4mrovqscu8eg9acNcOOYirF5TfrXQXw8qdPE-ssDYn7Lvb-GCGjAlWkS', 1, 0, 0, '', '', 1, 623039, 0),
(232, 'Ericka', 'Andrews', 'ericka_martin91@outlook.com', '6789000701', 'c0eb45456540bd5d6f4f3c22f3f0efd8', 1, 471481, '2016-06-26 15:44:01', '1466956308555.jpg', '21e6be1751554c4f2d52b2c9fdd69de844c6c47c17093653668218b7119c9b5e', 0, 0, 0, '', '', 1, 219058, 0),
(233, 'Jacob', 'Beckham', 'jacobbckhm@gmail.com', '7066147163', 'dd633d4b43ba721f68ed923d8d4f8cf8', 1, 713790, '2016-06-26 17:28:02', 'user-profile.png', 'f_mOOmHy2D8:APA91bEZDlyrOKnPx1_bboC1iufsVyVjFkOjo9Kq_vgOZzzHUiKTyLgJ2EnUCJ_A423_ysSg4f3g39soSFWv_6oL3FK3g0cPjHCs46UiK6DE4z98dCnQnnwOwaE8AVnNzf1MQqaMqX7o', 1, 0, 0, '', '', 1, 220512, 0),
(234, 'Tanika', 'Kennedy', 'tanikakennedy@yahoo.com', '6787990823', '81d4614c914bd24bd1d40b4e39247b4d', 1, 970477, '2016-06-26 19:22:56', '1467043419375.jpg', '7e3d74940af98163959031756c7098ae37ed05dd6041478f2fede59854c316f5', 0, 0, 0, '', '', 1, 550469, 0),
(235, 'Candace', 'Carter', 'candycolette@gmail.com', '8187383337', '98ddb72f504626b4073743b1c837bbdc', 1, 902718, '2016-06-27 00:51:02', 'user-profile.png', '13878cf7da85051d0d11ea29f7f43553c7334c1a5b10ebeaf24ba1a39ad08a3d', 0, 0, 0, '', '', 1, 498103, 0),
(236, 'Kimberly', 'Odigie', 'kimberly.odigie@gmail.com', '8184658228', 'df574db6ddf358c9cf111b82c56a56fe', 1, 114050, '2016-06-27 03:48:58', 'user-profile.png', '3accd036208c70ed66fa1b5cc862b6e5edd62dcb86070da0ee2701168eabae56', 0, 0, 0, '', '', 1, 832513, -1),
(237, 'Michael', 'Galloway', 'buckcitynow@gmail.com', '8044055055', 'a305f1d940731e4530478db1a12da759', 1, 327618, '2016-06-27 13:51:30', 'user-profile.png', '5c35104f45c0d963c7996830e13c4a9f2d8f56a25d98eb037783179eaa1e7b8e', 0, 0, 0, '', '', 1, 674078, 0),
(238, 'Antonett', 'Young', 'ayoung81@aol.com', '3478161779', '1382f84916b8c29842a4e79d40fac942', 1, 452473, '2016-06-27 15:45:30', '1467043371565.jpg', 'f7t4LCUsYDg:APA91bG8Qk3rVk8Gtf7Zy4syUCkqzsUy39bdtG869lJLzgs_zySevq-qsjUL149RUwivEOP1hXzOPjqmwEldnFO69xKO7ejgqashLCVCshd8PNvwdOQkYA_5Jc9qAr12e25Om13dLQR7', 1, 0, 0, '', '', 1, 469116, 0),
(239, 'Felix', 'Odigie', 'felix@myqapp.com', '6173881912', '2de5be3cf1cef0ad7d054ae0d231ce41', 1, 926552, '2016-06-28 03:08:08', 'user-profile.png', 'c39b042eb85b911d4fa8945e74347c1c5f93bb0531c42a89d2f5cfdca0c621e7', 0, 0, 0, '', '', 1, 931178, 0),
(240, 'Anita', 'Boateng', 'anitaboateng1@aol.com', '3474062535', 'c128ac948d5a36c23448bfcb4def6f64', 0, 802437, '2016-06-28 04:45:29', 'user-profile.png', '3d29c7ce5f53eb01c67f5d40aeee9960a3083e4c121197d2878db82cba0940f9', 0, 0, 0, '', '', 0, 288547, 0),
(241, 'Jessenia', 'Carrasquillo', 'jcarrasquillo90@icloud.com', '4049914198', '10af69de08a5aa2f86bf06c92c7dfe39', 1, 828183, '2016-06-28 06:35:49', 'user-profile.png', '1869f4809fdf09d82e55a05767bb4d6d526855e82190bf0b89c6958c0353f124', 0, 0, 0, '', '', 1, 326444, 0),
(242, 'Barbara', 'Horsley', 'barbiebabe115@gmail.com', '8018886538', '0dde07dd4c99c6bb41f2aaf9beb82ad3', 1, 870374, '2016-06-28 12:32:19', '1467360201779.jpg', 'cEMf7-GxBtc:APA91bGiijQoGc77feHGKVqymJfQfKGQm-xeEAhbGB2F5eDUOXVNHNwuz89ykuE0KJmHb4jBByto9VJMOUN0n4ve07ZO4BPJpF1rmDBbD0gd7wnjqWXI3fRwXWqPCeIbvKARVWg-FKag', 1, 0, 0, '', '', 1, 957107, 0),
(243, 'Brijesh', 'Bhakta', 'brijesh.lanetteam@gmail.com', '9898304401', '61c895e51d8b83de169b8f9a3fd45f82', 1, 896596, '2016-06-28 16:37:04', 'user-profile.png', 'dxlr38zW-dY:APA91bHym0V7YxLKy7v8LaCnHBByUFKm9gRWvOdNTuu7uvg9JeFbHySB8hNw9_UrrQEmt2mddeptgrIYTGytOK_ltz6Rii59Y1YleRxIU3EKmmBLjCd2ZgWymDYy4qORXwOseLEop4ba', 1, 0, 0, '', '', 1, 351846, 0),
(244, 'Kamilah', 'Carter', 'mimicarter007@gmail.com', '6783589025', '30fdb4b6b3a0cccf3dd3de45681c41fe', 1, 590824, '2016-06-28 18:57:50', 'user-profile.png', 'fX58MgkrqT4:APA91bHontaLLI6egTbp6pGfg2D36hOcD3TT4RsYhdgMtZ9JLT-TLvmAQ9UpKLphUv3MJ8x6TLSEqwwcRFWkbU0D0xt2Z3IWCdcEL3d-V7rJucmjlx9QEjgDW0nJCOsC4vxAA1nd7u1U', 1, 0, 0, '', '', 1, 915480, 0),
(245, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2038879349', 'df574db6ddf358c9cf111b82c56a56fe', 1, 882594, '2016-06-29 00:41:51', '1467161162621.jpg', '22baf75fb0f44f6139b10e4cc4b6df17682dee1458fba13df930a3d77ffe7423', 0, 753044, 0, '', '', 1, 881608, -1),
(246, 'Angelo', 'Pullen', 'apullen@mac.com', '4408044548', 'c6f078c4706c9c07e033cf189257bdce', 1, 230109, '2016-06-29 04:23:16', 'user-profile.png', '9a82a7a8e64eb53dd313b895cde9220230c1ec62d71ac8ae465469cf9473583f', 0, 0, 0, '', '', 1, 551893, 0),
(247, 'Alan', 'Liu', 'llwwzz36@gmail.com', '4122457236', 'a32fccc2d5dbc4b39e95dc5fb4607e94', 1, 561829, '2016-06-29 04:27:05', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 728601, 0),
(248, 'Kamilah', 'Carter', 'kcarter25@yahoo.com', '6783589025', '30fdb4b6b3a0cccf3dd3de45681c41fe', 1, 409307, '2016-06-30 14:34:18', '1467298113376.jpg', 'fX58MgkrqT4:APA91bHontaLLI6egTbp6pGfg2D36hOcD3TT4RsYhdgMtZ9JLT-TLvmAQ9UpKLphUv3MJ8x6TLSEqwwcRFWkbU0D0xt2Z3IWCdcEL3d-V7rJucmjlx9QEjgDW0nJCOsC4vxAA1nd7u1U', 1, 0, 0, '', '', 1, 243913, 0),
(249, 'Waulinda', 'Harris ', 'Waulinda@Gmail.com', '3476849032', 'd50bf1d1534491baebd71bc9d86aedfd', 1, 375474, '2016-06-30 15:19:29', 'user-profile.png', 'fdhWodZTkTs:APA91bFMG3j9nR_7GFfi8EIT_zr2sF7M7FouzDculdERO9hJoipmi4l7fMlCx5fuWZw3IJ-pkkbFFkSLVW-HfzTt_m9bW5sn5jMhYS5PYQ2lpt8CCHsK9JffVIgBzxOuJnyxn_A8Bjoj', 1, 0, 0, '', '', 1, 854164, 0),
(251, 'Ashley', 'Anthony', 'ashleynnanthony@gmail.com', '7703046301', '8f33d4ae5351058c16f33e6be9b9748b', 1, 149512, '2016-06-30 16:09:01', 'user-profile.png', 'b43b90e08991e5508308cea0a5f827ece75fb3c71d6861cb89e944f134f17813', 0, 0, 0, '', '', 1, 349614, 0),
(252, 'Ashley', ' Bennia', 'ashley.bennia@gmail.com', '9737276699', '8060bd3d3084bac78294d4e5e98db2d2', 1, 160705, '2016-07-01 00:53:58', 'user-profile.png', 'dQjS7K7dxS0:APA91bELEywQXAULVjaP1xsor3m9xa7d8--X8JAbowpVEjFPA2dI1RL6p72rbA9rDzMLwKjm77MyrDBHsFiWAurxXRKyZQwErIi-zmK_sc18QFu6qUXAPj-3KOaod3kJ_K2IhA2bs3pc', 1, 0, 0, '', '', 1, 570128, 0),
(253, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2038879349', 'df574db6ddf358c9cf111b82c56a56fe', 1, 654513, '2016-07-02 07:42:54', 'user-profile.png', 'c848829c74dcf48d3c7a109256d6b0bc39df06b66ace0e3dda95fda949f53442', 0, 753044, 0, '', '', 1, 868410, 0),
(254, 'Ruben', 'He', 'jrhernandez2@miners.utep.edu', '9154746047', '1bfa5ad9b6df629b5115bf6a50693960', 0, 815917, '2016-07-02 08:55:32', 'user-profile.png', '741b9bc3cedad0bdda701e75108da16836d703a088236957b4db726401dd0342', 0, 0, 0, '', '', 0, 907785, 0),
(255, 'Cheadee', 'Doe', 'cheadeedoe@gmail.com', '4043751600', 'c9d934eb2f74c2e0b44909cd7cf36054', 1, 862204, '2016-07-03 19:08:04', 'user-profile.png', 'eeb5373f8ddfdfe065dba28d7beaed59ab3fe48f861f252c9310e5c052391f9d', 0, 0, 0, '', '', 1, 361787, 0),
(256, 'Taja', 'Jackson', 'hill_taja@yahoo.com', '4192604385', '1bafcfa55eb70f7064f8fdfeff96c25e', 1, 599197, '2016-07-04 01:04:47', 'user-profile.png', 'fITkxkxGw88:APA91bHXdyJm5nf6ZtYepySbHHc2v9cG1goiKakyKbpkhNYxFn6ssKWFtL2c6MsuJx21HDes2j5SBhQ0yJwls_pdPA0_6RD61yPCnyueQyZdYvlEF-bIzu4WtCPLGSWqEbxNwScmZ8TZ', 1, 0, 0, '', '', 1, 473011, 0),
(257, 'Jamal', 'Jones', 'jamal.and.jones@gmail.com', '6099297013', '63d5718c8eefb353780d306ec401124c', 1, 227437, '2016-07-04 01:45:27', 'user-profile.png', '7ea7db180c4716030c1d1d334037daa701552e4ead9ff471162826f2f389da17', 0, 0, 0, '', '', 1, 656650, 0),
(258, 'Jake', 'Montagnino', 'jmonte98@gmail.com', '3478160721', 'f493da3dbc3eae54251ae7eb93485e24', 1, 127593, '2016-07-04 03:04:05', 'user-profile.png', 'b3c20c74154fbea1bc84c754c251be519238da2cab70bf33413490874d54fdb4', 0, 0, 0, '', '', 1, 180770, 0),
(259, 'Gina', 'Ramos', 'gramos98@yahoo.com', '3472556470', 'ed96a0035004529f335aabf8032ce982', 1, 321526, '2016-07-04 04:17:01', 'user-profile.png', 'db3b68742e289a6c9d07a7a1a05d4d34aafe4a914871e18576cf12fdb34c17b9', 0, 0, 0, '', '', 1, 524627, 0),
(260, 'Michele', 'Sawka', 'michelesawka@gmail.com', '4128979809', '901b1925348bafc95927477da938b000', 1, 864681, '2016-07-04 05:33:48', 'user-profile.png', '79277066c43c76795ca34a7b64335efa2266a899179d0d3f35a77b9750889c0c', 0, 0, 0, '', '', 1, 307045, 0),
(261, 'Cecily ', 'White', 'cecilylong19@gmail.com', '6788306836', '7b68a056e62b5e4c37555abb01f3ce9e', 1, 568361, '2016-07-04 06:15:02', '1467613369139.jpg', 'dTvqRJC8Xqk:APA91bEKU39PhLVHPF3C17eeCJy3hrrAs00PmepDLpBPeQkZTuswiNjx5Oxv5kBMwk_RrfTm-RF-8aEchOJ57W8ozCi4uhKap8SLU42xFdvCST16FlC7WylgotTLDEFadfneWKRZYzx9', 1, 0, 0, '', '', 1, 348003, 0),
(262, 'Taycia', 'Orr', 'taycia675@gmail.com', '7187089275', '81e9a04a493394eea9a4d43f516acb03', 1, 273636, '2016-07-04 17:25:18', 'user-profile.png', '6e5f6aa1b885da415d11da102ec890057de8b03771e225e2b1b6054e5b55f384', 0, 0, 0, '', '', 1, 511379, 0),
(263, 'David', 'Parmet', 'david@parmet.net', '9144004120', '2be5da916487774be70f5234a3f7a160', 1, 848186, '2016-07-04 18:15:14', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 334836, 0),
(264, 'Malene', 'Noel', 'malenenoel20@gmail.com', '3474854222', 'c8a3e684ea6ece8f653da48fe0609a8b', 1, 868030, '2016-07-04 18:48:40', 'user-profile.png', 'e9RVEhv1_QY:APA91bH0J71q_ZIpQGdychqURXKUxMso6ZED8KBuOIJ1mwAzQdWb7NUzbx8MVBu74IHxU9_xM_5vxrcHqBN6wct8T48P-i1gL2VUM1gi0sdJ8YoiLwdRkDaQvE0h_RvxeC4DdXyUFORc', 1, 0, 0, '', '', 1, 549669, 0),
(265, 'Wesley', 'Reeves', 'Wesrvs25@yahoo.com', '6268064841', 'b1a50cd7c822eb45b959d2be7c33de6d', 1, 592480, '2016-07-04 19:06:49', 'user-profile.png', 'fpfmRh8Ydkg:APA91bFU0EnSzWb_st1akoyK1YJscEj2OmUyqKz1DXwzMFdSrwgddx2zJU0JbyISpE2T7I5jIIhBpA3eOI0tJUXiry7XOYrwKRzUjKJnqdMYBgGaIP2BxGU328M7Dnvq_S-tqdaAvD0T', 1, 0, 0, '', '', 1, 288553, 0),
(266, 'Dan', 'Walters', 'danwalters6@gmail.com', '6513685913', '37ce81271c5eeddafa08aa5716f1b43e', 1, 136635, '2016-07-04 19:14:49', 'user-profile.png', 'f0df2df87a58bb53fc9cebe6d46f4ee3409e34b44f8f2b84ecb34f17ab7fe80a', 0, 0, 0, '', '', 1, 651304, 0),
(267, 'Adrienne', 'Moore', 'Admoore23@aol.com', '9175098032', '585fca2714bb560e320b963a91e0dd00', 1, 924392, '2016-07-04 19:16:30', 'user-profile.png', 'eS4OmUBqDyg:APA91bGz_gueUU0sdrYnrwom7xC4w-6Bgh05T-Pt1l92Pw-UE5yHPEINK9NubQNwU9mHRlcijAK68wIXNbGgKbX9eiUaAxl1YaU19V1u3w45JyHZLdzmluQNd5sohVKVnBGsDuAjmjX2', 1, 0, 0, '', '', 1, 852940, 0),
(268, 'Avery', 'Calhoun', 'averycalhoun62@gmail.com', '4706850090', '38a61f83d491656d6e0e2239acbb273a', 1, 766400, '2016-07-04 20:44:30', 'user-profile.png', '4939b24c2e0a85627813139ab7661ca1cc23d40a6895419794ee57f14f7812cc', 0, 0, 0, '', '', 1, 976013, 0),
(269, 'Jordan', 'Welder', 'jordanwelder09@gmail.com', '5159713593', '9ce24d07194be6dd2a42d18dfe8b194b', 1, 539767, '2016-07-04 21:08:57', 'user-profile.png', 'cYOyQuii598:APA91bESa6Yaa5ZKJZ77CnjL7oGNen-upxKW8HPmAZDHazt3Qm7qF8hdXTxfHWfNu4WPVnLcXYXhQuNx1dETkJ54u3xqvfFBRM41HXWeBsJdq0bi5A7x3Yy8SBIUziUwgglvI9XXhuvi', 1, 0, 0, '', '', 1, 296336, 0),
(270, 'Monica ', 'Kornblum ', 'monica.kornblum@gmail.com', '9177501482', 'a245bb19a460c198998dd1c0b4fb3ac5', 1, 424102, '2016-07-04 23:44:20', 'user-profile.png', 'eP4VVDl0uwk:APA91bGcNReyIYU0xb2OSdsKVc74JK6lR3js-dfKi45QYhoukE2r3sEtUHvguCj93oQ6nNNJbQHdLlE4MGy8ikVeoBjo1PgJTEcrg59gTf-4xcTN6BBM86Ux3Wg-8OcHgeZHf4YysD3o', 1, 0, 0, '', '', 1, 504611, 0),
(271, 'Crystal', 'Perkins', 'crystalcperkins@icloud.com', '6785279905', '916783fb03e5884c50e98449b8852b93', 1, 286031, '2016-07-05 00:00:17', '1467679589418.jpg', '6ed8dfd5cadf0c50e82d43af95e8adaa1c3813aade07909444ca4fd82f0a2a9c', 0, 0, 0, '', '', 1, 461650, 0),
(272, 'Gilda', 'Palacios', 'gildapalacios18@gmail.com', '9294423124', 'b7461dec13f2ff21b2e48af0ad09d30a', 1, 685454, '2016-07-05 02:51:58', 'user-profile.png', '684d50c7c65b03dfa735eac39ea366b4f6c8060fab96156f6c565716d06fdf35', 0, 0, 0, '', '', 1, 209599, 0),
(273, 'Nykiah', 'Morgan', 'nikkim2@msn.com', '5168526639', '6037e4ad83ed2d08fff1349098a8e75c', 1, 500057, '2016-07-05 10:01:30', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 563035, 0),
(274, 'Stephanie', 'Barquero', 'sbarquero91@aol.com', '9177036651', '72d3bb517666c7c5ebf75e43244eff9a', 0, 192668, '2016-07-05 12:34:26', 'user-profile.png', '6c50c52d1b6b55f683df30f0c300bf0ce5d9826bb0de61bab5325ad0ffe4638a', 0, 0, 0, '', '', 0, 679922, 0),
(275, 'Michelle ', 'Mosley', 'chelle_4334@yahoo.com', '4049096627', '7e2cd6933dc5d34162b078188a830e99', 1, 270597, '2016-07-05 13:18:57', 'user-profile.png', 'eFNgPSOry5Y:APA91bGwtRqRlvCAjZnnOiE8L38HPR9ep-_K2MhZZdx35GHBKCCDTzmjgr187PBKCEqI_rPIjedAe6Prf9e3X488JIyDN3O7yUN4CXx_HEMj7_T-5poxydFBqQWTMtra_BaGFRFydw1V', 1, 0, 0, '', '', 1, 710764, 0),
(276, 'Jeszenia', 'Jimenez', 'jvjimenez76@yahoo.com', '9177956847', 'f3e6204903cc7e4b0fa396608c53ca95', 1, 271590, '2016-07-05 13:38:28', 'user-profile.png', 'eX1ccW6yAws:APA91bFRKUA4TcyjIyoqt2umtXhkg0q9ioXzOjPZPuliPM8Cfcj4PnBX8Wi9UStw-pfvObWoEfnxDlwll0Js8mATARcjvLGfgozxpoGhlWexlunNP7TmUggffY5YKj32t_DfjfjJO5Kf', 1, 0, 0, '', '', 1, 941669, 0),
(277, 'Janiella', 'Franklyn', 'janiellafranklyn11@newdesignhigh.com', '3478560739', 'c9bde2ca2db07ef520e02405235cae18', 1, 867161, '2016-07-05 14:33:25', 'user-profile.png', '29307fbc596acd43c0ffe4714ebea094de449b2a817d5bfe932a5dd88952c9db', 0, 0, 0, '', '', 1, 890862, 0),
(278, 'Kassi', 'Lopez', 'kasilopez7@gmail.com', '6785992467', 'b6caf498d37e0f381ba849cc67342092', 1, 252582, '2016-07-05 16:52:15', 'user-profile.png', '4a0535f79c7acdab8225d2f1488d7592dabc53b842b2f9929aeda7cc0a8994d2', 0, 0, 0, '', '', 1, 550516, 0),
(279, 'Passion', 'Sims', 'passionmakella@gmail.com', '4703343939', '5b673e75d7637e86ea6456d73c81ab5a', 1, 167781, '2016-07-05 16:56:52', 'user-profile.png', 'fe9d5f2a5e4acf0ca2548dc6281875f799c5bd1000de29f739728e4522ad04ad', 0, 0, 0, '', '', 1, 745880, 0),
(280, 'Marisa', 'Peragine', 'marisaasaurus@gmail.com', '6316627942', 'e8e7604faf8c965f7871632688f5cc55', 1, 846888, '2016-07-05 17:01:16', 'user-profile.png', '5c6a78f86be165370672faff49fb3a9d8835b28f4b732939ae4282a799d33dfd', 0, 0, 0, '', '', 1, 636261, 0),
(281, 'Ashlyn', 'Nichols', 'ashlyn.nichols@icloud.com', '13103497018', '95bcdcc4c3f24ae6879cff0487dcf8b8', 1, 718913, '2016-07-05 17:09:19', '1467738683747.jpg', '4e86eb2a3e4d77dd653d4d21d34bed4099b8b863ed2d953739a7fc73f078482b', 0, 0, 0, '', '', 1, 559894, 0),
(282, 'Trashekia', 'Herndon ', 'trashekiaherndon@yahoo.com', '3343843502', '593355250ca2fd58b5f95fd0a3d351d6', 1, 689588, '2016-07-05 17:14:15', 'user-profile.png', 'e9emDEebF5E:APA91bHOudrGcwjnSeN587aaqErIKtFk2A9GuX-C0JOg_OzCil0bLaW7xhQXw5XD3CgzpSlcBVLHN6a0OI5O-dRXGdTMxOok0MxV825IoIiEiLh5bOXueoeh5kwAroAvkoVjklZZLehQ', 1, 0, 0, '', '', 1, 125703, 0),
(283, 'Shernette', 'Hyatt', 'shernettehyatt@gmail.com', '5163680282', 'e0530b3c80fdd96548fe5baf359210e2', 1, 734297, '2016-07-05 18:34:51', 'user-profile.png', '30619990e8252860b00412048fe87e5be2db5ded119ec5f6dcc387b1d2abd5e9', 0, 0, 0, '', '', 1, 730108, 0),
(284, 'Matthew', 'Mcdearmont', 'mmcdearmont@gmail.com', '7706807774', '4edb37609a2f7a736d26791c56a42fd0', 1, 697951, '2016-07-05 19:03:01', 'user-profile.png', '123d2d42704763833af88d27fa1a6fef5c7dfcb318245c57052672d6a6cbf473', 0, 0, 0, '', '', 1, 858176, 0),
(285, 'Michelle', 'Mayer', 'mellymay643@gmail.com', '9175334203', '80ea187491d423bda90f494c4b0aee0d', 1, 202856, '2016-07-05 19:14:51', 'user-profile.png', 'e0243d176420efc440f7bc0fed786f44bd4d10b7ccc5889d6afb68b0650d9b93', 0, 0, 0, '', '', 1, 349171, 0),
(286, 'Adam', 'Silverstrim ', 'ajsilverstrim@gmail.com', '6178187846', '4899378a9c402b2cebee746be67a64a7', 1, 435220, '2016-07-05 19:43:19', 'user-profile.png', 'fw_CdOy7f9g:APA91bF34EUts0sR0nTibREgtwpzaPeYiS4m3OsDUHH1Etdt2easc-cWM7ZUeQSM1SzjCJ6m_Xuxr2HgmLkzfObgcrjumQT4zs0CNx4p_SBlz72W6HlsQHYKUGDRO5Y7bQeHE8pHJ2_4', 1, 0, 0, '', '', 1, 611575, 0),
(287, 'Shirley', 'Rocha', 'sjr0115@gmail.com', '3479771733', 'ca7eeb90968027c077efb35b80cb7214', 0, 733876, '2016-07-05 20:58:04', 'user-profile.png', '3d33d5a1c657eb83924dff96325a978756e9666d92a5e13f379282b0b1a5fb40', 0, 0, 0, '', '', 0, 143720, 0),
(288, 'Kirstin', 'Smith', 'kirstinsmith1420@gmail.com', '3105910707', '5c2397a3dcd161e2fbfea8c3cf486169', 1, 981305, '2016-07-05 21:30:08', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 897034, 0),
(289, 'Dafanie', 'Chikumo', 'jolea21@yahoo.com', '7708829565', '4dc6d0f7d032b65dddd7c690f11725a1', 1, 982980, '2016-07-05 21:39:33', 'user-profile.png', 'dSW-uh6SpB8:APA91bFx9as6F80jNzbbLiaHA3ppJqGwlLCwZA1lf1K6GXHbBFYG9f0SOzDV6ikAURHMS3RaDdg5QwgNA7i75ak4UzYfngLj6qdEKm0a3ZuYzFK9g-Q-j8kEuGFLzRz3JoiSlIxzTGWj', 1, 0, 0, '', '', 1, 338818, 0),
(290, 'Roxie', 'Lewis', 'roxiedlewis@gmail.com', '6616749056', '4032818c0571cc734391c4542be4055b', 1, 364175, '2016-07-05 21:47:25', 'user-profile.png', 'euyjj2FsFfg:APA91bHWh3MuOw2_ELVxia0dYhlbmTksl3SvTIlg1OiDxP5xhRm_LeW9oYS1F4gJE0qQ_L2Rsp4LQrHqdrSMdTmr4aH_wSTBhjSuI-OMiJikGyJ2jhg2pgcPZ0uqJbCK1mozVft6iuyR', 1, 0, 0, '', '', 1, 442187, 0),
(291, 'Robin', 'Coleman', 'rcoleman1218@gmail.com', '6786700360', 'ce6f69198e9de2704d77be0639603b34', 1, 524942, '2016-07-05 23:23:51', 'user-profile.png', 'eySK2I7M1Hs:APA91bFPE1oCrSux2DreTU_IQvz5u1KFGdwUlYWk8jhK6lDWD30fyhhfXkRq-QVNCuBOyVoqep6vXZ15WUiGdm0EvqTel3AkzSbCa8TBPp96F1fSN8abCnPsBMB8CjnFL7AfK70Q1net', 1, 0, 0, '', '', 1, 909311, 0),
(292, 'Teresa', 'Brown', 'tree866@gmail.com', '4049529687', '1484d9ceeec04f01497f7ed990acedff', 1, 739000, '2016-07-05 23:42:48', '1467762869330.jpg', '383903216e2cf117cb4255ab27b4947e304886bd468a1802d0ae282d9b4d7843', 0, 0, 0, '', '', 1, 732268, 0),
(293, 'Parasia', 'Cook', 'parasiac@gmail.com', '6784994324', 'dc7e681bfaf7a3a1e9a4d255b225d85b', 1, 124297, '2016-07-05 23:56:17', 'user-profile.png', 'dXy2_4guH-U:APA91bG5bRpWbTjHwesEtmK0YhjfRC0ny07D7RAeSEbnUj_eDdtpReHHUl4I0CWDyq8vn9mAtVgVfAgLb3ciZj33unrO16068FyklJRWcU3ECM7A0-E0HI_SlE4v0rDK0gXBKcA_WQng', 1, 0, 0, '', '', 1, 430525, 0),
(294, 'Brincisky', 'Quinonez', 'brincisky@gmail.com', '3476846243', '78ebf44f92ffa944736b293fad677ceb', 1, 344002, '2016-07-06 04:11:39', 'user-profile.png', '1fd6bdbb64a3bcc5db709e570af0c00519d83fa2ba24f4c8448b31aece685141', 0, 0, 0, '', '', 1, 241551, 0),
(295, 'Kibwei', 'Mckinney', 'kibweim@gmail.com', '2022564753', '3548d6a64f17e4e22ddaf8f05027b7c2', 1, 238591, '2016-07-06 04:54:37', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 110700, 0),
(296, 'Darshea ', 'Allen', 'darsheaa@gmail.com', '6785166504', '04883b769b4b43f0bb79f9e3d8ae9582', 0, 802229, '2016-07-06 05:11:00', 'user-profile.png', 'dy74663LFZY:APA91bEak8t6-FwV-IJg9R86vT1NL4kt2-86Z-kQq7MVrQnhWABfizwaCxcY-aeoA7N46fEjiV0uBv-UO_BSTUJSgX7bP5Q75eyuj0AylamC1co39iHKO1QT3BCnimOc7KPUa1XhXb_2', 1, 0, 0, '', '', 0, 560732, 0),
(297, 'Tara', 'Sazegar', 'tsazegar40@gmail.com', '3103876275', 'd58d75d5d1abb0f8baa5d89a031a824d', 1, 730074, '2016-07-06 05:33:55', 'user-profile.png', '6672c48ad3de05ec273eccb668ee677b54dd01e35b2218fc4397af105a88de3a', 0, 0, 0, '', '', 1, 413899, 0),
(298, 'Jessica', 'Braunstein', 'jsbraunstein1@gmail.com', '5163828705', '917e14be5404ab01be8721acd99e1573', 1, 311098, '2016-07-06 05:47:45', 'user-profile.png', '71c2af5223a3f0365571284be2a6efbfc01dd9cbd156d0b47e2dda04a0a02b1b', 0, 0, 0, '', '', 1, 218843, 0),
(299, 'Rebecca', 'Clouse', 'beccaclouse@gmail.com', '9166072043', '41e93823272ecbefaa0d052e4a73e395', 1, 626622, '2016-07-06 09:25:41', 'user-profile.png', 'a78e4523e670f9c2a5c37e4a43831801d2475f5d41628fcc2344178100c99de3', 0, 0, 0, '', '', 1, 789475, 0),
(300, 'Tyneshia', 'Pitts', 'tyandnas@gmail.com', '7064617790', 'a5caff1f9fa22c3912a639ee9a311f61', 1, 536647, '2016-07-06 09:30:33', 'user-profile.png', 'fmMzJxEDpDs:APA91bF5kmPpS3niN5AjR4Xx7Cbe29ZwZT6zBi2iFJ4d-3iim9wH8ofG9vuS2fwaSwprXzvDcK2Gb3sNxD5Mm0xqvxZrZ4x_jWYlx4LufYQjaqKajUydC_phzAsM3IbCc6-k8rGeN-Ny', 1, 0, 0, '', '', 1, 257324, 0),
(301, 'Ashley', 'Amarante', 'ashleya0730@gmail.com', '3475069691', '4ce27087bb4e7b809ff90956b12650be', 1, 491209, '2016-07-06 16:06:30', 'user-profile.png', '49091b0e36c4f12f7aa7c31104540de2ea01b18eda66ff0100492298fd16c21d', 0, 0, 0, '', '', 1, 470130, 0),
(302, 'Star', 'Davis', 'stardavis8@gmail.com', '7062063919', 'ca0d589b7886f0f7303078f3f0dd3f18', 1, 298743, '2016-07-06 16:15:49', 'user-profile.png', '4eb9be953fffd3607d1a3da2044485582fbb111fc44dc13cf4d818bb9dbc91b1', 0, 0, 0, '', '', 1, 478215, 0),
(303, 'Shakeshia', 'Cole', 'shakeshiac1@gmail.com', '7737260802', 'f89f36c7477b2861e1cc0d692352c7c5', 1, 145210, '2016-07-06 17:58:02', 'user-profile.png', 'c6diyZLjmpA:APA91bH0sdeLb8wXbzOw2idiavcfEtHKI98PN7ujlckekbLMkTABMKP1ZDLvLDUFpdBNPp1nn6BhVSdac3d2hSmjE6cwEnNp03iOLgXSOsmhz-v7LGuy7Xy2ueP3fhPKkSXxnNUC-FNm', 1, 0, 0, '', '', 1, 618122, 0),
(304, 'Arian', 'Sanders', 'asanders5138@gmail.com', '9122282051', 'd796adaa662f9c4636ed4fb46e678874', 1, 389544, '2016-07-06 18:14:26', '1467829439209.jpg', 'b0019caab399ed2aeab1d2bf564498285cea0e185ac50a7ff8c8d8d750603a15', 0, 0, 0, '', '', 1, 455424, 0),
(305, 'Kiana', 'Sledge', 'kianadionee@aol.com', '7188254729', '2c15a2a954e933d2f9b1db5e6fddd7e4', 1, 818026, '2016-07-06 18:24:47', 'user-profile.png', 'ce6a52f1b8beeaa5446e136dce8abbaab217064b6c80af57e1dc6bd4f51b5ec1', 0, 0, 0, '', '', 1, 159894, 0),
(306, 'Tanner', 'Akman', 'tanner.akman@gmail.com', '3109209612', 'fb21ee566fbb537ad57df94fadf29e2d', 1, 114321, '2016-07-06 19:13:14', 'user-profile.png', 'dKhOo-Kd2SA:APA91bEy-_4PiHEfGJ2U4rwp08iazSMEQLA0HIizg0kl2ORTeYArtNFlU8InRrLt1uNV-S5RM50ccMQRi-z0xZSefPlOeR4puthDQMeeE48foxIGYVkkLSH8WER6pL4POQgLU_-6S4KA', 1, 0, 0, '', '', 1, 162190, 0),
(307, 'Jacqueline', 'Diaz', 'diaz.jackie78@gmail.com', '6193095286', '54ad65eddde10a4d63e88e9af1c2010c', 1, 262343, '2016-07-06 19:43:34', 'user-profile.png', '6e5614252a15e1abaf2c8463c2a70af370102d3f4ecae82d08a4a95d2c516f36', 0, 0, 0, '', '', 1, 261735, 0),
(308, 'Janequa ', 'Johnson ', 'janequanixon4@yahoo.com', '4049075860', 'f43fa677382ed5dc1de33594633b9f87', 1, 689719, '2016-07-06 22:55:40', 'user-profile.png', 'cdUPXZGAETc:APA91bHcJ_AXDVo_p0CjCEnMXAw1LkZB85s6gEh_ZEjk7y9sdkmiZuqQEqEXwPTA_zMqre902-P4FOmDkkRBaA288F0klbRqqflVlH7qrby2noFTkDD4KjwFq2ddEtQ1IYCc6UqX-hlZ', 1, 0, 0, '', '', 1, 541345, 0),
(309, 'Tetrianna', 'Beasley', 'tetriannas@gmail.com', '4046808694', '7e203d2911ea45e674a0a4439538880a', 1, 191560, '2016-07-06 23:41:03', 'user-profile.png', 'f1c43aec82638ea1e927a32d95b731cbe0218ccec2e6501ac648ee55c40ef002', 0, 0, 0, '', '', 1, 227081, 0),
(310, 'Janel', 'Wallace', 'jjwallac@aggies.ncat.edu', '9803228502', 'd6a654030551c7cee95245de94bcf189', 1, 202286, '2016-07-06 23:55:10', '1467849756159.jpg', 'c0tD-1Ca0Ao:APA91bFG_usRF5cxyiQRl---YqZnkmOvHPJlMWNp3uKiTJdcfv5DEtA7vjsF4gIBxXyfStYCqes2tR62_se31t7bgQQkkaIJZqnec_A4PzC_vaRF3mmw8alBF6M_Z3AxiF2DbV5TVl24', 1, 0, 0, '', '', 1, 806971, 0),
(311, 'Alex', 'Junior', 'alexbadine1@yahoo.com', '3477755975', '0c1e89fae405daab9c8035b25a633ea6', 1, 343333, '2016-07-06 23:59:14', 'user-profile.png', '82dab30d5fafda14a9529035d33ba5a498c8d2ef644bb3ba2b08de0476567d72', 0, 0, 0, '', '', 1, 627977, 0),
(312, 'Carmen', 'Echeverria', 'ecarmen99@yahoo.com', '3238757411', 'd213a137012dae4b44cabddb524243d6', 1, 942818, '2016-07-07 00:19:28', 'user-profile.png', '4bc4111bd840001df1d82877de5767bb0517fe4633e5234f628f7e59fefbbd9e', 0, 0, 0, '', '', 1, 623843, 0),
(313, 'Brandon', 'Lowmark', 'lowmarkb123@gmail.com', '5703509005', '9e9f9b690af7a01538962d6001c697e9', 1, 452382, '2016-07-07 00:40:55', 'user-profile.png', '824ba3d3b82cb88621aa7c6421d601782ce3c062b79f5660f269067f3406d14a', 0, 0, 0, '', '', 1, 885956, 0),
(314, 'Ibinka', 'Stone', 'fullfigureblackbarbie@gmail.com', '9013149946', 'e5bb1109e08b353ebc7498d1994345f4', 1, 223943, '2016-07-07 02:25:22', '1467859032684.jpg', 'cL6u4WOdCJo:APA91bFDStL-mqLpvFOqLCD4bzcCpqwF9vGTXatmYVjXxpgz6quygouU62oF0-DoLb2pKqAsxc-I2AgZrRxF7FfizjM3H5nv_zP-xwoqxqNiV55Z4GMt3iPTh9XVWJ6gDBnbl5r1V-Vd', 1, 0, 0, '', '', 1, 798493, 0),
(315, 'Diogenes', 'Dejesus', 'diogenesdejesus1995@gmail.com', '3474916064', '2a7cd1ef3fe5d1c8e04ef42543ee6761', 1, 380066, '2016-07-07 03:00:20', 'user-profile.png', 'eA3ztT4ADsk:APA91bF7OjbhyX461adhQEr1t6gp7xhbi-xIUlno8TW03jWnyVkcbePqtdXfPmCbyVrUyf81q0ihcWmumBWekeLP0Al4NUREw1Idm2xHq_Ix0gDoixzmuTHul1F250zH2KAz_9APg55O', 1, 0, 0, '', '', 0, 418789, 0),
(316, 'Juan', 'Ramos', 'juanramos285@gmail.com', '3473394119', '3eb45e2ae2141e63d85f4386aca4a756', 1, 431569, '2016-07-07 04:32:16', 'user-profile.png', 'fEYBhQNWWVI:APA91bGzpTG_WlzcgWKPnTnYrCBHqfMuuwy_4rjXpDPpVzW3masa4fXQWFLFnOYwY9UElWdUx-4TFLD1TLH1H4TqgbB-4ArPPn_3q__8PDGU0MBUxIa3ttbLKwSl66mE08IjqGl3c0Hh', 1, 0, 0, '', '', 1, 573466, 0),
(317, 'Vanessa', 'Lemaistre', 'vanessadiane7@gmail.com', '3236312434', '1a2a60c9da9eebaf157bfd0708c23ffa', 1, 766867, '2016-07-07 07:24:11', 'user-profile.png', 'fe2d87a04741d6a90330266f38772f8b7b24091027eff4ba1591bded18cb4b3b', 0, 0, 0, '', '', 1, 488822, 0),
(318, 'Nina', 'Blake', 'ninasimone.mb@gmail.com', '9145229912', '62859513a941ad5352b18c95037e339d', 1, 435186, '2016-07-07 11:39:13', 'user-profile.png', '4fc12fa22125ee4d022561e3cb52186f5968ebeb6d094dd2c44a9e1089feb50d', 0, 0, 0, '', '', 1, 934636, 0),
(319, 'Niyan', 'Richardson', 'niyanrdson@gmail.com', '3479251526', '688fcee214fc83dbb5fc2bba777011a5', 1, 226367, '2016-07-07 12:25:47', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 304669, 0),
(320, 'Meaghan', 'Mcleod', 'meaghan.mcleod@yahoo.com', '9144717382', '906df36b7524b20f46b8ecc028481424', 1, 969923, '2016-07-07 13:22:24', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 276727, 0),
(321, 'Jassiah', 'Mcnulty', 'jassiah96@gmail.com', '9147519937', '2e9cd0945a9ff8163bcfface4016b8fd', 1, 531845, '2016-07-07 17:10:38', 'user-profile.png', '1e03f4f5fe89a2c76e1f00d970badba795e87916f897b72aab4ed05b90a5c808', 0, 0, 0, '', '', 1, 456782, 0),
(322, 'Liqun', 'Cai', 'cailiqun123@gmail.com', '8053589458', '1fd595bdcd8630d006ca015a12cbc113', 1, 955140, '2016-07-07 17:23:10', 'user-profile.png', '3ac37d56c8a05e83317d512d1451aa0c83707d87f500fa82f19434653f9d83b5', 0, 0, 0, '', '', 1, 969850, 0),
(323, 'Priya', 'Bond', 'bondpriyabond@gmail.com', '8157157079', 'f18f7756b93c71fb036c8548eb61df57', 1, 751511, '2016-07-07 19:41:42', 'user-profile.png', '47ef063a0d24161d186587c1fef0be7fbd1251dbb94664f826b938f2671ee682', 0, 0, 0, '', '', 1, 170876, 0),
(324, 'Anjanette', 'Woods', 'anjanetteceo@aol.com', '3235612151', '437bdcbcef23a99f0e5aada99bfc2df7', 1, 650658, '2016-07-07 20:14:15', 'user-profile.png', 'ac627617ffd4d8c3284608e475deb20fae01660c52e10142f51e7091aad159c6', 0, 0, 0, '', '', 1, 869132, 0),
(325, 'Brittany', 'Louis', 'louisbrit1990@gmail.com', '7329771177', '5209d5293ab85eba6ec2704e94057813', 1, 875839, '2016-07-07 22:20:10', 'user-profile.png', '2a834e07205b143cd74a4ed5234a92a33c688b619a78c9217e8f47bd99978c2c', 0, 0, 0, '', '', 1, 273178, 0),
(326, 'Phil', 'Zaikovatyy ', 'pzaikovatyy@yahoo.com', '8186212531', 'a5087de93fba4ad4932b9221ff31d41d', 1, 600128, '2016-07-07 22:23:21', 'user-profile.png', 'fUBseVCBY9w:APA91bFBMgZOErrcaaFb-PAnTim2XaIrlk8xm4gVM_FOYOPjYJ-MFyNodfSTfMja19AKojDfhSQq3r52jPKWa-zJmgPRZJfwdJcwHsy838mleYKi15f3VDKsXngmQ_dJu2scufZ3jm48', 1, 0, 0, '', '', 1, 931668, 0),
(327, 'Shuneka', 'Andrews', 'shuneka.andrews@gmail.com', '4045429503', 'ab71a923cf896b7ffbad8f075241a2da', 1, 163346, '2016-07-08 01:27:28', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 301344, 0),
(328, 'Ivy', 'Ayling ', 'ivy.ayling@gmail.com', '3474441071', '452590b2b379e6c31a9f460affd0ecc3', 1, 100647, '2016-07-08 02:49:47', 'user-profile.png', 'evXxotpoQ7M:APA91bGUV6dOqOVV5HLn6fxCu6mJbyhHACBnmBbxpM3ITbAW9vrkOxRMmhS9S9AZmEuoNfptmRCA5XlVWJmTZ7IEzDreNkdoCl6wT_QXyFOF4Y-M1k4WTihU_1jsTpJxZ760Hgq4kt7_', 1, 0, 0, '', '', 1, 136230, 0),
(344, 'ishani', 'shah', 'lanetteam.ishani@gmail.com', '9429796373', '61c895e51d8b83de169b8f9a3fd45f82', 0, 653762, '2016-07-13 11:32:27', 'user-profile.png', 'fs-T7YFmZM4:APA91bG_xQU4224jLDFTS-nJTox3Oi5UXYv3lpS4aBDwqWUSNP-DntzBThMy0SKNLnKq8jDmlqvsS8ZztNQQ0teaNIoQKuo-XyIQQEYj3aXILznVRi4CyHV1da49C0e2Q1yNfZe66kJ1', 1, 0, 0, '', '', 0, 663967, 0),
(345, 'Yamini', 'Tailor', 'lanetteam.yamini@gmail.com', '7845123960', '61c895e51d8b83de169b8f9a3fd45f82', 1, 972630, '2016-07-13 12:16:41', 'user-profile.png', 'dZXD52Bfj-Q:APA91bF1WOpY4FDP1N3PfBA8DhwVzV0gO0v38OjKh7005unvS5U7NL1G0QqwRtTp67y3gFFnQ6ge22wHo2IamJeMh64N1EmeeWpIQ0PbgtVITLyQfV0wT7UA-2rjB2CDK_FFdLJuvaiO', 1, 862819, 0, '', '', 1, 477495, 0);

-- --------------------------------------------------------

--
-- Table structure for table `userCard`
--

CREATE TABLE IF NOT EXISTS `userCard` (
`userCardId` bigint(20) NOT NULL,
  `userId` bigint(20) NOT NULL,
  `cardNumber` int(11) NOT NULL,
  `cardToken` varchar(255) NOT NULL,
  `stripeCustomerAccount` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userCard`
--

INSERT INTO `userCard` (`userCardId`, `userId`, `cardNumber`, `cardToken`, `stripeCustomerAccount`) VALUES
(1, 1, 4242, 'tok_18AemjFPPcEdaZL8RS6rjEW3', 'cus_8RXsS0g3uozXSc'),
(2, 2, 4242, 'tok_18AfD8FPPcEdaZL8u3kFrnh7', 'cus_8RYJrDrcx7Eyxi'),
(3, 5, 4242, 'tok_18S33fFPPcEdaZL8g0ulJ3jE', 'cus_8RZQ5ejN8CRkVk'),
(4, 7, 4242, 'tok_18BD4eFPPcEdaZL8aK9A6FJp', 'cus_8S7JDOPgPIYP8m'),
(5, 6, 4242, 'tok_18BHVPFPPcEdaZL8YfrRjDBN', 'cus_8SBssB9YPve2od'),
(6, 8, 4242, 'tok_18C5w8FPPcEdaZL8uxM2BHug', 'cus_8T200vTYt887GA'),
(7, 12, 9936, 'tok_18EiJQJxXxi1ARvC8YA5Oglz', ''),
(8, 14, 3015, 'tok_18Gf5FFPPcEdaZL8jxOwIlJA', ''),
(9, 19, 4242, 'tok_18GvbuFPPcEdaZL8f9R8hMpN', ''),
(10, 22, 4242, 'tok_18HcFrFPPcEdaZL8e3ne9dub', ''),
(11, 18, 4993, 'tok_18TPfvJxXxi1ARvCUKBLoNC0', 'cus_8kvXrtLwIdKUC9'),
(12, 33, 4242, 'tok_18KxsrFPPcEdaZL8c2Ehj2HF', ''),
(13, 59, 604, 'tok_18L041FPPcEdaZL8JjplkRrC', ''),
(14, 63, 9855, 'tok_18LwrpFPPcEdaZL8Fv8uwbZT', ''),
(15, 64, 9501, 'tok_18LxVDFPPcEdaZL8xymks8jv', ''),
(16, 77, 1751, 'tok_18ML3GFPPcEdaZL8jnwr7J8n', ''),
(17, 117, 3015, 'tok_18N6YbJxXxi1ARvClAg38ClU', 'cus_8ePNYIbKPMB11e'),
(18, 120, 9212, 'tok_18NBVlFPPcEdaZL8n4bNwKIh', ''),
(19, 98, 1284, 'tok_18NCMaFPPcEdaZL8fEGLxCiE', ''),
(20, 67, 4242, 'tok_18TdiSJxXxi1ARvCxaz92bqG', 'cus_8jhy6aNHj4Nwdy'),
(21, 16, 3691, 'tok_18NVssFPPcEdaZL80Kx3gtHF', ''),
(22, 147, 2719, 'tok_18OT9rFPPcEdaZL8JprC2XKw', ''),
(23, 188, 4993, 'tok_18P1JMFPPcEdaZL8zAigF6BD', ''),
(24, 17, 4993, 'tok_18P1egJxXxi1ARvCXcvWfdUE', 'cus_8gORau5YbRJ55m'),
(25, 156, 5739, 'tok_18P5r1JxXxi1ARvCK3zWkVXK', 'cus_8gSmZUXlA8xRng'),
(26, 205, 4242, 'tok_18ToPRJxXxi1ARvCSgzcMCxT', 'cus_8lL41Gp8rWqjGK'),
(27, 210, 4472, 'tok_18PbroFPPcEdaZL8ZkzTEg1a', ''),
(28, 209, 844, 'tok_18PcW8FPPcEdaZL8g8SGMoJV', ''),
(29, 166, 3018, 'tok_18QH22FPPcEdaZL8fTnPMhcn', ''),
(30, 236, 4993, 'tok_18QqlmFPPcEdaZL8WLR3Btbj', ''),
(31, 239, 3015, 'tok_18SFbXJxXxi1ARvCzyFvJdfd', 'cus_8jj3T72fy7o2nU'),
(32, 123, 4423, 'tok_18RQmYFPPcEdaZL8PfzYoB7l', ''),
(33, 245, 4993, 'tok_18ShcUFPPcEdaZL8MCyU5GWp', ''),
(34, 223, 8066, 'tok_18RpaEFPPcEdaZL8cHSdu3zx', ''),
(35, 4, 4242, 'tok_18S2cZFPPcEdaZL89RsfhioX', 'cus_8jVdGbCCHks3ho'),
(36, 54, 3902, 'tok_18Sy0VFPPcEdaZL8wf12oBbA', ''),
(37, 253, 4993, 'tok_18TyavFPPcEdaZL8hdQGEpBZ', ''),
(38, 268, 7666, 'tok_18TyyqFPPcEdaZL8MPfXIUs7', ''),
(39, 322, 7697, 'tok_18UgFvFPPcEdaZL841P9gxXQ', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `qProvider`
--
ALTER TABLE `qProvider`
 ADD PRIMARY KEY (`qId`);

--
-- Indexes for table `qRequest`
--
ALTER TABLE `qRequest`
 ADD PRIMARY KEY (`qRequestId`), ADD KEY `qrequest_ibfk_1` (`userId`);

--
-- Indexes for table `qRequestAccept`
--
ALTER TABLE `qRequestAccept`
 ADD PRIMARY KEY (`requestAcceptId`);

--
-- Indexes for table `qRequestBillImages`
--
ALTER TABLE `qRequestBillImages`
 ADD PRIMARY KEY (`billImageId`), ADD KEY `qRequestId` (`qRequestId`);

--
-- Indexes for table `requestSentToQ`
--
ALTER TABLE `requestSentToQ`
 ADD PRIMARY KEY (`notificationId`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
 ADD PRIMARY KEY (`state_id`);

--
-- Indexes for table `stopDetail`
--
ALTER TABLE `stopDetail`
 ADD PRIMARY KEY (`stopDetailId`,`qRequestId`), ADD KEY `qRequestId` (`qRequestId`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `userCard`
--
ALTER TABLE `userCard`
 ADD PRIMARY KEY (`userCardId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `qProvider`
--
ALTER TABLE `qProvider`
MODIFY `qId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=226;
--
-- AUTO_INCREMENT for table `qRequest`
--
ALTER TABLE `qRequest`
MODIFY `qRequestId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=400;
--
-- AUTO_INCREMENT for table `qRequestAccept`
--
ALTER TABLE `qRequestAccept`
MODIFY `requestAcceptId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=128;
--
-- AUTO_INCREMENT for table `qRequestBillImages`
--
ALTER TABLE `qRequestBillImages`
MODIFY `billImageId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `requestSentToQ`
--
ALTER TABLE `requestSentToQ`
MODIFY `notificationId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=947;
--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=64;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `userId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=346;
--
-- AUTO_INCREMENT for table `userCard`
--
ALTER TABLE `userCard`
MODIFY `userCardId` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=40;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
