var url = require('url');
var express = require('express');
var router = express.Router();
var user = require('../model/tbluser.js');
var mail = require('../model/mail.js');
var email;

//==================================== call when user click on confirm button ==============

router.post('/resetPassword',function(req,res,err){
  user.resetPassword(email, req.body.confirmPassword, function (err, data) {
            if (err)
            {
                  res.json({status: '0', msg:'error'});
                  return;
            }
            else if(data.affectedRows > 0)
            {
                  res.send(data);
                  return;
            }
            else
            {
                  res.json({status: '0', msg : 'Unable to reset your password. Please try again.'});
                  return;
            }
  });
});

//=============================== call this route from link sended in mail=======================

router.get('/forgotPassword/*', function(req, res, next) {
  var url_parts = url.parse(req.url, true);
  var query = url_parts.query;
  user.forgotPasswordLink(email,req.query.random, function (err, data) {
          if (err)
          {
                res.json({status: '0', msg:'error'});
                return;
          }
          else if(data.affectedRows > 0)
          {
                res.render('forgotPassword');
                return;
          }
          else
          {
                res.send('You can not use this link again');
                return;
          }
  });
});

//======================================= forgot password ================================

router.post('/forgot',function(req,res,err){
  if(req.body.email == "" || req.body.email == undefined)
  {
        res.json({status:'0',msg:'Please enter your email address.'});
        return;
  }
  random = Math.floor(100000 + Math.random() * 900000);
  user.forgotPassword(req.body.email, random, function (err, data) {
                if (err)
                {
                        res.json({status:'0',msg:'error'});
                        return;
                }
                else if(data.affectedRows > 0)
                {
        				        email = req.body.email;
                        var link = "<a href='http://23.253.244.141/forgotPassword/?random="+ random +"'>CLICK HERE</a>"
                        mail.sendEmailForgot(req.body.email,link, function(err,data){
                          if(err)
                          {
                                      res.json({status:'0',msg:'Unable to send email.'});
                                      return;
                          }
                          else
                          {
                                      res.json({status:'1',msg:'A link to rest your password was sent to your email.'});
                                      return;
                          }
                        });
                }
                else
                {
                      res.json({status:'0',msg:'wrong email'});
                      return;
                }
    })
});

module.exports = router;
