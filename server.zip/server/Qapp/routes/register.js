var expressJwt = require('express-jwt');
var jwt = require('jsonwebtoken');
var settings = require('../config/database');
var nodemailer = require('nodemailer');
var mail = require('../model/mail.js');
var random;
var user = require('../model/tblregister.js');
module.exports = function (app) {

    //====================================================== register ============================
    
    app.post('/register', function (req, res, next) {
        if (req.body.fname == "" || req.body.lname == "" || req.body.email == "" || req.body.mobile == "" || req.body.password == "" || req.body.fname == undefined || req.body.lname == undefined || req.body.email == undefined || req.body.password == undefined || req.body.mobile == undefined || req.body.deviceToken == "" || req.body.deviceType == "" || req.body.deviceToken == undefined || req.body.deviceType == undefined) {
            res.json({ status: '0', msg : 'Please enter all required data.' });
            return;
        }
        random = Math.floor(100000 + Math.random() * 900000);
        mobileRandom = Math.floor(100000 + Math.random() * 900000);
        user.registerNew(req.body.fname, req.body.lname, req.body.email, req.body.mobile, req.body.password, random, req.body.deviceToken, req.body.deviceType, mobileRandom, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'error in sql syntax' });
                return;
            }
            else if (data[0][0].msg == 'exists') {
                res.json({ status: '0', msg : 'The email address you entered already exists.' });
                return;
            }
            else {
                var profile = {
                    id: data[0][0].userId
                };
                var token = jwt.sign(profile, settings.JWTPrivateKey, { expiresIn: settings.expiresIn });
                userInfo = {
                    "userId": data[0][0].userId,
                    "firstName": req.body.fname,
                    "lastName": req.body.lname,
                    "email": req.body.email,
                    "mobile": req.body.mobile,
                    "isEmailVerified": "0",
                    "userProfile": "http://23.253.244.141/images/user-profile.png",
                    "qId": "",
                    "registrationStepCompleted": "0"
                }
                mail.sendEmail(req.body.email, req.body.fname, random, function (mailErr, data) {
                    if (mailErr) {
                        res.json({ status: '1', msg: 'There was an error sending the verification email.' , userInfo: userInfo });
                        return;
                    }
                    else {
                        res.json({ token: token, status: '1', msg: 'Your Account has been created successfully', userInfo: userInfo });
                        return;
                    }
                });
                mail.twilioSendMsg(req.body.mobile, "Your Q Now mobile phone verification code is " + mobileRandom, function(msgErr,data){
                                if (msgErr)
                                {
                                    console.log(msgErr);
                                }
                                else
                                {
                                    console.log(data);
                                }
                       });
            }
        });
    });

    //================================================== signin =============================

    app.post('/signin', function (req, res) {
        var path = settings.path;
        if (req.body.email == "" || req.body.password == "" || req.body.email == undefined || req.body.password == undefined || req.body.deviceToken == "" || req.body.deviceType == "" || req.body.deviceToken == undefined || req.body.deviceType == undefined) {
            res.json({ status: '0', msg : 'Please enter all required data.' });
            return;
        }
        else {
            user.signin(req.body.email, req.body.password, req.body.deviceToken, req.body.deviceType, function (err, data) {
                if (err) {
                    res.json({ status: '0', msg: 'There was an error signing in.' });
                    return;
                }
                else if (data == false) {
                    res.json({ status: '0', msg : 'Incorrect username and/or password.' });
                    return;
                }
                else {
                    var profile = {
                        id: data[0].userId
                    };
                    var token = jwt.sign(profile, settings.JWTPrivateKey, { expiresIn: settings.expiresIn });
                    var emailverified = data[0].isEmailVerified.toString();
                    data[0].isEmailVerified = emailverified;
                    var isMobileverified = data[0].isMobileverified.toString();
                    data[0].isMobileverified = isMobileverified;
                    if (data[0].qId == null) {
                        data[0].qId = "";
                    }
                    else {
                        var Qid = data[0].qId.toString();
                        data[0].qId = Qid;
                    }
                    if (data[0].cardNumber == null) {
                        data[0].cardNumber = "";
                    }
                    else {
                        var cNumber = data[0].cardNumber.toString();
                        data[0].cardNumber = cNumber;
                    }
                    if (data[0].registrationStepCompleted == null) {
                        data[0].registrationStepCompleted = "0";
                    }
                    else {
                        var step = data[0].registrationStepCompleted.toString();
                        data[0].registrationStepCompleted = step;
                    }
                    var profilePic = path.concat(data[0].userProfile);
                    data[0].userProfile = profilePic;
                    res.json({ token: token, status: '1', msg: 'Success.', user: data[0] });
                    return;
                }
            });
        }
    });

    //========================================= authenticate (Admin login) =============================

    app.post('/authenticate', function (req, res, next) {
        //TODO validate req.body.username and req.body.password
        //if is invalid, return HTTP status as 401
        if (req.body.admin.email == null || req.body.admin.email == "") {
            res.send(400, { error: "Please enter your email." });
            return;
        }
        if (req.body.admin.password == null || req.body.admin.password == "") {
            res.send(400, { error: "Please enter your password." });
            return;
        }
        user.loginAdmin(req.body.admin.email, req.body.admin.password, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            else {
                if (data.length == 1) {
                    sess = req.session;
                    sess.email = req.body.admin.email;
                    //res.writeHead(301,
                    //  { Location: 'http://localhost:1337/AdminPanelHome.ejs'}
                    //);
                    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
                    res.render('AdminPanelHome.ejs', { "email": req.body.admin.email });
                //res.end();
                }
                else
                    res.render('AdminPanel.ejs', { title: "Admin Panel", errorName: "Invalid credentials!" , errorMessage : "The email and password combination you entered does not match our records.", errorVisibility: "normal" });
                return;
            }
        });
    });

    app.get('/getTwilio', function (req, res, next) {
        //TODO validate req.body.username and req.body.password
        //if is invalid, return HTTP status as 401
        var num = req.query.number == undefined ? "" : req.query.number;
        //var num = 123456789;
        mail.xmlfortwilio(num, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            else {
                res.header('Content-Type','text/xml').send(data);
            }
        });
    });

    app.post('/getTwilio', function (req, res, next) {
        //TODO validate req.body.username and req.body.password
        //if is invalid, return HTTP status as 401
        if(req.body.num == undefined || req.body.num == "")
            return res.send({"error": "Please provide number"});
        mail.xmlfortwilio(req.body.num, function (err, data) {
            if (err) {
                next(err);
                return;
            }
            else {
                res.header('Content-Type','text/xml').send(data);
            }
        });
    });
}
