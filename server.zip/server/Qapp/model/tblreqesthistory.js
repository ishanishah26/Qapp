var gcm = require('node-gcm');
var sql = require('../config/sql');
var connection = require('../config/database');
var gcmSender = new gcm.Sender(connection.gcmSenderKey);

//========================================== request accepted history List ==========================================

exports.showRequestAccepted = function (qId, callback) {
    // var query = 'SELECT qreqa.qRequestId,qreqa.isConfirmedByQ,qreq.isTransport,qreq.requestVerb, qreq.requestNoun, qreq.createdDate, qreq.requestStatus, u.firstName '
		// 													 + 'FROM qRequestAccept AS qreqa INNER JOIN qRequest AS qreq ON '
		// 													 + 'qreqa.qRequestId = qreq.qRequestId AND qreqa.qId="' + qId + '" INNER JOIN user AS u ON u.userId = qreq.userId';

    var query = 'SELECT qreqa.qRequestId,qreqa.isConfirmedByQ,qreq.isTransport,qreq.requestVerb, \
                qreq.requestNoun, qreq.createdDate, qreq.requestStatus, \
                u.firstName, u.lastName, u.userProfile, \
                qreqa.paymentReceivedByQ, qreqa.requestCompletionDateTime \
                FROM qRequestAccept AS qreqa \
                INNER JOIN qRequest AS qreq ON qreqa.qRequestId = qreq.qRequestId AND qreqa.qId="'+qId+'"\
                INNER JOIN user AS u ON u.userId = qreq.userId ORDER BY qreq.createdDate DESC';


    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== request history ==========================================

exports.requestHistory = function (userId, callback) {
    // var query = 'select qRequestId,isTransport,requestVerb,requestNoun,createdDate,requestStatus from qRequest where userId = "' + userId + '" order by createdDate DESC';
    var query = 'select m.qRequestId,m.isTransport,m.requestVerb,m.requestNoun, m.currentLat, m.currentLong, \
                  m.createdDate,m.requestStatus , qra.qId, qra.mapURL, qra.paymentDoneByRequestor as amountPaid, qra.paymentReceivedByQ as amountReceivedByQ, \
                  (qra.paymentDoneByRequestor - qra.paymentReceivedByQ) as QAdminFee, sum(qrbi.billAmount) AS reimbursementAmount, \
                  qp.firstName , qp.lastName , us.userProfile \
                  from qRequest m \
                  left join qRequestAccept qra on m.qRequestId = qra.qRequestId \
                  left join qProvider qp on qra.qId = qp.qId  \
                  left join user us on us.userId = qp.userId \
                  left outer join qRequestBillImages qrbi on m.qRequestId = qrbi.qRequestId \
                  where m.userId = "' + userId +'" group by m.qRequestId order by createdDate DESC';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== request user review ==========================================

exports.qRequestReview = function (qRequestId, speedRating, qualityRating, feedback, callback) {
    var query = 'UPDATE qRequestAccept SET speedRating ="' + speedRating + '" ,'
						 + 'qualityRating="' + qualityRating + '", feedback = "' + feedback + '", isReviewed = 1 , ratingDate = NOW() WHERE qRequestId ="' + qRequestId + '"; ';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== request history Id ==========================================

exports.requestHistoryId = function (userId, requestId, callback) {
    /*var query = 'SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.createdDate, qRequest.numberOfStops, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, qRequest.requestStatus, '
										+'qRequestAccept.qId, '
										+'qProvider.firstName, qProvider.lastName, qProvider.email, qProvider.mobile, '
										+'user.userProfile, '
										+'stopDetail.stopDetailId,stopDetail.stopLat, stopDetail.stopLong, stopDetail.address '
										+'FROM qRequest LEFT JOIN qRequestAccept ON qRequest.qRequestId = qRequestAccept.qRequestId '
										+'LEFT JOIN qProvider ON qRequestAccept.qId = qProvider.qId '
										+'LEFT JOIN user ON qProvider.userId = user.userId '
										+'LEFT JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId '
										+'WHERE qRequest.qRequestId = "'+ requestId +'" ORDER BY stopDetail.stopDetailId ASC';
*/
    var query = 'CALL qRequest_HistoryById_ruben_test("' + requestId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}
