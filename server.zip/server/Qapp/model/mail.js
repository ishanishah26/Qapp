//=========================================== configration =====================================
var settings = require('../config/database');
var nodemailer = require('nodemailer');
var emailtemplate = require('./emailTemplate');
var forgotPasswordEmail = require('./forgotPasswordTemplate');
var completeRequestTemplate = require('./completeRequestTemplate');
var reportIssueTemplate = require('./reportIssueTemplate');
var QregisteredEmail = require('./QregisteredEmail');
var QRatingDroppedEmail = require('./QRatingDroppedEmail');
var receiptUserSolveTemplate = require('./receiptUserSolveTemplate');
var receiptUserErrandTemplate = require('./receiptUserErrandTemplate');
var transporter = nodemailer.createTransport(settings.smtpConfig);
var moment = require('moment');
var path = require('path');

//================================================================== otp send =================================




exports.sendEmail = function (email, name, random, callback) {
    var output = name.substring(0, 1).toUpperCase() + name.substring(1);
    var date = moment().format('MMMM Do YYYY');
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : email,
        from : "info@theQNowapp.com",
        subject : "Verify your email address",
        html: emailtemplate.emailVerification.format(output, random, date) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//=============================================================== forgot password mail ================================

exports.sendEmailForgot = function (email, random, callback) {

    var date = moment().format('MMMM Do YYYY');


    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : email,
        from : "info@theQNowapp.com",
        subject : "Recover Your password",
        html: forgotPasswordEmail.emailVerification.format("", random, date) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//=============================================================== complete request ================================

exports.sendEmailComplete = function (email, name, verb, noun, fname, lname, payment, heading, image, transportDetails,
   requestFee, serviceFeeToQ, serviceFeeToUser, totalMinutes, distanceFee, durationFee, reimbursementAmt, subtotal, subtotalFee,
    isTransport, qProfile, userCardName, callback) {

    var path = settings.path
    var emailObj;
    var profilePic;


      if(reimbursementAmt == null){
        reimbursementAmt = 0;
      }


      if(isTransport == 1){
          emailObj = receiptUserErrandTemplate;
      }
      else{
          emailObj = receiptUserSolveTemplate;
      }

      if (qProfile == null || qProfile == "" ) {
         profilePic = "user-profile.png";
      }

      profilePic = path.concat(qProfile);

      var date = moment().format('MMMM Do YYYY');

      subtotalFee = parseFloat(subtotalFee).toFixed(2);
      subtotal = parseFloat(subtotal).toFixed(2);
      var grandTotal = parseFloat(subtotalFee) + parseFloat(subtotal);
      grandTotal =  parseFloat(grandTotal).toFixed(2);

      lname = lname.substring(0,1);

    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : email,
        from : "receipts@theQNowapp.com",
        subject : "Q Now Receipt",
        html: emailObj.emailTemplate.format(name, verb, noun, fname, lname, grandTotal, heading, image, transportDetails, date, subtotalFee,
          totalMinutes, parseFloat(distanceFee).toFixed(2), parseFloat(durationFee).toFixed(2), parseFloat(reimbursementAmt).toFixed(2) , subtotal,
           parseFloat(settings.anythingelseBaseRate).toFixed(2), parseFloat(settings.transportBaseRate).toFixed(2), profilePic, userCardName ) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//================================================= send message for Qprovider registration ==============================

exports.twilioSendMsg = function (toPhonenumber, msg, callback) {

    var client = require('twilio')(settings.TwilioAccountId, settings.TwilioAuthToken);
    //Add +1 to number for sending sms in USA
    client.messages.create({
        to: "+1" + toPhonenumber,
        from: settings.TwilioNumber,
        body: msg,
    }, function (err, message) {
        if (err) {
            console.log(err);
            callback(err, null);
        } else {
            callback(null, message);
        }
    });
};

//================================================= send message user to Qprovider ==============================

exports.twilioSendMsgForUser = function (toPhonenumber, fromPhonenumber, msg, callback) {

    var client = require('twilio')(settings.TwilioAccountId, settings.TwilioAuthToken);
    //Add +1 to number for sending sms in USA
    client.messages.create({
        to: "+1" + toPhonenumber,
        from: settings.TwilioNumber,
        body: msg,
    }, function (err, message) {
        if (err) {
            console.log(err);
            callback(err, null);
        } else {
            callback(null, message);
        }
    });
};

//=============================================================== forgot password mail ================================

exports.sendReportEmail = function (username, issue, email, callback) {
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : "info@theQNowapp.com",
        from : "info@theQNowapp.com",
        subject : "New Issue Reported",
        html: reportIssueTemplate.emailReport.format(username, issue, email) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

exports.sendQregistrationComplete = function (Qname, Qrole, email, address, city, state, mobile, callback) {
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : "HR@theQNowapp.com",
        from : "info@theQNowapp.com",
        subject : "New Q Registered",
        html: QregisteredEmail.emailHR.format(Qname, Qrole, email, mobile, address, city, state) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//sendQRatingDropped
exports.sendQRatingDropped = function (Qname, Qrole, email, address, city, state, mobile, avgRating, callback) {
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : "HR@theQNowapp.com",
        from : "info@theQNowapp.com",
        subject : "Q Rating dropped",
        html: QRatingDroppedEmail.emailHR.format(Qname, Qrole, email, mobile, address, city, state, avgRating) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });


}
exports.xmlfortwilio = function (number, callback) {
    var xml =  "<?xml version='1.0' encoding='UTF-8'?>" +
 "<Response>"+
 "<Dial record='true'  callerId='+13107892160'>"+
 "<Number>+"+number+"</Number>"+
 "</Dial>"+
 "</Response>";

callback(null, xml);
//res.header('Content-Type','text/xml').send(xml);


}
