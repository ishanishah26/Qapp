var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes/index');
var users = require('./routes/users');

var app = express();

var server = require('http').Server(app);
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(__dirname + '/public/favicon.ico'));
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(require('stylus').middleware(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));
app.post('/APIURL', function (req, res) {
    try {
        if (req.body.qIds == "" || req.body.qIds == undefined) {
            return res.json(401, "please provide qId");
        }
        
        if (req.body.messageBody == "" || req.body.messageBody == undefined) {
            return res.json(401, "please message Body ");
        }
		var arr = req.body.qIds.split(",");
		console.log("qIDs: " + arr);
        var messageData = JSON.stringify(req.body.messageBody);
        for (var i = 0; i < arr.length; i++) {
            
            try {
				qList[arr[i]].sendUTF(messageData);

				console.log("send to: " + arr[i]);

			} catch (err) {
			
				console.log("send to: " + arr[i] + ", Error : " + err );
			}
        }
        
        return res.json(200, "Status OK");
    } catch (err) {
        return res.json(500, err.message);
    }

});

app.post('/qDisconnectFromSocket', function (req, res) {
    try {
        if (req.body.qId == "" || req.body.qId == undefined) {
            return res.json(401, "please provide qId");
        }
        
        qList[req.body.qId].close();
        qList.splice(req.body.qId,1);
        console.log("Q disconnected from web socket. qId: ", req.body.qId);
        return res.json(200, "Status OK");
    } catch (err) {
        return res.json(500, err.message);
    }

});

app.set('port', 5050);
server.timeout = 0;
server.listen(app.get('port'), function () {
    console.log('Express server listening on port ' + server.address().port);
});

app.use('/', routes);
app.use('/users', users);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});




var WebSocketServer = require('websocket').server;


wsServer = new WebSocketServer({
    httpServer: server,
    // You should not use autoAcceptConnections for production 
    // applications, as it defeats all standard cross-origin protection 
    // facilities built into the protocol and the browser.  You should 
    // *always* verify the connection's origin and decide whether or not 
    // to accept it. 
    autoAcceptConnections: false
});

function originIsAllowed(origin) {
    // put logic here to detect whether the specified origin is allowed. 
    return true;
}

var qList = new Array();

wsServer.on('request', function (request) {
    
    try {
        if (!originIsAllowed(request.origin)) {
            // Make sure we only accept requests from an allowed origin 
            request.reject();
            console.log((new Date()) + ' Connection from origin ' + request.origin + ' rejected.');
            return;
        }
        
        var connection = request.accept();
		console.log((new Date()) + ' Connection accepted.');
		connection.sendUTF("Hi From Server");
        connection.on('message', function (message) {
            if (message.type === 'utf8') {
                console.log('Received Message: ' + message.utf8Data);
                connection.sendUTF(message.utf8Data);
                
                var MessageJSON = JSON.parse(message.utf8Data);
                if (MessageJSON.type == "qIndentity") {
                    console.log('Received Q identity: ' + message.utf8Data);
                    qList[MessageJSON.qId + ""] = connection;

                }

            }
            else if (message.type === 'binary') {
                console.log('Received Binary Message of ' + message.binaryData.length + ' bytes');
                connection.sendBytes(message.binaryData);
            }
        });
		connection.on('close', function (reasonCode, description) {
			
			console.log((new Date()) + ' Peer ' + connection.remoteAddress + ' disconnected.');
			
        });
    } catch (err) { }
});


wsServer.on('error', function (err) {
    console.log("Caught server socket error: ");
    console.log(err.stack);
});


//For handling uncaught exception like ECONNRESET
process.on('uncaughtException', function (err) {
    console.log("uncaughtException");
    console.error(err.stack);
    process.exit();
});

module.exports = app;