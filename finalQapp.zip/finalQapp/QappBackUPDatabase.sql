-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 09, 2016 at 05:38 PM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `finalQapp`
--
CREATE DATABASE IF NOT EXISTS `finalQapp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `finalQapp`;

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `cancel_Request`$$
CREATE DEFINER=`test`@`%` PROCEDURE `cancel_Request`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE t1 INT;
	DECLARE t2 INT;
	IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 2) THEN
		SELECT TIMESTAMPDIFF(MINUTE, (SELECT acceptDate from qRequestAccept where qRequestId = r_requestId), NOW() ) into t1;
		IF(t1 < 3) THEN
			select 'time < 180' as msg;
		ELSE
			select 'cant cancel' as msg;
		END IF;
	ELSE 
    IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 3) THEN
    select 'Cannot cancel the request. It is already completed.' as msg;
    ELSE
			select 'canceled' as msg;
			update qRequest set requestStatus = "4", cancelDate = NOW() where qRequestId = r_requestId;
		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);
        END IF;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `changeProfile_Email`$$
CREATE DEFINER=`test`@`%` PROCEDURE `changeProfile_Email`(IN `id` BIGINT, IN `new_email` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	IF EXISTS (select userId from user where email = new_email) THEN
		select 'exists' as msg;
	ELSE 
		select 'not exists' as msg;
    	UPDATE user SET passcode = random, isEmailVerified = "0", changedEmail = new_email WHERE userId = id;
		select firstName from user where userId = id;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `change_Email`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `change_Email`(IN `id` BIGINT(20), IN `new_email` VARCHAR(100), IN `random` INT)
    NO SQL
BEGIN
	IF EXISTS (select userId from user where email = new_email) THEN
		select 'exists' as msg;
	ELSE 
    	UPDATE user SET email = new_email, passcode = random WHERE userId = id;
		select 'update' as msg;
		select firstName from user where userId = id;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `confirmCalcel_Request`$$
CREATE DEFINER=`test`@`%` PROCEDURE `confirmCalcel_Request`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	IF EXISTS (select * from qRequest where qRequestId = r_requestId and requestStatus = 2) THEN
		
		select 'canceled' as msg;
        update qRequest set requestStatus = "4", cancelDate = NOW(), fine = "5" where qRequestId = r_requestId;
		update qRequestAccept set isConfirmedByQ = "2" where qRequestId = r_requestId;
		SELECT qRequestAccept.qId, qProvider.userId, qRequest.requestVerb, qRequest.requestNoun, user.deviceToken, user.deviceType
		FROM qRequestAccept
		INNER JOIN qProvider ON qRequestAccept.qId = qProvider.qId
		INNER JOIN qRequest ON qRequestAccept.qRequestId = qRequest.qRequestId
		INNER JOIN user ON qProvider.userId = user.userId
		WHERE qRequestAccept.qRequestId = r_requestId;
		select stripeCustomerAccount from qRequest qr join  userCard uc on qr.userId = uc.userId where  qRequestId = r_requestId;
		
		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);

	ELSE
		select 'canceled' as msg;
        select stripeCustomerAccount from qRequest qr join  userCard uc on qr.userId = uc.userId where  qRequestId = r_requestId;
        		Update qProvider set isPerformingRequest=0 where qId in(select qId from qRequestAccept where qRequestId = r_requestId);


	END IF;
END$$

DROP PROCEDURE IF EXISTS `confirm_Request`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `confirm_Request`(IN `r_qRequestId` BIGINT)
    NO SQL
BEGIN
	DECLARE amt float(9,2);
    
    	IF EXISTS (select * from qRequest where qRequestId = r_qRequestId and requestStatus = "4") THEN
					select 'Request Already Cancelled. You cannot complete it.' as msg;

        
       	Else
    
	UPDATE qProvider,qRequestAccept SET qRequestAccept.isConfirmedByQ = 1, qRequestAccept.requestCompletionDateTime = NOW(), qProvider.TotalRequestCompleted = qProvider.TotalRequestCompleted + 1  WHERE qProvider.qId = qRequestAccept.qId AND qRequestId = r_qRequestId; 
	UPDATE qRequest SET requestStatus = "3" WHERE qRequestId = r_qRequestId;
    
    Select sum(billAmount) into amt from qRequestBillImages where qRequestId = r_qRequestId group by qRequestId; 
    
	SELECT qRequestAccept.receiptTotalBill, qRequestAccept.milesTransported, qRequestAccept.acceptDate, qRequestBillImages.billImage, qProvider.qId, qProvider.firstName, qProvider.lastName,
	qProvider.qStripeId, qRequest.requestVerb, qRequest.requestNoun, user.firstName as u_name, user.email, user.deviceToken, user.deviceType,amt
	FROM qRequestAccept 
	LEFT JOIN qRequestBillImages ON qRequestAccept.qRequestId = qRequestBillImages.qRequestId
	INNER JOIN qProvider ON qRequestAccept.qId = qProvider.qId
	INNER JOIN qRequest ON qRequestAccept.qRequestId = qRequest.qRequestId
	INNER JOIN user ON qRequest.userId = user.userId
	WHERE qRequestAccept.qRequestId = r_qRequestId;
	
    Update qProvider set isPerformingRequest=0 where qId = (select qId from qRequest where qRequestId =r_qRequestId);
    
	SELECT userCard.userId , userCard.stripeCustomerAccount FROM userCard WHERE userId IN(SELECT userId FROM qRequest WHERE qRequestId = r_qRequestId);
    
    SELECT deviceToken AS qDeviceToken, deviceType AS qDeviceType FROM `user` WHERE userId IN ( SELECT userId FROM qProvider WHERE qId IN(SELECT qId FROM qRequestAccept WHERE qRequestId = r_qRequestId));
    
    SELECT stopDetail.reachedAtTime FROM stopDetail WHERE stopDetail.qRequestId = r_qRequestId AND stopDetail.stopDetailId = 1;
	End if;
END$$

DROP PROCEDURE IF EXISTS `create_userCard`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `create_userCard`(IN `r_userId` BIGINT, IN `r_cardNumber` INT, IN `r_cardToken` VARCHAR(255))
    NO SQL
BEGIN
	IF EXISTS (SELECT userId FROM userCard WHERE userId = r_userId) THEN
		UPDATE userCard SET cardNumber = r_cardNumber, cardToken = r_cardToken WHERE userId = r_userId;
        SELECT cardToken, stripeCustomerAccount, userId FROM userCard where userId = r_userId;
	ELSE 
    	INSERT INTO userCard(`userId`,`cardNumber`,`cardToken`) values(r_userId, r_cardNumber, r_cardToken);
        SELECT cardToken, stripeCustomerAccount, userId FROM userCard where userId = r_userId;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `delete_Account`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `delete_Account`(IN `id` BIGINT(20))
    NO SQL
BEGIN
	
	update user set isDeleted=1 WHERE userId = id;
	
END$$

DROP PROCEDURE IF EXISTS `insert_qProvider`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_qProvider`(IN `id` BIGINT(20), IN `curLat` FLOAT, IN `curLong` FLOAT, IN `q_fname` VARCHAR(50), IN `q_lname` VARCHAR(50), IN `q_email` VARCHAR(100), IN `q_zip` VARCHAR(50), IN `q_mobile` VARCHAR(50), IN `q_address` VARCHAR(255), IN `q_city` VARCHAR(50), IN `q_state` VARCHAR(50))
    NO SQL
BEGIN
	DECLARE qProviderId bigint;
	IF EXISTS (select qId from qProvider join user on qProvider.userId = user.userId  where user.IsDeleted=0 AND qProvider.email = q_email) THEN
		select 'exists' as msg;
	ELSE IF EXISTS(select qId from qProvider where userId = id) THEN
		select 'exists' as msg;
	ELSE
    	insert into qProvider(userId,currentLat,currentLong,firstName,lastName,email,address,city,state,zipCode,mobile,registrationStepCompleted) values(id,curLat,curLong,q_fname,q_lname,q_email,q_address,q_city,q_state,q_zip,q_mobile,1);
		select  LAST_INSERT_ID() into qProviderId;
		select 'insert' as msg, qProviderId;
	END IF;
END IF;
END$$

DROP PROCEDURE IF EXISTS `qAverageRating`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qAverageRating`(IN `qID` BIGINT)
    NO SQL
BEGIN
	
	IF EXISTS (select qId from qRequestAccept where qId = qId) THEN
		SELECT AVG(speedRating+qualityRating)/2 AS averageRating 
		FROM qRequestAccept 
		WHERE qId=qId AND isReviewed=1;
		SELECT u.firstName,u.lastName,qreqa.feedback,qreqa.ratingDate 
		FROM qRequestAccept AS qreqa INNER JOIN qRequest AS qreq 
		ON qreq.qRequestId=qreqa.qRequestId AND qreqa.qId=qId AND isReviewed=1
		INNER JOIN user AS u ON qreq.userId=u.userId
		ORDER BY qreqa.ratingDate DESC;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `qRequest_anyThingElse`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_anyThingElse`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT, IN `verb` VARCHAR(255), IN `noun` VARCHAR(255), IN `time` VARCHAR(255), IN `price` VARCHAR(255), IN `requiredNow` INT, IN `requiredDate` DATE, OUT `qRequsetId` BIGINT)
    NO SQL
BEGIN
	insert into qRequest(userId,currentLat,currentLong,requestVerb,requestNoun,qRequiredTime_Hr,qRequiredPayment,isRequiredNow,qRequiredDate,requestStatus) values(id,curLat,curLong,verb,noun,time,price,requiredNow,requiredDate,1);
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 25;
    	select LAST_INSERT_ID() into qRequsetId;

END$$

DROP PROCEDURE IF EXISTS `qRequest_anyThingElse_resend`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_anyThingElse_resend`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT)
    NO SQL
BEGIN
	
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Anything else%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 
	having temp < 25;
    
   update qProvider set LastRequestSent =  now() where qId in (SELECT qId FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 25);
    
END$$

DROP PROCEDURE IF EXISTS `qRequest_HistoryById`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_HistoryById`(IN `r_requestId` BIGINT)
    NO SQL
BEGIN
	DECLARE reimbursementAmount float(9,2);


 Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = r_requestId group by qRequestId; 
	SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.createdDate, qRequest.numberOfStops, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, qRequest.requestStatus,
qRequestAccept.qId,  qRequestAccept.paymentDoneByRequestor AS totalPayment, "16 + 0.20/min" AS baseRate , qRequestAccept.milesTransported , (qRequestAccept.milesTransported*0.20) AS distanceFee, qRequestAccept.paymentDoneByRequestor AS subTotal, qRequestAccept.paymentReceivedByQ AS TotalPaymentToQ , (qRequestAccept.paymentDoneByRequestor-qRequestAccept.paymentReceivedByQ) AS QAdminFee, reimbursementAmount, TIMESTAMPDIFF(MINUTE, qRequestAccept.acceptDate , qRequestAccept.requestCompletionDateTime) AS timeElapsed ,
qProvider.firstName, qProvider.lastName, qProvider.email, qProvider.mobile, user.userProfile, 
stopDetail.stopDetailId,stopDetail.stopLat, stopDetail.stopLong, stopDetail.address 
FROM qRequest LEFT JOIN qRequestAccept ON qRequest.qRequestId = qRequestAccept.qRequestId 
LEFT JOIN qProvider ON qRequestAccept.qId = qProvider.qId 
LEFT JOIN user ON qProvider.userId = user.userId
LEFT JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId 
WHERE qRequest.qRequestId = r_requestId ORDER BY stopDetail.stopDetailId ASC;
SELECT userId, cardNumber FROM userCard where userId IN(SELECT userId FROM qRequest WHERE qRequest.qRequestId = r_requestId);
END$$

DROP PROCEDURE IF EXISTS `qRequest_Tranport`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Tranport`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT, IN `verb` VARCHAR(255), IN `noun` VARCHAR(255), IN `time` VARCHAR(255), IN `price` VARCHAR(255), IN `nStops` INT, OUT `qRequsetId` INT)
    NO SQL
BEGIN
	insert into qRequest(userId,currentLat,currentLong,isTransport,requestVerb,requestNoun,qRequiredTime_Hr,qRequiredPayment,numberOfStops,requestStatus) values(id,curLat,curLong,1,verb,noun,time,price,nStops,1);
	select  LAST_INSERT_ID() into qRequsetId;
	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 25;
	select LAST_INSERT_ID() into qRequsetId;
END$$

DROP PROCEDURE IF EXISTS `qRequest_Tranport_resend`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `qRequest_Tranport_resend`(IN `id` BIGINT, IN `curLat` FLOAT, IN `curLong` FLOAT)
    NO SQL
BEGIN
	

	SELECT userId, qId, ( 3959 * acos( cos( radians( curLat ) ) * cos( radians( currentLat ) ) * cos( radians( currentLong ) - radians( curLong ) ) + sin( radians( curLat ) ) * sin( radians( currentLat ) ) ) ) AS temp
	FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 
	having temp < 25;
    
    update qProvider set LastRequestSent =  now() where qId in (SELECT qId FROM qProvider
	WHERE `roleOfQ` LIKE '%Transport%' and isQOnline = "1" and userId != id and isPerformingRequest =0 and (TIMESTAMPDIFF(Second,LastRequestSent,now()) >60 ||TIMESTAMPDIFF(Second,LastRequestSent,now()) is null ) 
	having temp < 25);

	END$$

DROP PROCEDURE IF EXISTS `reached_AtStop`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `reached_AtStop`(IN `q_RequestId` BIGINT, IN `Lat` FLOAT, IN `c_Long` FLOAT)
    NO SQL
BEGIN
	UPDATE stopDetail SET isQReachedAtStop = "1" WHERE qRequestId = q_RequestId and stopLat = Lat  and stopLong = c_Long ;
	SELECT address FROM stopDetail WHERE qRequestId =  q_RequestId and stopLat = Lat and stopLong = c_Long and isQReachedAtStop = "1";
	SELECT user.userId, user.mobile FROM user INNER JOIN  qRequest 
	ON qRequest.userId = user.userId WHERE qRequestId =  q_RequestId;
END$$

DROP PROCEDURE IF EXISTS `request_Accept`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `request_Accept`(IN `requestId` BIGINT, IN `qId` BIGINT)
    NO SQL
BEGIN
	IF EXISTS (select * from qRequest where qRequestId = requestId and requestStatus = "2") THEN
		select 'already accepted' as msg;	
	ELSE IF EXISTS (select * from qRequest where qRequestId = requestId and requestStatus = "4") THEN
		select 'request canceled' as msg;	
	ELSE
		Update qRequest set requestStatus = "2" where qRequestId = requestId;
		Update qProvider set isPerformingRequest =1 where qProvider.qId = qId;
		insert into qRequestAccept (qId,qRequestId)	values(qId,requestId);	
		select 'accept now' as msg;
		select qRequest.requestVerb, qRequest.requestNoun, qRequest.isTransport, user.userId, user.deviceToken, user.deviceType from qRequest 
		INNER JOIN user
		ON qRequest.userId = user.userId
		where qRequestId = requestId;
		#select firstName from qProvider where qId = qId;
	END IF;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `resendOtp_email`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `resendOtp_email`(IN `id` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	DECLARE mail varchar(255);
		UPDATE user SET passcode = random WHERE userId = id;
		select email as mail,firstName from user where userId = id;
END$$

DROP PROCEDURE IF EXISTS `resendOtp_mobile`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `resendOtp_mobile`(IN `id` VARCHAR(255), IN `random` INT)
    NO SQL
BEGIN
	DECLARE num varchar(255);
		UPDATE qProvider SET mobileVerificationCode = random WHERE userId = id;
		select mobile as num from qProvider where userId = id;
END$$

DROP PROCEDURE IF EXISTS `show_Request`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `show_Request`(IN `requestId` BIGINT)
    NO SQL
BEGIN
DECLARE reimbursementAmount float(9,2);
	IF EXISTS (select * from qRequest where qRequestId = requestId and isTransport = "1") THEN
		SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.currentLat, qRequest.currentLong, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.numberOfStops, qRequest.createdDate, user.userId, user.firstName, user.lastName, user.email, user.mobile, user.userProfile, stopDetail.stopDetailId, stopDetail.stopLat, stopDetail.stopLong, stopDetail.address
		FROM qRequest
		INNER JOIN user ON qRequest.userId = user.userId
		INNER JOIN stopDetail ON qRequest.qRequestId = stopDetail.qRequestId
		WHERE qRequest.qRequestId = requestId 
		ORDER BY stopDetail.stopDetailId ASC;	
	ELSE 
		SELECT qRequest.isTransport, qRequest.requestStatus, qRequest.requestVerb, qRequest.requestNoun, qRequest.currentLat, qRequest.currentLong, qRequest.qRequiredTime_Hr, qRequest.qRequiredPayment, qRequest.isRequiredNow, qRequest.qRequiredDate, qRequest.createdDate, user.userId, user.firstName, user.lastName, user.email, user.mobile, user.userProfile
		FROM qRequest
		INNER JOIN user ON qRequest.userId = user.userId
		WHERE qRequest.qRequestId = requestId;
	END IF;
    
        Select sum(billAmount) into reimbursementAmount from qRequestBillImages where qRequestId = requestId group by qRequestId; 

    
    SELECT paymentDoneByRequestor AS userPayment , paymentDoneByRequestor AS subTotal, paymentReceivedByQ AS TotalPaymentToQ , (paymentDoneByRequestor-paymentReceivedByQ) AS QAdminFee, reimbursementAmount FROM `qRequestAccept` WHERE qRequestId = requestId;
	SELECT qBankAccountNumber FROM qProvider WHERE qId IN (SELECT qId FROM qRequestAccept WHERE qRequestId = requestId);
END$$

DROP PROCEDURE IF EXISTS `update_Email`$$
CREATE DEFINER=`test`@`%` PROCEDURE `update_Email`(IN `id` BIGINT, IN `random` INT)
    NO SQL
BEGIN
	DECLARE new_email VARCHAR(100);
	SELECT changedEmail into new_email FROM user where userId = id;
	IF EXISTS (select * from qProvider where userId = id) THEN
		UPDATE user, qProvider SET user.isEmailVerified = "1", user.email = new_email, user.changedEmail = "" ,
		qProvider.email = new_email
		WHERE user.userId = qProvider.userId AND
		user.userId = id AND user.passcode = random;
	ELSE 
		UPDATE user SET isEmailVerified = "1", email = new_email, changedEmail = "" WHERE userId = id AND passcode = random;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `update_Mobile`$$
CREATE DEFINER=`test`@`%` PROCEDURE `update_Mobile`(IN `id` BIGINT, IN `random` INT)
    NO SQL
BEGIN
	DECLARE new_mobile VARCHAR(100);
	SELECT mobile into new_mobile FROM user where userId = id;
	IF EXISTS (select * from qProvider where userId = id) THEN
		UPDATE user, qProvider SET user.isMobileverified = "1", user.mobile = new_mobile, user.changedMobile = "" ,
		qProvider.mobile = new_mobile
		WHERE user.userId = qProvider.userId AND
		user.userId = id AND user.mobilePasscode = random;
	ELSE 
		UPDATE user SET isMobileverified = "1", mobile = new_mobile, changedMobile = "" WHERE userId = id AND mobilePasscode = random;
	END IF;
END$$

DROP PROCEDURE IF EXISTS `user_register`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `user_register`(IN `p_email` VARCHAR(255), IN `mobile` VARCHAR(50), IN `password` VARCHAR(50), IN `random` INT, IN `fname` VARCHAR(100), IN `lname` VARCHAR(100), IN `p_image` VARCHAR(255), IN `p_deviceToken` VARCHAR(255), IN `p_deviceType` INT, IN `mobileRandom` INT)
    NO SQL
BEGIN
	DECLARE userId BIGINT;
	IF EXISTS (select userId from user where email = p_email) THEN
		select 'exists' as msg;
	ELSE 
    	insert into user(firstName,lastName,email,mobile,password,passcode,userProfile,deviceToken,deviceType,mobilePasscode) values(fname,lname,p_email,mobile,password,random,p_image,p_deviceToken,p_deviceType,mobileRandom);
		select  LAST_INSERT_ID() into userId;
		select 'insert' as msg, userId;
	END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `qProvider`
--

DROP TABLE IF EXISTS `qProvider`;
CREATE TABLE IF NOT EXISTS `qProvider` (
  `qId` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `currentLat` float(9,6) NOT NULL,
  `currentLong` float(9,6) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zipCode` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `isMobileVerified` tinyint(4) NOT NULL COMMENT '0 = not varified 1 = verified',
  `mobileVerificationCode` varchar(100) NOT NULL,
  `nameOnDL` varchar(255) NOT NULL,
  `socialSecurityNo` varchar(255) NOT NULL,
  `dateOfBirth` date NOT NULL,
  `dlNo` varchar(255) NOT NULL,
  `dlState` varchar(255) NOT NULL,
  `dateOfDlExpiration` date NOT NULL,
  `highSchoolName` varchar(255) NOT NULL,
  `highSchoolCity` varchar(255) NOT NULL,
  `highSchoolState` varchar(255) NOT NULL,
  `highSchoolYOGrad` varchar(255) NOT NULL,
  `hsInfo` varchar(50) NOT NULL,
  `collegeInfo` varchar(255) NOT NULL,
  `totalYearOfProfExp` int(11) NOT NULL,
  `personalAssistantExp` int(11) NOT NULL,
  `roleOfQ` varchar(255) NOT NULL,
  `isStateDisclouserAcknowledged` tinyint(4) NOT NULL,
  `isBackgroundCheckAuthorized` tinyint(4) NOT NULL,
  `isQVerified` tinyint(4) NOT NULL DEFAULT '0',
  `registrationDate` datetime NOT NULL,
  `isQOnline` tinyint(4) NOT NULL,
  `registrationStepCompleted` int(11) NOT NULL COMMENT '1 = first step completd, 2= verification done, 7 =  completed all step',
  `TotalRequestCompleted` bigint(20) NOT NULL,
  `TotalPaymentReceived` float NOT NULL,
  `qBankAccountNumber` varchar(15) NOT NULL,
  `qStripeId` varchar(100) NOT NULL,
  `qStripeBankTokenId` varchar(100) NOT NULL,
  `qStripeBankId` varchar(100) NOT NULL,
  `isPerformingRequest` bit(1) NOT NULL DEFAULT b'0',
  `LastRequestSent` datetime NOT NULL,
  PRIMARY KEY (`qId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `qProvider`
--

INSERT INTO `qProvider` (`qId`, `userId`, `currentLat`, `currentLong`, `firstName`, `lastName`, `email`, `address`, `city`, `state`, `zipCode`, `mobile`, `isMobileVerified`, `mobileVerificationCode`, `nameOnDL`, `socialSecurityNo`, `dateOfBirth`, `dlNo`, `dlState`, `dateOfDlExpiration`, `highSchoolName`, `highSchoolCity`, `highSchoolState`, `highSchoolYOGrad`, `hsInfo`, `collegeInfo`, `totalYearOfProfExp`, `personalAssistantExp`, `roleOfQ`, `isStateDisclouserAcknowledged`, `isBackgroundCheckAuthorized`, `isQVerified`, `registrationDate`, `isQOnline`, `registrationStepCompleted`, `TotalRequestCompleted`, `TotalPaymentReceived`, `qBankAccountNumber`, `qStripeId`, `qStripeBankTokenId`, `qStripeBankId`, `isPerformingRequest`, `LastRequestSent`) VALUES
(1, 1, 21.148766, 72.762474, 'Tilak', 'Jethva', 'lanetteam.tilak@gmail.com', 'surat', 'surat', 'Connecticut', '79119', '8758504790', 0, '', 'Tilak Ckj Jethva', '4242', '1988-05-13', '758555', 'Arizona', '2014-05-13', '', '', '', '', 'Attended', 'Attended', 5, 5, 'Transport,Anything else', 1, 1, 1, '2016-05-13 06:47:45', 1, 7, 4, 4560, '6789', 'acct_18Aev7B96Z8Vx7eV', 'btok_8RYJryKlJQWxno', 'ba_18AfCQB96Z8Vx7eVcwrChixv', b'1', '2016-06-01 00:44:02'),
(2, 2, 21.154499, 72.765198, 'Riken', 'Doshi', 'lanetteam.riken@gmail.com', 'surat', 'surat', 'Armed Forces Americas', '99501', '9913060874', 0, '', 'Riken Vipul Doshi', '4242', '1983-05-13', '556566', 'Armed Forces Americas', '2021-05-13', '', '', '', '', 'Attended', 'Attended', 5, 5, 'Transport,Anything else', 1, 1, 1, '2016-05-13 06:59:28', 1, 7, 3, 9560, '6789', 'acct_18Aex6CEQO8c82kx', 'btok_8RY4nPdMY9y4iB', 'ba_18AeyYCEQO8c82kx9VGIRIhW', b'1', '2016-06-01 00:44:02'),
(3, 4, 21.148079, 72.760826, 'Tapan', 'Gohil', 'lanetteam.tapan@gmail.com', 'surat', 'surat', 'Federated Micronesia', '72201', '9998078073', 0, '', 'Tapan Rajeshbhai Gohil', '5555', '2010-05-13', '55799753$7$35197', 'Federated Micronesia', '2021-05-13', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 1, '2016-05-13 08:01:49', 1, 7, 6, 3040, '6789', 'acct_18AfziJwcSQT5h5t', 'btok_8RZR0xBqOlvZe6', 'ba_18AgIcJwcSQT5h5tAMjYLq7W', b'1', '2016-06-01 00:44:02'),
(4, 7, 34.106220, -118.463921, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '123 red st', 'los angeles ', 'California', '90077', '2038879349', 0, '', 'Kimberly Ann Idoko', '2534', '1979-05-13', '123457648', 'California', '2018-05-14', '', '', '', '', 'Graduated', 'Graduated', 12, 2, 'Transport,Anything else', 1, 1, 1, '2016-05-14 19:27:51', 0, 7, 0, 0, '1273', 'acct_18GsunLAzuI16PIU', 'btok_8Y1nxDG6fU90kY', 'ba_18GvjZLAzuI16PIUtom5sHKi', b'1', '0000-00-00 00:00:00'),
(5, 8, 21.148390, 72.760948, 'Test', 'User', 'lanetteam.sajid@gmail.com', 'surat', 'surat', 'New Mexico', '72201', '9998078073', 0, '', 'Test Android User', '5555', '1992-05-17', '11212212333', 'Nevada', '2038-05-17', '', '', '', '', 'Graduated', 'Graduated', 2, 3, 'Transport , Anything else', 1, 1, 1, '2016-05-17 06:04:49', 0, 7, 0, 0, '6789', 'acct_18C61qHqdzl1ODcq', 'btok_8T27o4ZEdqsc22', 'ba_18C62xHqdzl1ODcqesrZkUko', b'1', '0000-00-00 00:00:00'),
(6, 10, 34.106113, -118.463898, 'Demo', 'User', 'demo@qapp.com', 'surat', 'surat', 'Nevada', '72201', '9998887770', 0, '', 'Test Iphone User', '1111', '1991-05-18', '1335464647474', 'Northern Mariana Islands', '1993-05-18', '', '', '', '', 'Graduated', 'Graduated', 2, 2, 'Transport , Anything else', 1, 1, 1, '2016-05-18 06:32:00', 0, 7, 0, 0, '', 'acct_18CSuxGbOmsFu2tW', '', '', b'1', '0000-00-00 00:00:00'),
(7, 12, 19.387493, -99.209747, 'Cristian ', 'Try', 'lokinenuco@gmail.com', 'mmm', 'El paso', 'Texas', '79912', '9153556813', 0, '', '', '', '0000-00-00', '', '', '0000-00-00', '', '', '', '', '', '', 0, 0, '', 0, 0, 0, '0000-00-00 00:00:00', 0, 1, 0, 0, '', '', '', '', b'1', '0000-00-00 00:00:00'),
(8, 14, 34.106091, -118.463913, 'Felix', 'Odigie', 'felix@myqapp.com', '200 rosco rd', 'los angeles', 'California', '90077', '6173881912', 0, '', 'Felix Armstrong Odigie', '3964', '1976-09-30', '3418924', 'California', '2020-10-01', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport,Anything else', 1, 1, 1, '2016-05-29 21:09:02', 1, 7, 0, 0, '1912', 'acct_18GsufB2LZy7CiFA', 'btok_8XzoopMPMQB73D', 'ba_18GtoYB2LZy7CiFAcljMaM5w', b'1', '2016-05-30 23:36:40'),
(9, 17, 34.105587, -118.463585, 'Kevin', 'Robinson', 'thomas77607@aol.com', '2001 roscomare rd', 'Los  Angeles ', 'California', '90077', '8185197366', 0, '', 'Kevin Varden Robinson', '7525', '1956-05-23', 'D6704100', 'California', '2019-05-23', '', '', '', '', 'Graduated', 'Attended', 25, 5, 'Transport', 1, 1, 1, '2016-05-30 12:51:34', 0, 7, 0, 0, '', 'acct_18Gub1JTf5hIBqmy', '', '', b'1', '0000-00-00 00:00:00'),
(10, 16, 34.106117, -118.463905, 'Felix', 'Odigie', 'felix.odigie@gmail.com', '2000 rose rd', 'Los Angeles ', 'California', '90077', '6173881912', 0, '', 'Felix Odigie Odigie', '3964', '1976-10-01', '754689y', 'California', '2020-10-02', '', '', '', '', 'Graduated', 'Graduated', 15, 5, 'Transport , Anything else', 1, 1, 1, '2016-05-30 15:39:09', 0, 7, 2, 0, '1912', 'acct_18GxEOIY5VeKvAum', 'btok_8Y3xmoWa1Us56T', 'ba_18GxprIY5VeKvAumVqSTF0bP', b'1', '2016-05-30 16:53:21');

-- --------------------------------------------------------

--
-- Table structure for table `qRequest`
--

DROP TABLE IF EXISTS `qRequest`;
CREATE TABLE IF NOT EXISTS `qRequest` (
  `qRequestId` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `currentLat` float(9,6) NOT NULL,
  `currentLong` float(9,6) NOT NULL,
  `isTransport` tinyint(4) NOT NULL COMMENT '1 = Transport request 0 =any thing else request',
  `requestVerb` varchar(50) NOT NULL,
  `requestNoun` varchar(50) NOT NULL,
  `qRequiredTime_Hr` varchar(25) NOT NULL,
  `qRequiredPayment` varchar(255) NOT NULL,
  `numberOfStops` int(11) NOT NULL,
  `isRequiredNow` tinyint(4) NOT NULL DEFAULT '0',
  `qRequiredDate` date NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `requestStatus` int(11) NOT NULL COMMENT '1 = submitted, 2 = accepted, 3 = completed',
  `fine` int(11) NOT NULL,
  `cancelDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`qRequestId`),
  KEY `qrequest_ibfk_1` (`userId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;

--
-- Dumping data for table `qRequest`
--

INSERT INTO `qRequest` (`qRequestId`, `userId`, `currentLat`, `currentLong`, `isTransport`, `requestVerb`, `requestNoun`, `qRequiredTime_Hr`, `qRequiredPayment`, `numberOfStops`, `isRequiredNow`, `qRequiredDate`, `createdDate`, `requestStatus`, `fine`, `cancelDate`) VALUES
(1, 2, 21.147299, 72.760063, 1, 'Transport', 'Uvucj', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-13 12:16:39', 4, 5, '2016-05-13 12:18:16'),
(2, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:19:53', 4, 0, '2016-05-13 12:20:16'),
(3, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:20:19', 4, 0, '2016-05-13 12:20:32'),
(4, 2, 21.147303, 72.760063, 0, 'Vicucg', 'Bhvg', '2-3 hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 12:20:53', 4, 0, '2016-05-13 12:21:00'),
(5, 1, 21.147301, 72.760056, 0, 'Hybyb', 'Bubuvy', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 12:28:00', 3, 0, '0000-00-00 00:00:00'),
(6, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:43:22', 4, 0, '2016-05-13 12:43:37'),
(7, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:43:47', 4, 0, '2016-05-13 12:43:51'),
(8, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 0, '2016-05-14', '2016-05-13 12:44:10', 4, 0, '2016-05-13 12:44:19'),
(9, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:44:39', 3, 0, '0000-00-00 00:00:00'),
(10, 2, 21.148001, 72.760002, 0, 'Huu', 'Vgj', '> 3 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-13 12:46:51', 3, 0, '0000-00-00 00:00:00'),
(11, 1, 21.147522, 72.759933, 0, 'Juvu', 'Bgf', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 12:48:32', 3, 0, '0000-00-00 00:00:00'),
(12, 1, 21.147562, 72.760086, 0, 'Juvu', 'Bgf', '2-3 hrs', '$20-$100', 0, 1, '0000-00-00', '2016-05-13 13:01:03', 3, 0, '0000-00-00 00:00:00'),
(13, 5, 21.147984, 72.760773, 0, 'Dghdbd', 'Hrhdd', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-13 13:24:43', 4, 0, '2016-05-13 13:24:47'),
(14, 5, 21.148182, 72.760818, 0, 'Rhrhhr', 'Bhfhf', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-13 13:25:04', 4, 0, '2016-05-13 13:25:57'),
(15, 5, 21.148485, 72.760918, 0, 'Gdgdb', 'Vfbf', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-13 13:26:15', 3, 0, '0000-00-00 00:00:00'),
(16, 5, 21.147966, 72.760735, 0, 'Kyjt', 'Fbfb', '2-3hrs', '>$300', 0, 1, '0000-00-00', '2016-05-13 13:31:54', 3, 0, '0000-00-00 00:00:00'),
(17, 7, 34.106121, -118.463852, 1, 'Transport', 'Food', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-15 00:26:29', 1, 0, '0000-00-00 00:00:00'),
(18, 7, 34.106197, -118.463829, 0, 'Find', 'Fun', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:53:19', 3, 0, '0000-00-00 00:00:00'),
(19, 7, 34.106197, -118.463837, 0, 'Find', 'Fun', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:57:03', 4, 5, '2016-05-15 00:58:00'),
(20, 7, 34.106197, -118.463837, 0, 'Get', 'Help', '> 3 hrs', '>$300', 0, 0, '2016-05-14', '2016-05-15 00:58:35', 1, 0, '0000-00-00 00:00:00'),
(21, 7, 34.106197, -118.463837, 0, 'Get', 'Food', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:59:07', 4, 0, '2016-05-15 00:59:52'),
(22, 7, 34.106197, -118.463837, 0, 'Get', 'Food', '1-2 hrs', '<$20', 0, 1, '0000-00-00', '2016-05-15 00:59:56', 4, 0, '2016-05-15 01:00:16'),
(23, 6, 34.106140, -118.463760, 0, 'Find', 'Flights', '1-2hrs', '$20-100', 0, 1, '0000-00-00', '2016-05-15 02:58:27', 4, 0, '2016-05-15 02:59:04'),
(24, 6, 34.106110, -118.463882, 1, 'Transport', 'Food', '1-2hrs', '$20-100', 2, 0, '0000-00-00', '2016-05-15 03:02:17', 4, 0, '2016-05-15 03:03:00'),
(25, 8, 21.148430, 72.760971, 1, 'Transport', 'Computer', '2-3hrs', '$20-100', 2, 0, '0000-00-00', '2016-05-17 11:01:33', 1, 0, '0000-00-00 00:00:00'),
(26, 8, 21.148384, 72.760956, 0, 'Arrange', 'Party', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-17 11:02:37', 1, 0, '0000-00-00 00:00:00'),
(27, 12, 19.387451, -99.209839, 1, 'Transport', 'Plumber', '<1hr', '<$20', 2, 0, '0000-00-00', '2016-05-25 19:05:26', 4, 0, '2016-05-25 19:06:29'),
(28, 1, 34.148685, -118.435608, 1, 'Transport', 'Tequila', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-28 18:10:50', 4, 0, '2016-05-31 07:35:37'),
(29, 14, 0.000000, 0.000000, 1, 'Transport', 'Food', '1-2 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-30 01:57:47', 1, 0, '0000-00-00 00:00:00'),
(30, 14, 0.000000, 0.000000, 0, 'Find', 'Plumbers', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 02:00:31', 1, 0, '0000-00-00 00:00:00'),
(31, 14, 0.000000, 0.000000, 0, 'Find', 'Plumbers', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 02:03:49', 4, 0, '2016-05-30 02:03:59'),
(32, 14, 34.106117, -118.463974, 0, 'Find', 'Flights', '1-2hrs', '$20-100', 0, 0, '2016-05-30', '2016-05-30 03:08:04', 1, 0, '0000-00-00 00:00:00'),
(33, 7, 34.106125, -118.463860, 0, 'Find', 'Plumber', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 21:20:33', 4, 0, '2016-05-30 21:20:48'),
(34, 7, 34.106255, -118.463974, 0, 'Find', 'Plumber', '< 1 hr', '<$20', 0, 1, '0000-00-00', '2016-05-30 21:23:07', 3, 0, '0000-00-00 00:00:00'),
(35, 7, 34.106094, -118.463821, 1, 'Transport', 'Groceries', '< 1 hr', '$20-$100', 2, 0, '0000-00-00', '2016-05-30 21:33:03', 4, 5, '2016-05-30 21:36:46'),
(36, 7, 34.106102, -118.463638, 1, 'Transport', 'Dog', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-30 21:38:55', 4, 5, '2016-05-30 21:40:21'),
(37, 7, 34.106033, -118.463875, 1, 'Transport', 'Eggs', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-30 21:53:21', 3, 0, '0000-00-00 00:00:00'),
(38, 7, 34.106163, -118.463821, 1, 'Transport', 'Fun', '< 1 hr', '<$20', 2, 0, '0000-00-00', '2016-05-31 04:36:40', 1, 0, '0000-00-00 00:00:00'),
(39, 1, 21.147598, 72.760063, 0, 'Chjj', 'Kvjc', '2-3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-05-31 09:03:12', 4, 5, '2016-05-31 09:04:21'),
(40, 1, 21.147446, 72.760017, 1, 'Transport', 'Uffufh', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-31 09:06:32', 4, 0, '2016-05-31 09:18:05'),
(41, 1, 21.147488, 72.760048, 1, 'Transport', 'Gigiguc', '2-3 hrs', '$100-$300', 3, 0, '0000-00-00', '2016-05-31 09:19:12', 4, 5, '2016-05-31 09:20:21'),
(42, 2, 21.154499, 72.765198, 1, 'Transport', 'Sdfd', '1-2 hrs', '<$20', 3, 0, '0000-00-00', '2016-05-31 09:26:24', 3, 0, '0000-00-00 00:00:00'),
(43, 2, 21.154499, 72.765198, 1, 'Transport', 'Dxsvfds', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 09:31:53', 1, 0, '0000-00-00 00:00:00'),
(44, 2, 21.154499, 72.765198, 1, 'Transport', 'Dxsvfds', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 09:32:36', 1, 0, '0000-00-00 00:00:00'),
(45, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfd', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 09:35:16', 1, 0, '0000-00-00 00:00:00'),
(46, 2, 21.154499, 72.765198, 1, 'Transport', 'Dfg', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 09:37:14', 4, 0, '2016-05-31 09:37:27'),
(47, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfds', '2-3 hrs', '>$300', 3, 0, '0000-00-00', '2016-05-31 09:40:23', 4, 0, '2016-05-31 09:40:33'),
(48, 1, 21.147596, 72.760071, 0, 'Jviv', 'Jjvu', '2-3 hrs', '$100-$300', 0, 1, '0000-00-00', '2016-05-31 11:18:05', 4, 5, '2016-05-31 11:46:18'),
(49, 2, 21.154499, 72.765198, 1, 'Transport', 'Dsfsd', '1-2 hrs', '<$20', 2, 0, '0000-00-00', '2016-05-31 11:39:50', 4, 5, '2016-05-31 11:40:48'),
(50, 5, 21.146152, 72.760559, 0, 'Arrange', 'Tickets', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-31 12:07:13', 4, 0, '2016-05-31 12:07:24'),
(51, 2, 21.150225, 72.768677, 1, 'Transport', 'Bchc', '2-3 hrs', '$20-$100', 2, 0, '0000-00-00', '2016-05-31 12:08:35', 2, 0, '0000-00-00 00:00:00'),
(52, 5, 21.146152, 72.760559, 0, 'Arrange', 'Ticket', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-05-31 12:11:17', 4, 5, '2016-05-31 12:11:59'),
(53, 5, 21.146152, 72.760559, 1, 'Transport', 'Goods', '1-2hrs', '$100-300', 2, 0, '0000-00-00', '2016-05-31 12:36:10', 3, 0, '0000-00-00 00:00:00'),
(54, 5, 21.148094, 72.765564, 0, 'Arrange', 'Pizza', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:34:02', 3, 0, '0000-00-00 00:00:00'),
(55, 5, 21.148094, 72.765564, 0, 'Arrange', 'Painter', '2-3hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:40:05', 3, 0, '0000-00-00 00:00:00'),
(56, 5, 21.148094, 72.765564, 0, 'Arrange', 'Teacher', '1-2hrs', '$100-300', 0, 1, '0000-00-00', '2016-06-01 05:44:02', 3, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `qRequestAccept`
--

DROP TABLE IF EXISTS `qRequestAccept`;
CREATE TABLE IF NOT EXISTS `qRequestAccept` (
  `requestAcceptId` bigint(20) NOT NULL AUTO_INCREMENT,
  `qId` bigint(20) NOT NULL,
  `qRequestId` bigint(20) NOT NULL,
  `acceptDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `isConfirmedByQ` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 = not completed, 1 = completed, 2 = canceled',
  `isPaymentDone` tinyint(4) NOT NULL DEFAULT '0',
  `requestCompletionDateTime` datetime NOT NULL,
  `receiptTotalBill` float NOT NULL,
  `milesTransported` varchar(100) NOT NULL,
  `paymentDoneDateTime` datetime NOT NULL,
  `paymentDoneByRequestor` float NOT NULL,
  `paymentReceivedByQ` float NOT NULL,
  `speedRating` int(11) NOT NULL,
  `qualityRating` int(11) NOT NULL,
  `feedback` varchar(255) NOT NULL DEFAULT ' ',
  `ratingDate` datetime NOT NULL,
  `isReviewed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`requestAcceptId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `qRequestAccept`
--

INSERT INTO `qRequestAccept` (`requestAcceptId`, `qId`, `qRequestId`, `acceptDate`, `isConfirmedByQ`, `isPaymentDone`, `requestCompletionDateTime`, `receiptTotalBill`, `milesTransported`, `paymentDoneDateTime`, `paymentDoneByRequestor`, `paymentReceivedByQ`, `speedRating`, `qualityRating`, `feedback`, `ratingDate`, `isReviewed`) VALUES
(1, 1, 1, '2016-05-13 12:17:01', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(2, 2, 5, '2016-05-13 12:28:11', 1, 1, '2016-05-13 07:28:59', 0, '', '2016-05-13 07:28:59', 71.48, 65.2, 5, 5, 'Hchchnchxhxjuucjdhxhxhcudjfydjucudcjxhcjxgxhgx xx', '2016-05-13 07:29:24', 1),
(3, 1, 9, '2016-05-13 12:44:54', 1, 1, '2016-05-13 07:45:37', 0, '', '2016-05-13 07:45:37', 19.68, 15.2, 5, 5, 'ubtbt g gb', '2016-05-13 07:46:14', 1),
(4, 1, 10, '2016-05-13 12:47:29', 1, 1, '2016-05-13 07:47:53', 0, '', '2016-05-13 07:47:53', 19.68, 15.2, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(5, 2, 11, '2016-05-13 12:48:38', 1, 1, '2016-05-13 07:51:25', 0, '', '2016-05-13 07:51:25', 19.68, 15.2, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(6, 2, 12, '2016-05-13 13:01:13', 1, 1, '2016-05-13 08:03:03', 0, '', '2016-05-13 08:03:03', 19.68, 15.2, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(7, 3, 15, '2016-05-13 13:26:26', 1, 1, '2016-05-13 08:27:07', 0, '', '2016-05-13 08:27:07', 19.68, 15.2, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(8, 3, 16, '2016-05-13 13:32:02', 1, 1, '2016-05-13 08:32:07', 0, '', '2016-05-13 08:32:07', 19.68, 15.2, 1, 2, '', '2016-05-13 08:32:13', 1),
(9, 1, 18, '2016-05-15 00:53:23', 1, 1, '2016-05-14 19:55:03', 0, '', '2016-05-14 19:55:03', 19.68, 15.2, 1, 1, '', '2016-05-14 19:55:16', 1),
(10, 1, 19, '2016-05-15 00:57:14', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(11, 10, 34, '2016-05-30 21:23:46', 1, 1, '2016-05-30 16:27:32', 0, '', '2016-05-30 16:27:32', 19.68, 15.2, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(12, 10, 35, '2016-05-30 21:33:36', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(13, 10, 36, '2016-05-30 21:39:26', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(14, 10, 37, '2016-05-30 21:53:32', 1, 1, '2016-05-30 17:01:38', 0, '0.09', '2016-05-30 17:01:38', 52.66, 47.63, 1, 1, 'great!', '2016-05-30 17:01:53', 1),
(15, 2, 39, '2016-05-31 09:03:18', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(16, 2, 41, '2016-05-31 09:19:26', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(17, 1, 42, '2016-05-31 09:26:47', 1, 1, '2016-05-31 05:38:03', 0, '0.031412', '2016-05-31 05:38:03', 144.01, 135.8, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(18, 2, 48, '2016-05-31 11:18:12', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(19, 1, 49, '2016-05-31 11:40:08', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(20, 1, 51, '2016-05-31 12:08:44', 0, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(21, 3, 52, '2016-05-31 12:11:25', 2, 0, '0000-00-00 00:00:00', 0, '', '0000-00-00 00:00:00', 0, 0, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(22, 3, 53, '2016-05-31 12:36:23', 1, 1, '2016-06-01 00:27:24', 0, '0.41', '2016-06-01 00:27:24', 58.1, 52.86, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(23, 3, 54, '2016-06-01 05:34:11', 1, 1, '2016-06-01 00:36:29', 0, '', '2016-06-01 00:36:29', 20.72, 16.2, 0, 0, ' ', '0000-00-00 00:00:00', 0),
(24, 3, 55, '2016-06-01 05:40:13', 1, 1, '2016-06-01 00:41:10', 0, '', '2016-06-01 00:41:10', 20.72, 16.2, 4, 4, '', '2016-06-01 00:41:24', 1),
(25, 3, 56, '2016-06-01 05:44:12', 1, 1, '2016-06-01 00:45:00', 0, '', '2016-06-01 00:45:00', 20.72, 16.2, 0, 0, ' ', '0000-00-00 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `qRequestBillImages`
--

DROP TABLE IF EXISTS `qRequestBillImages`;
CREATE TABLE IF NOT EXISTS `qRequestBillImages` (
  `billImageId` bigint(20) NOT NULL AUTO_INCREMENT,
  `qRequestId` bigint(20) NOT NULL,
  `billImage` varchar(2000) NOT NULL,
  `billAmount` float(9,2) NOT NULL,
  PRIMARY KEY (`billImageId`),
  KEY `qRequestId` (`qRequestId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `qRequestBillImages`
--

INSERT INTO `qRequestBillImages` (`billImageId`, `qRequestId`, `billImage`, `billAmount`) VALUES
(1, 5, '1463142535884.jpg', 50.00),
(2, 34, '1464643622979.jpg', 0.00),
(3, 37, '1464645517373.jpg', 12.00),
(4, 37, '1464645606745.jpg', 11.32),
(5, 37, '1464645680349.jpg', 11.49),
(6, 42, '1464691071662.jpg', 123.00),
(7, 53, '1464758834752.jpg', 40.00),
(8, 54, '1464759379159.jpg', 1.00),
(9, 55, '1464759645136.jpg', 1.00),
(10, 56, '1464759875619.jpg', 1.00);

-- --------------------------------------------------------

--
-- Table structure for table `reportIssue`
--

DROP TABLE IF EXISTS `reportIssue`;
CREATE TABLE IF NOT EXISTS `reportIssue` (
  `issueDetail` varchar(255) NOT NULL,
  `userId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reportIssue`
--

INSERT INTO `reportIssue` (`issueDetail`, `userId`) VALUES
('Fix bugs  please ', 12),
('i''m having trouble logging in ', 7),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1),
('problem', 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(50) NOT NULL,
  `state_ab` varchar(50) NOT NULL,
  PRIMARY KEY (`state_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=64 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`, `state_ab`) VALUES
(1, 'Armed Forces Americas', 'AA'),
(2, 'Armed Forces Europe', 'AE'),
(3, 'Alaska', 'AK'),
(4, 'Alabama', 'AL'),
(5, 'Armed Forces Pacific', 'AP'),
(6, 'Arkansas', 'AR'),
(7, 'American Samoa', 'AS'),
(8, 'Arizona', 'AZ'),
(9, 'California', 'CA'),
(10, 'Colorado', 'CO'),
(11, 'Connecticut', 'CT'),
(12, 'District of Columbia', 'DC'),
(13, 'Delaware', 'DE'),
(14, 'Florida', 'FL'),
(15, 'Federated Micronesia', 'FM'),
(16, 'Georgia', 'GA'),
(17, 'Guam', 'GU'),
(18, 'Hawaii', 'HI'),
(19, 'Iowa', 'IA'),
(20, 'Idaho', 'ID'),
(21, 'Illinois', 'IL'),
(22, 'Indiana', 'IN'),
(23, 'Kansas', 'KS'),
(24, 'Kentucky', 'KY'),
(25, 'Louisiana', 'LA'),
(26, 'Massachusetts', 'MA'),
(27, 'Maryland', 'MD'),
(28, 'Maine', 'ME'),
(29, 'Marshall Islands', 'MH'),
(30, 'Michigan', 'MI'),
(31, 'Minnesota', 'MN'),
(32, 'Missouri', 'MO'),
(33, 'Northern Mariana Islands', 'MP'),
(34, 'Mississippi', 'MS'),
(35, 'Montana', 'MT'),
(36, 'North Carolina', 'NC'),
(37, 'North Dakota', 'ND'),
(38, 'Nebraska', 'NE'),
(39, 'New Hampshire', 'NH'),
(40, 'New Jersey', 'NJ'),
(41, 'New Mexico', 'NM'),
(42, 'Nevada', 'NV'),
(43, 'New York', 'NY'),
(44, 'Ohio', 'OH'),
(45, 'Oklahoma', 'OK'),
(46, 'Oregon', 'OR'),
(47, 'Pennsylvania', 'PA'),
(48, 'Puerto Rico', 'PR'),
(49, 'Palau', 'PW'),
(50, 'Rhode Island', 'RI'),
(51, 'South Carolina', 'SC'),
(52, 'South Dakota', 'SD'),
(53, 'Tennessee', 'TN'),
(54, 'Texas', 'TX'),
(55, 'United States Minor Outlying Islands', 'UM'),
(56, 'Utah', 'UT'),
(57, 'Virginia', 'VA'),
(58, 'US Virgin Islands', 'VI'),
(59, 'Vermont', 'VT'),
(60, 'Washington', 'WA'),
(61, 'Wisconsin', 'WI'),
(62, 'West Virginia', 'WV'),
(63, 'Wyoming', 'WY');

-- --------------------------------------------------------

--
-- Table structure for table `stopDetail`
--

DROP TABLE IF EXISTS `stopDetail`;
CREATE TABLE IF NOT EXISTS `stopDetail` (
  `stopDetailId` bigint(20) NOT NULL,
  `qRequestId` varchar(255) NOT NULL,
  `stopLat` float(9,6) NOT NULL,
  `stopLong` float(9,6) NOT NULL,
  `address` varchar(255) NOT NULL,
  `isQReachedAtStop` tinyint(4) NOT NULL,
  `reachedAtTime` datetime NOT NULL,
  `distanceTravelled` float(9,2) NOT NULL,
  `timeTakenForTravel` float(9,2) NOT NULL,
  PRIMARY KEY (`stopDetailId`,`qRequestId`),
  KEY `qRequestId` (`qRequestId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stopDetail`
--

INSERT INTO `stopDetail` (`stopDetailId`, `qRequestId`, `stopLat`, `stopLong`, `address`, `isQReachedAtStop`, `reachedAtTime`, `distanceTravelled`, `timeTakenForTravel`) VALUES
(1, '1', 21.146875, 72.759598, 'Luxuria Business Hub, Beside Dumas Resort, Dumas Rd, Vesu, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '17', 34.152893, -118.448975, 'Domino''s Pizza, 4467 Van Nuys Blvd, Sherman Oaks, CA 91403, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '24', 34.105061, -118.463203, 'Haines Obtains Ltd 1924 Roscomare Rd, Los Angeles, CA 90077, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '25', 21.150036, 72.761703, '(21.1500353, 72.7617048) ', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '27', 19.386772, -99.210098, 'Cto de la Unidad 33 Cto de la Unidad 33, Sta Fé IMSS, 01170 Ciudad de México, D.F., México', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '28', 34.152534, -118.453819, 'CVS Pharmacy, 14735 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '29', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '35', 34.153294, -118.456673, 'Pavilions, 14845 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '36', 34.106052, -118.463676, '1954-1980 Roscomare Rd, 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '37', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '38', 34.106125, -118.463692, '1954-1980 Roscomare Rd, 1954-1980 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '40', 21.147446, 72.759575, 'Vastu Luxuria | Surat, Nr. Dumas Resort, Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '41', 21.147026, 72.759743, 'ASK-EHS Engineering & Consultants Pvt. Ltd., 214 to 217 | Luxuria Business Hub | Besides Dumas Resort | Dumas Road, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '42', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '43', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '44', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '45', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '46', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '47', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '49', 21.154778, 72.764931, 'KFC - Surat Central, Ground Floor, Surat Central, IRIS Mall, Opposite Valantine Mall, Surat - Dumus Road, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '51', 21.150087, 72.768715, 'Raghuvir Party Plot, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(1, '53', 21.146473, 72.759399, 'Dumas Resorts Pvt Ltd 18/2, Dumas Road, Rundh, Rundh, New Magdalla, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '1', 21.153954, 72.763397, 'Nidhi impotrade pvt ltd, New Magdalla, Surat, Gujarat, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '17', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '24', 34.106400, -118.465675, 'Brentwood Express 1978 Linda Flora Dr, Los Angeles, CA 90077, United States', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '25', 21.147640, 72.765335, '(21.1476404, 72.7653356) ', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '27', 19.388283, -99.210121, 'Cto de la Unidad 5 Cto de la Unidad 5, Maria G. de García Ruiz, 01160 Ciudad de México, D.F., México', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '28', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '29', 34.151253, -118.454292, '14724 Ventura Blvd, 14724 Ventura Blvd, Sherman Oaks, CA 91403, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '35', 34.106152, -118.464073, '2001 Roscomare Rd, 2001 Roscomare Rd, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '36', 34.161167, -118.510155, 'Bubbles Pet Spa Encino, 17301 Ventura Blvd, Encino, CA 91316, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '37', 34.106155, -118.463280, '2002 Roscomare Rd, 2002 Roscomare Rd, Los Angeles, CA 90077, USA', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '38', 34.106400, -118.465675, 'Brentwood Express, 1978 Linda Flora Dr, Los Angeles, CA 90077, USA', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '40', 21.151699, 72.762497, 'Empire Chevrolet, Plot No. 3, Dumas Road, Near Rangoli Hotel, Rundh, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '41', 21.147179, 72.759789, 'La Net Team Software Solutions Pvt. LTD., 405/406 Luxuria Business Hub, Near VR mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '42', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '43', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '44', 21.154350, 72.764778, 'Blaster Family Spot, Mall Gaurav Path,, Dumas Rd, Central Revenue Colony, Athwa, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '45', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '46', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '47', 21.154457, 72.764816, 'Gili, Mahrana Pratap Marg, Athwalines, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '49', 21.154463, 72.764687, 'Cafe Coffee Day - Inside Iris Mall, Inside Iris Mall, Gaurav Path, Dumas Road, Opp Valentine Multiplex, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '51', 21.149622, 72.767448, 'DMD Party Plot, Piplod, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(2, '53', 21.148399, 72.765404, 'Safal Square,UM Rd,Vesu Udhana-Magdalla Rd, Vesu, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '1', 21.136570, 72.751862, 'Players Sports & Cafe, Cityplus Multiplex Front Parking Lot, Surat Dumas Road, Near Opp L & T Colony, Magdalla Port Road, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '40', 21.141336, 72.754982, 'Mataji hardware, Gail Colony, Vesu, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '41', 21.147442, 72.759575, 'Om Meditronics Pvt. Ltd., 506, Vastu Luxuria, Near Dumas Resort, Near VR Mall, Surat - Dumas Rd, New Magdalla, Surat, Gujarat 394518, India', 0, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '42', 21.154417, 72.764633, 'Central Mall, Opp. Valentine Multiplex, Surat - Dumas Road, Athwa, Piplod, Surat, Gujarat 395007, India', 1, '0000-00-00 00:00:00', 0.00, 0.00),
(3, '47', 21.154417, 72.764633, 'Central Mall, Opp. Valentine Multiplex, Surat - Dumas Road, Athwa, Piplod, Surat, Gujarat 395007, India', 0, '0000-00-00 00:00:00', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `userId` bigint(20) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `isEmailVerified` tinyint(4) NOT NULL DEFAULT '0' COMMENT '1=verified 0 = not verified ',
  `passcode` int(11) NOT NULL,
  `createdDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `userProfile` varchar(255) NOT NULL,
  `deviceToken` varchar(255) NOT NULL,
  `deviceType` int(11) NOT NULL COMMENT '1 = android 0= IOS',
  `forgotRandom` int(11) NOT NULL,
  `userType` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 for user and 1 for admin',
  `changedEmail` varchar(255) NOT NULL,
  `changedMobile` varchar(255) NOT NULL,
  `isMobileverified` tinyint(4) NOT NULL,
  `mobilePasscode` int(11) NOT NULL,
  `isDeleted` bit(1) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userId`, `firstName`, `lastName`, `email`, `mobile`, `password`, `isEmailVerified`, `passcode`, `createdDate`, `userProfile`, `deviceToken`, `deviceType`, `forgotRandom`, `userType`, `changedEmail`, `changedMobile`, `isMobileverified`, `mobilePasscode`, `isDeleted`) VALUES
(1, 'Tilak', 'Jethva', 'lanetteam.tilak@gmail.com', '8758504790', 'Lanet@123', 1, 223440, '2016-05-13 11:42:23', '1463140084582.jpg', '8865a8271c7e070f967c10fcfce234f4cfd4ff7ed00b707334e1389cdc92cbfd', 0, 0, 0, '', '', 1, 311586, b'1'),
(2, 'Riken', 'Doshi', 'lanetteam.riken@gmail.com', '9913060874', 'Lanet@123', 1, 396276, '2016-05-13 11:53:51', '1463140878975.jpg', '04ec71c66ea08cda38d694872b66eafb748022d4627281b26d83edb926aadf4f', 0, 0, 0, '', '', 1, 641974, b'1'),
(3, 'Admin', 'Admin', 'admin@qapp.com', '', 'admin@123', 1, 223440, '2016-05-13 11:42:23', '1463140084582.jpg', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 1, '', '', 1, 311586, b'0'),
(4, 'Tapan', 'Gohil', 'lanetteam.tapan@gmail.com', '9998078073', 'Lanet@123', 1, 994616, '2016-05-13 12:25:18', '1464696868232.jpg', 'euRYRttTfy8:APA91bF8Sz4mOsu6ueptcIaNPkZ88D_BP3_UKLrhHlg7O0e6Z1N76Jkirjsj1FjDOx7bmuOYbkjecXewEYr1jHQ2HUvHoluNo8mfjNPm3N4svBrebb1EZ53e7ouo1f14LvaGfNoSef7g', 1, 0, 0, '', '', 1, 707978, b'0'),
(5, 'Vimal', 'Gajera', 'lanetteam.vimalgajera@gmail.com', '9998078073', 'Lanet@123', 1, 837844, '2016-05-13 12:51:50', 'user-profile.png', 'cTW1COhKWTU:APA91bFJMNpHEEgfH31OPkOsPnpL7fgRQgHJSANH92LMFPaeKHtny0a4ycQ_e-moF2s1sia36MZTKbJI-gf1-II0mr1x524Psw1sGWCYJSh7J-JlltbFdampxeo5WaGWPZxxv47UL5Ir', 1, 0, 0, '', '', 1, 792848, b'0'),
(6, 'Felix', 'Odigie', 'felix@valdecapital.com', '6173881912', 'Rico@860424', 1, 102349, '2016-05-14 15:10:18', 'user-profile.png', 'fztKILuB0Ks:APA91bEBYSJKnMapew_-T6uMNykmI35xXgnbmpzKry_4imGjY3ArGqphXkKtC-d31BHWFAYZw8FIr3aWFUpnBHkWM82LTHKCH7Tpes3Alx_t6xfg8a7k2lgjjMBiGGXs_97UbBeKudEp', 1, 0, 0, '', '', 1, 699296, b'0'),
(7, 'Kimberly', 'Idoko', 'kimberly.idoko@gmail.com', '2038879349', 'Justice2!', 1, 437133, '2016-05-15 00:24:24', '1464634891868.jpg', 'c9eb1d638f30fe6b2446c612fbb0a764ce86c87e5dc49278b8351d4d9ccc2d22', 0, 0, 0, 'kimberly.odigie@myqapp.com', '', 1, 475464, b'0'),
(9, 'Test', 'User', 'test@gmail.com', '9998078073', 'Abc@1234', 0, 114006, '2016-05-18 11:27:39', 'user-profile.png', 'fy4rcoxZiP4:APA91bHAc0J3_EVO6etx6UhMEkfWfYKRvZFctodFGYy66WDTt4iFcLyGTjmz2v8Y_taT5Uy97G-v8SHhz8klr2UtVOM1zjZKpHkHAR-3BR8Uzabi2JltsfsSRQxDNyK0fSFkyVjkzOOW', 1, 0, 0, '', '', 0, 416426, b'0'),
(10, 'Demo', 'User', 'demo@qapp.com', '9998887770', 'Qapp@123', 1, 636797, '2016-05-18 11:29:35', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 289355, b'0'),
(11, 'Fly', 'Flyerson', 'flyflyerson@gmail.com', '4088214398', 'Apple123!', 1, 997161, '2016-05-19 19:04:39', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 514664, b'0'),
(12, 'Cristian ', 'Try', 'lokinenuco@gmail.com', '9153556813', 'Salomon123!@', 1, 338221, '2016-05-23 21:24:12', 'user-profile.png', 'fdlsbwWEYBs:APA91bFS1umeDo6B7VAXleg3DbP5HYBqLm9o0OBeDA82U345nqnHXRWM4FEan4wd79JznzyDoVUBOmneMtrilUQxkX2EfzoCgBSpuXNy7otUANObo7rv5omSNdV_Kgw1GIh9SDDNI1MJ', 1, 0, 0, 'criptoc@hotmail.com ', '', 1, 588823, b'0'),
(13, 'Deric', 'Mccloud', 'dericrmccloud@gmail.com', '13342210826', 'Mccloud#1', 1, 102562, '2016-05-28 03:18:13', 'user-profile.png', 'fgeycO9zXZY:APA91bED6eJGClpwv20yWOdZj6-xXDtWtPtaMhYyL5pYtqq4y__iUrXS6ELFT2zBiQqzt6bEkb0iR10A96Wz7DFEmpm97BYGYxSwdTSe8peY1TleIp5LD84pIDvMDwGJvvhB369RPb28', 1, 0, 0, '', '', 1, 115515, b'0'),
(14, 'Felix', 'Odigie', 'felix@myqapp.com', '6173881912', 'Ric0860424!', 0, 797199, '2016-05-29 04:04:39', '1464628686642.jpg', 'fztKILuB0Ks:APA91bEBYSJKnMapew_-T6uMNykmI35xXgnbmpzKry_4imGjY3ArGqphXkKtC-d31BHWFAYZw8FIr3aWFUpnBHkWM82LTHKCH7Tpes3Alx_t6xfg8a7k2lgjjMBiGGXs_97UbBeKudEp', 1, 0, 0, 'felix.odigie@gmail.com', '', 1, 845208, b'0'),
(15, 'Angela', 'Ciochetti', 'am.ciochetti@gmail.com', '8604178983', 'Angela19!', 1, 353389, '2016-05-30 14:26:17', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 647736, b'0'),
(16, 'Felix', 'Odigie', 'felix.odigie@gmail.com', '6173881912', 'Ric0860424!', 1, 301756, '2016-05-30 17:25:01', 'user-profile.png', 'fztKILuB0Ks:APA91bEBYSJKnMapew_-T6uMNykmI35xXgnbmpzKry_4imGjY3ArGqphXkKtC-d31BHWFAYZw8FIr3aWFUpnBHkWM82LTHKCH7Tpes3Alx_t6xfg8a7k2lgjjMBiGGXs_97UbBeKudEp', 1, 0, 0, '', '', 1, 745696, b'0'),
(17, 'Kevin', 'Robinson', 'thomas77607@aol.com', '8185197366', 'Johnson$7', 1, 239592, '2016-05-30 17:36:06', 'user-profile.png', 'f_mlA2d66YY:APA91bHFwm7Ic0fLUuRjrU7GWP3he8VpNUn95wfM77IGAZ845kNVn46_Cjgva4Ny6R0608v28mHLvtP6Gu-Im_z2fkARxDyXhr9XxOVdPlJIuFaPMyF04G4DJjEhjDQTVCpYIW2U2cNd', 1, 187841, 0, '', '', 1, 571912, b'0'),
(18, 'Paulette', 'Simone', 'rapturre@gmail.com', '8189179171', 'Kimberly$22', 1, 187942, '2016-05-30 17:43:45', 'user-profile.png', '2c6c1f73ddfae2f5a8d49af0c5a663b6304f6f31f130dc4d8dfe57e2aac9fea8', 0, 0, 0, '', '', 1, 812346, b'0'),
(19, 'Kimberly', 'Idoko', 'kimberly.odigie@gmail.com', '2038879349', 'Justice2!', 0, 522432, '2016-05-30 18:59:05', 'user-profile.png', 'a55d4df6fab72c8ece21f59e65a2f0cf4c7ffbd06416c1c9f7a607b4a087622d', 0, 0, 0, '', '', 0, 656955, b'0'),
(22, 'Ruben', 'Hernandez', 'jrhernandez2x@gmail.com', '9154746047', 'Th3qp@ss', 0, 429172, '2016-06-01 16:08:36', 'user-profile.png', 'fd81a177996845116f5f57bdb94dd549dcdeb1d8091bc9e6800bd6b6f829a5a4', 0, 0, 0, '', '', 0, 131730, b'0'),
(26, 'Shweta', 'b', 'lanetteam.shweta@gmail.com', '9726624558', 'Lanet@123', 0, 655153, '2016-06-09 11:51:07', 'user-profile.png', 'thaoiap', 1, 0, 0, '', '', 0, 738698, b'0');

-- --------------------------------------------------------

--
-- Table structure for table `userCard`
--

DROP TABLE IF EXISTS `userCard`;
CREATE TABLE IF NOT EXISTS `userCard` (
  `userCardId` bigint(20) NOT NULL AUTO_INCREMENT,
  `userId` bigint(20) NOT NULL,
  `cardNumber` int(11) NOT NULL,
  `cardToken` varchar(255) NOT NULL,
  `stripeCustomerAccount` varchar(255) NOT NULL,
  PRIMARY KEY (`userCardId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `userCard`
--

INSERT INTO `userCard` (`userCardId`, `userId`, `cardNumber`, `cardToken`, `stripeCustomerAccount`) VALUES
(1, 1, 4242, 'tok_18AemjFPPcEdaZL8RS6rjEW3', 'cus_8RXsS0g3uozXSc'),
(2, 2, 4242, 'tok_18AfD8FPPcEdaZL8u3kFrnh7', 'cus_8RYJrDrcx7Eyxi'),
(3, 5, 4242, 'tok_18AgHRFPPcEdaZL8DHkb1Oho', 'cus_8RZQ5ejN8CRkVk'),
(4, 7, 4242, 'tok_18BD4eFPPcEdaZL8aK9A6FJp', 'cus_8S7JDOPgPIYP8m'),
(5, 6, 4242, 'tok_18BHVPFPPcEdaZL8YfrRjDBN', 'cus_8SBssB9YPve2od'),
(6, 8, 4242, 'tok_18C5w8FPPcEdaZL8uxM2BHug', 'cus_8T200vTYt887GA'),
(7, 12, 9936, 'tok_18EiJQJxXxi1ARvC8YA5Oglz', ''),
(8, 14, 3015, 'tok_18Gf5FFPPcEdaZL8jxOwIlJA', ''),
(9, 19, 4242, 'tok_18GvbuFPPcEdaZL8f9R8hMpN', ''),
(10, 22, 4242, 'tok_18HcFrFPPcEdaZL8e3ne9dub', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
