var sql = require('../config/sql');
var connection = require('../config/database');
var stripe = require('stripe')(connection.stripeTestSecretKey);
var createqExternalAccountFunc;

//============================== Create customer account of user =============================

exports.createStripeCustomer = function (userId, token, callback) {
    sql.executeSql('SELECT email FROM user WHERE userId= "' + userId + '"', function (err, data) {
        if (!err) {
            stripe.customers.create({
                email: data[0].email,
                //description: 'Customer for Qapp',
                source: token // obtained with Stripe.js
                //default_source: token
            }, function (err, customer) {
                if (!err) {
                    sql.executeSql('UPDATE userCard SET stripeCustomerAccount="' + customer.id + '" WHERE userId= "' + userId + '"', function (err, Updatedata) {
                        if (!err) {
                            callback(null, customer);
                        } else {
                            callback(err, null);
                        }
                    });

                } else {
                    callback(err, null);
                }
            });
        }
        else {
            callback(err, null);
        }
    });
    
}

//============================== update customer account of user =============================

exports.updateStripeCustomer = function (userId, token, callback) {
    sql.executeSql('SELECT stripeCustomerAccount FROM userCard WHERE userId= "' + userId + '"', function (err, data) {
        if (!err) {
            stripe.customers.update(data[0].stripeCustomerAccount, {
                //description: "Customer for test@example.com",
                source: token
                //default_source: token
            }, function (err, customer) {
                if (!err) {
                    sql.executeSql('UPDATE userCard SET stripeCustomerAccount="' + customer.id + '" WHERE userId= "' + userId + '"', function (err, Updatedata) {
                        if (!err) {
                            callback(null, customer);
                        } else {
                            callback(err, null);
                        }
                    });

                } else {
                    callback(err, null);
                }
            });
        }
        else {
            callback(err, null);
        }
    });
    
}

//============================== token for bank account =============================

exports.stripeCardDetails = function (userId, callback) {
    sql.executeSql('SELECT cardToken FROM userCard WHERE userId= "' + userId + '"', function (err, data) {
        if (!err) {
            stripe.tokens.retrieve(data[0].cardToken, function (err, token) {
                // asynchronously called
                callback(null, token);
            });
        }
        else {
            callback(err, null);
        }
    });
    
}


//===================================== create new stripe account ==============================

exports.createStripeAccount = function (qId, accountDetails, callback) {
    
    stripe.accounts.create(accountDetails, function (err, account) {
        // asynchronously called
        if (!err) {
            sql.executeSql('UPDATE qProvider SET qStripeId="' + account.id + '" WHERE qId= "' + qId + '"', function (err, data) {
                if (!err) {
                    callback(null, account);
                }
                else {
                    callback(err, null);
                }
            });
        }
        else
            callback(err, null);
    });
}

//============================== token for bank account =============================

exports.stripeBankAccountToken = function (qId, tokenDetails, callback) {
    var qBankAccountNumber = tokenDetails.bank_account.account_number;
    qBankAccountNumber = qBankAccountNumber.substring(qBankAccountNumber.length - 4, qBankAccountNumber.length);
    stripe.tokens.create(tokenDetails, function (err, token) {
        // asynchronously called
        var j;
        if (!err) {
            sql.executeSql('UPDATE qProvider SET qBankAccountNumber = "'+ qBankAccountNumber +'",qStripeBankTokenId="' + token.id + '" WHERE qId= "' + qId + '"', function (err, data) {
                if (!err) {
                    callback(null, token);
                }
                else {
                    callback(err, null);
                }
            });
        }
        else {
            callback(err, null);
        }
    });
}



//createQStripeBankAccount
//============================== token for bank account =============================

exports.createQStripeBankAccount = function (userId, tokenDetails, callback) {
    var qBankAccountNumber = tokenDetails.bank_account.account_number;
    qBankAccountNumber = qBankAccountNumber.substring(qBankAccountNumber.length - 4, qBankAccountNumber.length);
    sql.executeSql('SELECT qId,qStripeId FROM qProvider WHERE userId= "' + userId + '"', function (err, data) {
        if (!err) {
            stripe.tokens.create(tokenDetails, function (err, token) {
                if (!err) {
                    sql.executeSql('UPDATE qProvider SET  qBankAccountNumber = "' + qBankAccountNumber + '", qStripeBankTokenId="' + token.id + '" WHERE qId= "' + data[0].qId + '"', function (err, updateData) {
                        if (!err) {
                            createqExternalAccountFunc(data[0].qId, function (err, externalAccountData) {
                                var j; 
                            });
                            callback(null, token);
                        }
                        else {
                            callback(err, null);
                        }
                    });
                }
                else {
                    callback(err, null);
                }
            });
        }
        else {
            callback(err, null);
        }
    });
}




//====================== assigning q stripe account and bank token from db ========================

exports.createqExternalAccount = createqExternalAccountFunc = function (qId, callback) {
    sql.executeSql('SELECT qStripeId,qStripeBankTokenId FROM qProvider WHERE qId= "' + qId + '"', function (err, data) {
        if (!err) {
            if (data[0].qStripeId != "" && data[0].qStripeBankTokenId != "") {
                
                stripe.accounts.createExternalAccount(data[0].qStripeId, { external_account: data[0].qStripeBankTokenId }, function (err, bank_account) {
                    if (!err) {
                        sql.executeSql('UPDATE qProvider SET qStripeBankId="' + bank_account.id + '" WHERE qId= "' + qId + '"', function (err, data) {
                            if (!err) {
                                callback(null, bank_account);
                            }
                            else {
                                callback(err, null);
                            }
                        });
                    }
                    else {
                        callback(err, null);
                    }
                });
            }
        }
        else {
            callback(err, null);
        }
    });
    /*stripe.accounts.update(stripeAccountId, { tos_acceptance: { date: Math.floor(Date.now() / 1000), ip: request.connection.remoteAddress } }, function (err, Update){
        var j;
    });*/
}


//Charge
/*
var charge = stripe.charges.create({
    amount: 1000, // amount in cents, again
    currency: "usd",
    source: stripeToken,
    description: "Example charge"
}, function (err, charge) {
    if (err && err.type === 'StripeCardError') {
    // The card has been declined
    }
});*/

//====================== Charge a User ========================

exports.createCharge = function (chargeAmount, stripeCustomerId, applicationFee, qStripeAccount, qId, qRequestId, callback) {
    
    var amtToCharge = (Number((chargeAmount).toFixed(0)));//.split('.');
    
    var amtOfFee = (Number((applicationFee).toFixed(0)));//(applicationFee * 100);//.split('.');
    var charge = {
        amount: amtToCharge, // amount in cents, again
        currency: "usd",
        customer: stripeCustomerId,
        application_fee: amtOfFee,
        destination: qStripeAccount,
        description: "Request completed charge"
    }
    
    sql.executeSql('UPDATE qRequestAccept SET isPaymentDone = 1, paymentDoneDateTime = NOW(), paymentDoneByRequestor ="'+ (amtToCharge/100) +'", paymentReceivedByQ = "'+ ((amtToCharge - amtOfFee)/100) +'"  WHERE qRequestId= "' + qRequestId + '"', function (err, data) {
        if (!err) {
            stripe.charges.create(charge, function (err, charge) {
                if (err) {
                    // The card has been declined
                    callback(err, null);
                } else {
                    sql.executeSql('UPDATE qProvider SET TotalPaymentReceived = TotalPaymentReceived + "' + (amtToCharge - amtOfFee) + '" WHERE qId= "' + qId + '"', function (err, data) {
                        if (!err) {
                            callback(null, charge);
                        }
                        else {
                            callback(err, null);
                        }
                    });
                }
            });
        }
        else {
            callback(err, null);
        }
    });
 
}


exports.chargeCustomerAccount = function (chargeAmount, stripeCustomerId,callback) {
	try {
		stripe.charges.create({
			amount: chargeAmount, // amount in cents, again
			currency: "usd",
			customer: stripeCustomerId // Previously stored, then retrieved
		});
		callback(null, '1');
	} catch (err) { 
		callback(err, null);
	}

};

