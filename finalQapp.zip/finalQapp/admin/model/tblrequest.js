var gcm = require('node-gcm');
var sql = require('../config/sql');
var connection = require('../config/database');
var apn = require('./push.js');
var StripeModel = require('./tblstripe.js');
var gcmSender = new gcm.Sender(connection.gcmSenderKey);
var qList = require('../app.js').qList;
var uList = require('../app.js').uList;
var http = require('http');

// ============================================ Qrequest Any thing else ==================================

exports.qRequestElse = function (userId, curLat, curLong, verb, noun, time, price, isRequireNow, requiredDate, callback) {
    var query = 'SET @QrequestId = 0; CALL qRequest_anyThingElse("' + userId + '","' + curLat + '","' + curLong + '","' + verb + '","' + noun + '","' + time + '","' + price + '","' + isRequireNow + '","' + requiredDate + '",@QrequestId); SELECT @QrequestId;';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            var deviceTokenA, deviceTokenI, message, msg;
            if (data[1].length == 0) {
                callback(null, data);
            }
            else {
                
                //START
                var qIds = "";
                for (var i = 0; i < data[1].length; i++) {
                    //START
                    if (i == 0) {
                        qIds += data[1][i].qId;
                    } else {
                        qIds += "," + data[1][i].qId;
                    }
                }
                
                // do a POST request
                // create the JSON object
                var jsonObject = JSON.stringify({
                    "messageBody" : {
                        "key": "Any Thing Else",
                        "Title": "New Request",
                        "Verb": "" + verb,
                        "Noun": "" + noun,
                        "cost": "" + price,
                        "time": "" + time,
                        "Lat": "" + curLat,
                        "Long": "" + curLong,
                        "requestId": "" + data[3][0]['@QrequestId']
                    },
                    "qIds" : qIds
                });
                
                // prepare the header
                var postheaders = {
                    'Content-Type' : 'application/json',
                    'Content-Length' : Buffer.byteLength(jsonObject, 'utf8')
                };
                
                // the post options
                var optionspost = {
                    host : '23.253.244.141',
                    port : 5050,
                    path : '/APIURL',
                    method : 'POST',
                    headers : postheaders
                };
                
                // do the POST call
                var reqPost = http.request(optionspost, function (res) {
					console.log("statusCode: ", res.statusCode);
					
					if (res.statusCode == 200) {
						
						//Update the LastRequestTime in DB 
						var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
						sql.executeSql(query, function (err, data) {
							
							if (err) {
								console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
							}
							else {
								console.log("LastRequestSent Updated for Q succefully " + qIds);
							}
						});
					}

                    // uncomment it for header details
                    //  console.log("headers: ", res.headers);
                    
                    res.on('data', function (d) {
                        console.info('POST result:\n');
                        process.stdout.write(d);
                        console.info('\nPOST completed');
                    });
                });
                // write the json data
                reqPost.write(jsonObject);
                reqPost.end();
                reqPost.on('error', function (e) {
                    console.error(e);
                });
                
                //END
                
                for (var i = 0; i < data[1].length; i++) {
                    var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
                    
                    sql.executeSql(subquery, function (err, result) {
                        if (result[0].deviceType == 1) {
                            var message = new gcm.Message({
                                "data": {
                                    "key1": "Any Thing Else"
                                },
                                "notification": {
                                    "Title": "New Request",
                                    "Verb": "'" + verb + "'",
                                    "Noun": "'" + noun + "'",
                                    "cost": "'" + price + "'",
                                    "time": "'" + time + "'",
                                    "Lat": "'" + curLat + "'",
                                    "Long": "'" + curLong + "'",
                                    "requestId": "'" + data[3][0]['@QrequestId'] + "'"
                                }
                            });
                            deviceTokenA = result[0].deviceToken;
                            gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                if (err) {
                                    console.error(err);
                                }
                                else {
                                    console.log(response);
                                }
                            });
                        }
                        else {
                            deviceTokenI = result[0].deviceToken;
                            var msg = {
                                "notification": {
                                    "key": "1",
                                    "Title": "New Request",
                                    "Verb": "" + verb,
                                    "Noun": "" + noun,
                                    "cost": "" + price,
                                    "time": "" + time,
                                    "Lat": "" + curLat,
                                    "Long": "" + curLong,
                                    "requestId": "" + data[3][0]['@QrequestId']
                                }
                            };
                            var alert = "New Request";
                            apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                if (err) {
                                    console.log(err);
                                }
                                else {
                                    console.log(response);
                                }
                            });
                        }
                    });
                }
                
                
                callback(null, data);
            }
        }
        else {
            callback(err, null);
        }
    });
}

// ============================================ Qrequest Transport ==================================

exports.qRequestTranport = function (userId, curLat, curLong, verb, noun, time, price, nStops, stops, callback) {
    var requestId;
    var query = 'SET @QrequestId = 0; CALL qRequest_Tranport("' + userId + '","' + curLat + '","' + curLong + '","' + verb + '","' + noun + '","' + time + '","' + price + '","' + nStops + '",@QrequestId); SELECT @QrequestId;';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            var deviceTokenA, deviceTokenI;
            requestId = data[3][0]['@QrequestId'];
            for (var i = 0; i < stops.length; i++) {
                var stopId = i + 1;
                sql.executeSql('insert into stopDetail(stopDetailId,qRequestId,stopLat,stopLong,address) values(' + stopId + ',"' + requestId + '","' + stops[i].lat + '","' + stops[i].long + '","' + stops[i].address + '")', function (err, next) {
                    if (err) {
                        callback(err, null);
                    }
                });
            }
            if (data[1].length == 0) {
                callback(null, data);
            }
            else {
                
                
                
                
                //START
                var qIds = "";
                for (var i = 0; i < data[1].length; i++) {
                    //START
                    if (i == 0) {
                        qIds += data[1][i].qId;
                    } else {
                        qIds += "," + data[1][i].qId;
                    }
                }
				
				

                // do a POST request
                // create the JSON object
                var jsonObject = JSON.stringify({
                    "messageBody" : {
                        "key": "Transport",
                        "Title": "New Request",
                        "Verb": "" + verb,
                        "Noun": "" + noun,
                        "cost": "" + price,
                        "time": "" + time,
                        "Lat": "" + curLat,
                        "Long": "" + curLong,
                        "requestId": "" + data[3][0]['@QrequestId']
                    },
                    "qIds" : qIds
                });
                
                // prepare the header
                var postheaders = {
                    'Content-Type' : 'application/json',
                    'Content-Length' : Buffer.byteLength(jsonObject, 'utf8')
                };
                
                // the post options
                var optionspost = {
                    host : '23.253.244.141',
                    port : 5050,
                    path : '/APIURL',
                    method : 'POST',
                    headers : postheaders
                };
                try {
                    // do the POST call
					var reqPost = http.request(optionspost, function (res) {
						
						if (res.statusCode == 200) { 
							
							//Update the LastRequestTime in DB 
							var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
							sql.executeSql(query, function (err, data) { 
							
								if (err) { 
									console.log("Error while updating the LastRequestSent " + err + "  Q---" +qIds );
								}
								else { 
									console.log("LastRequestSent Updated for Q succefully " +  qIds);
								}
							});
						}

                        console.log("statusCode: ", res.statusCode);
                        // uncomment it for header details
                        //  console.log("headers: ", res.headers);
                        
                        res.on('data', function (d) {
                            console.info('POST result:\n');
                            process.stdout.write(d);
                            console.info('\nPOST completed');
                        });
                    });
                    // write the json data
                    reqPost.write(jsonObject);
                    reqPost.end();
                    reqPost.on('error', function (e) {
                        console.error(e);
                    });
                } catch (err) {
                    console.log(err.message);
                }
                //END
                
                for (var i = 0; i < data[1].length; i++) {
                    var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
                    sql.executeSql(subquery, function (err, result) {
                        if (result[0].deviceType == 1) {
                            deviceTokenA = result[0].deviceToken;
                            var message = new gcm.Message({
                                "data": {
                                    "key1": "Transport"
                                },
                                "notification": {
                                    "Title": "New Request",
                                    "Verb": "'" + verb + "'",
                                    "Noun": "'" + noun + "'",
                                    "cost": "'" + price + "'",
                                    "time": "'" + time + "'",
                                    "Lat": "'" + curLat + "'",
                                    "Long": "'" + curLong + "'",
                                    "requestId": "'" + data[3][0]['@QrequestId'] + "'"
                                }
                            });
                            gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                if (err) {
                                    console.error(err);
                                }
                                else {
                                    console.log(response);
                                }
                            });
                        }
                        else {
                            deviceTokenI = result[0].deviceToken;
                            console.log(deviceTokenI);
                            var msg = {
                                "notification": {
                                    "key": "1",
                                    "Title": "New Request",
                                    "Verb": "" + verb,
                                    "Noun": "" + noun,
                                    "cost": "" + price,
                                    "time": "" + time,
                                    "Lat": "" + curLat,
                                    "Long": "" + curLong,
                                    "requestId": "" + data[3][0]['@QrequestId']
                                }
                            };
                            var alert = "New Request";
                            apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                if (err) {
                                    console.log(err);
                                }
                                else {
                                    console.log(response);
                                }
                            });
                        }
                    });
                }
                
                callback(null, data);
            }
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== request history Id ==========================================

exports.showRequest = function (requestId, callback) {
    var query = 'CALL show_Request("' + requestId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== request accept ==========================================

exports.requestAccept = function (requsetId, qId, callback) {
    var query = 'CALL request_Accept("' + requsetId + '","' + qId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            var deviceTokenA, deviceTokenI;
            if (data[0][0].msg == 'accept now' && data[1].length > 0) {
                if (data[1][0].deviceType == 1) {
                    var message = new gcm.Message({
                        "data": {
                            "key1": "Request Accepted"
                        },
                        "notification": {
                            "Title": "Request Accepted",
                            "Verb": "'" + data[1][0].requestVerb + "'",
                            "Noun": "'" + data[1][0].requestNoun + "'",
                            "isTransport": "" + data[1][0].isTransport,
                            "requestId": "'" + requsetId + "'",
                            "Message": "Your request accepted"
                        }
                    });
                    deviceTokenA = data[1][0].deviceToken;
                    console.log("in android");
                    console.log(deviceTokenA);
                    gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                        if (err) {
                            console.error(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                else {
                    deviceTokenI = data[1][0].deviceToken;
                    console.log("in accepted token");
                    console.log(deviceTokenI);
                    var msg = {
                        "notification": {
                            "key": "2",
                            "Title": "Request Accepted",
                            "Verb": "" + data[1][0].requestVerb,
                            "Noun": "" + data[1][0].requestNoun,
                            "isTransport": "" + data[1][0].isTransport,
                            "requestId": "" + requsetId,
                            "Message": "Your request accepted"
                        }
                    };
                    var alert = "Request Accepted";
                    apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                        if (err) {
                            console.log(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
            }
            callback(null, data);

        }
        else {
            callback(err, null);
        }
    });
}

//========================================== Q request Completed Confiramtion ==========================================


exports.setIsConfirmed = function (qRequestId, userType, callback) {
    var query = 'CALL confirm_Request("' + qRequestId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data[0].length > 0) {
                if (data[0][0].deviceType == 1) {

                    var message = new gcm.Message({
                        "data": {
                            "key1": "Request Completed"
                        },
                        "notification": {
                            "Title": "Request Completed",
                            "Verb": "'" + data[0][0].requestVerb + "'",
                            "Noun": "'" + data[0][0].requestNoun + "'",
                            "cost": "'" + data[0][0].amt + "'",
                            "requestId": "'" + qRequestId + "'"
                        }
                    });
                    deviceTokenA = data[0][0].deviceToken;
                    gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                        if (err) {
                            console.error(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                else {
                    deviceTokenI = data[0][0].deviceToken;
                    var msg = {
                        "notification": {
                            "key": "3",
                            "Title": "Request Completed",
                            "Verb": "" + data[0][0].requestVerb,
                            "Noun": "" + data[0][0].requestNoun,
                            "cost": "" + data[0][0].amt,
                            "requestId": "" + qRequestId
                        }
                    };
                    var alert = "Request Completed";
                    apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                        if (err) {
                            console.log(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                //var a = new Date(); // Now
                var a = new Date(), b, d, min, requestFee, total_payment, total_q, total_app;
                
                // Deduct the payment
                if (data[0][0].requestVerb == 'Transport' || data[0][0].requestVerb == 'transport') {
                    b = data[0][0].acceptDate;
                    d = (b - a);
                    min = (d / 60000) - 60;
                    if (min < 0) {
                        min = 0;
					}
					total_q = 0;
                    var diff = Math.abs(new Date() - data[0][0].acceptDate);
                    var minutes = Math.floor((diff / 1000) / 60);
					//requestFee = ((16 + (data[0][0].milesTransported * 0.20) + (min * 0.25)) * 3.6 / 100);
					requestFee = (16 + (data[0][0].milesTransported * 0.20) + (min * 0.25));
					total_q = total_q + (requestFee * 0.8);
					total_q = total_q + data[0][0].amt;
					
					total_payment = (requestFee + data[0][0].amt) + ((requestFee + data[0][0].amt) * 3.6 / 100);
                  //  total_q = data[0][0].amt + ((requestFee * 8) / 10);
                    total_app = total_payment - total_q;
                }
                else {
                    
                    var diff = Math.abs(new Date() - data[0][0].acceptDate);
                    var minutes = Math.floor((diff / 1000) / 60);
                    b = data[0][0].acceptDate;
                    d = (a - b);
                    min = (d / 60000) - 60;
                    if (min < 0) {
                        min = 0;
					}
					total_q = 0;
					//requestFee = ((19 + (min * 0.30)) * 3.6 / 100);
					requestFee = (19 + (min * 0.30));
					total_q = total_q + (requestFee * 0.8);
					total_q = total_q + data[0][0].amt;
					

                    total_payment = (requestFee + data[0][0].amt) + ((requestFee + data[0][0].amt) * 3.6 / 100);
                    //total_q = data[0][0].amt + ((requestFee * 8) / 10);
                    total_app = total_payment - total_q;
				}
				
				
				//var queryUpdate = "update qRequestAccept set paymentRecievedByQ = " + total_q + ", paymentDoneByRequestor = " + total_app+" where qRequestId = '" + qRequestId + "'";
				//sql.executeSql(queryUpdate, function (error, datarec) {
				//	console.log("paymentRecievedByQ Updated");
				//});

			
                
                var amtToCharge = (Number((total_payment).toFixed(2)) * 100);
				data[0][0].receiptTotalBill = amtToCharge;
                var amtOfFee = (Number((total_app).toFixed(2)) * 100);
                var chargeDetails = {
                    minutes : minutes,
                    requestFee : requestFee,
                    totalPayment : amtToCharge,
                    totalPayableAmountToQ : total_q,
                    applicationFee : amtOfFee
                }
                var stripeCustomerAccount = "";
                if (data[1].length > 0) {
                    stripeCustomerAccount = data[1][0].stripeCustomerAccount;
                }
                StripeModel.createCharge(amtToCharge, stripeCustomerAccount, amtOfFee , data[0][0].qStripeId, data[0][0].qId, qRequestId, function (err, chargedData) {
                    if (!err) {
                        var SendNotificationOfCharge = {
                            "Notify" : [
                                {
                                    "deviceToken": data[0][0].deviceToken,
                                    "deviceType": data[0][0].deviceType
                                },
                                {
                                    "deviceToken": data[2][0].qDeviceToken,
                                    "deviceType": data[2][0].qDeviceType
                                }]
                        };
                        for (var i = 0; i < SendNotificationOfCharge.Notify.length ; i++) {
                            if (SendNotificationOfCharge.Notify[i].deviceType == 1) {
                                var message = new gcm.Message({
                                    "data": {
                                        "key1": "User Charged"
                                    },
                                    "notification": {
                                        "Title": "User charged for request",
                                        "Verb": "'" + data[0][0].requestVerb + "'",
                                        "Noun": "'" + data[0][0].requestNoun + "'",
                                        "cost": "'" + data[0][0].amt + "'",
                                        "requestId": "'" + qRequestId + "'",
                                        "amountCharged": "" + (chargedData.amount / 100)
                                    }
                                });
                                deviceTokenA = SendNotificationOfCharge.Notify[i].deviceToken;
                                gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                                    if (err) {
                                        console.error(err);
                                    }
                                    else {
                                        console.log(response);
                                    }
                                });
                            }
                            else {
                                deviceTokenI = SendNotificationOfCharge.Notify[i].deviceToken;
                                var msg = {
                                    "notification": {
                                        "key": "5",
                                        "Title": "Request Completed",
                                        "Verb": "" + data[0][0].requestVerb,
                                        "Noun": "" + data[0][0].requestNoun,
                                        "cost": "" + data[0][0].amt,
                                        "requestId": "" + qRequestId,
                                        "amountCharged": "" + (chargedData.amount / 100)
                                    }
                                };
                                var alert = "User Charged";
                                apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                                    if (err) {
                                        console.log(err);
                                    }
                                    else {
                                        console.log(response);
                                    }
                                });
                            }
                        }
                    } else {
                        //Code if stripe fails to charge user
						var errrrrrrrrr;
						console.log("charge failed......");
                    }
                });
            }
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== receipt Upload ==========================================

exports.receiptUpload = function (qRequestId, filePath, billAmount, callback) {
    var query = 'insert into qRequestBillImages(qRequestId,billImage,billAmount) values("' + qRequestId + '","' + filePath + '","' + billAmount + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== Q request total miles Transported  ==========================================

exports.setMilesTransported = function (qRequestId, milesTransported, callback) {
    var query = 'UPDATE qRequestAccept SET milesTransported="' + milesTransported + '" WHERE qRequestId = "' + qRequestId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}


/*
//========================================== Q receipt total bill ==========================================

exports.setqReceiptBill = function (qRequestId, receiptTotalBill, milesTransported, callback) {
    var query = 'UPDATE qRequestAccept SET receiptTotalBill="' + receiptTotalBill + '",milesTransported="' + milesTransported + '" WHERE qRequestId = "' + qRequestId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}
*/
//========================================== change status reached at stop ==========================================

exports.changeStatusOfStop = function (qRequestId, Lat, Long, callback) {
    var query = "CALL  reached_AtStop ('" + qRequestId + "'," + Lat + "," + Long + ")";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== change status reached at stop ==========================================

exports.totalCompletedStop = function (qRequestId, callback) {
    var query = 'select stopDetailId as completedStop from stopDetail WHERE qRequestId = "' + qRequestId + '" and isQReachedAtStop = 1';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== cancel request ==========================================

exports.cancelRequest = function (qRequestId, callback) {
    var query = 'Call cancel_Request ("' + qRequestId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//========================================== cancel request ==========================================

exports.confirmCancelRequest = function (qRequestId, callback) {
    var query = 'CALL confirmCalcel_Request("' + qRequestId + '")';
    sql.executeSql(query, function (err, data) {
		if (!err) {
			
			if (data[2].length > 0) { 
			
				StripeModel.chargeCustomerAccount(5, data[2].stripeCustomerAccount, function (err, data) {
					
				});
			}

			if (data[1].length > 0) {
				
                if (data[1][0].deviceType == 1) {
                    var message = new gcm.Message({
                        "data": {
                            "key1": "Request Cancelled"
                        },
                        "notification": {
                            "Title": "Request Cancelled",
                            "Verb": "'" + data[1][0].requestVerb + "'",
                            "Noun": "'" + data[1][0].requestNoun + "'",
                            "requestId" : qRequestId
                        }
                    });
                    deviceTokenA = data[1][0].deviceToken;
                    gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
                        if (err) {
                            console.error(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
                else {
                    deviceTokenI = data[1][0].deviceToken;
                    var msg = {
                        "notification": {
                            "key": "4",
                            "Title": "Request Cancelled",
                            "Verb": "" + data[1][0].requestVerb,
                            "Noun": "" + data[1][0].requestNoun,
                            "requestId" : qRequestId
                        }
                    };
                    var alert = "Request Cancelled";
                    apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
                        if (err) {
                            console.log(err);
                        }
                        else {
                            console.log(response);
                        }
                    });
                }
            }
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}


//declineRequests


//========================================== cancel request ==========================================

exports.declineRequests = function (callback) {
    //var query = 'UPDATE qRequest SET requestStatus=-1 WHERE requestStatus=1';
    var query = 'UPDATE qRequest SET requestStatus=-1 WHERE requestStatus=1 AND TIMESTAMPDIFF(MINUTE, qRequest.createdDate , NOW() ) > 60';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//===============================================   20 second   ========================================================

exports.resendRequest = function (callback) {
	
	var query = "SELECT * FROM `qRequest` WHERE requeststatus =1 and TIMESTAMPDIFF(MINUTE,createdDate,now()) <60 ";
	sql.executeSql(query, function (err, data) {
		
		if (!err) { 
			
			for (var i = 0; i < data.length; i++) {
				
				if (data[i].isTransport == 1) {
					
					var query = 'CALL qRequest_Tranport_resend("' + data[i].userId + '","' + data[i].currentLat + '","' + data[i].currentLong + ')';
					sql.executeSql(query, function (err, dataq) {
						
						if (!err) {
							//START
							var qIds = "";
							for (var j = 0; j < dataq.length; j++) {
								//START
								if (i == 0) {
									qIds += dataq[j].qId;
								} else {
									qIds += "," + dataq[j].qId;
								}
							}
							
							
							
							// do a POST request
							// create the JSON object
							var jsonObject = JSON.stringify({
								"messageBody" : {
									"key": "Transport",
									"Title": "New Request",
									"Verb": "" + data[i].requestVerb,
									"Noun": "" + data[i].requestNoun,
									"cost": "" + data[i].qRequiredPayment,
									"time": "" + data[i].qRequiredTime_Hr,
									"Lat": "" + data[i].currentLat,
									"Long": "" + data[i].currentLong,
									"requestId": "" + data[i].qRequestId
								},
								"qIds" : qIds
							});
							
							// prepare the header
							var postheaders = {
								'Content-Type' : 'application/json',
								'Content-Length' : Buffer.byteLength(jsonObject, 'utf8')
							};
							
							// the post options
							var optionspost = {
								host : 'lanetteam.com',
								port : 5051,
								path : '/APIURL',
								method : 'POST',
								headers : postheaders
							};
							try {
								// do the POST call
								var reqPost = http.request(optionspost, function (res) {
									
									if (res.statusCode == 200) {
										
										//Update the LastRequestTime in DB 
										var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
										sql.executeSql(query, function (err, data) {
											
											if (err) {
												console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
											}
											else {
												console.log("LastRequestSent Updated for Q succefully " + qIds);
											}
										});
									}
									
									console.log("statusCode: ", res.statusCode);
									// uncomment it for header details
									//  console.log("headers: ", res.headers);
									
									res.on('data', function (d) {
										console.info('POST result:\n');
										process.stdout.write(d);
										console.info('\nPOST completed');

									});
								});
								// write the json data
								reqPost.write(jsonObject);
								reqPost.end();
								reqPost.on('error', function (e) {
									console.error(e);
								});
							} catch (err) {
								console.log(err.message);
							}
							//END
							
							for (var i = 0; i < data.length; i++) {
								var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
								sql.executeSql(subquery, function (err, result) {
									if (result[0].deviceType == 1) {
										deviceTokenA = result[0].deviceToken;
										var message = new gcm.Message({
											"data": {
												"key1": "Transport"
											},
											"notification": {
												"Title": "New Request",
												"Verb": "'" + verb + "'",
												"Noun": "'" + noun + "'",
												"cost": "'" + price + "'",
												"time": "'" + time + "'",
												"Lat": "'" + curLat + "'",
												"Long": "'" + curLong + "'",
												"requestId": "'" + data[3][0]['@QrequestId'] + "'"
											}
										});
										gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
											if (err) {
												console.error(err);
											}
											else {
												console.log(response);
											}
										});
									}
									else {
										deviceTokenI = result[0].deviceToken;
										console.log(deviceTokenI);
										var msg = {
											"notification": {
												"key": "1",
												"Title": "New Request",
												"Verb": "" + verb,
												"Noun": "" + noun,
												"cost": "" + price,
												"time": "" + time,
												"Lat": "" + curLat,
												"Long": "" + curLong,
												"requestId": "" + data[3][0]['@QrequestId']
											}
										};
										var alert = "New Request";
										apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
											if (err) {
												console.log(err);
											}
											else {
												console.log(response);
											}
										});
									}
								});
							}

						}
						else {
							callback(err, null);
						}
					
					});

				}
				else { 
					
					var query = 'CALL qRequest_anyThingElse_resend("' + data[i].userId + '","' + data[i].currentLat + '","' + data[i].currentLong + ')';
					sql.executeSql(query, function (err, dataq) {
						
						if (!err) {
							//START
							var qIds = "";
							for (var i = 0; i < dataq[1].length; i++) {
								//START
								if (i == 0) {
									qIds += dataq[1][i].qId;
								} else {
									qIds += "," + dataq[1][i].qId;
								}
							}
							
							
							
							// do a POST request
							// create the JSON object
							var jsonObject = JSON.stringify({
								"messageBody" : {
									"key": "Anything Else",
									"Title": "New Request",
									"Verb": "" + data[i].requestVerb,
									"Noun": "" + data[i].requestNoun,
									"cost": "" + data[i].qRequiredPayment,
									"time": "" + data[i].qRequiredTime_Hr,
									"Lat": "" + data[i].currentLat,
									"Long": "" + data[i].currentLong,
									"requestId": "" + data[i].qRequestId
								},
								"qIds" : qIds
							});
							
							// prepare the header
							var postheaders = {
								'Content-Type' : 'application/json',
								'Content-Length' : Buffer.byteLength(jsonObject, 'utf8')
							};
							
							// the post options
							var optionspost = {
								host : 'lanetteam.com',
								port : 5051,
								path : '/APIURL',
								method : 'POST',
								headers : postheaders
							};
							try {
								// do the POST call
								var reqPost = http.request(optionspost, function (res) {
									
									if (res.statusCode == 200) {
										
										//Update the LastRequestTime in DB 
										var query = "Update qProvider set LastRequestSent = now() where qId in (" + qIds + ")";
										sql.executeSql(query, function (err, data) {
											
											if (err) {
												console.log("Error while updating the LastRequestSent " + err + "  Q---" + qIds);
											}
											else {
												console.log("LastRequestSent Updated for Q succefully " + qIds);
											}
										});
									}
									
									console.log("statusCode: ", res.statusCode);
									// uncomment it for header details
									//  console.log("headers: ", res.headers);
									
									res.on('data', function (d) {
										console.info('POST result:\n');
										process.stdout.write(d);
										console.info('\nPOST completed');

									});
								});
								// write the json data
								reqPost.write(jsonObject);
								reqPost.end();
								reqPost.on('error', function (e) {
									console.error(e);
								});
							} catch (err) {
								console.log(err.message);
							}
							//END
							
							for (var i = 0; i < data.length; i++) {
								var subquery = 'select deviceToken, deviceType from user where userId = "' + data[1][i].userId + '"';
								sql.executeSql(subquery, function (err, result) {
									if (result[0].deviceType == 1) {
										deviceTokenA = result[0].deviceToken;
										var message = new gcm.Message({
											"data": {
												"key1": "Transport"
											},
											"notification": {
												"Title": "New Request",
												"Verb": "" + data[i].requestVerb,
												"Noun": "" + data[i].requestNoun,
												"cost": "" + data[i].qRequiredPayment,
												"time": "" + data[i].qRequiredTime_Hr,
												"Lat": "" + data[i].currentLat,
												"Long": "" + data[i].currentLong,
												"requestId": "" + data[i].qRequestId
											}
										});
										gcmSender.send(message, { registrationTokens: [deviceTokenA] }, function (err, response) {
											if (err) {
												console.error(err);
											}
											else {
												console.log(response);
											}
										});
									}
									else {
										deviceTokenI = result[0].deviceToken;
										console.log(deviceTokenI);
										var msg = {
											"notification": {
												"key": "1",
												"Title": "New Request",
												"Verb": "" + data[i].requestVerb,
												"Noun": "" + data[i].requestNoun,
												"cost": "" + data[i].qRequiredPayment,
												"time": "" + data[i].qRequiredTime_Hr,
												"Lat": "" + data[i].currentLat,
												"Long": "" + data[i].currentLong,
												"requestId": "" + data[i].qRequestId
											}
										};
										var alert = "New Request";
										apn.pushNotification(alert, msg, deviceTokenI, function (err, response) {
											if (err) {
												console.log(err);
											}
											else {
												console.log(response);
											}
										});
									}
								});
							}

						}
						else {
							callback(err, null);
						}
					
					});
				}

				
			}
					
		}
		else { 
			callback(err, null);
		}

	});

}
