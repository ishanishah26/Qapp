//=========================================== configration =====================================
var settings = require('../config/database');
var nodemailer = require('nodemailer');
var emailtemplate = require('./emailTemplate');
var forgotPasswordEmail = require('./ForgotePasswordEmail');
var completeRequestTemplate = require('./completeRequestTemplate');
var reportIssueTemplate = require('./reportIssueTemplate');
var transporter = nodemailer.createTransport(settings.smtpConfig);

//================================================================== otp send =================================

exports.sendEmail = function (email, name, random, callback) {
    var output = name.substring(0, 1).toUpperCase() + name.substring(1);
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : email,
        from : "info@myqapp.com",
        subject : "Verify your email address",
        html: emailtemplate.emailVerification.format(output, random) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//=============================================================== forgot password mail ================================

exports.sendEmailForgot = function (email, random, callback) {
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : email,
        from : "info@myqapp.com",
        subject : "Recover Your password",
        html: forgotPasswordEmail.emailVerification.format("", random) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//=============================================================== complete request ================================

exports.sendEmailComplete = function (email, name, verb, noun, fname, lname, payment, heading, image, transportDetails, callback) {
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : email,
        from : "receipts@myqapp.com",
        subject : "Complete Your Request",
        html: completeRequestTemplate.emailVerification.format(name, verb, noun, fname, lname, payment, heading, image, transportDetails) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}

//================================================= send message for Qprovider registration ==============================

exports.twilioSendMsg = function (toPhonenumber, msg, callback) {

    var client = require('twilio')(settings.TwilioAccountId, settings.TwilioAuthToken);
    //Add +1 to number for sending sms in USA
    client.messages.create({
        to: "+1" + toPhonenumber,
        from: settings.TwilioNumber,
        body: msg,
    }, function (err, message) {
        if (err) {
            console.log(err);
            callback(err, null);
        } else {
            callback(null, message);
        }
    });
};

//================================================= send message user to Qprovider ==============================

exports.twilioSendMsgForUser = function (toPhonenumber, fromPhonenumber, msg, callback) {

    var client = require('twilio')(settings.TwilioAccountId, settings.TwilioAuthToken);
    //Add +1 to number for sending sms in USA
    client.messages.create({
        to: "+1" + toPhonenumber,
        from: settings.TwilioNumber,
        body: msg,
    }, function (err, message) {
        if (err) {
            console.log(err);
            callback(err, null);
        } else {
            callback(null, message);
        }
    });
};

//=============================================================== forgot password mail ================================

exports.sendReportEmail = function (username, issue, callback) {
    transporter.sendMail({
        host : "23.253.244.141",
        port : "80",
        domain : "23.253.244.141",
        to : "info@myqapp.com",
        from : "info@myqapp.com",
        subject : "New Issue Reported",
        html: reportIssueTemplate.emailReport.format(username, issue) // html body
    },
              function (err, data) {
        if (err) {
            callback(err, null);
        }
        else {
            callback(null, data);
        }
    });
}
