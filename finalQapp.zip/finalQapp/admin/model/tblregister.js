var gcm = require('node-gcm');
var connection = require('../config/database');
var sql = require('../config/sql');
var gcmSender = new gcm.Sender(connection.gcmSenderKey);

//===================================== new register ==============================

exports.registerNew = function (fname, lname, email, mobile, password, random, deviceToken, deviceType, mobileRandom,  callback) {
    var image = "user-profile.png";
    var query = 'CALL user_register("' + email + '","' + mobile + '","' + password + '","' + random + '","' + fname + '","' + lname + '","' + image + '","' + deviceToken + '","' + deviceType + '","' + mobileRandom + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

// ============================================ Signin ==================================

exports.signin = function (email, password, deviceToken, deviceType, callback) {
    var query = 'SELECT user.userId, user.firstName, user.lastName, user.email, user.mobile, user.isEmailVerified, user.isMobileverified, user.userProfile , qProvider.qId, qProvider.isQVerified, qProvider.registrationStepCompleted , userCard.cardNumber '
                          + 'FROM user '
                          + 'LEFT JOIN qProvider ON qProvider.userId = user.userId '
                          + 'LEFT JOIN userCard ON userCard.userId = user.userId '
                          + 'WHERE user.email = "' + email + '" AND password="' + password + '" AND isDeleted=0';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                var id = data[0].userId;
                var subquery = 'UPDATE user SET deviceToken = "' + deviceToken + '", deviceType = "' + deviceType + '" WHERE userId = "' + id + '"';
                sql.executeSql(subquery, function (err, data) {
                    if (err) {
                        console.log(err);
                        callback(err, null);
                    }
                    console.log(data);
                });
                callback(null, data);
            }
            else {
                callback(null, false);
            }
        }
        else {
            callback(err, null);
        }
    });
}

// ============================================ Signin Admin ==================================
exports.loginAdmin = function (email, password, callback) {
    var query = "SELECT email FROM user where userType=1 AND email='" + email + "' AND password='" + password + "'";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};
