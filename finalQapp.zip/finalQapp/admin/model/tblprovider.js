var gcm = require('node-gcm');
var sql = require('../config/sql');
var connection = require('../config/database');
var gcmSender = new gcm.Sender(connection.gcmSenderKey);
var tblStripes = require('./tblstripe.js');

// ============================================ Qprovider ==============================================

exports.qProviderRequest = function (userId, curLat, curLong, fname, lname, email, zipCode, mobile, address, city, state, callback) {
    //var query = 'CALL insert_qProvider("' + userId + '","' + curLat + '","' + curLong + '","' + fname + '","' + lname + '","' + email + '","' + zipCode + '","' + mobile + '","' + random + '")';
    var query = 'CALL insert_qProvider("' + userId + '","' + curLat + '","' + curLong + '","' + fname + '","' + lname + '","' + email + '","' + zipCode + '","' + mobile + '","' + address + '","' + city + '","' + state + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== Qprovide step 3 =======================================

exports.qProviderRequestThird = function (userId, lFname, lMname, lLname, securityNum, dob, dlNum, state, dlExpiration, hsInfo, clgInfo, yearoProfExp, yearoProfAssiExp, qRole, callback) {
    var name = lFname + " " + lMname + " " + lLname;
    var query = 'UPDATE qProvider SET nameOnDL="' + name + '", socialSecurityNo = "' + securityNum + '", dateOfBirth = "' + dob + '",dlNo = "' + dlNum + '",dlState = "' + state + '",dateOfDlExpiration = "' + dlExpiration + '",hsInfo = "' + hsInfo + '",collegeInfo = "' + clgInfo + '",totalYearOfProfExp = "' + yearoProfExp + '",personalAssistantExp = "' + yearoProfAssiExp + '",roleOfQ = "' + qRole + '",isStateDisclouserAcknowledged = "1",isBackgroundCheckAuthorized = "1",registrationDate = now(),registrationStepCompleted = "7" WHERE userId = "' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

// ============================================ verify mobile number ==================================

exports.verifyMobile = function (userId, passcode, callback) {
    var query = 'UPDATE qProvider SET isMobileVerified = "1", registrationStepCompleted = "2" where userId="' + userId + '" and mobileVerificationCode ="' + passcode + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== Change mobile ===============================

exports.changeMobile = function (userId, mobile, random, callback) {
    var query = 'UPDATE qProvider SET mobile="' + mobile + '", mobileVerificationCode="' + random + '" WHERE userId = "' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== Change resended otp ===============================

exports.changeOtp = function (userId, random, callback) {
    var query = 'CALL resendOtp_mobile("' + userId + '","' + random + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== qProvider activate =============================

exports.qProviderActive = function (userId, curLat, curLong, callback) {
    var query = 'UPDATE qProvider SET isQOnline="1", currentLat = "' + curLat + '", currentLong = "' + curLong + '"WHERE isQVerified="1" AND userId="' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}


exports.checkQBankAccount = function (qId, callback) {

    var query = "Select * from qProvider where qStripeBankId is not null and qStripeBankId <> '' and userId = '" + qId + "'";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });

}


//=================================== qProvider offline ===================================

exports.qProviderDeactive = function (userId, callback) {
    var query = 'update qProvider set isQOnline="0" where userId="' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}
//========================================== Q provider average rating ======================

exports.qProviderAverageRating = function (qId, callback) {
    var query = 'CALL qAverageRating("' + qId + '")';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== qProvider activate =============================

exports.updateLocationOfQ = function (qId, curLat, curLong, callback) {
    var query = 'update qProvider set currentLat = "' + curLat + '", currentLong = "' + curLong + '"where userId="' + qId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}

//======================================== state ==========================================

exports.getstates = function (callback) {
    var query = 'select state_id,state_name from state';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);

        }
        else {
            callback(err, null);
        }
    });
}

//======================================== state ==========================================

exports.getSatusOfQ = function (userId, callback) {
    var query = 'select isQOnline from qProvider where userId = "' + userId + '"';
    sql.executeSql(query, function (err, data) {
        if (!err) {
            callback(null, data);
        }
        else {
            callback(err, null);
        }
    });
}


//======================================== qlist ==========================================

exports.qlist = function (callback) {
    var query = "SELECT qId, firstName, email, mobile, roleOfQ, isQVerified, qStripeId, qStripeBankTokenId, qStripeBankId FROM qProvider";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};


//======================================== Update Q verification ==========================================

exports.updateStatus = function (qId, status, ipAddr, callback) {
    var q = "UPDATE qProvider SET isQVerified='" + status + "' WHERE qId='" + qId + "'";

    sql.executeSql(q, function (err, data) {
        if (!err) {
            if (data.affectedRows > 0) {
                data.message = "Q Status Updated";
                newdata = {
                    "message": "Q Status Updated",
                    "qId": qId,
                    "isActive": status
                };

                if (status == 1) {
                    var q = "SELECT * from qProvider WHERE qId='" + qId + "'";

                    sql.executeSql(q, function (err, data) {

                        if (!err) {
                            if (data.length > 0) {

                                if (data[0].qStripeId == '' || data[0].qStripeId == undefined) {

                                    var accountDetails = {
                                        "managed": true,
                                        "country": "US",
                                        "email": data[0].email,
                                        "support_phone": data[0].mobile,
                                        "tos_acceptance": {
                                            "date": Math.floor(Date.now() / 1000),
                                            "ip": ipAddr
                                        },
                                        "legal_entity": {
                                            "address": {
                                                "city": data[0].city,
                                                "country": "US",
                                                "line1": data[0].address,
                                                "postal_code": data[0].zipCode,
                                                "state": data[0].state
                                            },
                                            "dob": {
                                                "day": data[0].dateOfBirth.getDate(),
                                                "month": data[0].dateOfBirth.getMonth() + 1,
                                                "year": data[0].dateOfBirth.getFullYear(),
                                            },
                                            "first_name": data[0].firstName,
                                            "last_name": data[0].lastName,
                                            "type": "individual",
                                            "ssn_last_4": data[0].socialSecurityNo//,
                                            //"personal_id_number" : req.body.personalIdNumber
                                        }
                                    };

                                    tblStripes.createStripeAccount(qId, accountDetails, function (err, data) {

                                        if (err) {

                                            var q = "UPDATE qProvider SET isQVerified='" + 0 + "' WHERE qId='" + qId + "'";

                                            sql.executeSql(q, function (err1, data) {
                                                callback(err, data);

                                            });


                                        }
                                        else {
                                            callback(null, data);

                                        }

                                    });

                                }else{
                                    callback(null, newdata);
                                }
                            }
                        }
                        else {
                            callback(err, data);

                        }

                    });
                }else{
                    callback(null, newdata);
                }

            }
            else {
                callback(err, data);

            }
        }
        else {
            callback(err, data);

        }
    });
};

//======================================== check if Q has stripe account ==========================================
exports.checkQStripeAccount = function (qId, callback) {
    var q = 'SELECT qStripeId FROM qProvider WHERE qStripeId!="" AND qId="' + qId + '"';
    sql.executeSql(q, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        } else
            callback(err, data);
    });
};


//======================================== Q details by Id ==========================================

exports.qdetailsbyid = function (qId, callback) {
    var query = "SELECT * FROM qProvider WHERE qId='" + qId + "'";
    sql.executeSql(query, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        }
    });
};

//isQProviderVerified

//======================================== check if Q has stripe account ==========================================
exports.isQProviderVerified = function (userId, callback) {
    var q = 'SELECT isQVerified FROM qProvider WHERE userId IN (SELECT userId FROM user WHERE userId="' + userId + '")';
    sql.executeSql(q, function (err, data) {
        if (!err) {
            if (data.length > 0) {
                callback(null, data);
            }
            else {
                callback(err, data);
            }
        } else
            callback(err, data);
    });
};

//======================================== Update Q service ==========================================
exports.updateService = function (qId, service, callback) {
    var q = 'UPDATE qProvider SET roleOfQ = "'+ service +'" WHERE qId = "'+ qId +'" ';
    sql.executeSql(q, function (err, data) {
        if (!err) {
                callback(null, data);
        } else
            callback(err, data);
    });
};