exports.dbconfig = {
	host: 'localhost',
	user: 'root',
	password: 'wR0C8i885TzpU9TEb0R7',
	database: 'finalQapp',
	multipleStatements: true
}

exports.webPort = 80;
exports.path = "http://23.253.244.141/images/";
exports.JWTPrivateKey = "1234";
exports.expiresIn = 86400;  //in seconds
exports.TwilioAccountId = "ACac1adfd7285efc0563531146a9bf379f";
exports.TwilioAuthToken = "39d3aadc66471306e5aac6f5d7e4ac95";
exports.TwilioNumber = "+13107892160";
//exports.gcmSenderKey = "AIzaSyCy_tBoJyfxSNYr7zbqMTgls6VuemHAjpI";
exports.gcmSenderKey = "AIzaSyC_39FmoE40BQp2BrXvMEhD-9jPj0C_j7Q";

//exports.stripeTestSecretKey = "sk_test_W3RDD23NiW1ewcGuqBOV5YNU";
//exports.stripeTestPublishKey = "pk_test_3n5iRg9ZKnjJWXBttso6hUdA";

exports.stripeTestSecretKey = "sk_live_dF00Zt9ifyExiHQo1TiXx6Kq";
exports.stripeTestPublishKey = "pk_live_YCVUMmNTrNlVGt6lotEDUvRD";
exports.smtpConfig = {
   host: 'myqappcom.domain.com',
   port: 587,
   auth: {
       user: 'receipts@myqapp.com',
       pass: 'Qapp1234'
   },
	 tls: {
		rejectUnauthorized: false
	}
};


exports.apnConfig = {
   "gateway": "gateway.sandbox.push.apple.com",
   "cert": __dirname + "/certificate/Certificates_dev.pem",
   "key": __dirname + "/certificate/Certificates_dev_Key.pem",
   "passphrase": "QApp"
};
//POP Server: myqappcom.domain.com ( port 110 )
