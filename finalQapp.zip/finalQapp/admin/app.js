var express = require('express');
var session = require('express-session');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var routes = require('./routes/index');
var user = require('./routes/user');
var admin = require('./routes/admin');
var request = require('./routes/request');
var requestHistory = require('./routes/requestHistory');
var qProvider = require('./routes/qProvider');
var stripeRoute = require('./routes/stripe.js');
var expressJwt = require('express-jwt');
var jwt = require('jsonwebtoken');
var settings = require('./config/database');
var CronJob = require('cron').CronJob;
var tblRequest = require('./model/tblrequest.js');
var app = express();
app.use(bodyParser.urlencoded({
    extended: true
}));
app.use(bodyParser.json());
app.use(session({ secret: 'Qapp1234', cookie: { maxAge: 300000 }, resave: true, saveUninitialized: true }))
//Cron job for declining qRequests after 60 minutes
//var job = new CronJob({
//    cronTime: '59 * * * * *',
//    onTick: function () {
//        //Runs every 1 minutes
//        tblRequest.declineRequests(function (err, data) { 
//            console.log("Cleaned requests at" + new Date());
//        });
//    },
//    start: false,
//});
//job.start();

//var job1 = new CronJob({
//	cronTime: '1 * * * * *',
//	onTick: function () {
//		//Runs every 1 minutes
//		console.log("Sending Request every one second...." + new Date());
//	},
//	start: false,
//});
//job1.start();


var cron = require('cron').CronJob;
new cron('*/5 * * * * *', function () {
	//console.log('You will see this message every second ' + new Date());
	//tblRequest.resendRequest(function (err, data) { 
	
	//	console.log("resend requests at" + new Date());

	//});



}, null, true, 'America/Los_Angeles');

new cron('0 * * * * *', function () {
	//console.log('You will see this message every minute ' + new Date());

	//tblRequest.declineRequests(function (err, data) { 
 //           console.log("Cleaned requests at" + new Date());
 //       });

}, null, true, 'America/Los_Angeles');




//Session veriable declaration
var sess;
//Allow cross origin
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

var server = require('http').Server(app);
// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');


 
app.post('/APIURL', function (req, res) {
    if (req.body.qId == "" || req.body.qId == undefined) {
        return res.json(401, "please provide qId");
    }
    else {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        res.render('AdminPanel', { title: "Admin Panel", errorName: "" , errorMessage : "", errorVisibility: "none" })
    }
});

app.get('/', function (req, res) {
    sess = req.session;
    if (sess.email) {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        return res.render('AdminPanelHome.ejs', { "email": sess.email });
    }
    else {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        res.render('AdminPanel', { title: "Admin Panel", errorName: "" , errorMessage : "", errorVisibility: "none" })
    }
});

/*app.get('/admin', function (req, res) {
    sess = req.session;
    if (sess.email) {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        return res.render('AdminPanelHome.ejs', { "email": sess.email });
    }
    else {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        res.render('AdminPanel', { title: "Admin Panel", errorName: "" , errorMessage : "", errorVisibility: "none" })
    }
});
*/



// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use('/api', expressJwt({ secret: settings.JWTPrivateKey }));
app.use('/api', function(req, res, next) {
	var authorization = req.header("authorization");
	var session = JSON.parse( new Buffer((authorization.split(' ')[1]).split('.')[1], 'base64').toString());
    res.locals.session = session;
    next();
});

app.use(favicon(__dirname + '/public/static_image/logo.ico'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(require('less-middleware')(path.join(__dirname, 'public')));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/restricted', function (req, res) {
	console.log('user ' + req.user.email + ' is calling /api/restricted');
	res.json({
		name: 'foo'
	});
});


app.use('/', routes);

app.use('/api', user);
app.use('/api', request);
app.use('/api', qProvider);
app.use('/api', requestHistory);
require('./routes/register')(app);
app.use('/', stripeRoute);
app.use('/', admin);
//require('./routes/mail')(app);
String.prototype.format = function () {
   var formatted = this;
   for (var i = 0; i < arguments.length; i++) {
       var regexp = new RegExp('\\{{' + i + '\\}}', 'gi');
       formatted = formatted.replace(regexp, arguments[i]);
   }
   return formatted;
};
// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});




var qList = new Array();
var uList = new Array();

//var WebSocketServer = require('websocket').server;
//wsServer = new WebSocketServer({
//	httpServer: server,
//	// You should not use autoAcceptConnections for production 
//	// applications, as it defeats all standard cross-origin protection 
//	// facilities built into the protocol and the browser.  You should 
//	// *always* verify the connection's origin and decide whether or not 
//	// to accept it. 
//	autoAcceptConnections: false
//});

function originIsAllowed(origin) {
	// put logic here to detect whether the specified origin is allowed. 
	return true;
}

//wsServer.on('request', function (request) {
	
//	if (!originIsAllowed(request.origin)) {
//		// Make sure we only accept requests from an allowed origin 
//		request.reject();
//		console.log((new Date()) + ' Connection from origin ' + request.origin + ' rejected.');
//		return;
//	}
	
//	var connection = request.accept('echo-protocol', request.origin);
//	console.log((new Date()) + ' Connection accepted.');
//	connection.on('message', function (message) {
//		if (message.type === 'utf8') {
//			console.log('Received Message: ' + message.utf8Data);
//			var messageJson;
//			try {
//				messageJson = JSON.parse(message.utf8Data);
//				if (messageJson.type == "qidentity") {
//					qList[messageJson.qId] = connection;
//					console.log("q identity request recieved");
//				}
//				else if (messageJson.method == "uidentity") { 
//					uList[messageJson.qId] = connection;
//					console.log("user identity request recieved");
//				}
//			}
//			catch (err) { 
			
//			}

//			connection.sendUTF(message.utf8Data);
//		}
//		else if (message.type === 'binary') {
//			console.log('Received Binary Message of ' + message.binaryData.length + ' bytes');
//			connection.sendBytes(message.binaryData);
//		}
//	});
//	connection.on('close', function (reasonCode, description) {
//		console.log((new Date()) + ' Peer ' + connection.remoteAddress + ' disconnected.');
//	});
//});
//module.exports.qList = qList;
//module.exports.uList = uList;

process.on('uncaughtException', function (err) { 
	console.error(err);
});

var debug = require('debug')('QApp');
app.set('port', process.env.PORT || settings.webPort);

server.listen(app.get('port'), function () {
    debug('Express server listening on port ' + server.address().port);
});
