﻿var settings = require('../config/database');
var stripeModel = require('../model/tblstripe');
var express = require('express');
var router = express.Router();


//====================== register new stripe account ===========================

router.post('/registerqstripeaccount', function (req, res, next) {

    if (req.body.qId == null || req.body.qId == "") {
        res.send(400, { error: "Please provide qId" });
        return;
    }
    if (req.body.email == null || req.body.email == "") {
        res.send(400, { error: "Please provide email" });
        return;
    }
    if (req.body.firstName == null || req.body.firstName == "") {
        res.send(400, { error: "Please provide first name" });
        return;
    }
    if (req.body.lastName == null || req.body.lastName == "") {
        res.send(400, { error: "Please provide last name" });
        return;
    }   
    if (req.body.phonenumber == null || req.body.phonenumber == "") {
        res.send(400, { error: "Please provide phone number" });
        return;
    }
    if (req.body.streetAddress == null || req.body.streetAddress == "") {
        res.send(400, { error: "Please provide street address" });
        return;
    }
    if (req.body.city == null || req.body.city == "") {
        res.send(400, { error: "Please provide city" });
        return;
    }
    if (req.body.state == null || req.body.state == "") {
        res.send(400, { error: "Please provide state" });
        return;
    }
    
    if (req.body.postalCode == null || req.body.postalCode == "") {
        res.send(400, { error: "Please provide postal code" });
        return;
    }
    /*if (req.body.country == null || req.body.country == "") {
        res.send(400, { error: "Please provide country" });
        return;
    }*/
    if (req.body.accountType == null || req.body.accountType == "") {
        res.send(400, { error: "Please provide account type" });
        return;
    }
    if (req.body.ssnlast4 == null || req.body.ssnlast4 == "") {
        res.send(400, { error: "Please provide ssn last 4 numbers" });
        return;
    }
    /*if (req.body.personalIdNumber == null || req.body.personalIdNnumber == "") {
        res.send(400, { error: "Please provide personal id number" });
        return;
    }*/
    if (req.body.dobday == null || req.body.dobday == "") {
        res.send(400, { error: "Please provide dob day" });
        return;
    }
    if (req.body.dobmonth == null || req.body.dobmonth == "") {
        res.send(400, { error: "Please provide dob month" });
        return;
    }
    if (req.body.dobyear == null || req.body.dobyear == "") {
        res.send(400, { error: "Please provide dob year" });
        return;
    }
/*    var accountDetails = {
        "managed": true,
        "country": req.body.country,
        "email": req.body.email,
        "support_phone": req.body.phonenumber,
        "tos_acceptance": {
            "date": Math.floor(Date.now() / 1000),
            "ip": res.connection.remoteAddress
        };
*/
    var accountDetails = {
        "managed": true,
        "country": "US",
        "email": req.body.email,
        "support_phone": req.body.phonenumber,
        "tos_acceptance": {
            "date": Math.floor(Date.now() / 1000),
            "ip": res.connection.remoteAddress
        },
        "legal_entity": {
            "address": {
                "city": req.body.city,
                "country": "US",
                "line1": req.body.streetAddress,
                "postal_code": req.body.postalCode,
                "state": req.body.state
            },
            "dob": {
                "day": req.body.dobday,
                "month": req.body.dobmonth,
                "year": req.body.dobyear
            },
            "first_name": req.body.firstName,
            "last_name": req.body.lastName,
            "type": req.body.accountType,
            "ssn_last_4" : req.body.ssnlast4//,
            //"personal_id_number" : req.body.personalIdNumber
        }
    };

    stripeModel.createStripeAccount(req.body.qId, accountDetails, function (err, data) {
        if (err) {
            res.json(412, err.message);
            return;
        }
        else {
            res.json(200, data);
            return;
        }
    });
});

//====================== create new stripe account ===========================

router.post('/createstripebankaccounttoken', function (req, res, next) {

    if (req.body.qId == null || req.body.qId == "") {
        res.send(400, { error: "Please provide qId" });
        return;
    }
    /*if (req.body.country == null || req.body.country == "") {
        res.send(400, { error: "Please provide country" });
        return;
    }
    if (req.body.currency == null || req.body.currency == "") {
        res.send(400, { error: "Please provide currency standard" });
        return;
    }*/
    if (req.body.accountHolderName == null || req.body.accountHolderName == "") {
        res.send(400, { error: "Please provide account holder name" });
        return;
    }
    if (req.body.accountHolderType == null || req.body.accountHolderType == "") {
        res.send(400, { error: "Please provide account holder type" });
        return;
    }
    if (req.body.routingNumber == null || req.body.routingNumber == "") {
        res.send(400, { error: "Please provide routing number" });
        return;
    }
    if (req.body.accountNumber == null || req.body.accountNumber == "") {
        res.send(400, { error: "Please provide account number" });
        return;
    }
    var tokenDetails = {
        bank_account: {
            country: "US",
            currency: "usd",
            account_holder_name: req.body.accountHolderName,//optional
            account_holder_type: req.body.accountHolderType ,//optional
            routing_number: req.body.routingNumber,//optional
            account_number: req.body.accountNumber
        }
    };
    
    stripeModel.stripeBankAccountToken(req.body.qId, tokenDetails, function (err, data) {
        if (err) {
            res.json(412, err.message);
            return;
        }
        else {
            res.json(200, data);
            return;
        }
    });
});


//====================== link stripe account and bank token from qId ===========================
router.post('/createExternalAccount', function (req, res, next) {

    if (req.body.qId == null || req.body.qId == "") {
        res.send(400, { error: "Please provide qId" });
        return;
    }
    stripeModel.createqExternalAccount(req.body.qId, function (err, data) {
        if (err) {
            
            if (err.message.split(":")[0] == "You cannot use a Stripe token more than once") {
                res.json(299, "Account already linked");
                return;
            }
            else {
                res.json(412, err.message);
                return;           
            }
        }
        else {
            res.json(200, data);
            return;
        }
    });
});

//http://192.168.200.93:1337/stripewebhook

router.post('/stripewebhook', function (req, res, next) {
    //TODO validate req.body.username and req.body.password
    //if is invalid, return HTTP status as 401
    var j;
    console.log("called webhook");
});


module.exports = router;