var multer = require('multer');
var express = require('express');
var path = require('path');
var router = express.Router();
var expressJwt = require('express-jwt');
var jwt = require('jsonwebtoken');
var settings = require('./../config/database');
var mail = require('../model/mail.js');
var random;
var request = require('../model/tblrequest.js');

//================================================== Qrequest ====================================

router.post('/qRequest', function (req, res, next) {
    var session = res.locals.session;
    if (req.body.isTranport == "" || req.body.curLat == "" || req.body.curLong == "" || req.body.verb == "" || req.body.noun == "" || req.body.time == "" || req.body.price == "") {
        res.json({ status: '0', msg: 'please fill data' });
        return;
    }
    if (req.body.isTranport == 0) {
        var date = req.body.requiredDate;
        var requiredDate = date.replace("/", "-");
        request.qRequestElse(session.id, req.body.curLat, req.body.curLong, req.body.verb, req.body.noun, req.body.time, req.body.price, req.body.isRequireNow, requiredDate, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'error' });
                return;
            }
            else {
                res.json({ status: '1', msg: 'Request done successfully', requestId: data[3][0]['@QrequestId'] });
                return;
            }
        });
    }
    else {
        request.qRequestTranport(session.id, req.body.curLat, req.body.curLong, req.body.verb, req.body.noun, req.body.time, req.body.price, req.body.numOfStop, req.body.stops, function (err, data) {
            if (err) {
                res.json({ status: '0', msg: 'error' });
                return;
            }
            else {
                res.json({ status: '1', msg: 'Request done successfully', requestId: data[3][0]['@QrequestId'] });
                return;
            }
        });
    }
});

//======================================= Show request =====================================

router.post('/showRequest', function (req, res, next) {
    var path = settings.path, qBankAccountNumber = "";
    if (req.body.requestId == "" || req.body.requestId == null) {
        res.json({ status: '0', msg: 'please set requset id' });
        return;
    }
    request.showRequest(req.body.requestId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in sql' });
            return;
        }
        else if (data[0].length > 0) {
            var profilePic = path.concat(data[0][0].userProfile);
            if (data[2].length > 0) {
                qBankAccountNumber = data[2][0].qBankAccountNumber;
            }
            if (data[0][0].isTransport == 1) {
                var stop = [];
                for (var i = 0; i < data[0].length; i++) {
                    stop[i] = {
                        "Lat": data[0][i].stopLat,
                        "Long": data[0][i].stopLong,
                        "Address": data[0][i].address
                    };
                }
                var request = {
                    "userId": data[0][0].userId,
                    "isTransport": data[0][0].isTransport.toString(),
                    "requestStatus": data[0][0].requestStatus,
                    "requestVerb": data[0][0].requestVerb,
                    "requestNoun": data[0][0].requestNoun,
                    "currentLat": data[0][0].currentLat.toString(),
                    "currentLong": data[0][0].currentLong.toString(),
                    "qRequiredTime_Hr": data[0][0].qRequiredTime_Hr,
                    "qRequiredPayment": data[0][0].qRequiredPayment,
                    "numberOfStops": data[0][0].numberOfStops.toString(),
                    "createdDate": data[0][0].createdDate,
                    "firstName": data[0][0].firstName,
                    "lastName": data[0][0].lastName,
                    "email": data[0][0].email,
                    "mobile": data[0][0].mobile,
                    "userProfile": profilePic,
                    "stops": stop,
                    "billDetails": data[1],
                    "qBankAccountNumber": qBankAccountNumber
                };
                res.json({ status: '1', request: request });
                return;
            }
            else {
                if (data[0].qRequiredDate != '0000-00-00') {
                    var date = data[0][0].qRequiredDate + "";
                    var train_date = date.split(" ");
                    data[0][0].qRequiredDate = train_date[2] + " " + train_date[1] + " " + train_date[3];
                }
                var isTranport = data[0][0].isTransport.toString();
                data[0][0].isTransport = isTranport;
                var currentLat = data[0][0].currentLat.toString();
                data[0][0].currentLat = currentLat;
                var currentLong = data[0][0].currentLong.toString();
                data[0][0].currentLong = currentLong;
                var isRequireNow = data[0][0].isRequiredNow.toString();
                data[0][0].isRequiredNow = isRequireNow;
                data[0][0].userProfile = profilePic;
                data[0][0].billDetails = data[1];
                data[0][0].qBankAccountNumber = qBankAccountNumber;
                res.json({ status: '1', request: data[0][0] });
                return;
            }
        }
        else {
            res.json({ status: '0', msg: 'no data found for this request' });
            return;
        }

    });
});

//======================================= request accept =====================================

router.post('/requestAccept', function (req, res, next) {
    if (req.body.requestId == "" || req.body.requestId == undefined || req.body.qId == "" || req.body.qId == undefined) {
        res.json({ status: '0', msg: 'please provie requset id and qId' });
        return;
    }
    request.requestAccept(req.body.requestId, req.body.qId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in accept request' });
            return;
        }
        else if (data[0][0].msg == 'already accepted') {
            res.json({ status: '2', msg: 'Sorry, Request already accepted' });
            return;
        }
        else if (data[0][0].msg == 'request canceled') {
            res.json({ status: '2', msg: 'Sorry, Request was canceled by user' });
            return;
        }
        else {
            res.json({ status: '1', msg: 'You have accept request successfully' });
            return;
        }
    });
});

//========================================== Q request Completed Confiramtion ==========================================

router.post('/setqRequestConfirmation', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.qRequestId == undefined) {
        res.json({ status: '0', msg: 'please enter qId' });
        return;
    }
    if (req.body.userType == "" || req.body.userType == undefined) {
        res.json({ status: '0', msg: 'please enter userType' });
        return;
    }
    request.setIsConfirmed(req.body.qRequestId, req.body.userType, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in reporting issue' });
            return;
        }
        else if (data[0].length == 0) {
            res.json({ status: '0', msg: 'error in reporting issue' });
            return;
        }
        else if (data[0].length > 0) {
            var heading = "Receipt/Document Uploaded: ";
            var imageList = "", transportDetails = "";
            if (data[0][0].billImage != null) {
                for (var i = 0; i < data[0].length; i++) {
                    imageList += "<img border='0' src='http://23.253.244.141/images/" + data[0][i].billImage + "' style='max-width:500px; ' /><br />";
                }
            }
            else {
                var heading = ""
                var imageList = "";
            }
            if (false) {
                transportDetails = "<tr>data[0][0].milesTransported</tr>";
            }
            mail.sendEmailComplete(data[0][0].email, data[0][0].u_name, data[0][0].requestVerb, data[0][0].requestNoun, data[0][0].firstName, data[0][0].lastName, data[0][0].receiptTotalBill, heading, imageList, transportDetails, function (err, data) {
                if (err) {
                    res.json({ status: '0', msg: 'mail is not send' });
                    return;
                }
                else {
                    res.json({ status: '1', msg: 'Request confirmed successfully' });
                    return;
                }
            });
        }
    });
});

//========================================== receipt upload ==========================================

var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/images/')
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + path.extname(file.originalname)) //Appending extensiom
    }
});

var upload = multer({ storage: storage });
router.post('/receiptUpload', upload.single('billImage'), function (req, res, next) {
    
    if (req.file == "" || req.file == undefined) {
        res.json({ status: '0', msg: 'please provide image' });
        return;
    }
    if (req.body.qRequestId == "" || req.body.qRequestId == undefined) {
        res.json({ status: '0', msg: 'please provide requestId' });
        return;
    }
    if (req.body.billAmount == "" || req.body.billAmount == undefined) {
        res.json({ status: '0', msg: 'please provide billAmount' });
        return;
    }
    request.receiptUpload(req.body.qRequestId, req.file.filename, req.body.billAmount, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in receipt upload' });
            return;
        }
        else {
            res.json({ status: '1', msg: 'Receipt uploaded successfully' });
            return;
        }
    });
});

//========================================== Q request miles transported Bill ==========================================

router.post('/setMilesTransported', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.qRequestId == undefined) {
        res.json({ status: '0', msg : 'please provide qRequestId' });
        return;
    }
    if (req.body.milesTransported == "" || req.body.milesTransported == undefined) {
        res.json({ status: '0', msg : 'please provide milesTransported' });
        return;
    }
    request.setMilesTransported(req.body.qRequestId, req.body.milesTransported, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in updating miles transported' });
            return;
        }
        else {
            if (data.changedRows == 0 || data.affectedRows == 0) {
                res.json({ status: '0', msg: 'No request matched in records' });
                return;
            } else {
                res.json({ status: '1', msg: 'Request milesTransported updated successfully' });
                return;
            }
        }
    });
});

//========================================== change status of stop ==========================================

router.post('/reachedAtStop', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.Lat == "" || req.body.Long == "" || req.body.Lat == undefined || req.body.Long == undefined || req.body.qRequestId == undefined) {
        res.json({ status: '0', msg: 'please provide qRequestId and Lat Long' });
        return;
    }
    request.changeStatusOfStop(req.body.qRequestId, req.body.Lat, req.body.Long, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in change status' });
            return;
        }
        else if (data.length > 0) {
            var msg = "Q is reached at stop '" + data[0][0].address + "'";
            mail.twilioSendMsg(data[1][0].mobile, msg, function (err, data) {
                if (err) {
                    console.log(err);
                }
                else {
                    console.log(data);
                }
            });
            res.json({ status: '1', msg: 'updated successfully' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'problem in change status please try again' });
            return;
        }
    });
});

//========================================== total completed stops ==========================================

router.post('/totalCompletedStop', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.qRequestId == undefined) {
        res.json({ status: '0', msg: 'please provide qRequestId' });
        return;
    }
    request.totalCompletedStop(req.body.qRequestId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in change status' });
            return;
        }
        else if (data.length > 0) {
            res.json({ status: '1', stop: data });
            return;
        }
        else {
            res.json({ status: '0', msg: 'no data found' });
            return;
        }
    });
});

//============================================== cancel request ===================================================

router.post('/cancelRequest', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.qRequestId == undefined) {
        res.json({ status: '0', msg: 'please provide qRequestId' });
        return;
    }
    request.cancelRequest(req.body.qRequestId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in change status' });
            return;
        }
        else if (data[0][0].msg == 'canceled') {
            res.json({ status: '1', msg: 'Cancel Request successfully' });
            return;
        }
        else if (data[0][0].msg == 'cant cancel') {
            res.json({ status: '0', msg: 'Sorry, Your request was accepted more than 3 minute ago. Therefore, You can not cancel this request' });
            return;
        }
        else if (data[0][0].msg == 'time < 180') {
            res.json({ status: '0', msg: 'Your request was accepted. Therefore, cancellation is subject to a $5 penalty as per the Terms of Service' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'no request found' });
            return;
        }
    });
});

//============================================== cancel request ===================================================

router.post('/confirmCancelRequest', function (req, res, next) {
    if (req.body.qRequestId == "" || req.body.qRequestId == undefined) {
        res.json({ status: '0', msg: 'please provide qRequestId' });
        return;
    }
    request.confirmCancelRequest(req.body.qRequestId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error in change status' });
            return;
        }
		else if (data[0][0].msg == 'canceled') {
			
			// Charge the card for penalty $5

			
			res.json({ status: '1', msg: 'Cancel Request successfully' });
            return;
        }
        else {
            res.json({ status: '0', msg: 'sorry, you can not cancel this request' });
            return;
        }
    });
});
module.exports = router;
