var express = require('express');
var router = express.Router();
var tblqProviderModel = require('../model/tblprovider.js');
var tblUserModel = require('../model/tbluser');

router.get('/AdminDashBoard', function (req, res) {
    sess = req.session;
    if (sess.email) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('AdminPanelHome.ejs', { "email": sess.email });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" })
    }
});

router.get('/AdminPanel', function (req, res) {
    if (req.session) {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        return res.render('AdminPanelHome.ejs', { "email": sess.email });
    } else {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        res.render('AdminPanel', { title: "Admin Panel", errorName: "" , errorMessage : "", errorVisibility: "none" })
    }
});

router.get('/QList', function (req, res) {
    sess = req.session;
    if (sess.email) {
        tblqProviderModel.qlist(function (err, qlist) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('QList', { QList: qlist })
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" })
    }
});

//QUpdate
router.post('/QUpdate', function (req, res) {
    sess = req.session;
    if (sess.id) {
		
		tblqProviderModel.updateStatus(req.body.qId, req.body.isActive, res.connection.remoteAddress, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else { 
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" })
    }
});


router.post('/QUpdateService', function (req, res) {
    sess = req.session;
    if (sess.id) {

		tblqProviderModel.updateService(req.body.qId, req.body.service, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" })
    }
});


//UpdateUserStatus
router.post('/userUpdateStatus', function (req, res) {
    sess = req.session;
    if (sess.id) {

		tblUserModel.updateAccountStatus(req.body.userId, req.body.isActive, function (err, data) {
			if (!err) {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(200, data)
			} else {
				res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
				return res.json(422, err);
			}
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" })
    }
});


//GetUsersList
router.get('/usersList', function (req, res) {
    sess = req.session;
    if (sess.email) {
        tblUserModel.getUsersList(function (err, usersList) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.render('Users', { userList: usersList })
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" })
    }
});


//checkQStripeAccount
router.post('/checkQStripeAccount', function (req, res) {
    sess = req.session;
    if (sess.email) {
        tblqProviderModel.checkQStripeAccount(req.body.qId, function (err, qlist) {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            return res.send({ QList: qlist })
        });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in", errorMessage: "Please login first to view page", errorVisibility: "normal" })
    }
});

//==============================q Details=============================================

router.post('/getDetailsOfQ', function (req, res, next) {
    if (req.body.qId == "" || req.body.qId == null) {
        res.json(400, { error : 'please provide qId' });
        return;
    }
    tblqProviderModel.qdetailsbyid(req.body.qId, function (err, data) {
        if (err) {
            res.json({ status: '0', msg: 'error' });
            return;
        }
        else {
            res.json(200, data);
            return;
        }
    });
});

//logout
router.get('/logout', function (req, res) {
    req.session.destroy(function (err) {
        if (err)
            console.log(err);
        else
            res.redirect('/');
    });
});
//Rendering views done

router.get('/*', function (req, res) {
    sess = req.session;
    if (sess.email) {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        return res.render('AdminPanelHome.ejs', { "email": sess.email });
    }
    else {
        res.render('AdminPanel', { title: "Admin Panel", errorName: "Not Logged in" , errorMessage : "Please login first to view page", errorVisibility: "normal" })
    }
});
module.exports = router;
